import { Investment, Investments } from './pano-investments-overview.interface';

export const MOCK_FULLY_ALLOCATED_LIFESTAGE: Investments = {
  investments: [
    {
      allocationPercentage: 100,
      apirCode: 'BTA0288AU',
      fundName: '1940s Lifestage',
      balance: 10000
    }
  ]
};

export const MOCK_PARTIALLY_ALLOCATED_LIFESTAGE: Investments = {
  investments: [
    {
      allocationPercentage: 40,
      apirCode: 'BTA9281AU',
      fundName: 'APN AREIT',
      balance: 4000
    },
    {
      allocationPercentage: 60,
      apirCode: 'BTA0288AU',
      fundName: '1940s Lifestage',
      balance: 6000
    }
  ]
};

export const MOCK_NO_BALANCE_LIFESTAGE: Investments = {
  investments: [
    {
      allocationPercentage: 100,
      apirCode: 'BTA0288AU',
      fundName: '1940s Lifestage',
      balance: 0
    }
  ]
};

export const MOCK_NO_LIFESTAGE: Investments = {
  investments: [
    {
      allocationPercentage: 100,
      apirCode: 'BTA9281AU',
      fundName: 'APN AREIT',
      balance: 10000
    }
  ]
};

export const MOCK_INVESTMENT: Investment = {
  allocationPercentage: 100,
  apirCode: 'BTA0288AU',
  fundName: '1940s Lifestage',
  balance: 10000
};
