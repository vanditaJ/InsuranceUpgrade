import { Component, Input, OnInit } from '@angular/core';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';
import { StateParams } from '@upgrade/upgrade.services';
import { find, includes } from 'lodash';

import { CUSTOMER_TYPE_BT_SUPER_LIFETIME } from '../../pano-insurance.constants';
import { InsurancePolicy } from '../../pano-insurance.interface';

import {
  ADDITIONAL_INFORMATION_BOOKLET_LABEL,
  BT_SUPER_LIFETIME_INSURANCE_GUIDE_URL,
  CONSOLIDATION_FORM_LABEL,
  EXPANSION_ICON,
  HEADING_TEXT,
  INSURANCE_GUIDE_LABEL,
  INSURANCE_LINKS,
  OCCUPATION_CATEGORY_INFO_BTSFL,
  OCCUPATION_CATEGORY_INFO_GENERIC,
  OCCUPATION_CATEGORY_INFO_TITLE,
  SUB_HEADING_TEXT,
  TAKEOVER_FORM_LABEL,
  TRANSFER_FORM_LABEL,
  TRANSFER_INSURANCE_TITLE
} from './pano-insurance-links.constants';
import { InsuranceLink } from './pano-insurance-links.interface';

@Component({
  selector: 'pano-insurance-links',
  templateUrl: './pano-insurance-links.component.html'
})
export class PanoInsuranceLinksComponent implements OnInit {
  @Input() policies: InsurancePolicy[];
  @Input() account: Account;

  subHeadingLink: Link;
  insuranceLinks: InsuranceLink[] = INSURANCE_LINKS;
  activeLinks: InsuranceLink[];

  readonly heading: string = HEADING_TEXT;
  readonly subHeading: string = SUB_HEADING_TEXT;
  readonly expansionIcon: Icon = EXPANSION_ICON;

  constructor(private readonly linkService: PanoSuperLinkService, private stateParams: StateParams) {}

  ngOnInit(): void {
    this.configureLinks();
  }

  configureLinks(): void {
    const accountId = this.stateParams.accountId;

    this.subHeadingLink = this.linkService.getLink(LinkType.INSURANCE_COVER_TYPES, accountId, this.account);

    this.insuranceLinks.forEach(insuranceLink => {
      if (insuranceLink.linkType) {
        insuranceLink.link = this.linkService.getLink(insuranceLink.linkType, accountId, this.account);

        if (insuranceLink.title === OCCUPATION_CATEGORY_INFO_TITLE) {
          this.configureOccupationCategoryInfoLink(insuranceLink);
        }

        if (insuranceLink.title === TRANSFER_INSURANCE_TITLE) {
          this.configureTransferInsuranceLink(insuranceLink);
        }
      }
    });

    this.activeLinks =
      this.policies.length > 0
        ? this.insuranceLinks.filter(insuranceLink => this.showInsuranceLink(insuranceLink))
        : this.insuranceLinks;
  }

  configureOccupationCategoryInfoLink(insuranceLink: InsuranceLink): void {
    insuranceLink.content =
      this.account.product.productSubType === 'CORPORATE_SUPER' || this.isWgp()
        ? insuranceLink.content.replace('{information}', OCCUPATION_CATEGORY_INFO_GENERIC)
        : insuranceLink.content.replace('{information}', OCCUPATION_CATEGORY_INFO_BTSFL);

    if (this.account.product.productSubType === 'CORPORATE_SUPER') {
      this.setLinkLabel(insuranceLink.link, INSURANCE_GUIDE_LABEL);

      // Override link if the member holds any lifetime cover
      if (this.policies.filter(policy => policy.customerType === CUSTOMER_TYPE_BT_SUPER_LIFETIME).length > 0) {
        insuranceLink.link.link = BT_SUPER_LIFETIME_INSURANCE_GUIDE_URL;
      }
    } else {
      this.setLinkLabel(insuranceLink.link, ADDITIONAL_INFORMATION_BOOKLET_LABEL);
    }
  }

  configureTransferInsuranceLink(insuranceLink: InsuranceLink): void {
    if (this.isWgp()) {
      this.setLinkLabel(insuranceLink.link, TRANSFER_FORM_LABEL);
    } else if (this.account.product.productSubType === 'CORPORATE_SUPER') {
      this.setLinkLabel(insuranceLink.link, CONSOLIDATION_FORM_LABEL);
    } else {
      this.setLinkLabel(insuranceLink.link, TAKEOVER_FORM_LABEL);
    }
  }

  showInsuranceLink(insuranceLink: InsuranceLink): boolean {
    return insuranceLink.applicableNote
      ? find(this.policies, insurance => includes(insurance.applicableNotes, insuranceLink.applicableNote))
      : true;
  }

  setLinkLabel(link: Link, label: string): void {
    link.label = label;
    link.a11yProps.ariaLabel = link.a11yProps.ariaLabel.replace('{label}', label);
  }

  isWgp(): boolean {
    return this.account.pdsStatus === 'WGP_CURRENT' || this.account.pdsStatus === 'WGP_CEASED';
  }
}
