export interface AemContent {
  details: AemFragment[];
}

export interface AemFragment {
  type: string;
  id: string;
  data: {
    headerText: string;
    description: string;
  };
}
