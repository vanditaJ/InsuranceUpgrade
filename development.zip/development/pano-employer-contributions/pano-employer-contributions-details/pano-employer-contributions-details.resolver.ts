import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { Account } from './pano-employer-contributions-details.interfaces';

export function panoEmployerContributionsDetailsResolver($transition$): Promise<Account> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const accountId = accountService.getAccountId();

  return accountService.getAccount(accountId).catch(() =>
    $transition$
      .injector()
      .get('$state')
      .go('app.investor.account.systemError', { accountId })
  );
}
