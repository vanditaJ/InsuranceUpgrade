import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

@Component({
  selector: 'pano-content-dialog',
  templateUrl: './pano-content-dialog.component.html'
})
export class PanoContentDialogComponent {
  constructor(
    public readonly dialogRef: MatDialogRef<PanoContentDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      headerText: string;
      descriptionText: string;
      closeButton: Button;
      closeIcon: Button;
    }
  ) {}

  closeDialog(): void {
    this.dialogRef.close();
  }
}
