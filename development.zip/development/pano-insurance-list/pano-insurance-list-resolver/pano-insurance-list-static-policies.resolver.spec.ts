
import { PanoInsuranceListService } from '../pano-insurance-list.service';

import { panoInsuranceListStaticPoliciesResolver } from '../pano-insurance-list-resolver/pano-insurance-list-static-policies-resolver';
import { MOCK_STATIC_POLICIES } from '../pano-insurance-list.constants.spec';
import { of } from 'rxjs';

describe('panoInsuranceListStaticPoliciesResolver', () => {

  let panoInsuranceServiceSpyObj: jasmine.SpyObj<PanoInsuranceListService>;
  let transition;

  const getObj: any = { get: () => {} };

  beforeEach(() => {
    panoInsuranceServiceSpyObj = jasmine.createSpyObj('PanoInsuranceListService', ['getStaticPolicyData']);
    transition = {
      injector: () => getObj
    };
    
  });

  it('calls panoInsuranceListStaticPoliciesResolver method', async () => {
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');
    getSpy.withArgs(PanoInsuranceListService).and.returnValue(panoInsuranceServiceSpyObj);

    panoInsuranceServiceSpyObj.getStaticPolicyData.and.returnValues(of([ MOCK_STATIC_POLICIES ]));  
    const promise = panoInsuranceListStaticPoliciesResolver(transition);  
    const policies = await promise;  
    expect(policies).toEqual([  MOCK_STATIC_POLICIES ]);

  });
});
