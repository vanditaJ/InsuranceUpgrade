import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DIALOG_CONFIG } from '@bt/components/common';
import { CopyMatrixPipe, CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataModule, DataService } from '@bt/services/data';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { UIRouter } from '@uirouter/core';
import {
  PanoUpgradeAccountService,
  PanoUpgradeClientInfoService,
  PanoUpgradePermissionService,
  StateParams
} from '@upgrade/upgrade.services';
import { of } from 'rxjs';

import { PanoInvestmentOverviewInfoDialogComponent } from './pano-investment-overview-info-dialoq/pano-investment-overview-info-dialog.component';
import { PanoInvestmentsOverviewVideoModalComponent } from './pano-investments-overview-video-modal/pano-investments-overview-video-modal.component';
import { PanoInvestmentsOverviewComponent } from './pano-investments-overview.component';
import { CMS_CONTENT_KEYS, VIDEO_MODAL_DIALOG_CONFIG } from './pano-investments-overview.constants';
import {
  MOCK_FULLY_ALLOCATED_LIFESTAGE,
  MOCK_NO_BALANCE_LIFESTAGE,
  MOCK_NO_LIFESTAGE,
  MOCK_PARTIALLY_ALLOCATED_LIFESTAGE
} from './pano-investments-overview.constants.spec';
import { CmsContent, InvestmentAllocation, PersonalRateOfReturn } from './pano-investments-overview.interface';
import { PanoInvestmentsOverviewService } from './pano-investments-overview.service';

describe('PanoInvestmentsOverviewComponent', () => {
  let component: PanoInvestmentsOverviewComponent;
  let fixture: ComponentFixture<PanoInvestmentsOverviewComponent>;
  let investmentsOverviewService: PanoInvestmentsOverviewService;
  let currentInvestmentsSpy;

  let dataService: DataService<any>;

  const BT_SUPER_ACCOUNT: Account = {
    accountName: 'accountName',
    accountNumber: '1234eLM0',
    firstMoneyReceivedDate: '',
    product: { productSubType: 'CORPORATE_SUPER' },
    key: { accountId: '1234eLMO' },
    pdsStatus: 'WGP_CURRENT'
  };

  const PERSONAL_RATE_OF_RETURN: PersonalRateOfReturn = {
    apirCode: 'BT888AU',
    rateOfReturn: 10.52,
    investmentOptionName: '1980s Lifestage',
    startDate: '2021-01-01',
    endDate: '2021-07-01'
  };

  const COMMON_CMS_CONTENT: Partial<CmsContent> = {
    details: [
      {
        id: 'asdf',
        data: {
          description: '<p>whereYourMoneyIsInvestedPanelImage</p>',
          headerText: 'whereYourMoneyIsInvestedPanelImage'
        }
      },
      {
        id: 'asdf',
        data: {
          description: '<p>12</p>',
          headerText: 'performanceComparisonWgpFundRate'
        }
      },
      {
        id: 'asdf',
        data: {
          description: '<p>super happy</p>',
          headerText: 'areYouHappyYesIam'
        }
      },
      {
        id: 'asdf',
        data: {
          description: '<p>super happy</p>',
          headerText: 'videoIframe'
        }
      },
      {
        id: 'asdf',
        data: {
          description: 'ror heading',
          headerText: 'howRateOfReturnCalculatedHeading'
        }
      },
      {
        id: 'asdf',
        data: {
          description: 'ror body',
          headerText: 'howRateOfReturnCalculatedBody'
        }
      },
      {
        id: 'asdf',
        data: {
          description: 'video iframe',
          headerText: 'videoIframe'
        }
      },
      {
        id: 'asdf',
        data: {
          description: '24',
          headerText: 'performanceRate1WGPValue'
        }
      },
      {
        id: 'asdf',
        data: {
          description: '14',
          headerText: 'performanceRate2WGPValue'
        }
      }
    ]
  };
  const INVESTMENT_ALLOCATIONS: InvestmentAllocation[] = [
    {
      allocation: '12.33',
      name: 'BHP Limited'
    }
  ];

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy()
    }
  };

  const mockClientInfo = {
    send: jasmine.createSpy()
  };

  const mockInvestment = {
    allocationPercentage: 100,
    apirCode: 'BTA0288AU',
    fundName: '1940s Lifestage',
    balance: 10000
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInvestmentsOverviewComponent],
        imports: [
          DataModule,
          HttpClientTestingModule,
          MatDialogModule,
          CopyMatrixPipeModule,
          MatTabsModule,
          NoopAnimationsModule
        ],
        providers: [
          PanoInvestmentsOverviewComponent,
          {
            provide: StateParams,
            useValue: {
              accountId: '1234eLMO'
            }
          },
          PanoInvestmentsOverviewService,
          PanoDisclaimersService,
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccount: () => BT_SUPER_ACCOUNT
            }
          },
          CopyMatrixPipe,
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradeClientInfoService, useValue: mockClientInfo },
          {
            provide: MatDialog,
            useValue: {
              open: jasmine.createSpy().and.returnValue({
                afterClosed: jasmine.createSpy().and.returnValue({ subscribe: jasmine.createSpy() })
              })
            }
          },
          {
            provide: PanoUpgradePermissionService,
            useValue: {
              hasPermission: jasmine.createSpy()
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentsOverviewComponent);
    dataService = TestBed.inject(DataService);
    investmentsOverviewService = TestBed.inject(PanoInvestmentsOverviewService);

    component = fixture.componentInstance;
    component.account = BT_SUPER_ACCOUNT;

    currentInvestmentsSpy = spyOn(investmentsOverviewService, 'getCurrentInvestments');
    currentInvestmentsSpy.and.returnValue(of(MOCK_FULLY_ALLOCATED_LIFESTAGE));

    spyOn(investmentsOverviewService, 'getPersonalRateOfReturn').and.returnValue(of(PERSONAL_RATE_OF_RETURN));
    spyOn(dataService, 'retrieve').and.returnValue(of({}));
    spyOn(investmentsOverviewService, 'getCommonCmsContent').and.returnValue(of(COMMON_CMS_CONTENT));
    spyOn(investmentsOverviewService, 'getAustralianSharesTopTenCmsContent').and.returnValue(
      of(INVESTMENT_ALLOCATIONS)
    );
    spyOn(investmentsOverviewService, 'getAustralianSectorWeights').and.returnValue(of(INVESTMENT_ALLOCATIONS));
    spyOn(investmentsOverviewService, 'getInternationalTopTen').and.returnValue(of(INVESTMENT_ALLOCATIONS));
    spyOn(investmentsOverviewService, 'getInternationalRegionWeights').and.returnValue(of(INVESTMENT_ALLOCATIONS));
    spyOn(investmentsOverviewService, 'logActivity');
    spyOn(investmentsOverviewService, 'navigateAndLog');
  });

  afterEach(() => currentInvestmentsSpy.calls.reset());

  describe('Component', () => {
    describe('Lifestage fund selection', () => {
      it('should populate investment for fully allocated lifestage fund', () => {
        currentInvestmentsSpy.and.returnValue(of(MOCK_FULLY_ALLOCATED_LIFESTAGE));
        component.ngOnInit();

        expect(investmentsOverviewService.getCurrentInvestments).toHaveBeenCalled();
        expect(component.investment).toEqual(MOCK_FULLY_ALLOCATED_LIFESTAGE.investments[0]);
      });

      it('should not populate investment for partially allocated lifestage fund', () => {
        currentInvestmentsSpy.and.returnValue(of(MOCK_PARTIALLY_ALLOCATED_LIFESTAGE));

        component.ngOnInit();

        expect(component.investment).toBeUndefined();
      });

      it('should not populate investment for lifestage fund with no balance', () => {
        currentInvestmentsSpy.and.returnValue(of(MOCK_NO_BALANCE_LIFESTAGE));

        component.ngOnInit();

        expect(component.investment).toBeUndefined();
      });

      it('should not populate investment if there is no lifestage fund', () => {
        currentInvestmentsSpy.and.returnValue(of(MOCK_NO_LIFESTAGE));

        component.ngOnInit();

        expect(component.investment).toBeUndefined();
      });
    });

    describe('BT Super account', () => {
      it('should acquire the personal rate of return', () => {
        component.ngOnInit();

        expect(investmentsOverviewService.getPersonalRateOfReturn).toHaveBeenCalled();
        expect(component.personalRateOfReturn).toEqual(PERSONAL_RATE_OF_RETURN);
      });
      it('should acquire common cms content', () => {
        component.ngOnInit();

        expect(investmentsOverviewService.getCommonCmsContent).toHaveBeenCalled();
        expect(component.cmsContent).toBeTruthy();
      });
    });
    describe('exploreInvestmentOptions', () => {
      beforeEach(() => {
        component.investment = mockInvestment;
        component.emulating = false;
      });
      it('should call service to log activity with correct params', () => {
        component.exploreInvestmentOptions('simple');
        expect(investmentsOverviewService.logActivity).toHaveBeenCalledWith(
          'none',
          'clicked: investment option: simple',
          'unanswered',
          'BTA0288AU',
          '1234eLM0',
          false
        );
      });
      it('should call service to log activity with correct params - emulating', () => {
        component.emulating = true;
        component.exploreInvestmentOptions('simple');
        expect(investmentsOverviewService.logActivity).toHaveBeenCalledWith(
          'none',
          'clicked: investment option: simple',
          'unanswered',
          'BTA0288AU',
          '1234eLM0',
          true
        );
      });
      it('should call service to log activity with correct params when data changes', () => {
        component.happy = 'yes';
        component.exploreInvestmentOptions('full');
        expect(investmentsOverviewService.logActivity).toHaveBeenCalledWith(
          'none',
          'clicked: investment option: full',
          'yes',
          'BTA0288AU',
          '1234eLM0',
          false
        );
      });
    });
    describe('navigateAndLog', () => {
      beforeEach(() => {
        component.investment = mockInvestment;
        component.emulating = false;
      });
      it('should call call service to log and navigate with correct params', () => {
        component.navigateAndLog('Account overview');
        expect(investmentsOverviewService.navigateAndLog).toHaveBeenCalledWith(
          'app.investor.account.overview',
          {},
          'clicked: Account overview',
          'unanswered',
          'BTA0288AU',
          '1234eLM0',
          false
        );
      });
      it('should call call service to log and navigate with correct params', () => {
        component.emulating = true;
        component.navigateAndLog('Your investments');
        expect(investmentsOverviewService.navigateAndLog).toHaveBeenCalledWith(
          'app.investor.account.investments',
          {},
          'clicked: Your investments',
          'unanswered',
          'BTA0288AU',
          '1234eLM0',
          true
        );
      });
    });
    describe('howAreTheseCalculatedClicked', () => {
      beforeEach(() => {
        component.investment = mockInvestment;
      });
      it('should call call service to log activity with correct params', () => {
        component.howAreTheseCalculatedClicked();
        expect(investmentsOverviewService.logActivity).toHaveBeenCalledWith(
          'none',
          'clicked: how are these calculated',
          'unanswered',
          'BTA0288AU',
          '1234eLM0',
          false
        );
      });
    });
    describe('navigateToChangeInvestments', () => {
      beforeEach(() => {
        component.investment = mockInvestment;
        component.emulating = false;
      });
      it('should call service to log and navigate with correct params', () => {
        component.happy = 'no';
        component.navigateToChangeInvestments();
        expect(investmentsOverviewService.navigateAndLog).toHaveBeenCalledWith(
          'app.investor.account.changeInvestments.investmentForm',
          { addNew: true },
          'clicked: change investment strategy',
          'no',
          'BTA0288AU',
          '1234eLM0',
          false
        );
      });
      it('should call service to log and navigate with correct params when emulating', () => {
        component.happy = 'no';
        component.emulating = true;
        component.navigateToChangeInvestments();
        expect(investmentsOverviewService.navigateAndLog).toHaveBeenCalledWith(
          'app.investor.account.changeInvestments.investmentForm',
          { addNew: true },
          'clicked: change investment strategy',
          'no',
          'BTA0288AU',
          '1234eLM0',
          true
        );
      });
    });
    describe('showVideoModal', () => {
      it('should do stuff', () => {
        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(true))
          })
        };
        component.happy = 'no';

        component.showVideoModal();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoInvestmentsOverviewVideoModalComponent, {
          ...VIDEO_MODAL_DIALOG_CONFIG,
          ariaLabelledBy: 'modal-title',
          data: {
            content: component.cmsContent[CMS_CONTENT_KEYS.videoIframe + 'Modal'],
            heading: component.cmsContent[CMS_CONTENT_KEYS.videoHeading]
          }
        });
        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.happy).toBe('no');
      });
    });

    describe('Rate of return calculation dialog', () => {
      it('should open dialog with properties passed', () => {
        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        const calledWith = {
          ariaLabelledBy: 'More information on how rate of return numbers are calculated',
          autoFocus: true,
          ...DIALOG_CONFIG.DEFAULT,
          data: {
            headerText: 'ror heading',
            bodyText: 'ror body'
          }
        };

        component.ngOnInit();
        component.showRorCalculationInfoDialog();
        expect((component as any).dialog.open).toHaveBeenCalledWith(
          PanoInvestmentOverviewInfoDialogComponent,
          calledWith
        );
      });
    });
  });

  describe('View', () => {
    beforeEach(() => {
      fixture.detectChanges();
      component.personalRateOfReturn = PERSONAL_RATE_OF_RETURN;
      component.cmsContent = [];
    });

    it('should show disclaimers', () => {
      expect(fixture.debugElement.query(By.css('.ts-test-date-disclaimer'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.ts-test-asset-disclaimer'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.ts-test-general-disclaimer'))).toBeTruthy();
    });

    it('should show loading spinner while fetching data', () => {
      component.loading = true;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-investments-overview'))).toBeFalsy();
    });
    it('should show page when loading complete', () => {
      component.loading = false;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).toBeFalsy();
      expect(fixture.debugElement.query(By.css('.js-test-investments-overview'))).toBeTruthy();
    });

    it('should call show rate of return info method when button link is clicked', () => {
      spyOn(component, 'showRorCalculationInfoDialog');
      fixture.debugElement
        .query(By.css('.ts-test-open-ror-calculation-dialog-button'))
        .nativeElement.dispatchEvent(new Event('btClick', null));

      expect(component.showRorCalculationInfoDialog).toHaveBeenCalled();
    });

    it('should not show sector or region weights if there is no data for them', () => {
      component.australianSectorWeights = undefined;
      component.internationalRegionWeights = undefined;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.js-test-sector-weights'))).toBeFalsy();
      expect(fixture.debugElement.query(By.css('.js-test-region-weights'))).toBeFalsy();
    });

    it('should not show sector or region weights if there is no data for them', () => {
      component.australianSectorWeights = [];
      component.internationalRegionWeights = [];
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.js-test-sector-weights'))).toBeFalsy();
      expect(fixture.debugElement.query(By.css('.js-test-region-weights'))).toBeFalsy();
    });
  });
});
