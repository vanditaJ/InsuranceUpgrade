import { Icon } from '@bt/components/icon';

import { Benefits, InsurancePolicy } from '../pano-insurance.interface';

export interface InsuranceHelpTile {
  phoneIcon: Icon;
  contactNumberText: string;
  contactDetails: string;
}

export interface PolicyAlertCondition {
  showPolicyLT90DaysAlert?: boolean;
  showPmifNotActiveGT30DaysAlert?: boolean;
  isOccupationCodeAbsent?: boolean;
}

export interface ActionMenuCondition {
  showMenuAction?: boolean;
  showChangeMenuAction?: boolean;
  showDecreaseMenuAction?: boolean;
  showIncreaseMenuAction?: boolean;
  showEyIncreaseMenuAction?: boolean;
  icon: string;
}

export interface Insurances extends InsurancePolicy, ActionMenuCondition, PolicyAlertCondition {
  occupationClass: string;
  policyStatusLabel: string;
  optInDateLabel: string;
  benefits: Benefits;
  popoverText: string;
  pdsLink: string;
  policyGT60DaysMessage?: string;
}

export interface ModalObj {
  heading: string;
  description: string;
  showContinueButton?: boolean;
}

export interface TableTitle {
  name: string;
  label?: string;
  align?: string;
  whoPays?: boolean;
  smoking?: boolean;
  optInDate?: boolean;
}

export interface InsuranceDetail {
  title: string;
  type: string;
  tableTitles: TableTitle[];
  insurances: Insurances[];
  availableTableTitles?: TableTitle[];
  totalCoverAmount?: number;
  totalPremiumAmount?: number;
  showWhoPays?: boolean;
  showSmokerStatus?: boolean;
  showDeathFootNote?: boolean;
  showPendingFootNote?: boolean;
  showInactiveFootNote?: boolean;
  showInsuranceFootNote?: boolean;
}

export interface Range {
  start: number;
  end: number;
}

export interface PoliciesInScope {
  coverSubTypeIds?: Array<number>;
  coverSubTypeIdRange?: Array<Range>;
}
