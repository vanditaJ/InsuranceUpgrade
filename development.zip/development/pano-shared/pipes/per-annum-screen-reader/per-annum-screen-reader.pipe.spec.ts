import { PerAnnumScreenReaderPipe } from './per-annum-screen-reader.pipe';

describe('Per Annum Screen Reader Pipe', () => {
  it('should create an instance', () => {
    const pipe = new PerAnnumScreenReaderPipe();
    expect(pipe).toBeTruthy();
  });

  it('should replace pa with accessibleHTML', () => {
    const pipe = new PerAnnumScreenReaderPipe();
    const content = 'Test pa';
    const expectedContent = "Test <span aria-hidden='true'>pa</span><span class='sr-only'>per annum</span>";

    const result = pipe.transform(content);
    expect(result).toEqual(expectedContent);
  });

  it('should not replace other content with accessibleHTML', () => {
    const pipe = new PerAnnumScreenReaderPipe();
    const content = 'Test p.a.';

    const result = pipe.transform(content);
    expect(result).toEqual(content);
  });
});
