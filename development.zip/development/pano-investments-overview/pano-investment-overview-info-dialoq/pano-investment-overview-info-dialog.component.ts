import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

import { CLOSE_DIALOG_BUTTON, EXIT_DIALOG_BUTTON } from './pano-investment-overview-info-dialog.constants';

@Component({
  selector: 'pano-investment-overview-info-dialog',
  templateUrl: './pano-investment-overview-info-dialog.component.html'
})
export class PanoInvestmentOverviewInfoDialogComponent {
  readonly closeButton: Button = CLOSE_DIALOG_BUTTON;
  readonly exitButton: Button = EXIT_DIALOG_BUTTON;

  constructor(
    public readonly dialogRef: MatDialogRef<PanoInvestmentOverviewInfoDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      headerText: string;
      bodyText: string;
    }
  ) {}

  close(): void {
    this.dialogRef.close();
  }
}
