import { AemContent } from '@panorama/services/cms';
import { first, get } from 'lodash-es';

export function findContentByKey(cms: Array<Partial<AemContent>>, filterType: string): string {
  return get(first(cms.filter((item: AemContent) => get(item, 'data.headerText') === filterType)), 'data.description');
}
