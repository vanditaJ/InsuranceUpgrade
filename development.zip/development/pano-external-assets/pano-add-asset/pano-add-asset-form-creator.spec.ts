import { TestBed, waitForAsync } from '@angular/core/testing';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment-timezone';

import {
  TEST_ADD_CASH_EXTERNAL_FORM,
  TEST_ADD_DP_EXTERNAL_FORM,
  TEST_ADD_ILS_EXTERNAL_FORM,
  TEST_ADD_LS_EXTERNAL_FORM,
  TEST_ADD_MF_EXTERNAL_FORM,
  TEST_ADD_MP_EXTERNAL_FORM,
  TEST_ADD_OTH_EXTERNAL_FORM,
  TEST_ADD_TD_EXTERNAL_FORM
} from '../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { assetSelectedValidator } from '../pano-external-assets-custom-validator';

import { PanoAddAssetFormCreator } from './pano-add-asset-form-creator';

describe('PanoAddAssetFormCreator ', () => {
  let panoAddAssetFormCreator: PanoAddAssetFormCreator;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        providers: [FormBuilder, PanoAddAssetFormCreator]
      });
    })
  );

  beforeEach(() => {
    panoAddAssetFormCreator = TestBed.inject(PanoAddAssetFormCreator);
  });

  describe('createAddAssetCashForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('cash');
      expect(expectedResult.get('assetClassCode').value).toEqual(
        TEST_ADD_CASH_EXTERNAL_FORM.get('assetClassCode').value
      );
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_CASH_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_CASH_EXTERNAL_FORM.get('marketValue').value);
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_CASH_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_CASH_EXTERNAL_FORM.get('source').value);
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_CASH_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
    });
  });

  describe('createAddAssetTDForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('td');
      expect(expectedResult.get('assetClassCode').value).toEqual(TEST_ADD_TD_EXTERNAL_FORM.get('assetClassCode').value);
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_TD_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_TD_EXTERNAL_FORM.get('marketValue').value);
      expect(moment(expectedResult.get('maturityDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_TD_EXTERNAL_FORM.get('maturityDate').value).format('DD MMM YYYY')
      );
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_TD_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_TD_EXTERNAL_FORM.get('source').value);
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_TD_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
    });
  });

  describe('createAddAssetLSForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('ls');
      expect(expectedResult.get('assetClassCode').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('assetClassCode').value);
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('marketValue').value);
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('source').value);
      expect(expectedResult.get('quantity').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('quantity').value);
      expect(expectedResult.get('positionCode').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('positionCode').value);
      expect(expectedResult.get('panoramaAssetDetails').value).toEqual(
        TEST_ADD_LS_EXTERNAL_FORM.get('positionCode').value
      );
      expect(expectedResult.get('assetId').value).toEqual(TEST_ADD_LS_EXTERNAL_FORM.get('positionCode').value);
      expect(expectedResult.get('isPanoramaAsset').value).toEqual(
        TEST_ADD_LS_EXTERNAL_FORM.get('isPanoramaAsset').value
      );
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_LS_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
    });
  });

  describe('createAddAssetILSForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('ils');
      expect(expectedResult.get('assetClassCode').value).toEqual(
        TEST_ADD_ILS_EXTERNAL_FORM.get('assetClassCode').value
      );
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_ILS_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_ILS_EXTERNAL_FORM.get('marketValue').value);
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_ILS_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_ILS_EXTERNAL_FORM.get('source').value);
      expect(expectedResult.get('quantity').value).toEqual(TEST_ADD_ILS_EXTERNAL_FORM.get('quantity').value);
      expect(expectedResult.get('positionCode').value).toEqual(TEST_ADD_ILS_EXTERNAL_FORM.get('positionCode').value);
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_ILS_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
    });
  });

  describe('createAddDirectPropertyForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('dp');
      expect(expectedResult.get('assetClassCode').value).toEqual(TEST_ADD_DP_EXTERNAL_FORM.get('assetClassCode').value);
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_DP_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_DP_EXTERNAL_FORM.get('marketValue').value);
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_DP_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_DP_EXTERNAL_FORM.get('source').value);
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_DP_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
      expect(expectedResult.get('propertyType').value).toEqual(TEST_ADD_DP_EXTERNAL_FORM.get('propertyType').value);
    });
  });

  describe('createAddAssetMPForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('mp');
      expect(expectedResult.get('assetClassCode').value).toEqual(TEST_ADD_MP_EXTERNAL_FORM.get('assetClassCode').value);
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_MP_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_MP_EXTERNAL_FORM.get('marketValue').value);
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_MP_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_MP_EXTERNAL_FORM.get('source').value);
      expect(expectedResult.get('positionCode').value).toEqual(TEST_ADD_MP_EXTERNAL_FORM.get('positionCode').value);
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_MP_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
    });
  });

  describe('createAddAssetMFForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('mf');
      expect(expectedResult.get('assetClassCode').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('assetClassCode').value);
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('marketValue').value);
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('source').value);
      expect(expectedResult.get('quantity').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('quantity').value);
      expect(expectedResult.get('positionCode').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('positionCode').value);
      expect(expectedResult.get('panoramaAssetDetails').value).toEqual(
        TEST_ADD_MF_EXTERNAL_FORM.get('positionCode').value
      );
      expect(expectedResult.get('assetId').value).toEqual(TEST_ADD_MF_EXTERNAL_FORM.get('positionCode').value);
      expect(expectedResult.get('isPanoramaAsset').value).toEqual(
        TEST_ADD_MF_EXTERNAL_FORM.get('isPanoramaAsset').value
      );
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_MF_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
    });
  });

  describe('createAddAssetOTHForm', () => {
    it('should add formControls in to the FormGroups FormArray', () => {
      const expectedResult = panoAddAssetFormCreator.createAddAssetForm('oth');
      expect(expectedResult.get('assetClassCode').value).toEqual(
        TEST_ADD_OTH_EXTERNAL_FORM.get('assetClassCode').value
      );
      expect(expectedResult.get('assetTypeCode').value).toEqual(TEST_ADD_OTH_EXTERNAL_FORM.get('assetTypeCode').value);
      expect(expectedResult.get('marketValue').value).toEqual(TEST_ADD_OTH_EXTERNAL_FORM.get('marketValue').value);
      expect(expectedResult.get('positionName').value).toEqual(TEST_ADD_OTH_EXTERNAL_FORM.get('positionName').value);
      expect(expectedResult.get('source').value).toEqual(TEST_ADD_OTH_EXTERNAL_FORM.get('source').value);
      expect(expectedResult.get('quantity').value).toEqual(TEST_ADD_OTH_EXTERNAL_FORM.get('quantity').value);
      expect(expectedResult.get('positionCode').value).toEqual(TEST_ADD_OTH_EXTERNAL_FORM.get('positionCode').value);
      expect(moment(expectedResult.get('valuationDate').value).format('DD MMM YYYY')).toEqual(
        moment(TEST_ADD_OTH_EXTERNAL_FORM.get('valuationDate').value).format('DD MMM YYYY')
      );
    });
  });

  describe('reAssignValidatorsForMarketValueAndValuationDate', () => {
    beforeEach(() => {
      spyOn(panoAddAssetFormCreator, 'attachDynamicValidators');
    });

    it('should call attachDynamicValidators with respective field and empty validators when enableValidator is false', () => {
      const assetDetailsFormGroup = new FormGroup({
        marketValue: new FormControl('10000', [
          Validators.required,
          Validators.min(0.01),
          Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
        ]),
        valuationDate: new FormControl(moment('2019-11-11T00:00:00.000+11:00').tz('Australia/Sydney'), [
          Validators.required
        ])
      });

      panoAddAssetFormCreator.reAssignValidatorsForMarketValueAndValuationDate(assetDetailsFormGroup, false);
      expect(panoAddAssetFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['valuationDate'],
        []
      );
      expect(panoAddAssetFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['marketValue'],
        []
      );
    });

    it('should call attachDynamicValidators with respective field and correct validators  when enableValidator is true', () => {
      const assetDetailsFormGroup = new FormGroup({
        marketValue: new FormControl('10000', [
          Validators.required,
          Validators.min(0.01),
          Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
        ]),
        valuationDate: new FormControl(moment('2019-11-11T00:00:00.000+11:00').tz('Australia/Sydney'), [
          Validators.required
        ])
      });

      panoAddAssetFormCreator.reAssignValidatorsForMarketValueAndValuationDate(assetDetailsFormGroup, true);
      expect(panoAddAssetFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['valuationDate'],
        [jasmine.any(Function) as any]
      );
      expect(panoAddAssetFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['marketValue'],
        [
          jasmine.any(Function) as any,
          jasmine.any(Function) as any,
          jasmine.any(Function) as any,
          jasmine.any(Function) as any
        ]
      );
    });
  });

  describe('reAssignValidatorsForPanoramaAssetDetails', () => {
    beforeEach(() => {
      spyOn(panoAddAssetFormCreator, 'attachDynamicValidators');
    });

    const assetDetailsFormGroup = new FormGroup({
      panoramaAssetDetails: new FormControl(null, [Validators.required, assetSelectedValidator])
    });

    it('should call attachDynamicValidators with respective field and empty validators when enableValidator is false', () => {
      panoAddAssetFormCreator.reAssignValidatorsForPanoramaAssetDetails(assetDetailsFormGroup, false);
      expect(panoAddAssetFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['panoramaAssetDetails'],
        []
      );
    });

    it('should call attachDynamicValidators with respective field and correct validators when enableValidator is true', () => {
      panoAddAssetFormCreator.reAssignValidatorsForPanoramaAssetDetails(assetDetailsFormGroup, true);
      expect(panoAddAssetFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['panoramaAssetDetails'],
        [jasmine.any(Function) as any, jasmine.any(Function) as any]
      );
    });
  });
});
