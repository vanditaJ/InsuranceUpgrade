import { Link } from '@bt/components/link';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';

export interface InsuranceLink {
  title: string;
  content: string;
  linkType?: LinkType;
  link?: Link;
  contentAfterLink?: string;
  index: number;
  applicableNote?: string;
}
