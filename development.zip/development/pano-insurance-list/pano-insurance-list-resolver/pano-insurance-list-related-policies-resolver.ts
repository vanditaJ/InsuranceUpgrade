import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { RelatedAccounts } from '../pano-insurance-list.interface';
import { PanoInsuranceListService } from '../pano-insurance-list.service';

export function panoInsuranceListRelatedPoliciesResolver($transition$): Promise<RelatedAccounts[]> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const panoInsuranceListService = $transition$.injector().get(PanoInsuranceListService);
  return panoInsuranceListService.getRelatedAccounts(accountService.getAccountId()).toPromise();
}
