export interface AemTextItem {
  data: {
    headerText: string;
    description: string;
  };
}
