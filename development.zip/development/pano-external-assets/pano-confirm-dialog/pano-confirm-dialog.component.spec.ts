import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

import {
  ACTION_CANCEL,
  ACTION_CONFIRM,
  ASSET_DELETE_CONFIRM_DESCRIPTION,
  ASSET_DELETE_CONFIRM_HEADER,
  CANCEL_DELETE_BUTTON,
  CONFIRM_DELETE_BUTTON
} from '../pano-external-assets-constants/pano-external-assets.constants';

import { PanoConfirmDialogComponent } from './pano-confirm-dialog.component';

describe('PanoConfirmDialogComponent', () => {
  let component: PanoConfirmDialogComponent;
  let fixture: ComponentFixture<PanoConfirmDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [MatDialogModule],
        declarations: [PanoConfirmDialogComponent],
        providers: [
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          {
            provide: MAT_DIALOG_DATA,
            useValue: {
              actionConfirm: ACTION_CONFIRM,
              actionCancel: ACTION_CANCEL,
              headerText: ASSET_DELETE_CONFIRM_HEADER,
              descriptionText: ASSET_DELETE_CONFIRM_DESCRIPTION,
              confirmButton: CONFIRM_DELETE_BUTTON,
              cancelButton: CANCEL_DELETE_BUTTON
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [PanoConfirmDialogComponent]
        }
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoConfirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('confirmAction()', () => {
      it('should call dialog close method with with respective action passed', () => {
        component.confirmAction(ACTION_CONFIRM);

        expect(component.dialogRef.close).toHaveBeenCalledWith(ACTION_CONFIRM);
      });
    });
  });

  describe('view', () => {
    it('should have correct header if headerText exists', () => {
      expect(fixture.debugElement.query(By.css('.js-test-pano-confirm-header')).nativeElement.innerHTML.trim()).toBe(
        ASSET_DELETE_CONFIRM_HEADER
      );
    });

    it('should have not have a header if headerText is empty', () => {
      component.data.headerText = '';
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.js-test-pano-confirm-header'))).toBeFalsy();
    });

    it('should have correct sub heading', () => {
      expect(
        fixture.debugElement.query(By.css('.js-test-pano-confirm-description')).nativeElement.innerHTML.trim()
      ).toBe(ASSET_DELETE_CONFIRM_DESCRIPTION);
    });

    describe('bt-buttons', () => {
      it('should have correct properties', () => {
        expect(fixture.debugElement.query(By.css('.js-test-pano-confirm-button-cancel')).properties.config).toEqual(
          CANCEL_DELETE_BUTTON
        );
        expect(fixture.debugElement.query(By.css('.js-test-pano-confirm-button-confirm')).properties.config).toEqual(
          CONFIRM_DELETE_BUTTON
        );
      });

      it('should call correct method when cancel button clicked', () => {
        spyOn(component, 'confirmAction');
        fixture.debugElement
          .query(By.css('.js-test-pano-confirm-button-cancel'))
          .nativeElement.dispatchEvent(new Event('btClick', null));

        expect(component.confirmAction).toHaveBeenCalledWith(ACTION_CANCEL);
      });

      it('should call correct method when confirm button clicked', () => {
        spyOn(component, 'confirmAction');
        fixture.debugElement
          .query(By.css('.js-test-pano-confirm-button-confirm'))
          .nativeElement.dispatchEvent(new Event('btClick', null));

        expect(component.confirmAction).toHaveBeenCalledWith(ACTION_CONFIRM);
      });
    });
  });
});
