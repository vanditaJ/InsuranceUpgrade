import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { Permission } from '../pano-insurance.interface';
import { PanoInsuranceService } from '../pano-insurance.service';

export function panoInsurancePermissionResolver($transition$): Promise<Permission> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const panoInsuranceService = $transition$.injector().get(PanoInsuranceService);
  return panoInsuranceService.getPermissions(accountService.getAccountId()).toPromise();
}
