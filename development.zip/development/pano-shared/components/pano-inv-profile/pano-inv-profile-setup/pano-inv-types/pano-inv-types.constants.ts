import { Alert } from '@bt/components/alert';

export const INVESTMENT_TYPES_TITLE: string = 'Which investment types are you interested in?';

export const SHARES_ETFS_ONLY_DESCRIPTION: string =
  'Includes shares, Exchange Traded Funds (ETFs) and other ASX-traded securities.';
export const ALL_INVESTMENT_TYPES_DESCRIPTION: string =
  'Includes shares and ETFs as well as managed funds, managed portfolios and term deposits.';

export const REQUIRE_INVESTMENT_TYPE_ALERT: Alert = {
  type: 'error',
  outline: true,
  inline: true,
  messages: 'Select one of the investment types.'
};
