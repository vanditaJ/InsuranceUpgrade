import { Component } from '@angular/core';
import { Loading } from '@bt/components/loading';

import { LOADING_TITLE, SAVE_PROFILE_LOADING } from './pano-inv-profile-loading.constants';

@Component({
  selector: 'pano-inv-profile-loading',
  templateUrl: './pano-inv-profile-loading.component.html'
})
export class PanoInvestmentProfileLoadingComponent {
  readonly saveProfileLoading: Loading = SAVE_PROFILE_LOADING;
  readonly loadingTitle: string = LOADING_TITLE;
}
