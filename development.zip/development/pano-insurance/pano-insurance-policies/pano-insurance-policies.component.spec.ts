import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { DIALOG_CONFIG } from '@bt/components/common';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouter } from '@uirouter/core';
import {
  PanoUpgradeAccountService,
  PanoUpgradeFeatureService,
  PanoUpgradePermissionService,
  StateParams
} from '@upgrade/upgrade.services';
import { of, throwError } from 'rxjs';

import { PanoInsuranceService } from '../pano-insurance.service';
import { PanoInsuranceUtil } from '../pano-insurance.util';

import { PanoActivateInsuranceDialogComponent } from './pano-activate-insurance-dialog/pano-activate-insurance-dialog.component';
import { PanoInsuranceExitSiteDialogComponent } from './pano-insurance-exit-site-dialog/pano-insurance-exit-site-dialog.component';
import { PanoInsurancePoliciesComponent } from './pano-insurance-policies.component';
import {
  MOCK_ACCOUNT,
  MOCK_AEM_CONTENT_POLICIES,
  MOCK_BTSFL_ACCOUNT,
  MOCK_BTS_ACCOUNT,
  MOCK_BTS_EY_ACCOUNT,
  MOCK_BTS_WGP_ACCOUNT,
  MOCK_PERMISSIONS,
  MOCK_POLICIES,
  MOCK_POLICIES_LIST,
  MOCK_VISIBLE_POLICIES_LIST
} from './pano-insurance-policies.component.constants.spec';
import {
  ACTIVATE_COVER_BUTTON,
  ACTIVATE_INFO_ALERT,
  ACTIVATE_INSURANCE_DIALOG_CONFIG,
  ACTIVATE_INSURANCE_REQUESTED_ALERT,
  BASE,
  CALCULATE_COVER_MESSAGE,
  CALCULATOR_ICON,
  DEFAULT_PAGE_LOADING,
  EMULATING,
  INACTIVITY_INFO_ALERT,
  INSURANCE,
  INSURANCE_HELP_TILE_CONTENT,
  INSURANCE_PORTAL_BUTTON,
  INSURANCE_SSO_AIA_FEATURE,
  INVESTOR_ACCOUNT_ERROR_STATE,
  INVESTOR_BTSUPER_PMIF,
  INVESTOR_GLOBAL_DISCLAIMER_BTSUPER,
  INVESTOR_INSURANCE_PYSOPTIN,
  KEEP_INSURANCE_BUTTON,
  NO_INSURANCE_ALERT,
  OCCUPATION_GUIDE_LINK,
  OPT_IN_STATUS,
  POLICIES_INFO_ALERT,
  PYS_OPT_IN_ALL_DIALOG_CONFIG,
  PYS_SUBMIT_FAIL_ALERT
} from './pano-insurance-policies.constants';
import { PanoInsurancePoliciesUtil } from './pano-insurance-policies.util';
import { MOCK_NO_OCCUPATION_CODE_POLICY } from './pano-insurance-policies.util.spec.constants';
import { PanoPysOptInAllComponent } from './pano-pys-optin-all/pano-pys-opt-in-all.component';

describe('PanoInsurancePoliciesComponent', () => {
  let component: PanoInsurancePoliciesComponent;
  let fixture: ComponentFixture<PanoInsurancePoliciesComponent>;
  let panoInsuranceService: PanoInsuranceService;
  let panoUpgradeAccountService: PanoUpgradeAccountService;
  let panoUpgradeFeatureService: PanoUpgradeFeatureService;
  let panoUpgradePermissionService: PanoUpgradePermissionService;
  let panoInsurancePoliciesUtil: PanoInsurancePoliciesUtil;

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy()
    }
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInsurancePoliciesComponent],
        imports: [
          DataModule,
          HttpClientTestingModule,
          LayoutModule,
          MatDialogModule,
          MatSnackBarModule,
          RouterTestingModule,
          PipesTestingModule
        ],
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: MatDialog, useValue: { open: jasmine.createSpy() } },
          PanoInsuranceService,
          {
            provide: PanoDisclaimersService,
            useValue: {
              evaluateDisclaimer: () => 'disclaimer'
            }
          },
          {
            provide: PanoSuperLinkService,
            useValue: {
              getUrl: () => 'https://hello'
            }
          },
          PanoInsurancePoliciesUtil,
          PanoInsuranceUtil,
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccountId: () => '1234'
            }
          },
          {
            provide: PanoUpgradeFeatureService,
            useValue: {
              hasAccess: () => true
            }
          },
          {
            provide: PanoUpgradePermissionService,
            useValue: {
              hasPermission: jasmine.createSpy()
            }
          },
          {
            provide: StateParams,
            useValue: {
              accountId: 'EncodedAccountId'
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsurancePoliciesComponent);
    component = fixture.componentInstance;
    component.cmsContent = MOCK_AEM_CONTENT_POLICIES;
    component.policies = MOCK_POLICIES_LIST;
    component.account = MOCK_BTS_ACCOUNT;
    component.insurancePermissions = MOCK_PERMISSIONS;
    panoInsuranceService = TestBed.inject(PanoInsuranceService);
    panoUpgradeFeatureService = TestBed.inject(PanoUpgradeFeatureService);
    panoUpgradeAccountService = TestBed.inject(PanoUpgradeAccountService);
    panoUpgradePermissionService = TestBed.inject(PanoUpgradePermissionService);
    panoInsurancePoliciesUtil = TestBed.inject(PanoInsurancePoliciesUtil);
    fixture.detectChanges();
  });

  describe('Component', () => {
    it('should have correct values for its properties', () => {
      expect(component.state).toBeUndefined();
      expect(component.loadingSpinner).toEqual(DEFAULT_PAGE_LOADING);
      expect(component.inactivityInfoAlert).toEqual(INACTIVITY_INFO_ALERT);
      expect(component.policiesInfoAlert).toEqual(POLICIES_INFO_ALERT);
      expect(component.noInsuranceAlert).toEqual(NO_INSURANCE_ALERT);
      expect(component.keepInsuranceButton).toEqual(KEEP_INSURANCE_BUTTON);
      expect(component.insuranceHelpTileContent).toEqual(INSURANCE_HELP_TILE_CONTENT);
      expect(component.heading).toEqual(INSURANCE);
      expect(component.calculateCoverMessage).toEqual(CALCULATE_COVER_MESSAGE);
      expect(component.activateInfoAlert).toEqual(ACTIVATE_INFO_ALERT);
      expect(component.date).toBeTruthy();
      expect(component.disclaimer).toBeTruthy();
      expect(component.occupationGuideLink).toBe(OCCUPATION_GUIDE_LINK);
    });

    describe('ngOnInit', () => {
      it('should call feature service and permission service method and set values to properties', () => {
        spyOn(panoUpgradeFeatureService, 'hasAccess').and.returnValue(true);
        spyOn(panoInsurancePoliciesUtil, 'checkActive').and.returnValue(true);
        spyOn(panoInsurancePoliciesUtil, 'pysAndPMIFOptInRequired').and.returnValue(false);
        spyOn(panoInsurancePoliciesUtil, 'pysOptInRequiredForPolicies').and.returnValue(true);
        spyOn(panoInsurancePoliciesUtil, 'pmifOptInRequiredForPolicies').and.returnValue(true);
        component.policies = MOCK_POLICIES_LIST;

        component.ngOnInit();

        expect(panoUpgradePermissionService.hasPermission).toHaveBeenCalledWith(EMULATING, BASE);
        expect(panoUpgradeFeatureService.hasAccess).toHaveBeenCalledWith(INVESTOR_INSURANCE_PYSOPTIN);
        expect(panoUpgradeFeatureService.hasAccess).toHaveBeenCalledWith(INVESTOR_GLOBAL_DISCLAIMER_BTSUPER);
        expect(panoUpgradePermissionService.hasPermission).toHaveBeenCalledWith(INSURANCE_SSO_AIA_FEATURE, BASE);
        expect(panoUpgradePermissionService.hasPermission).toHaveBeenCalledWith(
          INVESTOR_BTSUPER_PMIF,
          MOCK_BTS_ACCOUNT.accountNumber
        );
        expect(panoInsurancePoliciesUtil.checkActive).toHaveBeenCalledWith(component.policies[0]);
        expect(panoInsurancePoliciesUtil.pysAndPMIFOptInRequired).toHaveBeenCalledWith(component.policies);
        expect(panoInsurancePoliciesUtil.pysOptInRequiredForPolicies).toHaveBeenCalledWith(component.policies);
        expect(panoInsurancePoliciesUtil.pmifOptInRequiredForPolicies).toHaveBeenCalledWith(component.policies);
        expect(component.isAvailableForPysOptIn).toBe(true);
        expect(component.isAvailableForPmifPysOptIn).toBe(false);
      });

      it('should display the insurance panel if the permission is set to true ', () => {
        component.ngOnInit();
        component.showInsurancePanel();
        expect(component.displayInsurancePanel).toBe(true);
      });

      it('should filter policies and set correct values if policies were not provided', () => {
        component.policies = null;

        component.ngOnInit();

        expect(component.policies.length).toBe(0);
        expect(component.visiblePolicies.length).toBe(0);
        expect(component.hasVisiblePolicies).toBe(false);
        expect(component.hasExternalPoliciesOnly).toBe(false);
        expect(component.hasInternalAndExternalPolicies).toBe(false);
      });

      it('should filter policies and set correct values if no policies are visible', () => {
        component.policies = MOCK_POLICIES_LIST;
        component.pmifPermission = true;

        component.ngOnInit();

        expect(component.policies.length).toBe(3);
        expect(component.visiblePolicies.length).toBe(0);
        expect(component.hasVisiblePolicies).toBe(false);
        expect(component.hasExternalPoliciesOnly).toBe(false);
        expect(component.hasInternalAndExternalPolicies).toBe(false);
      });

      it('should filter policies and set correct values if policies are visible', () => {
        component.policies = MOCK_VISIBLE_POLICIES_LIST;
        component.pmifPermission = true;

        component.ngOnInit();

        expect(component.policies.length).toBe(2);
        expect(component.visiblePolicies.length).toBe(2);
        expect(component.hasVisiblePolicies).toBe(true);
        expect(component.hasExternalPoliciesOnly).toBe(false);
        expect(component.hasInternalAndExternalPolicies).toBe(true);
      });

      it('should set displayNoOccupationCodeMessage to true if policy customer type is pcs and policy is not external and not lifetime cover and occupation class is null', () => {
        spyOn(component, 'showNoOccupationCodeAlertMessage').and.returnValue(true);
        component.ngOnInit();

        expect(component.displayNoOccupationCodeMessage).toBe(true);
      });
    });

    describe('showNoOccupationCodeAlertMessage', () => {
      it('should return true if policy is suitable to show in insurance tables', () => {
        spyOn(panoInsurancePoliciesUtil, 'isPolicySuitableForNoOccupationCodeAlert').and.returnValue(true);
        const result = component.showNoOccupationCodeAlertMessage([MOCK_NO_OCCUPATION_CODE_POLICY]);

        expect(result).toBe(true);
      });

      it('should return false if policy is not suitable to show in insurance tables', () => {
        spyOn(panoInsurancePoliciesUtil, 'isPolicySuitableForNoOccupationCodeAlert').and.returnValue(false);
        const result = component.showNoOccupationCodeAlertMessage([MOCK_NO_OCCUPATION_CODE_POLICY]);

        expect(result).toBe(false);
      });
    });

    describe('showInsuranceTiles', () => {
      it('should set displayInsuranceTiles to false if linked to EY employer and has no active policies', () => {
        component.account = MOCK_BTS_EY_ACCOUNT;
        component.hasExternalPoliciesOnly = false;
        fixture.detectChanges();

        component.showInsuranceTiles(false);

        expect(component.displayInsuranceTiles).toBe(false);
      });

      it('should set displayInsuranceTiles to false if linked to EY employer and has only external policies', () => {
        component.account = MOCK_BTS_EY_ACCOUNT;
        component.hasExternalPoliciesOnly = true;
        fixture.detectChanges();

        component.showInsuranceTiles(true);

        expect(component.displayInsuranceTiles).toBe(false);
      });

      it('should set displayInsuranceTiles to true if linked to EY employer and has internal policies', () => {
        component.account = MOCK_BTS_EY_ACCOUNT;
        component.hasExternalPoliciesOnly = false;
        fixture.detectChanges();

        component.showInsuranceTiles(true);

        expect(component.displayInsuranceTiles).toBe(true);
      });

      it('should set displayInsuranceTiles to true if not linked to EY employer and has no active policies', () => {
        component.account = MOCK_BTS_ACCOUNT;
        component.hasExternalPoliciesOnly = false;
        fixture.detectChanges();

        component.showInsuranceTiles(false);

        expect(component.displayInsuranceTiles).toBe(true);
      });

      it('should set displayInsuranceTiles to false if not linked to EY employer and has only external policies', () => {
        component.account = MOCK_BTS_ACCOUNT;
        component.hasExternalPoliciesOnly = true;
        fixture.detectChanges();

        component.showInsuranceTiles(true);

        expect(component.displayInsuranceTiles).toBe(false);
      });

      it('should set displayInsuranceTiles to true if not linked to EY employer and has internal policies', () => {
        component.account = MOCK_BTS_ACCOUNT;
        component.hasExternalPoliciesOnly = false;
        fixture.detectChanges();

        component.showInsuranceTiles(true);

        expect(component.displayInsuranceTiles).toBe(true);
      });
    });

    describe('setInsuranceInfoMessages', () => {
      describe('when there are visible policies', () => {
        it('should set generic message when no external policies', () => {
          component.account = MOCK_ACCOUNT;
          fixture.detectChanges();

          component.setInsuranceInfoMessages(true, false, '1234');

          expect(component.insuranceInfoMessage).toBe(MOCK_AEM_CONTENT_POLICIES[0].data.description);
          expect(component.displayInsuranceInfoPdsLink).toBeFalse();
        });

        it('should set generic message when there are external policies and account is EY', () => {
          component.account = MOCK_BTS_EY_ACCOUNT;
          fixture.detectChanges();

          component.setInsuranceInfoMessages(true, true, '1234');

          expect(component.insuranceInfoMessage).toBe(MOCK_AEM_CONTENT_POLICIES[0].data.description);
          expect(component.displayInsuranceInfoPdsLink).toBeFalse();
        });

        it('should set external insurance message when there are external policies and account is not EY', () => {
          component.account = MOCK_ACCOUNT;
          fixture.detectChanges();

          component.setInsuranceInfoMessages(true, true, '1234');

          expect(component.insuranceInfoMessage).toBe(MOCK_AEM_CONTENT_POLICIES[2].data.description);
          expect(component.displayInsuranceInfoPdsLink).toBeFalse();
        });
      });

      describe('when there are no visible policies', () => {
        it('should set correct messages for EY accounts', () => {
          component.account = MOCK_BTS_EY_ACCOUNT;
          fixture.detectChanges();

          component.setInsuranceInfoMessages(false, false, '1234');

          expect(component.insuranceInfoMessage).toBe(MOCK_AEM_CONTENT_POLICIES[1].data.description);
          expect(component.noInsuranceAlertMessage).toBe(MOCK_AEM_CONTENT_POLICIES[3].data.description);
          expect(component.displayInsuranceInfoPdsLink).toBeTrue();
          expect(component.insuranceInfoPdsLink.link).toBeDefined();
        });

        it('should set correct no insurance message for WGP accounts', () => {
          component.account = MOCK_BTS_WGP_ACCOUNT;
          fixture.detectChanges();

          component.setInsuranceInfoMessages(false, false, '1234');

          expect(component.insuranceInfoMessage).toBe(MOCK_AEM_CONTENT_POLICIES[1].data.description);
          expect(component.noInsuranceAlertMessage).toBe(MOCK_AEM_CONTENT_POLICIES[4].data.description);
          expect(component.displayInsuranceInfoPdsLink).toBeTrue();
          expect(component.insuranceInfoPdsLink.link).toBeDefined();
        });

        it('should set correct no insurance message for BTS accounts', () => {
          component.account = MOCK_BTS_ACCOUNT;
          fixture.detectChanges();

          component.setInsuranceInfoMessages(false, false, '1234');

          expect(component.insuranceInfoMessage).toBe(MOCK_AEM_CONTENT_POLICIES[1].data.description);
          expect(component.noInsuranceAlertMessage).toBe(MOCK_AEM_CONTENT_POLICIES[5].data.description);
          expect(component.displayInsuranceInfoPdsLink).toBeTrue();
          expect(component.insuranceInfoPdsLink.link).toBeDefined();
        });

        it('should set correct no insurance message for BTSFL accounts', () => {
          component.account = MOCK_BTSFL_ACCOUNT;
          fixture.detectChanges();

          component.setInsuranceInfoMessages(false, false, '1234');

          expect(component.insuranceInfoMessage).toBe(MOCK_AEM_CONTENT_POLICIES[1].data.description);
          expect(component.noInsuranceAlertMessage).toBe(MOCK_AEM_CONTENT_POLICIES[6].data.description);
          expect(component.displayInsuranceInfoPdsLink).toBeTrue();
          expect(component.insuranceInfoPdsLink.link).toBeDefined();
        });
      });
    });

    describe('refreshPolicies', () => {
      it('should initialise loading prop and update policies with successful response ', () => {
        spyOn(panoInsuranceService, 'getPolicies').and.returnValue(of([MOCK_POLICIES]));
        spyOn(panoUpgradeAccountService, 'getAccountId');
        component.refreshPolicies();
        expect(panoUpgradeAccountService.getAccountId).toHaveBeenCalled();
        expect(component.policies).toEqual([MOCK_POLICIES]);
        expect(component.loading).toBe(false);
      });

      it('should call stateService of route for erroneous response ', () => {
        spyOn(panoInsuranceService, 'getPolicies').and.returnValue(throwError('error'));
        spyOn(panoUpgradeAccountService, 'getAccountId');
        component.account = MOCK_BTS_ACCOUNT;
        component.refreshPolicies();
        expect(panoUpgradeAccountService.getAccountId).toHaveBeenCalled();
        expect(component.policies).not.toBe([MOCK_POLICIES]);
        expect(mockUiRouter.stateService.go).toHaveBeenCalledWith(INVESTOR_ACCOUNT_ERROR_STATE, {
          accountId: component.account.key.accountId
        });
      });
    });

    describe('showPysOptInModal', () => {
      it('should set flag with correct component when getting successful response ', () => {
        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(true))
          })
        };

        spyOn(component, 'refreshPolicies');
        component.account = MOCK_BTS_ACCOUNT;

        component.showPysOptInModal();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoPysOptInAllComponent, {
          ...PYS_OPT_IN_ALL_DIALOG_CONFIG,
          data: {
            accountId: '1234'
          }
        });
        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.activatePysInsuranceRequested).toBe(true);
        expect(component.isAvailableForPysOptIn).toBe(false);
        expect(component.refreshPolicies).toHaveBeenCalled();
      });

      it('should not set flag when getting erroneous response ', () => {
        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(false))
          })
        };
        component.account = MOCK_BTS_ACCOUNT;

        spyOn(component, 'refreshPolicies');

        component.showPysOptInModal();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoPysOptInAllComponent, {
          ...PYS_OPT_IN_ALL_DIALOG_CONFIG,
          data: {
            accountId: '1234'
          }
        });
        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.refreshPolicies).not.toHaveBeenCalled();
      });
    });

    describe('showActivateInsuranceDialog', () => {
      beforeEach(() => {
        spyOn(panoInsurancePoliciesUtil, 'getSFLPolicyWithRiskCommencementDateGreaterThan30').and.returnValue(true);
      });

      it('should open active insurance dialog', () => {
        component.account = MOCK_BTS_ACCOUNT;

        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(OPT_IN_STATUS.success))
          })
        };

        component.showActivateInsuranceDialog(true, true);

        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoActivateInsuranceDialogComponent, {
          ...ACTIVATE_INSURANCE_DIALOG_CONFIG,
          data: {
            accountId: '1234',
            optInToPmif: true,
            optInToPys: true,
            showStandardCoverGreaterThan30DaysText: true
          }
        });
      });

      it('should set activateInsuranceRequested flag after modal closed with success', () => {
        component.account = MOCK_BTS_ACCOUNT;

        spyOn(component, 'refreshPolicies');

        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(OPT_IN_STATUS.success))
          })
        };

        component.showActivateInsuranceDialog(true, true);

        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.isAvailableForPmifPysOptIn).toBe(false);
        expect(component.displayPMIFMessage).toBe(false);
        expect(component.activateInsuranceRequested).toBe(true);
        expect(component.pysSubmitFailed).toBeUndefined();
        expect(component.refreshPolicies).toHaveBeenCalled();
      });

      it('should set activateInsuranceRequested flag after modal closed with pmifActivated', () => {
        component.account = MOCK_BTS_ACCOUNT;

        spyOn(component, 'refreshPolicies');

        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(OPT_IN_STATUS.pmifActivated))
          })
        };

        component.showActivateInsuranceDialog(true, false);

        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.displayPMIFSuccessMessage).toBe(true);
        expect(component.isAvailableForPmifPysOptIn).toBe(false);
        expect(component.displayPMIFMessage).toBe(false);
        expect(component.pysSubmitFailed).toBeUndefined();
        expect(component.refreshPolicies).toHaveBeenCalled();
      });

      it('should not set activateInsuranceRequested flag after modal closed with error/no action', () => {
        component.account = MOCK_BTS_ACCOUNT;

        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(OPT_IN_STATUS.none))
          })
        };

        component.showActivateInsuranceDialog(true, true);

        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.activateInsuranceRequested).toBeUndefined();
        expect(component.pysSubmitFailed).toBeUndefined();
      });

      it('should set activateInsuranceRequested and pysSubmitFailed flag after modal closed with pysFail', () => {
        component.account = MOCK_BTS_ACCOUNT;

        spyOn(component, 'refreshPolicies');

        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(OPT_IN_STATUS.pysFail))
          })
        };

        component.showActivateInsuranceDialog(true, true);

        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.isAvailableForPmifPysOptIn).toBe(false);
        expect(component.displayPMIFMessage).toBe(false);
        expect(component.activateInsuranceRequested).toBe(true);
        expect(component.pysSubmitFailed).toBe(true);
        expect(component.refreshPolicies).toHaveBeenCalled();
      });
    });

    describe('setValuesForOptInStatusSuccessAndPYSFail', () => {
      it('should set activateInsuranceRequested to true and call setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse', () => {
        spyOn(component, 'setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse');
        component.setValuesForOptInStatusSuccessAndPYSFail();

        expect(component.activateInsuranceRequested).toBe(true);
        expect(component.setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse).toHaveBeenCalled();
      });
    });

    describe('setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse', () => {
      it('should set isAvailableForPmifPysOptIn and displayPMIFMessage to false', () => {
        component.setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse();

        expect(component.isAvailableForPmifPysOptIn).toBe(false);
        expect(component.displayPMIFMessage).toBe(false);
      });
    });

    describe('ngOnDestroy', () => {
      it('should unsubscribe pysOptInSubscription', () => {
        spyOn(component.pysOptInAllDialogSubscription, 'unsubscribe');
        component.ngOnDestroy();
        expect(component.pysOptInAllDialogSubscription.unsubscribe).toHaveBeenCalled();
      });
    });

    describe('openExitSiteDialog', () => {
      it('should open exitSite dialog', () => {
        component.openExitSiteDialog();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoInsuranceExitSiteDialogComponent, {
          ...DIALOG_CONFIG.DEFAULT,
          autoFocus: false,
          ariaLabel: 'Open exit website dialog'
        });
      });
    });
  });

  describe('view', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should show loading spinner while fetching data', () => {
      component.loading = true;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).not.toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-policies'))).toBeNull();
    });

    it('should not show loading spinner once data is fetched', () => {
      component.loading = false;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-policies'))).not.toBeNull();
    });

    describe('policies Section', () => {
      let policiesSection: DebugElement;

      beforeEach(() => {
        component.loading = false;
        policiesSection = fixture.debugElement.query(By.css('.js-test-policies'));
      });

      it('should always show insurance info text', () => {
        expect(policiesSection.query(By.css('.js-test-insurance-info'))).toBeTruthy();
      });

      it('should show more insurance info when the PDS link is required', () => {
        component.displayInsuranceInfoPdsLink = true;
        fixture.detectChanges();
        expect(policiesSection.query(By.css('.js-test-insurance-info'))).toBeTruthy();
        expect(policiesSection.query(By.css('.js-test-more-insurance-info'))).toBeTruthy();
      });

      describe('inactivityInfo alert', () => {
        it('should show bt-alert with bt-button when all conditions are met', () => {
          component.hasVisiblePolicies = true;
          component.isAvailableForPysOptIn = true;
          component.isPysOptInInvestor = true;
          fixture.detectChanges();

          const btAlertEl = policiesSection.query(By.css('bt-alert'));
          expect(btAlertEl).toBeTruthy();
          expect(btAlertEl.properties.config).toBe(INACTIVITY_INFO_ALERT);

          const btButtonEl = btAlertEl.query(By.css('bt-button'));
          expect(btButtonEl).toBeTruthy();
          expect(btButtonEl.properties.config).toBe(KEEP_INSURANCE_BUTTON);
        });

        it('should not show bt-alert when any conditions are not met', () => {
          component.hasVisiblePolicies = false;
          component.isAvailableForPysOptIn = true;
          component.isPysOptInInvestor = true;
          fixture.detectChanges();

          let alert = policiesSection.query(By.css('.js-available-for-pys-opt-in-alert-box'));
          expect(alert).toBeFalsy();

          component.hasVisiblePolicies = true;
          component.isAvailableForPysOptIn = false;
          component.isPysOptInInvestor = true;
          fixture.detectChanges();

          alert = policiesSection.query(By.css('.js-available-for-pys-opt-in-alert-box'));
          expect(alert).toBeFalsy();

          component.hasVisiblePolicies = true;
          component.isAvailableForPysOptIn = true;
          component.isPysOptInInvestor = false;
          fixture.detectChanges();

          alert = policiesSection.query(By.css('.js-available-for-pys-opt-in-alert-box'));
          expect(alert).toBeFalsy();
        });
      });

      describe('activate pys insurance requested alert', () => {
        it('should exist when pys activation requested', () => {
          component.activatePysInsuranceRequested = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.ts-activate-pys-insurance-requested-alert'));
          expect(alert.properties.config).toBe(ACTIVATE_INSURANCE_REQUESTED_ALERT);
        });

        it('should not exist when activation not requested', () => {
          component.activatePysInsuranceRequested = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.ts-activate-pys-insurance-requested-alert'));
          expect(alert).toBeFalsy();
        });
      });

      describe('activate insurance requested alert', () => {
        it('should exist when activation requested', () => {
          component.activateInsuranceRequested = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.ts-activate-insurance-requested-alert'));
          expect(alert.properties.config).toBe(ACTIVATE_INSURANCE_REQUESTED_ALERT);
        });

        it('should not exist when activation not requested', () => {
          component.activateInsuranceRequested = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.ts-activate-insurance-requested-alert'));
          expect(alert).toBeFalsy();
        });
      });

      describe('pys submit fails alert', () => {
        it('should exist when pysSubmitFailed is set', () => {
          component.pysSubmitFailed = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.ts-pys-submit-failed-alert'));
          expect(alert.properties.config).toBe(PYS_SUBMIT_FAIL_ALERT);
        });

        it('should not exist when pysSubmitFailed not set', () => {
          component.pysSubmitFailed = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.ts-pys-submit-failed-alert'));
          expect(alert).toBeFalsy();
        });
      });

      describe('pmif and pys info alert', () => {
        it('should show bt-alert with bt-button when isAvailableForPmifPysOptIn is true', () => {
          component.pmifPermission = true;
          component.isAvailableForPmifPysOptIn = true;
          fixture.detectChanges();
          const btAlertEl = policiesSection.query(By.css('bt-alert'));
          expect(btAlertEl).toBeTruthy();
          expect(btAlertEl.properties.config).toBe(ACTIVATE_INFO_ALERT);
          const btButtonEl = btAlertEl.query(By.css('bt-button'));
          expect(btButtonEl).toBeTruthy();
          expect(btButtonEl.properties.config).toBe(ACTIVATE_COVER_BUTTON);
        });
      });

      describe('pano-insurance-tables', () => {
        it('should exists when policies exists', () => {
          component.policies = [MOCK_POLICIES];
          component.account = MOCK_BTS_ACCOUNT;
          fixture.detectChanges();
          const panoInsuranceTablesComponent = fixture.debugElement.query(By.css('pano-insurance-tables'));
          expect(panoInsuranceTablesComponent.nativeElement).toBeTruthy();
          expect(panoInsuranceTablesComponent.properties.account).toEqual(MOCK_BTS_ACCOUNT);
          expect(panoInsuranceTablesComponent.properties.policies).toEqual([MOCK_POLICIES]);
        });

        it('should not exist when policies dont exist', () => {
          component.policies = [];
          fixture.detectChanges();
          expect(policiesSection.query(By.css('pano-insurance-tables'))).toBeFalsy();
        });
      });

      describe('noInsurance alert', () => {
        it('should show bt-alert when policies dont exist', () => {
          component.policies = [];
          fixture.detectChanges();
          const btAlertEl = policiesSection.queryAll(By.css('bt-alert'))[0];
          expect(btAlertEl).toBeTruthy();
          expect(btAlertEl.properties.config).toEqual(NO_INSURANCE_ALERT);
        });

        it('should not show bt-alert when policies exists', () => {
          component.policies = [MOCK_POLICIES];
          fixture.detectChanges();
          const btAlertEl = policiesSection.queryAll(By.css('bt-alert'))[1];
          expect(btAlertEl).toBeFalsy();
        });
      });
    });

    describe('policy info alert', () => {
      it('should exists', () => {
        component.hasInternalAndExternalPolicies = true;
        fixture.detectChanges();
        const infoBtAlert = fixture.debugElement.query(By.css('bt-alert.js-test-policyInfo-alert'));
        expect(infoBtAlert).toBeTruthy();
        expect(infoBtAlert.properties.config).toBe(POLICIES_INFO_ALERT);
      });

      it('should not exist', () => {
        component.hasInternalAndExternalPolicies = false;
        fixture.detectChanges();
        const infoBtAlert = fixture.debugElement.query(By.css('bt-alert.js-test-policyInfo-alert'));
        expect(infoBtAlert).toBeFalsy();
      });
    });

    describe('insurance tiles section', () => {
      let insuranceTilesEl: DebugElement;

      beforeEach(() => {
        component.displayInsuranceTiles = true;
        fixture.detectChanges();
        insuranceTilesEl = fixture.debugElement.query(By.css('.js-insurance-tiles'));
      });

      it('should contain pano-insurance-tiles', () => {
        expect(insuranceTilesEl.query(By.css('pano-insurance-tiles'))).toBeTruthy();
      });

      it('should contain pano-insurance-links', () => {
        expect(insuranceTilesEl.query(By.css('.js-card-insurance-link-content pano-insurance-links'))).toBeTruthy();
      });

      it('should hide no external policies section', () => {
        expect(fixture.debugElement.query(By.css('.js-no-insurance-tiles'))).toBeFalsy();
      });

      describe('insurance card content', () => {
        it('should have bt-icon', () => {
          const btIconEl = insuranceTilesEl.query(By.css('.js-card-insurance-content bt-icon'));
          expect(btIconEl).toBeTruthy();
          expect(btIconEl.properties.config).toBe(INSURANCE_HELP_TILE_CONTENT.phoneIcon);
        });

        it('should have contact number', () => {
          expect(insuranceTilesEl.query(By.css('.js-card-insurance-contact')).nativeElement.innerText).toBe(
            INSURANCE_HELP_TILE_CONTENT.contactNumberText
          );
        });

        it('should have contact details', () => {
          expect(insuranceTilesEl.query(By.css('p')).nativeElement.innerText).toBe(
            INSURANCE_HELP_TILE_CONTENT.contactDetails
          );
        });
      });
    });

    describe('no insurance tiles section', () => {
      let noInsuranceTilesEl: DebugElement;

      beforeEach(() => {
        component.displayInsuranceTiles = false;
        fixture.detectChanges();
        noInsuranceTilesEl = fixture.debugElement.query(By.css('.js-no-insurance-tiles'));
      });

      it('should show only external policies section', () => {
        expect(noInsuranceTilesEl).toBeTruthy();
      });

      it('should hide no external policies section', () => {
        expect(fixture.debugElement.query(By.css('.js-insurance-tiles'))).toBeFalsy();
      });

      describe('insurance card content', () => {
        it('should have bt-icon', () => {
          const btIconEl = noInsuranceTilesEl.query(By.css('.js-card-insurance-content bt-icon'));
          expect(btIconEl).toBeTruthy();
          expect(btIconEl.properties.config).toBe(INSURANCE_HELP_TILE_CONTENT.phoneIcon);
        });

        it('should have contact number', () => {
          expect(noInsuranceTilesEl.query(By.css('.js-card-insurance-contact')).nativeElement.innerText).toBe(
            INSURANCE_HELP_TILE_CONTENT.contactNumberText
          );
        });

        it('should have contact details', () => {
          expect(noInsuranceTilesEl.query(By.css('p')).nativeElement.innerText).toBe(
            INSURANCE_HELP_TILE_CONTENT.contactDetails
          );
        });
      });
    });

    describe('pmif display message alert box', () => {
      it('should show pmif display alert box with button', () => {
        spyOn(component, 'showActivateInsuranceDialog');
        component.pmifPermission = true;
        component.displayPMIFMessage = true;
        component.isAvailableForPmifPysOptIn = false;
        fixture.detectChanges();

        const alert = fixture.debugElement.query(By.css('.js-pmif-display-alert-box'));
        expect(alert).toBeTruthy();
        expect(alert.properties.config).toEqual(ACTIVATE_INFO_ALERT);

        const button = alert.query(By.css('bt-button'));
        expect(button).toBeTruthy();

        button.triggerEventHandler('btClick', null);
        expect(component.showActivateInsuranceDialog).toHaveBeenCalledWith(true, false);
      });

      it('should not show pmif display alert box with button', () => {
        spyOn(component, 'showActivateInsuranceDialog');
        component.pmifPermission = false;
        component.displayPMIFMessage = true;
        component.isAvailableForPmifPysOptIn = false;
        fixture.detectChanges();

        const alert = fixture.debugElement.query(By.css('.js-pmif-display-alert-box'));
        expect(alert).toBeFalsy();
      });
    });

    describe('message disclaimer section', () => {
      it('should exists', () => {
        component.isDisclaimerBtSuperInvestor = true;
        component.hasExternalPoliciesOnly = false;
        fixture.detectChanges();
        const disclaimerEl = fixture.debugElement.query(By.css('.js-message-disclaimer'));
        expect(disclaimerEl).toBeTruthy();
      });

      it('should not exist', () => {
        component.isDisclaimerBtSuperInvestor = false;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.js-message-disclaimer'))).toBeFalsy();
      });
    });

    describe('AIA insurance panel', () => {
      describe('when integration is enabled & policies are in scope', () => {
        beforeEach(() => {
          component.isIntegrationToAiaEnabled = true;
          component.displayInsurancePanel = true;
          fixture.detectChanges();
        });

        it('should show AIA insurance panel', () => {
          const aiaInsurancePanel = fixture.debugElement.query(By.css('.js-aia-insurance-panel'));
          expect(aiaInsurancePanel).toBeTruthy();
        });

        it('should have calculator icon', () => {
          const calculatorIcon = fixture.debugElement.query(By.css('.js-test-calculator-icon'));
          expect(calculatorIcon).toBeTruthy();
          expect(calculatorIcon.properties.config).toEqual(CALCULATOR_ICON);
        });

        it('should have information text', () => {
          expect(fixture.debugElement.query(By.css('.js-test-aia-info-text')).nativeElement.innerText).toBe(
            CALCULATE_COVER_MESSAGE
          );
        });

        it('should have AIA insurance button and calls openExitSiteDialog method on click', () => {
          spyOn(component, 'openExitSiteDialog');
          const aiaInsurancePortalBtn = fixture.debugElement.query(By.css('.js-test-insurance-portal-button'));
          expect(aiaInsurancePortalBtn).toBeTruthy();
          expect(aiaInsurancePortalBtn.properties.config).toEqual(INSURANCE_PORTAL_BUTTON);
          aiaInsurancePortalBtn.nativeElement.dispatchEvent(new Event('btClick'));

          expect(component.openExitSiteDialog).toHaveBeenCalled();
        });
      });

      describe('when integration is disabled', () => {
        it("shouldn't show AIA insurance panel or internal elements", () => {
          component.isIntegrationToAiaEnabled = false;
          fixture.detectChanges();
          const aiaInsurancePanel = fixture.debugElement.query(By.css('.js-aia-insurance-panel'));
          const calculatorIcon = fixture.debugElement.query(By.css('.js-test-calculator-icon'));
          const aiaInfoText = fixture.debugElement.query(By.css('.js-test-aia-info-text'));
          const aiaInsurancePortalBtn = fixture.debugElement.query(By.css('.js-test-insurance-portal-button'));
          expect(aiaInsurancePanel).toBeFalsy();
          expect(calculatorIcon).toBeFalsy();
          expect(aiaInfoText).toBeFalsy();
          expect(aiaInsurancePortalBtn).toBeFalsy();
        });
      });

      describe('when integration is enabled and permission to show insurance panel is disabled', () => {
        it("shouldn't show AIA insurance panel or internal elements", () => {
          component.isIntegrationToAiaEnabled = true;
          component.displayInsurancePanel = false;
          fixture.detectChanges();
          const aiaInsurancePanel = fixture.debugElement.query(By.css('.js-aia-insurance-panel'));
          const calculatorIcon = fixture.debugElement.query(By.css('.js-test-calculator-icon'));
          const aiaInfoText = fixture.debugElement.query(By.css('.js-test-aia-info-text'));
          const aiaInsurancePortalBtn = fixture.debugElement.query(By.css('.js-test-insurance-portal-button'));
          expect(aiaInsurancePanel).toBeFalsy();
          expect(calculatorIcon).toBeFalsy();
          expect(aiaInfoText).toBeFalsy();
          expect(aiaInsurancePortalBtn).toBeFalsy();
        });
      });
    });

    describe('occupation category message', () => {
      it('should show a message containing links to the occupation guide and email form when category is missing', () => {
        component.displayNoOccupationCodeMessage = true;
        fixture.detectChanges();

        const occupationCategoryMessage = fixture.debugElement.query(By.css('.js-test-occupation-category-message'));
        const occupationGuideLink = fixture.debugElement.query(By.css('.js-test-occupation-guide-link'));
        const occupationCategoryLink = fixture.debugElement.query(By.css('.js-test-occupation-category-link'));

        expect(occupationCategoryMessage).toBeTruthy();
        expect(occupationGuideLink).toBeTruthy();
        expect(occupationCategoryLink).toBeTruthy();
      });

      it('should hide the message when category is present', () => {
        component.displayNoOccupationCodeMessage = false;
        fixture.detectChanges();

        const occupationCategoryMessage = fixture.debugElement.query(By.css('.js-test-occupation-category-message'));
        const occupationGuideLink = fixture.debugElement.query(By.css('.js-test-occupation-guide-link'));
        const occupationCategoryLink = fixture.debugElement.query(By.css('.js-test-occupation-category-link'));

        expect(occupationCategoryMessage).toBeFalsy();
        expect(occupationGuideLink).toBeFalsy();
        expect(occupationCategoryLink).toBeFalsy();
      });
    });
  });
});
