import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { LayoutModule } from '@panorama/components/layout';
import { PanoUpgradePermissionService, StateParams } from '@upgrade/upgrade.services';
import { cloneDeep } from 'lodash-es';

import { PanoInsuranceLinksComponent } from './pano-insurance-links.component';
import {
  BTSFL_ACCOUNT,
  BTS_ACCOUNT,
  LINK,
  POLICY_FN1,
  POLICY_II1,
  POLICY_II1_II2,
  POLICY_II2,
  POLICY_LIFETIME,
  TEST_ACTIVE_LINKS,
  TEST_INSURANCE_LINKS,
  TEST_OCCUPATION_CATEGORY_INFO_LINK,
  TEST_TRANSFER_INSURANCE_LINK,
  WGP_ACCOUNT
} from './pano-insurance-links.component.spec.constants';
import {
  ADDITIONAL_INFORMATION_BOOKLET_LABEL,
  BT_SUPER_LIFETIME_INSURANCE_GUIDE_URL,
  CONSOLIDATION_FORM_LABEL,
  EXPANSION_ICON,
  HEADING_TEXT,
  INSURANCE_GUIDE_LABEL,
  INSURANCE_LINKS,
  OCCUPATION_CATEGORY_INFO_BTSFL,
  OCCUPATION_CATEGORY_INFO_GENERIC,
  SUB_HEADING_TEXT,
  TAKEOVER_FORM_LABEL,
  TRANSFER_FORM_LABEL
} from './pano-insurance-links.constants';

describe('PanoInsuranceLinksComponent', () => {
  let component: PanoInsuranceLinksComponent;
  let fixture: ComponentFixture<PanoInsuranceLinksComponent>;
  let superLinkService: PanoSuperLinkService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInsuranceLinksComponent],
        imports: [LayoutModule, RouterTestingModule],
        providers: [
          PanoSuperLinkService,
          {
            provide: PanoUpgradePermissionService,
            useValue: { hasPermission: jasmine.createSpy() }
          },
          {
            provide: StateParams,
            useValue: {
              accountId: 'EncodedAccountId'
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsuranceLinksComponent);
    component = fixture.componentInstance;
    superLinkService = TestBed.inject(PanoSuperLinkService);

    /* Without any value to @Input attribute Component fails to be created.
    So set input property here to avoid the use of TestHostComponent */
    component.account = BTSFL_ACCOUNT;
    component.policies = [POLICY_II1];
    fixture.detectChanges();
  });

  describe('Component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct value for heading', () => {
      expect(component.heading).toBe(HEADING_TEXT);
    });

    it('should have correct value for subHeading', () => {
      expect(component.subHeading).toBe(SUB_HEADING_TEXT);
    });

    it('should have correct value for expansionIcon', () => {
      expect(component.expansionIcon).toEqual(EXPANSION_ICON);
    });

    it('should have correct value for insuranceLinks', () => {
      expect(component.insuranceLinks).toBe(INSURANCE_LINKS);
    });

    describe('ngOnInit', () => {
      beforeEach(() => {
        spyOn(superLinkService, 'getLink').and.returnValue(cloneDeep(LINK));
        component.insuranceLinks = TEST_INSURANCE_LINKS;
        fixture.detectChanges();
      });

      it('should set activeLinks excluding particular link from insuranceLinks if showInsuranceLink returns false', () => {
        component.policies = [POLICY_II1];
        const spy = spyOn(component, 'showInsuranceLink').and.returnValue(false);
        component.ngOnInit();

        expect(spy).toHaveBeenCalled();
        expect(component.activeLinks.length).toBe(0);
      });

      it('should set activeLinks including particular link in insuranceLinks if showInsuranceLink returns true', () => {
        component.policies = [POLICY_II1];
        const spy = spyOn(component, 'showInsuranceLink').and.returnValue(true);
        component.ngOnInit();

        expect(spy).toHaveBeenCalled();
        expect(component.activeLinks.length).toBe(component.insuranceLinks.length);
      });

      it('should set activeLinks no policies', () => {
        component.policies = [];

        component.ngOnInit();

        expect(component.activeLinks.length).toBe(component.insuranceLinks.length);
      });
    });

    describe('configureLinks', () => {
      beforeEach(() => {
        spyOn(superLinkService, 'getLink').and.returnValues(
          cloneDeep(LINK),
          cloneDeep(LINK),
          cloneDeep(LINK),
          cloneDeep(LINK),
          cloneDeep(LINK),
          cloneDeep(LINK)
        );
      });

      it('should set the subHeadingLink', () => {
        component.configureLinks();

        expect(component.subHeadingLink).toEqual(LINK);
      });

      it('should set the link for each InsuranceLink with a LinkType', () => {
        component.insuranceLinks = cloneDeep(TEST_INSURANCE_LINKS);
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].link).toEqual(LINK);
        expect(component.insuranceLinks[1].link).toBeFalsy();
        expect(component.insuranceLinks[2].link).toEqual(LINK);
        expect(component.insuranceLinks[3].link).toBeFalsy();
        expect(component.insuranceLinks[4].link).toBeFalsy();
      });

      it('should configure the occupation category info link correctly for BTSFL accounts', () => {
        component.account = BTSFL_ACCOUNT;
        component.insuranceLinks = [cloneDeep(TEST_OCCUPATION_CATEGORY_INFO_LINK)];
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].content).toContain(OCCUPATION_CATEGORY_INFO_BTSFL);
        expect(component.insuranceLinks[0].link.link).toBe('test url');
        expect(component.insuranceLinks[0].link.label).toBe(ADDITIONAL_INFORMATION_BOOKLET_LABEL);
        expect(component.insuranceLinks[0].link.a11yProps.ariaLabel).toContain(ADDITIONAL_INFORMATION_BOOKLET_LABEL);
      });

      it('should configure the occupation category info link correctly for wgp accounts', () => {
        component.account = WGP_ACCOUNT;
        component.insuranceLinks = [cloneDeep(TEST_OCCUPATION_CATEGORY_INFO_LINK)];
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].content).toContain(OCCUPATION_CATEGORY_INFO_GENERIC);
        expect(component.insuranceLinks[0].link.link).toBe('test url');
        expect(component.insuranceLinks[0].link.label).toBe(INSURANCE_GUIDE_LABEL);
        expect(component.insuranceLinks[0].link.a11yProps.ariaLabel).toContain(INSURANCE_GUIDE_LABEL);
      });

      it('should configure the occupation category info link correctly for BTS accounts with lifetime cover', () => {
        component.account = BTS_ACCOUNT;
        component.policies = [POLICY_LIFETIME];
        component.insuranceLinks = [cloneDeep(TEST_OCCUPATION_CATEGORY_INFO_LINK)];
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].content).toContain(OCCUPATION_CATEGORY_INFO_GENERIC);
        expect(component.insuranceLinks[0].link.link).toBe(BT_SUPER_LIFETIME_INSURANCE_GUIDE_URL);
        expect(component.insuranceLinks[0].link.label).toBe(INSURANCE_GUIDE_LABEL);
        expect(component.insuranceLinks[0].link.a11yProps.ariaLabel).toContain(INSURANCE_GUIDE_LABEL);
      });

      it('should configure the occupation category info link correctly for other accounts', () => {
        component.account = BTS_ACCOUNT;
        component.insuranceLinks = [cloneDeep(TEST_OCCUPATION_CATEGORY_INFO_LINK)];
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].content).toContain(OCCUPATION_CATEGORY_INFO_GENERIC);
        expect(component.insuranceLinks[0].link.link).toBe('test url');
        expect(component.insuranceLinks[0].link.label).toBe(INSURANCE_GUIDE_LABEL);
        expect(component.insuranceLinks[0].link.a11yProps.ariaLabel).toContain(INSURANCE_GUIDE_LABEL);
      });

      it('should configure the transfer insurance link correctly for WGP accounts', () => {
        component.account = WGP_ACCOUNT;
        component.insuranceLinks = [cloneDeep(TEST_TRANSFER_INSURANCE_LINK)];
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].link.link).toBe('test url');
        expect(component.insuranceLinks[0].link.label).toBe(TRANSFER_FORM_LABEL);
        expect(component.insuranceLinks[0].link.a11yProps.ariaLabel).toContain(TRANSFER_FORM_LABEL);
      });

      it('should configure the transfer insurance link correctly for BTS accounts', () => {
        component.account = BTS_ACCOUNT;
        component.insuranceLinks = [cloneDeep(TEST_TRANSFER_INSURANCE_LINK)];
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].link.link).toBe('test url');
        expect(component.insuranceLinks[0].link.label).toBe(CONSOLIDATION_FORM_LABEL);
        expect(component.insuranceLinks[0].link.a11yProps.ariaLabel).toContain(CONSOLIDATION_FORM_LABEL);
      });

      it('should configure the transfer insurance link correctly for other accounts', () => {
        component.account = BTSFL_ACCOUNT;
        component.insuranceLinks = [cloneDeep(TEST_TRANSFER_INSURANCE_LINK)];
        fixture.detectChanges();

        component.configureLinks();

        expect(component.insuranceLinks[0].link.link).toBe('test url');
        expect(component.insuranceLinks[0].link.label).toBe(TAKEOVER_FORM_LABEL);
        expect(component.insuranceLinks[0].link.a11yProps.ariaLabel).toContain(TAKEOVER_FORM_LABEL);
      });
    });

    describe('showInsuranceLink', () => {
      beforeEach(() => {
        component.insuranceLinks = TEST_INSURANCE_LINKS;
        fixture.detectChanges();
      });

      it('include insurance link having no particular applicable note', () => {
        component.policies = [POLICY_II1];

        expect(component.showInsuranceLink(TEST_INSURANCE_LINKS[4])).toBeTruthy();
      });

      it('include particular II1 insurance links', () => {
        component.policies = [POLICY_II1];

        component.showInsuranceLink(TEST_INSURANCE_LINKS[0]);

        expect(component.showInsuranceLink(TEST_INSURANCE_LINKS[0])).toBeTruthy();
      });

      it('include particular II2 insurance links', () => {
        component.policies = [POLICY_II2];

        expect(component.showInsuranceLink(TEST_INSURANCE_LINKS[2])).toBeTruthy();
      });

      it('include particular II1 and II2 insurance links', () => {
        component.policies = [POLICY_II1_II2];

        expect(component.showInsuranceLink(TEST_INSURANCE_LINKS[0])).toBeTruthy();
      });

      it('exclude particular insurance link', () => {
        component.policies = [POLICY_FN1];

        expect(component.showInsuranceLink(TEST_INSURANCE_LINKS[0])).toBeFalsy();
      });
    });
  });

  describe('Template', () => {
    beforeEach(() => {
      component.activeLinks = TEST_ACTIVE_LINKS;
      component.subHeadingLink = LINK;
      fixture.detectChanges();
    });

    it('should render correct value for heading', () => {
      const el = fixture.debugElement.query(By.css('.js-test-link-heading'));
      expect(el.nativeElement.innerHTML).toBe(HEADING_TEXT);
    });

    it('should render correct value for sub-heading', () => {
      const el = fixture.debugElement.query(By.css('.link-heading'));
      expect(el.nativeElement.innerHTML).toContain(SUB_HEADING_TEXT);
      expect(el.nativeElement.innerHTML).toContain('<bt-link>');
    });

    it('should render correct title for each link', () => {
      const els = fixture.debugElement.queryAll(By.css('.custom-panel-header'));
      expect(component.activeLinks.length).toBe(els.length);

      expect(els[0].nativeElement.innerHTML).toContain(TEST_ACTIVE_LINKS[0].title);
      expect(els[1].nativeElement.innerHTML).toContain(TEST_ACTIVE_LINKS[1].title);
      expect(els[2].nativeElement.innerHTML).toContain(TEST_ACTIVE_LINKS[2].title);
    });

    it('should render correct value for each link', () => {
      const els = fixture.debugElement.queryAll(By.css('.js-test-link'));
      expect(component.activeLinks.length).toBe(els.length);

      expect(els[0].nativeElement.innerHTML).toContain(TEST_ACTIVE_LINKS[0].content);
      expect(els[0].nativeElement.innerHTML).not.toContain('<bt-link>');

      expect(els[1].nativeElement.innerHTML).toContain(TEST_ACTIVE_LINKS[1].content);
      expect(els[1].nativeElement.innerHTML).toContain('<bt-link>');

      expect(els[2].nativeElement.innerHTML).toContain(TEST_ACTIVE_LINKS[2].content);
      expect(els[2].nativeElement.innerHTML).toContain('<bt-link>');
      expect(els[2].nativeElement.innerHTML).toContain(TEST_ACTIVE_LINKS[2].contentAfterLink);
    });
  });
});
