import { Button } from '@bt/components/button';

export const CLOSE_BUTTON: Button = {
  action: 'button',
  label: 'Close',
  size: 'large',
  type: 'outline',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Close dialog'
  }
};

export const CONTINUE_BUTTON: Button = {
  action: 'button',
  label: 'Continue',
  size: 'large',
  type: 'solid',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Continue'
  }
};

export const CLOSE_ICON_BUTTON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  size: 'medium',
  colourModifier: 'basic',
  a11yProps: {
    ariaLabel: 'Close dialog'
  }
};
