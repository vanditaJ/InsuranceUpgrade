import { Injectable } from '@angular/core';
import { BtError, DataService } from '@bt/services/data';
import { AemTitleLink } from '@investor/account/pano-shared/interfaces';
import { Observable } from 'rxjs';

import {
  AEM_URL_SUFFIX,
  GENERIC_OPTIONS,
  INVESTMENT_OVERVIEW_FAQ_AEM_URL
} from './pano-investments-overview-questions.constants';

@Injectable()
export class PanoInvestmentsOverviewQuestionsService {
  constructor(private dataService: DataService<AemTitleLink | BtError>) {}

  getAemContent(apirCode: string): Observable<AemTitleLink | BtError> {
    return this.dataService.retrieve(
      `${INVESTMENT_OVERVIEW_FAQ_AEM_URL}/${apirCode}/${AEM_URL_SUFFIX}`,
      GENERIC_OPTIONS
    );
  }
}
