import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DataService } from '@bt/services/data';
import { Observable } from 'rxjs';

import { PanoInsuranceListOptInComponent } from './pano-insurance-list-opt-in/pano-insurance-list-opt-in.component';
import { Policy, RelatedAccounts } from './pano-insurance-list.interface';

@Injectable({
  providedIn: 'root'
})
export class PanoInsuranceListService {
  public selectedIndex = -1;
  public policiesAccounts = '../api/policy/v1_0/accounts/';
  public staticAccounts = '../api/v1_0/staticreference?category=all';
  constructor(private http: HttpClient, public dialog: MatDialog, private dataService: DataService<any>) {}
  
  submitPysOptInRequest(policyNumbers, accountId: string) {
    return this.http.post(
      `../api/v1/investor/accounts/${accountId}/insurance-policy/opt-in`,
      JSON.stringify(policyNumbers),
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );
  }
  openModal() {
    this.dialog.open(PanoInsuranceListOptInComponent);
  }

  closeModal() {
    this.dialog.closeAll();
  }

  getPolicies(accountId: string): Observable<Policy[]> {
    return this.dataService.retrieve(`${this.policiesAccounts}${accountId}`);
  }
  getStaticPolicyData() {
    return this.dataService.retrieve(`${this.staticAccounts}`);
  }
  getRelatedAccounts(accountId: string): Observable<RelatedAccounts[]> {
    return this.dataService.retrieve(`../api/policy/v1_0/accounts/${accountId}/relatedaccounts`);
  }
}
