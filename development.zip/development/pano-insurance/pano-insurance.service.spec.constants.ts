import { CoverAmountOptions, InsuranceRate } from './pano-change-cover-insurance/pano-change-cover-insurance.interface';
import { InsuranceOption, InsurancePolicy, PolicyStatus, PolicyType } from './pano-insurance.interface';

export const POLICIES: Array<InsurancePolicy> = [
  {
    policyType: PolicyType.DEATH,
    policyName: 'Income Protection',
    policyNumber: '5273590',
    qualifierName: 'Salary continuance cover',
    premium: '0.00',
    status: PolicyStatus.PENDING,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    commencementDate: '2021-03-01T00:00:00.000+11:00',
    sumInsured: 4521,
    coverSubTypeId: 20,
    coverLevel: 'Double',
    ageNextBirthday: 54,
    newCoverType: null,
    customised: true,
    customerType: 'Retail',
    employerFunded: false,
    associatedTpd: [21]
  },
  {
    policyType: PolicyType.DEATH_AND_TPD,
    policyName: 'Income Protection',
    policyNumber: '5273591',
    qualifierName: 'Salary continuance cover',
    premium: '0.00',
    status: PolicyStatus.PENDING,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    commencementDate: '2021-03-01T00:00:00.000+11:00',
    sumInsured: 4521,
    coverSubTypeId: 11,
    coverLevel: 'Single',
    ageNextBirthday: 54,
    newCoverType: null,
    customised: true,
    customerType: 'Retail',
    employerFunded: false
  },
  {
    policyType: PolicyType.TPD,
    policyName: 'Income Protection',
    policyNumber: '5273592',
    qualifierName: 'Salary continuance cover',
    premium: '0.00',
    status: PolicyStatus.INACTIVE,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    commencementDate: '2021-03-01T00:00:00.000+11:00',
    sumInsured: 4521,
    coverSubTypeId: 21,
    coverLevel: 'Single',
    ageNextBirthday: 54,
    newCoverType: null,
    customised: true,
    customerType: 'Retail',
    employerFunded: false
  }
];

export const INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Income Protection',
  policyNumber: '5273590',
  qualifierName: 'Salary continuance cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: true,
  customerType: 'Retail',
  employerFunded: false
};

export const PERMISSIONS = {
  'insurance.aia.showManageInsurancePanel': 'true'
};

export const PARAMS = {
  policyNumber: '5273590',
  status: PolicyStatus.ACTIVE,
  currentStartDate: '2020-11-02'
};

export const INSURANCE_RATES: Array<InsuranceRate> = [
  {
    coverOptionId: '93',
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    coverLevel: 'Single',
    coverAmount: 37500,
    premium: '2.61',
    increase: false
  },
  {
    coverOptionId: '95',
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    coverLevel: 'Triple',
    coverAmount: 112500,
    premium: '7.82',
    increase: true
  },
  {
    coverOptionId: '96',
    policyType: PolicyType.DEATH_AND_TPD,
    policyName: 'Death and Total & Permanent Disability (TPD) cover',
    coverLevel: 'Single',
    coverAmount: 37500,
    premium: '3.06',
    increase: true
  },
  {
    coverOptionId: '97',
    policyType: PolicyType.DEATH_AND_TPD,
    policyName: 'Death and Total & Permanent Disability (TPD) cover',
    coverLevel: 'Double',
    coverAmount: 75000,
    premium: '6.12',
    increase: true
  },
  {
    coverOptionId: '98',
    policyType: PolicyType.DEATH_AND_TPD,
    policyName: 'Death and Total & Permanent Disability (TPD) cover',
    coverLevel: 'Triple',
    coverAmount: 112500,
    premium: '9.19',
    increase: true
  }
];

export const INSURANCE_OPTIONS: InsuranceOption[] = [
  {
    waitingPeriod: '30 days',
    benefitPeriods: ['2 years', '5 years', 'Age 65']
  },
  {
    waitingPeriod: '90 days',
    benefitPeriods: ['2 years', '5 years', 'Age 65']
  },
  {
    waitingPeriod: '180 days',
    benefitPeriods: ['Age 65']
  },
  {
    waitingPeriod: '720 days',
    benefitPeriods: ['Age 65']
  }
];

export const EXPECTED_OPTIONS_DEATH_DECREASE: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Triple',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single']
    }
  ]
};

export const EXPECTED_OPTIONS_DEATH_CHANGE: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Triple',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single', 'Triple']
    },
    {
      coverType: PolicyType.DEATH_AND_TPD,
      coverLevels: ['Single', 'Double', 'Triple']
    }
  ]
};

export const EXPECTED_OPTIONS_DEATH_MISSING: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Triple',
  coverTypeSelected: []
};
