import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Link } from '@bt/components/link';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataService } from '@bt/services/data';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradePermissionService, StateParams } from '@upgrade/upgrade.services';
import { of } from 'rxjs';

import { PanoLearnAboutInvestmentsComponent } from './pano-learn-about-investments.component';
import { AEM_TEXT_URL, GENERIC_OPTIONS } from './pano-learn-about-investments.constants';
import { PanoLearnAboutInvestmentsService } from './pano-learn-about-investments.service';

describe('PanoLearnAboutInvestmentsComponent', () => {
  let component: PanoLearnAboutInvestmentsComponent;
  let fixture: ComponentFixture<PanoLearnAboutInvestmentsComponent>;
  let disclaimerService: PanoDisclaimersService;
  let superLinkService: PanoSuperLinkService;
  let service: PanoLearnAboutInvestmentsService;

  const ENCODED_ACCOUNT_ID: string = 'EncodedAccountId';
  const ACCOUNT: Partial<Account> = {
    key: {
      accountId: 'EncodedAccountId'
    },
    accountNumber: 'accountNumber',
    heritageCohort: 'OPEN',
    product: { productSubType: 'CORPORATE_SUPER' }
  };

  const LINK: Link = {
    icon: {
      name: 'icon-chevron-left-circle-solid'
    },
    isLinkExternal: true,
    label: 'test link',
    link: 'test url',
    openNewTab: false,
    type: 'flat',
    colourModifier: 'primary',
    iconPosition: 'left'
  };

  const dataService = {
    retrieve: jasmine.createSpy().and.returnValue(
      of({
        details: []
      })
    )
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoLearnAboutInvestmentsComponent],
        imports: [
          BrowserAnimationsModule,
          MatButtonToggleModule,
          MatFormFieldModule,
          MatInputModule,
          MatRadioModule,
          CopyMatrixPipeModule
        ],
        providers: [
          {
            provide: DataService,
            useValue: dataService
          },
          PanoLearnAboutInvestmentsService,
          PanoDisclaimersService,
          PanoLearnAboutInvestmentsService,
          PanoSuperLinkService,
          {
            provide: PanoUpgradePermissionService,
            useValue: { hasPermission: jasmine.createSpy() }
          },
          {
            provide: StateParams,
            useValue: {
              accountId: ENCODED_ACCOUNT_ID
            }
          },
          {
            provide: UIRouter,
            useValue: {}
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoLearnAboutInvestmentsComponent);
    disclaimerService = TestBed.inject(PanoDisclaimersService);
    spyOn(disclaimerService, 'evaluateDisclaimer').and.returnValue('disclaimer');
    component = fixture.componentInstance;
    superLinkService = TestBed.inject(PanoSuperLinkService);
    spyOn(superLinkService, 'getLink').and.returnValue(LINK);
    service = TestBed.inject(PanoLearnAboutInvestmentsService);
  });

  describe('Component', () => {
    describe('BT Super account', () => {
      beforeEach(() => {
        component.account = ACCOUNT as Account;
        spyOn(service, 'getTextContent').and.returnValue(of({}));
        component.ngOnInit();
      });
      it('should display the required links and disclaimer', () => {
        expect(component.disclaimer).toBeTruthy();
        expect(component.date).toBeTruthy();
      });

      it('should display the required links and disclaimer', () => {
        expect(component.investmentOptionsLink).toEqual(LINK);
        expect(component.performanceLink).toEqual(LINK);
        expect(component.unitPricesWgpLink).toEqual(LINK);
        expect(component.feesLink).toEqual(LINK);
        expect(component.spreadLink).toEqual(LINK);
      });

      it('should load the text content', () => {
        expect(service.getTextContent).toHaveBeenCalled();
      });
    });
  });

  describe('service', () => {
    describe('getTextContent', () => {
      beforeEach(() => {
        dataService.retrieve.calls.reset();
        dataService.retrieve.and.returnValue(
          of({
            details: [
              {
                type: 'title_text_link',
                id: 'general',
                data: {
                  headerText: 'headerText',
                  description: '\u003cp\u003eheaderText\u003c/p\u003e\r\n'
                }
              }
            ]
          })
        );
      });

      it('should load the text from aem', () => {
        service.getTextContent();
        expect(dataService.retrieve).toHaveBeenCalledWith(AEM_TEXT_URL, GENERIC_OPTIONS);
      });
    });
  });

  describe('view', () => {
    beforeEach(() => {
      component.account = ACCOUNT as Account;
      component.investmentOptionsLink = LINK;
      component.performanceLink = LINK;
      component.unitPricesWgpLink = LINK;
      component.feesLink = LINK;
      component.spreadLink = null;
      fixture.detectChanges();
    });

    it('should show loading spinner while fetching data', () => {
      component.loading = true;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-learn-about-investments'))).toBeFalsy();
    });

    it('should show page when loading complete', () => {
      component.loading = false;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).toBeFalsy();
      expect(fixture.debugElement.query(By.css('.js-test-learn-about-investments'))).toBeTruthy();
    });

    it('should only show the tiles with links', () => {
      component.loading = false;
      component.investmentOptionsLink = LINK;
      component.performanceLink = LINK;
      component.unitPricesWgpLink = LINK;
      component.feesLink = null;
      component.spreadLink = null;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.js-test-investment-options'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-performance'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-unit-prices'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-fees'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-spread'))).toBeFalsy();
    });
  });
});
