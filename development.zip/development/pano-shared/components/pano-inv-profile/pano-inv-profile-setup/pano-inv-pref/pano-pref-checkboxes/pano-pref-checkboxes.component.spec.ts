import { HarnessLoader } from '@angular/cdk/testing';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';
import { Component, NO_ERRORS_SCHEMA, SimpleChange } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatCheckboxHarness } from '@angular/material/checkbox/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { cloneDeep } from 'lodash-es';

import { CheckboxField } from '../pano-inv-pref.interface';

import { PanoCheckboxesComponent } from './pano-pref-checkboxes.component';
import { MOCK_CHECKBOX_FIELDS } from './pano-pref-checkboxes.component.data.spec';

@Component({
  template: `
    <pano-pref-checkboxes [(checkBoxFields)]="checkBoxFields" (checkBoxFieldsChange)="checkBoxFieldsChange($event)">
    </pano-pref-checkboxes>
  `
})
class TestHostComponent {
  checkBoxFields: CheckboxField[] = cloneDeep(MOCK_CHECKBOX_FIELDS);
  checkBoxFieldsChange(): void {}
}

describe('PanoCheckboxesComponent', () => {
  let component: PanoCheckboxesComponent;
  let fixture: ComponentFixture<PanoCheckboxesComponent>;
  let loader: HarnessLoader;

  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [PanoCheckboxesComponent, TestHostComponent],
      imports: [MatCheckboxModule, ReactiveFormsModule, NoopAnimationsModule],
      providers: [{ provide: FormBuilder, useValue: formBuilder }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoCheckboxesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    loader = TestbedHarnessEnvironment.loader(fixture);
  });

  describe('view', () => {
    it('should load checkboxes', async () => {
      component.ngOnChanges({ checkBoxFields: new SimpleChange(0, MOCK_CHECKBOX_FIELDS, true) });

      fixture.detectChanges();

      const checkboxes = await loader.getAllHarnesses(MatCheckboxHarness);

      expect(checkboxes.length).toBe(MOCK_CHECKBOX_FIELDS.length);
      expect(await checkboxes[0].getLabelText()).toBe(MOCK_CHECKBOX_FIELDS[0].descripton);
    });

    it('should call checkBoxFieldsChange() when form value gets changed', async () => {
      spyOn(component.checkBoxFieldsChange, 'emit').and.stub();

      component.ngOnChanges({ checkBoxFields: new SimpleChange(0, MOCK_CHECKBOX_FIELDS, false) });
      fixture.detectChanges();

      const checkboxes = await loader.getAllHarnesses(MatCheckboxHarness);
      await checkboxes[0].toggle();

      expect(component.checkBoxFieldsChange.emit).toHaveBeenCalled();
    });
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct input and output mapping with its host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);

      const hostComponent = hostFixture.componentInstance;
      const currentComp: PanoCheckboxesComponent = hostFixture.debugElement.query(By.directive(PanoCheckboxesComponent))
        .componentInstance;

      spyOn(hostComponent, 'checkBoxFieldsChange');

      hostFixture.detectChanges();
      currentComp.checkBoxFieldsChange.emit(MOCK_CHECKBOX_FIELDS);

      expect(currentComp.checkBoxFields).toEqual(hostComponent.checkBoxFields);
      expect(hostComponent.checkBoxFieldsChange).toHaveBeenCalled();
    });

    describe('ngOnChanges()', () => {
      beforeEach(() => {
        component.ngOnChanges({ checkBoxFields: new SimpleChange([], [...MOCK_CHECKBOX_FIELDS], true) });
      });

      it('should create form group', () => {
        expect(component.form).toBeTruthy();
      });

      it('should return formGroup with empty controls when checkBoxFields is empty', () => {
        component.ngOnChanges({ checkBoxFields: new SimpleChange([], null, true) });

        expect(component.form.controls.length).toBeFalsy();
      });

      it('should return formGroup with controls when checkBoxFields is NOT empty', () => {
        expect(component.form.contains(MOCK_CHECKBOX_FIELDS[0].name)).toBeTruthy();
        expect(component.form.controls[MOCK_CHECKBOX_FIELDS[0].name].value).toEqual(MOCK_CHECKBOX_FIELDS[0].value);
      });
    });

    describe('OnDestroy()', () => {
      it('should call unsubscribe$.complete', () => {
        const unsubSpy = spyOn(component.unsubscribe$, 'complete').and.stub();

        component.ngOnDestroy();

        expect(unsubSpy).toHaveBeenCalled();
      });
    });
  });
});
