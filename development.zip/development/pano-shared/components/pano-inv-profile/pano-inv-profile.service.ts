import { Injectable } from '@angular/core';
import { BtError, DataService } from '@bt/services/data';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { getInvestmentProfileOptions, getInvestmentProfilePath } from './pano-inv-profile.constants';
import { InvestmentProfile } from './pano-inv-profile.interface';

@Injectable()
export class PanoInvestmentProfileService {
  constructor(private dataService: DataService<InvestmentProfile | BtError>) {}

  getInvestmentProfile(accountId: string): Observable<InvestmentProfile | BtError> {
    return this.dataService
      .retrieve(getInvestmentProfilePath(accountId), getInvestmentProfileOptions(accountId))
      .pipe(map((profile: InvestmentProfile) => (profile?.accountId ? profile : undefined)));
  }

  setInvestmentProfile(
    accountId: string,
    investmentProfile: InvestmentProfile
  ): Observable<InvestmentProfile | BtError> {
    return this.dataService.update(
      getInvestmentProfilePath(accountId),
      investmentProfile,
      getInvestmentProfileOptions(accountId)
    );
  }
}
