import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { ACCOUNTING_SOFTWARE_CONNECTION_PENDING_ALERT } from '../pano-external-assets.constants';

import { PanoExternalAssetsConnectionPendingComponent } from './pano-external-assets-connection-pending.component';

@Component({
  template: `
    <pano-external-assets-connection-pending> </pano-external-assets-connection-pending>
  `
})
class TestHostComponent {}

describe('PanoExternalAssetsConnectionPendingComponent', () => {
  let fixture: ComponentFixture<PanoExternalAssetsConnectionPendingComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoExternalAssetsConnectionPendingComponent, TestHostComponent],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoExternalAssetsConnectionPendingComponent);
  });

  describe('view', () => {
    it('Should have warning alert info', () => {
      fixture.detectChanges();
      const warningAlert = fixture.debugElement.query(
        By.css('.js-test-external-assets-connection-pending-warning-alert')
      );
      expect(warningAlert.properties.config).toEqual(ACCOUNTING_SOFTWARE_CONNECTION_PENDING_ALERT);
      expect(warningAlert.nativeElement.innerHTML).toContain('Accounting software connection requested');
      expect(warningAlert.nativeElement.innerHTML).toContain(
        'Connection to accounting software has been requested. The linked accountant must authorise this connection. Once active, data from the accounting software will replace any manually entered external assets.'
      );
    });

    it('should have correctly instantiated from host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const currentComp: PanoExternalAssetsConnectionPendingComponent = hostFixture.debugElement.query(
        By.directive(PanoExternalAssetsConnectionPendingComponent)
      ).componentInstance;
      hostFixture.detectChanges();
      expect(currentComp).toBeTruthy();
      expect(currentComp.warningAlert).toBe(ACCOUNTING_SOFTWARE_CONNECTION_PENDING_ALERT);
    });
  });
});
