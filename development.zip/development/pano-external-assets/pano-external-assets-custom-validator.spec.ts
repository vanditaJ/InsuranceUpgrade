import { FormControl, FormGroup } from '@angular/forms';

import {
  alphaNumericValidator,
  assetCodeValidator,
  assetSelectedValidator
} from './pano-external-assets-custom-validator';

describe('external-asset-custom-validator', () => {
  describe('assetCodeValidator()', () => {
    it('should return null if test control value is null', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl(null, [assetCodeValidator()])
      });
      expect(assetCodeError.get('testControl').errors).toEqual(null);
    });

    it('should return null if test control value is valid', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl('abc1212db', [assetCodeValidator()])
      });
      expect(assetCodeError.get('testControl').errors).toEqual(null);
    });

    it('should return assetCode in error object if test control passed non assetCodeFormat', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl('avd', [assetCodeValidator()])
      });
      expect(assetCodeError.get('testControl').errors.assetCode).toEqual(true);
    });
  });

  describe('alphaNumericValidator()', () => {
    it('should return null if test control value is null', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl(null, [alphaNumericValidator()])
      });
      expect(assetCodeError.get('testControl').errors).toEqual(null);
    });

    it('should return null if test control value is valid', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl('abc1212db', [alphaNumericValidator()])
      });
      expect(assetCodeError.get('testControl').errors).toEqual(null);
    });

    it('should return alphaNumeric in error object if test control pattern not matched', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl('+/12-', [alphaNumericValidator()])
      });
      expect(assetCodeError.get('testControl').errors.nonAlphaNumeric).toEqual(true);
    });

    it('should return alphaNumeric in error object if test control pattern not matched in anywhere in entire string ', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl('12-+', [alphaNumericValidator()])
      });
      expect(assetCodeError.get('testControl').errors.nonAlphaNumeric).toEqual(true);
    });
  });

  describe('assetSelectedValidator', () => {
    it('should return null if test control value is null', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl(null, [assetSelectedValidator])
      });
      expect(assetCodeError.get('testControl').errors).toEqual(null);
    });

    it('should return null if test control value is valid', () => {
      const validAsset = { assetId: '123', assetCode: 'test' };
      const assetCodeError = new FormGroup({
        testControl: new FormControl(validAsset, [assetSelectedValidator])
      });
      expect(assetCodeError.get('testControl').errors).toEqual(null);
    });

    it('should return assetSelectedValidator in error object if test control pattern not matched', () => {
      const assetCodeError = new FormGroup({
        testControl: new FormControl('test', [assetSelectedValidator])
      });
      expect(assetCodeError.get('testControl').errors.assetSelected).toEqual(true);
    });
  });
});
