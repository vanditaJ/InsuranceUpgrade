import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { FormArray } from '@angular/forms';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { Subscription } from 'rxjs/internal/Subscription';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import {
  ASSET_TYPES,
  DATE_PICKER_ICON,
  DELETE_BUTTON,
  SR_ONLY_BREAKPOINTS
} from '../pano-external-assets-constants/pano-external-assets.constants';
import { AssetTypeTotalDetails, ExternalAssetDeleteDetails } from '../pano-external-assets.interfaces';

@Component({
  selector: 'pano-external-assets-cash',
  templateUrl: './pano-external-assets-cash.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoExternalAssetsCashComponent implements OnChanges, OnDestroy {
  @Input() cashFormArray: FormArray;
  @Input() assetCount: number;

  @Output()
  assetDelete: EventEmitter<ExternalAssetDeleteDetails> = new EventEmitter();
  @Output()
  assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails> = new EventEmitter();

  datePickerIcon: Icon = DATE_PICKER_ICON;
  deleteButton: Button = DELETE_BUTTON;
  today: Date = moment().tz('Australia/Sydney');
  totalMarketValue: number;
  srOnlyBreakpoints = SR_ONLY_BREAKPOINTS;

  private controlsValueChangesSubscriptions: Subscription[] = [];

  constructor(private panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil) {}

  ngOnDestroy(): void {
    this.calculateTotal();
    this.unregisterControlsValueChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      get(changes, 'assetCount.currentValue') !== get(changes, 'assetCount.previousValue') ||
      get(changes, 'cashFormArray.currentValue') !== get(changes, 'cashFormArray.previousValue')
    ) {
      this.unregisterControlsValueChanges();
      this.registerControlsValueChanges();
      this.calculateTotal();
    }
  }

  registerControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges(
      this.cashFormArray,
      this.calculateTotal.bind(this)
    );
  }

  unregisterControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges(
      this.controlsValueChangesSubscriptions
    );
  }

  deleteCash(index: number, positionId: string, isNewAsset: boolean): void {
    this.panoExtAssetsCommonUtil.deleteAsset(
      {
        index,
        assetTypeCode: ASSET_TYPES.cash.code,
        positionId,
        isNewAsset
      },
      this.assetDelete
    );
  }

  calculateTotal(): void {
    this.totalMarketValue = this.panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue(
      this.cashFormArray,
      ASSET_TYPES.cash.code,
      this.assetTotalMarketValueUpdate
    );
  }
}
