import { Account } from '@investor/account/pano-shared/interfaces';

export const WGP_DISCLAIMER: string = 'WGP disclaimer {1}';
export const EY_DISCLAIMER: string = 'EY disclaimer {1}';
export const BTS_BTSFL_DISCLAIMER: string = 'BTS and BTSFL disclaimer';

export const BT_SUPER_ACCT: Partial<Account> = {
  pdsStatus: 'DEFAULT',
  productDescription: 'BT Super',
  heritageCohort: 'RETAIL'
};

export const BTSFL_NON_WGP_ACCT: Partial<Account> = {
  pdsStatus: 'DEFAULT',
  productDescription: 'BT Super for Life',
  heritageCohort: 'RETAIL'
};

export const WGP_PLUM_ACCT: Partial<Account> = {
  pdsStatus: 'WGP_CURRENT',
  productDescription: 'BT Super for Life',
  heritageCohort: 'PLUM'
};

export const WGP_OPEN_ACCT: Partial<Account> = {
  pdsStatus: 'WGP_CURRENT',
  productDescription: 'BT Super for Life',
  heritageCohort: 'OPEN'
};

export const WGP_NO_COHORT_ACCT: Partial<Account> = {
  pdsStatus: 'WGP_CURRENT',
  productDescription: 'BT Super for Life'
};

export const EY_ACCT: Partial<Account> = {
  pdsStatus: 'EY',
  productDescription: 'BT Super for Life'
};
