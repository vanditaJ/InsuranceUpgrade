export interface Email {
  email: string;
}

export interface Owner {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  emails: Array<Email>;
}

export interface Account {
  accountNumber: string;
  owners?: Owner[];
}

export interface Profile {
  clientId: string;
}

export interface NotificationResponse {
  receiptId: string;
}
