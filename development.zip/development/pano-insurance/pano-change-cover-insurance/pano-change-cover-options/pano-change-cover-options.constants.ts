import { Button } from '@bt/components/button';

import { PanoHintInlineButtons } from '../pano-change-cover-insurance.interface';

import { ContentDialogDataConfig } from './pano-content-dialog/pano-content-dialog.interfaces';

export const EXCLUSIONS_HEADER: string = 'Exclusions';

export const EXCLUSIONS_AEM_KEY: string = 'exclusions_modal';

export const PRE_EXISTING_CONDITIONS_HEADER: string = 'Pre-existing conditions';

export const PRE_EXISTING_CONDITIONS_AEM_KEY: string = 'pre_existing_conditions_modal';

export const CUSTOMISED_INSURANCE_HEADER: string = 'Customised cover';

export const CUSTOMISED_INSURANCE_AEM_KEY: string = 'customised_cover_modal';

export const DECREASE_COVER_AEM_KEY: string = 'decrease_cover_decrease_message';

export const CHANGE_COVER_AEM_KEY: string = 'change_cover_change_message';

export const CLOSE_TEXT_BUTTON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  iconPosition: 'right',
  colourModifier: 'primary',
  label: 'Close',
  size: 'large',
  type: 'solid',
  a11yProps: {
    ariaLabel: 'Close dialog'
  }
};

export const CLOSE_ICON_BUTTON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  size: 'medium',
  colourModifier: 'basic',
  a11yProps: {
    ariaLabel: 'Close dialog'
  }
};

export const PANO_HINT_INLINE_BUTTONS: PanoHintInlineButtons = {
  notBeCoveredForCertainEvents: {
    action: 'button',
    colourModifier: 'primary',
    size: 'small',
    type: 'flat',
    label: 'not be covered for certain events'
  },
  preExistingConditions: {
    action: 'button',
    colourModifier: 'primary',
    size: 'small',
    type: 'flat',
    label: 'pre-existing conditions'
  },
  customisedCover: {
    action: 'button',
    colourModifier: 'primary',
    size: 'small',
    type: 'flat',
    label: 'Customised cover'
  }
};

export const EXCLUSIONS_CONFIG: ContentDialogDataConfig = {
  headerText: EXCLUSIONS_HEADER,
  descriptionText: null,
  closeButton: CLOSE_TEXT_BUTTON,
  closeIcon: CLOSE_ICON_BUTTON
};

export const PRE_EXISTING_CONDITIONS_CONFIG: ContentDialogDataConfig = {
  headerText: PRE_EXISTING_CONDITIONS_HEADER,
  descriptionText: null,
  closeButton: CLOSE_TEXT_BUTTON,
  closeIcon: CLOSE_ICON_BUTTON
};

export const CUSTOMISED_INSURANCE_CONFIG: ContentDialogDataConfig = {
  headerText: CUSTOMISED_INSURANCE_HEADER,
  descriptionText: null,
  closeButton: CLOSE_TEXT_BUTTON,
  closeIcon: CLOSE_ICON_BUTTON
};

export const COVER_AMOUNT_CHANGE_AS_GET_OLDER_LINK =
  'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/pdf/btsfl-additional-information-booklet.pdf#page=95';
