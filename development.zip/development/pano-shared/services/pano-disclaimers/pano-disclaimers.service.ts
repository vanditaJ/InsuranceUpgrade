import { Injectable } from '@angular/core';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';

import { EY_URL, OPEN, WGP_COHORT_URL, WGP_OPEN_URL } from './pano-disclaimers.service.constants';

@Injectable()
export class PanoDisclaimersService {
  constructor(private copyMatrixPipe: CopyMatrixPipe) {}

  evaluateDisclaimer(account: any): string {
    if (account.pdsStatus === 'EY') {
      return this.copyMatrixPipe.transform('DS-IP-0379').replace('{1}', EY_URL);
    }

    if (this.isWgp(account)) {
      const link = this.isOpenOrNoCohort(account)
        ? WGP_OPEN_URL
        : WGP_COHORT_URL.replace('{cohort}', account.heritageCohort.toLowerCase());
      return this.copyMatrixPipe.transform('DS-IP-0378').replace('{1}', link);
    }

    return this.copyMatrixPipe.transform('DS-IP-0258');
  }

  private isOpenOrNoCohort(account): boolean {
    return !account.heritageCohort || account.heritageCohort === OPEN;
  }

  private isWgp(account): boolean {
    return account.pdsStatus === 'WGP_CURRENT' || account.pdsStatus === 'WGP_CEASED';
  }
}
