import { Injectable } from '@angular/core';
import { Account } from '@investor/account/pano-shared/interfaces';
import { find } from 'lodash-es';

import {
  CUSTOMER_TYPE_BT_SFL,
  CUSTOMER_TYPE_BT_SUPER,
  CUSTOMER_TYPE_BT_SUPER_LIFETIME
} from '../pano-insurance.constants';
import { InsurancePolicy } from '../pano-insurance.interface';

import { DYNAMIC_LINKS, INSURER_CODE, LinkType } from './pano-insurance-shared-link.service.constants';

@Injectable()
export class PanoInsuranceSharedLinkService {
  public getUrl(type: LinkType, policy: InsurancePolicy, account: Account): string {
    const urlMap: Record<string, string> = DYNAMIC_LINKS[type].urlMap;
    return this.getMappedUrl(urlMap, policy, account);
  }

  private getMappedUrl(urlMap: Record<string, string>, policy: InsurancePolicy, account: Account): string {
    const url = this.getUrlFromPolicyHierarchy(urlMap, policy, account);
    return this.replaceCohort(url, account.heritageCohort);
  }

  private getUrlFromPolicyHierarchy(urlMap: Record<string, string>, policy: InsurancePolicy, account: Account): string {
    const hierarchy = [];
    if (policy.insurerCode) {
      const insurerCode = find(INSURER_CODE, code => code.name === policy.insurerCode).type;
      hierarchy.push(insurerCode);
    }

    if (policy.westpacGroupPlan && (account.pdsStatus === 'WGP_CURRENT' || account.pdsStatus === 'WGP_CEASED')) {
      if (!account.heritageCohort || account.heritageCohort === 'OPEN') {
        hierarchy.push('WGP_OPEN');
      } else if (account.heritageCohort) {
        hierarchy.push('WGP_COHORT');
      }
    }

    if (policy.customerType === CUSTOMER_TYPE_BT_SFL) {
      hierarchy.push('PERSONAL_SUPER');
    } else if (policy.customerType === CUSTOMER_TYPE_BT_SUPER) {
      hierarchy.push('CORPORATE_SUPER');
    } else if (policy.customerType === CUSTOMER_TYPE_BT_SUPER_LIFETIME) {
      hierarchy.push('CORPORATE_SUPER_LIFETIME');
    }
    hierarchy.push('DEFAULT');

    // Find urls for each level added to the hierarchy, then return the url for the highest level present
    return hierarchy.map(level => urlMap[level]).filter(url => !!url)[0];
  }

  private replaceCohort(baseUrl: string, cohort: string): string {
    let url = baseUrl;
    if (url && cohort) {
      url = url.replace('{cohort}', cohort.toLowerCase());
    }
    return url;
  }
}
