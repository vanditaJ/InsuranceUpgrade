import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { FormArray } from '@angular/forms';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { Subscription } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import {
  ASSET_TYPES,
  DATE_PICKER_ICON,
  DELETE_BUTTON,
  SR_ONLY_BREAKPOINTS
} from '../pano-external-assets-constants/pano-external-assets.constants';
import { AssetTypeTotalDetails, ExternalAssetDeleteDetails } from '../pano-external-assets.interfaces';

@Component({
  selector: 'pano-external-assets-term-deposit',
  templateUrl: './pano-external-assets-term-deposit.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoExternalAssetsTermDepositComponent implements OnChanges, OnDestroy {
  @Input() tdFormArray: FormArray;
  @Input() assetCount: number;

  @Output()
  assetDelete: EventEmitter<ExternalAssetDeleteDetails> = new EventEmitter();
  @Output()
  assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails> = new EventEmitter();

  datePickerIcon: Icon = DATE_PICKER_ICON;
  deleteButton: Button = DELETE_BUTTON;
  srOnlyBreakpoints = SR_ONLY_BREAKPOINTS;
  today: Date = moment().tz('Australia/Sydney');
  totalMarketValue: number;

  private controlsValueChangesSubscriptions: Subscription[] = [];
  private maturityDateControlsValueChangesSubscriptions: Subscription[] = [];

  constructor(private panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil) {}

  ngOnDestroy(): void {
    this.calculateTotal();
    this.unregisterControlsValueChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      get(changes, 'assetCount.currentValue') !== get(changes, 'assetCount.previousValue') ||
      get(changes, 'tdFormArray.currentValue') !== get(changes, 'tdFormArray.previousValue')
    ) {
      this.unregisterControlsValueChanges();
      this.registerControlsValueChanges();
      this.calculateTotal();
    }
  }

  registerControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges(
      this.tdFormArray,
      this.calculateTotal.bind(this)
    );

    this.tdFormArray.controls.forEach(fg => {
      if (!fg.get('isNewAsset').value) {
        this.maturityDateControlsValueChangesSubscriptions.push(
          fg.get('maturityDate').valueChanges.subscribe(() => {
            fg.get('isMaturityDateChanged').setValue(true);
          })
        );
      }
    });
  }

  unregisterControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges(
      this.controlsValueChangesSubscriptions
    );
    this.maturityDateControlsValueChangesSubscriptions.forEach(subscription => subscription.unsubscribe());
    this.maturityDateControlsValueChangesSubscriptions = [];
  }

  deleteTermDeposit(index: number, positionId: string, isNewAsset: boolean): void {
    this.panoExtAssetsCommonUtil.deleteAsset(
      {
        index,
        assetTypeCode: ASSET_TYPES.td.code,
        positionId,
        isNewAsset
      },
      this.assetDelete
    );
  }

  calculateTotal(): void {
    this.totalMarketValue = this.panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue(
      this.tdFormArray,
      ASSET_TYPES.td.code,
      this.assetTotalMarketValueUpdate
    );
  }
}
