import { Injectable } from '@angular/core';
import { BtError, DataService } from '@bt/services/data';
import { Observable } from 'rxjs';

import { AEM_CONTENT_URL, GENERIC_OPTIONS } from './pano-fees.constants';
import { AemContent } from './pano-fees.interface';

@Injectable()
export class PanoFeesService {
  constructor(private dataService: DataService<AemContent | BtError>) {}

  getAemContent(): Observable<AemContent | BtError> {
    return this.dataService.retrieve(AEM_CONTENT_URL, GENERIC_OPTIONS);
  }
}
