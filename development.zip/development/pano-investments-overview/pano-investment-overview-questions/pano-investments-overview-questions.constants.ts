import { Icon } from '@bt/components/icon';
import { Optionals } from '@bt/services/data';

export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0344' };

export const INVESTMENT_OVERVIEW_FAQ_AEM_URL: string = '/content/secure/panorama/_services/investments-overview/faq';

export const AEM_URL_SUFFIX: string = '_jcr_content.getAggr.getContentPage.json';

export const EXPANSION_ICON: Icon = {
  name: 'icon-chevron-right',
  size: 'x-small'
};
