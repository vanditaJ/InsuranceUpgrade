import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { IconModule } from '@bt/components/icon';
import { LinkModule } from '@bt/components/link';
import { LoadingModule } from '@bt/components/loading';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataModule } from '@bt/services/data';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';
import { NgxMaskModule } from 'ngx-mask';

import { PanoEmployerContributionsDetailsComponent } from './pano-employer-contributions-details/pano-employer-contributions-details.component';
import { panoEmployerContributionsDetailsResolver } from './pano-employer-contributions-details/pano-employer-contributions-details.resolver';
import { PanoEmployerContributionsDetailsService } from './pano-employer-contributions-details/pano-employer-contributions-details.service';

@NgModule({
  declarations: [PanoEmployerContributionsDetailsComponent],
  providers: [PanoEmployerContributionsDetailsService],
  entryComponents: [PanoEmployerContributionsDetailsComponent],
  imports: [
    AlertModule,
    ButtonModule,
    CommonModule,
    CopyMatrixPipeModule,
    DataModule,
    IconModule,
    LayoutModule,
    LinkModule,
    LoadingModule,
    HttpClientModule,
    MatButtonToggleModule,
    MatFormFieldModule,
    MatRadioModule,
    MatInputModule,
    NgxMaskModule.forRoot({}),
    ReactiveFormsModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.employerContributions',
          url: '/employer-contributions',
          component: PanoEmployerContributionsDetailsComponent,
          data: {
            requiredPermissions: {
              rule: 'corporatesuper.view',
              targetId: 'a'
            },
            title: 'Employer contributions'
          },
          resolve: {
            account: ['$transition$', panoEmployerContributionsDetailsResolver]
          }
        }
      ]
    })
  ]
})
export class PanoEmployerContributionsModule {}
