import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { cloneDeep } from 'lodash-es';
import { noop, of, throwError } from 'rxjs';

import {
  ASSET_TOTAL_VALUATION,
  SOFTWARE_DATA_CONNECTED_STATE,
  SOFTWARE_DATA_MANUAL_STATE,
  SOFTWARE_DATA_PENDING_STATE,
  SOFTWARE_STATUS_DATA_CONNECTED,
  SOFTWARE_STATUS_DATA_MANUAL,
  SOFTWARE_STATUS_DATA_PENDING
} from './pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { AccountingSoftwareStatus } from './pano-external-assets.interfaces';
import { panoExternalAssetsResolveData } from './pano-external-assets.resolver';
import { PanoExternalAssetsService } from './pano-external-assets.service';

describe('panoExternalAssetsResolveData', () => {
  const successHandler: jasmine.Spy = jasmine.createSpy();
  const errorHandler: jasmine.Spy = jasmine.createSpy();

  let externalAssetsServiceSpyObj: jasmine.SpyObj<PanoExternalAssetsService>;
  let accountServiceSpyObj: jasmine.SpyObj<PanoUpgradeAccountService>;

  beforeEach(() => {
    externalAssetsServiceSpyObj = jasmine.createSpyObj('PanoExternalAssetsService', [
      'getAccountingSoftwareStatus',
      'getValuationForExternalAsset'
    ]);
    accountServiceSpyObj = jasmine.createSpyObj('PanoUpgradeAccountService', ['getAccountId']);
  });

  afterEach(() => {
    externalAssetsServiceSpyObj.getAccountingSoftwareStatus.calls.reset();
    externalAssetsServiceSpyObj.getValuationForExternalAsset.calls.reset();
    accountServiceSpyObj.getAccountId.calls.reset();
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  it('calls getAccountingSoftwareStatus method with account id as input ', () => {
    const accountId = '123';
    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(noop, noop);

    expect(externalAssetsServiceSpyObj.getAccountingSoftwareStatus).toHaveBeenCalledWith(accountId);
  });

  describe('with pending connection', () => {
    const accountId = '123';

    it('getAccountingSoftwareStatus should resolve data with screen type pending with only status service call', () => {
      accountServiceSpyObj.getAccountId.and.returnValue(accountId);
      const data: AccountingSoftwareStatus = cloneDeep(SOFTWARE_STATUS_DATA_PENDING);
      externalAssetsServiceSpyObj.getAccountingSoftwareStatus.and.returnValue(of(data));
      panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(
        successHandler,
        errorHandler
      );

      expect(externalAssetsServiceSpyObj.getValuationForExternalAsset).not.toHaveBeenCalled();
      expect(successHandler).toHaveBeenCalledWith(SOFTWARE_DATA_PENDING_STATE);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('getAccountingSoftwareStatus should not resolve data in case of error', () => {
      accountServiceSpyObj.getAccountId.and.returnValue(accountId);
      externalAssetsServiceSpyObj.getAccountingSoftwareStatus.and.returnValue(throwError('error'));
      panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(
        successHandler,
        errorHandler
      );

      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalled();
    });
  });

  describe('with manual connection', () => {
    it('getAccountingSoftwareStatus should resolve data with screen type manual with only status service call', () => {
      accountServiceSpyObj.getAccountId.and.returnValue('123');
      const data: AccountingSoftwareStatus = cloneDeep(SOFTWARE_STATUS_DATA_MANUAL);
      externalAssetsServiceSpyObj.getAccountingSoftwareStatus.and.returnValue(of(data));
      panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(
        successHandler,
        errorHandler
      );

      expect(externalAssetsServiceSpyObj.getValuationForExternalAsset).not.toHaveBeenCalled();
      expect(successHandler).toHaveBeenCalledWith(SOFTWARE_DATA_MANUAL_STATE);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('getAccountingSoftwareStatus should not resolve data in case of error', () => {
      accountServiceSpyObj.getAccountId.and.returnValue('456');
      externalAssetsServiceSpyObj.getAccountingSoftwareStatus.and.returnValue(throwError('error'));
      panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(
        successHandler,
        errorHandler
      );

      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalled();
    });
  });

  describe('with connected connection', () => {
    it('getAccountingSoftwareStatus should resolve data with screen type connected with valuation call as well', () => {
      accountServiceSpyObj.getAccountId.and.returnValue('123');
      const data: AccountingSoftwareStatus = cloneDeep(SOFTWARE_STATUS_DATA_CONNECTED);
      externalAssetsServiceSpyObj.getAccountingSoftwareStatus.and.returnValue(of(data));
      externalAssetsServiceSpyObj.getValuationForExternalAsset.and.returnValue(of(cloneDeep(ASSET_TOTAL_VALUATION)));
      panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(
        successHandler,
        errorHandler
      );

      expect(externalAssetsServiceSpyObj.getValuationForExternalAsset).toHaveBeenCalled();
      expect(successHandler).toHaveBeenCalledWith(SOFTWARE_DATA_CONNECTED_STATE);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should fail if first account software status getAccountingSoftwareStatus service get success but valuation service gets failed', () => {
      accountServiceSpyObj.getAccountId.and.returnValue('123');
      const data: AccountingSoftwareStatus = cloneDeep(SOFTWARE_STATUS_DATA_CONNECTED);
      externalAssetsServiceSpyObj.getAccountingSoftwareStatus.and.returnValue(of(data));
      externalAssetsServiceSpyObj.getValuationForExternalAsset.and.returnValue(throwError('error'));
      panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(
        successHandler,
        errorHandler
      );

      expect(externalAssetsServiceSpyObj.getValuationForExternalAsset).toHaveBeenCalled();
      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalled();
    });

    it('should not call valuation service in case first software status getAccountingSoftwareStatus service itself gets failed', () => {
      accountServiceSpyObj.getAccountId.and.returnValue('456');
      externalAssetsServiceSpyObj.getAccountingSoftwareStatus.and.returnValue(throwError('error'));
      panoExternalAssetsResolveData(accountServiceSpyObj, externalAssetsServiceSpyObj).subscribe(
        successHandler,
        errorHandler
      );

      expect(externalAssetsServiceSpyObj.getValuationForExternalAsset).not.toHaveBeenCalled();
      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalled();
    });
  });
});
