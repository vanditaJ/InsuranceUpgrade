import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AnalyticsModule, AnalyticsService } from '@bt/services/analytics';
import { ANALYTICS_CONFIG, API_BASE_PATH } from '@bt/tokens';
import { UIRouter } from '@uirouter/angular';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { PanoFormsComponent } from './pano-forms.component';
import { DOCUMENT_LIBRARY_MODULE_NAME, SERVICE_REQUESTS_CONFIGS } from './pano-forms.constants';

describe('PanoFormsComponent', () => {
  let component: PanoFormsComponent;
  let fixture: ComponentFixture<PanoFormsComponent>;
  let uiRouter: UIRouter;
  let analyticsService: AnalyticsService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [AnalyticsModule],
        declarations: [PanoFormsComponent],
        providers: [
          { provide: ANALYTICS_CONFIG, useValue: {} },
          {
            provide: API_BASE_PATH,
            useValue: { monolith: '/ng/secure', investor: '/investor/secure', professional: '/professional/secure' }
          },
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccountId: () => '12345'
            }
          },
          {
            provide: UIRouter,
            useValue: {
              stateService: {
                go: jasmine.createSpy()
              }
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoFormsComponent);
    component = fixture.componentInstance;
    uiRouter = TestBed.inject(UIRouter);
    analyticsService = TestBed.inject(AnalyticsService);
  });

  describe('component', () => {
    it('should create', () => expect(component).toBeTruthy());

    describe('ngOnInit()', () => {
      it('should call analyticsService.track with correct arguments', () => {
        spyOn(analyticsService, 'track');
        component.ngOnInit();

        expect(analyticsService.track).toHaveBeenCalledWith({
          pageName: 'investor-forms'
        });
      });

      it('should create config for pano-service-requests correctly', () => {
        component.ngOnInit();

        expect(component.serviceRequestsConfig).toEqual({
          apiUrl: '/investor/secure/api/v1/account/12345/service-requests',
          ...SERVICE_REQUESTS_CONFIGS
        });
      });
    });

    describe('navigateToDocumentLibrary()', () => {
      it('should call uiRouter.stateService.go with correct param', () => {
        component.navigateToDocumentLibrary();

        expect(uiRouter.stateService.go).toHaveBeenCalledOnceWith(DOCUMENT_LIBRARY_MODULE_NAME);
      });
    });
  });

  describe('view', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should show a h1', () => {
      expect(fixture.debugElement.query(By.css('h1')).nativeElement.innerHTML).toBe('Forms');
    });

    it('followed by p', () => {
      expect(fixture.debugElement.query(By.css('p')).nativeElement.innerHTML?.trim()).toBe(
        'Find the form you need, then complete and send it to BT, Once we have received your form, it will display on the Forms status page.'
      );
    });

    describe('followed by mat-tab', () => {
      let matTabs: DebugElement[];

      beforeEach(() => {
        matTabs = fixture.debugElement.queryAll(By.css('mat-tab'));
      });

      it('tab-1: should have correct label and content - p element and bt-button', () => {
        expect(matTabs[0].nativeElement.getAttribute('label')).toBe('List of forms');

        expect(matTabs[0].query(By.css('p')).nativeElement.innerHTML).toBe(
          'Forms are available in your Document library for downloading.'
        );

        const btButton = matTabs[0].query(By.css('bt-button'));
        expect(btButton.properties.config).toEqual(component.goToDocumentLibrabry);

        spyOn(component, 'navigateToDocumentLibrary');
        btButton.nativeElement.dispatchEvent(new Event('btClick'));

        expect(component.navigateToDocumentLibrary).toHaveBeenCalled();
      });

      it('tab-2: should have correct label and content - pano-service-requests', () => {
        expect(matTabs[1].nativeElement.getAttribute('label')).toBe('Forms status');

        expect(matTabs[1].query(By.css('pano-service-requests')).properties.config).toEqual(
          component.serviceRequestsConfig
        );
      });
    });
  });
});
