import { Injectable } from '@angular/core';
import { Link } from '@bt/components/link';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoUpgradePermissionService } from '@upgrade/upgrade.services';

import { LinkType, WGP_DYNAMIC_LINKS } from './pano-super-link.service.constants';

@Injectable()
export class PanoSuperLinkService {
  constructor(private readonly permissionService: PanoUpgradePermissionService) {}

  public getUrl(type: LinkType, accountId: string, account: Account): string {
    if (this.isEnabled(type, accountId)) {
      const urlMap: Record<string, string> = WGP_DYNAMIC_LINKS[type].urlMap;
      return this.getMappedUrl(urlMap, accountId, account);
    }
    return null;
  }

  public getLink(type: LinkType, accountId: string, account: Account): Link {
    const linkUrl: string = this.getUrl(type, accountId, account);
    let link: Link;
    if (linkUrl) {
      link = WGP_DYNAMIC_LINKS[type].link;
      link.link = this.getUrl(type, accountId, account);
    }
    return link;
  }

  public getLinks(types: Array<LinkType>, accountId: string, account: Account): Array<Link> {
    return types.map(type => this.getLink(type, accountId, account)).filter(link => !!link);
  }

  private isEnabled(type: LinkType, accountId: string) {
    const permission = WGP_DYNAMIC_LINKS[type].permission;
    if (permission) {
      return this.permissionService.hasPermission(permission, accountId);
    }
    return true;
  }

  private getMappedUrl(urlMap: Record<string, string>, accountId: string, account: Account): string {
    let url = this.getUrlFromHierarchy(urlMap, account);
    url = this.replaceCohort(url, account.heritageCohort);
    url = this.replaceAccount(url, accountId);
    return url;
  }

  private getUrlFromHierarchy(urlMap: Record<string, string>, account: Account): string {
    const hierarchy = [];
    if (account.pdsStatus === 'EY') {
      hierarchy.push('EY');
    }
    if (account.pdsStatus === 'WGP_CURRENT' || account.pdsStatus === 'WGP_CEASED') {
      if (!account.heritageCohort || account.heritageCohort === 'OPEN') {
        hierarchy.push('WGP_OPEN');
      } else if (account.heritageCohort) {
        hierarchy.push('WGP_COHORT');
      }
    }
    hierarchy.push(account.product.productSubType);
    hierarchy.push('DEFAULT');

    // Find urls for each level added to the hierarchy, then return the url for the highest level present
    return hierarchy.map(level => urlMap[level]).filter(url => url === '' || !!url)[0];
  }

  private replaceCohort(baseUrl: string, cohort: string): string {
    let url = baseUrl;
    if (url && cohort) {
      url = url.replace('{cohort}', cohort.toLowerCase());
    }
    return url;
  }

  private replaceAccount(baseUrl: string, accountId: string): string {
    let url = baseUrl;
    if (url && accountId) {
      url = url.replace('{account}', accountId);
    }
    return url;
  }
}
