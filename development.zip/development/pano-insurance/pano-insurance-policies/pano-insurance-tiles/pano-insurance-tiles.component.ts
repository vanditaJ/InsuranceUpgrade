import { Component } from '@angular/core';

import { INSURANCE_TILES } from './pano-insurance-tiles.constants';
import { InsuranceTile } from './pano-insurance-tiles.interface';

@Component({
  selector: 'pano-insurance-tiles',
  templateUrl: './pano-insurance-tiles.component.html',
  styleUrls: ['./pano-insurance-tiles.component.scss']
})
export class PanoInsuranceTilesComponent {
  tiles: InsuranceTile[] = INSURANCE_TILES;
}
