import { Component } from '@angular/core';
import { Alert } from '@bt/components/alert';

import { ACCOUNTING_SOFTWARE_CONNECTION_PENDING_ALERT } from '../pano-external-assets.constants';

@Component({
  selector: 'pano-external-assets-connection-pending',
  templateUrl: './pano-external-assets-connection-pending.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoExternalAssetsConnectionPendingComponent {
  warningAlert: Alert = ACCOUNTING_SOFTWARE_CONNECTION_PENDING_ALERT;
}
