import { NgModule } from '@angular/core';
import { panoAccountResolver } from '@investor/account/pano-shared/resolvers';
import { LayoutModule } from '@panorama/components/layout';
import { DocumentLibraryModule } from '@panorama/doc-library';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';

import { PanoDocumentsComponent } from './pano-documents.component';

@NgModule({
  declarations: [PanoDocumentsComponent],
  providers: [],
  entryComponents: [],
  imports: [
    DocumentLibraryModule,
    LayoutModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.documentLibrary',
          url: '/document-library',
          component: PanoDocumentsComponent,
          data: {
            title: 'Document library'
          },
          resolve: {
            account: ['$transition$', panoAccountResolver]
          }
        }
      ]
    })
  ]
})
export class PanoDocumentsModule {}
