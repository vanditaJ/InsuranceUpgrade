import { Component, EventEmitter, Input, NO_ERRORS_SCHEMA, Output } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { MOCK_INVESTMENT_PROFILE } from '@investor/account/pano-shared/components/pano-inv-profile/pano-inv-profile.constants.spec';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { cloneDeep } from 'lodash-es';

import { INVESTMENT_TYPES } from '../pano-inv-profile.constants';
import {
  InvestmentObjective,
  InvestmentProfile,
  InvestmentTimeframe,
  RedemptionFrequency,
  ReturnObjective
} from '../pano-inv-profile.interface';

import { PanoInvestmentPreferencesComponent } from './pano-inv-pref/pano-inv-pref.component';
import { PanoInvestmentProfileSetupComponent } from './pano-inv-profile-setup.component';
import {
  MOCK_INVESTMENT_OBJECTIVES,
  MOCK_INVESTMENT_TIMEFRAMES,
  MOCK_REDEMPTION_FREQUENCIES,
  MOCK_RETURN_OBJECTIVES
} from './pano-inv-profile-setup.component.data.spec';
import {
  INVESTMENT_OBJECTIVES,
  INVESTMENT_TIMEFRAMES,
  LIQUIDITY_NEED_SLIDER,
  RISK_SLIDER
} from './pano-inv-profile-setup.constants';
import { PanoInvestmentTypesComponent } from './pano-inv-types/pano-inv-types.component';

@Component({
  template: `
    <pano-inv-profile-setup [profile]="profile"> </pano-inv-profile-setup>
  `
})
class TestHostComponent {
  profile: InvestmentProfile = MOCK_INVESTMENT_PROFILE;
}

@Component({
  selector: 'pano-inv-types',
  template: ``
})
class TestPanoInvestmentTypesComponent {
  @Input() investmentType: string;
  @Output() investmentTypeChange: EventEmitter<string> = new EventEmitter();

  public form: FormGroup = new FormGroup({
    investmentType: new FormControl()
  });
}

describe('PanoInvestmentProfileSetupComponent', () => {
  let component: PanoInvestmentProfileSetupComponent;
  let fixture: ComponentFixture<PanoInvestmentProfileSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [PanoInvestmentProfileSetupComponent, TestHostComponent],
      providers: [
        {
          provide: PanoUpgradeAccountService,
          useValue: {
            getAccountId: () => '12345678'
          }
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentProfileSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct input with its host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const hostComponent = hostFixture.componentInstance;
      const currentComp: PanoInvestmentProfileSetupComponent = hostFixture.debugElement.query(
        By.directive(PanoInvestmentProfileSetupComponent)
      ).componentInstance;

      hostFixture.detectChanges();

      expect(currentComp.profile).toEqual(hostComponent.profile);
    });

    describe('ngOnInit()', () => {
      it('should save profile passed in', () => {
        component.profile = MOCK_INVESTMENT_PROFILE;

        component.ngOnInit();

        expect(component.existingProfile).toEqual(component.profile);
      });

      it('should call resetProfilePreferences()', () => {
        spyOn(component as any, 'resetProfilePreferences').and.stub();
        component.profile = MOCK_INVESTMENT_PROFILE;

        component.ngOnInit();

        expect((component as any).resetProfilePreferences).toHaveBeenCalledWith(true);
      });

      it('should call transformInvestmentPreferencesFromTextValue() if it has existing profile', () => {
        spyOn(component as any, 'transformInvestmentPreferencesFromTextValue').and.stub();
        component.profile = MOCK_INVESTMENT_PROFILE;

        component.ngOnInit();

        expect((component as any).transformInvestmentPreferencesFromTextValue).toHaveBeenCalled();
      });

      it('should NOT call transformInvestmentPreferencesFromTextValue() if it has NO  existing profile', () => {
        spyOn(component as any, 'transformInvestmentPreferencesFromTextValue').and.stub();
        component.profile = undefined;

        component.ngOnInit();

        expect((component as any).transformInvestmentPreferencesFromTextValue).not.toHaveBeenCalled();
      });

      it('should call saveTransformedProfilePreferences()', () => {
        spyOn(component as any, 'saveTransformedProfilePreferences').and.stub();
        component.profile = MOCK_INVESTMENT_PROFILE;

        component.ngOnInit();

        expect((component as any).saveTransformedProfilePreferences).toHaveBeenCalled();
      });
    });

    describe('initInvestmentProfile()', () => {
      it('should init investment profile corretly', () => {
        component.profile = undefined;
        component.accountId = 'TEST ACCOUNT';

        component.initInvestmentProfile();

        expect(component.profile).toBeTruthy();
        expect(component.profile.accountId).toBe(component.accountId);
        expect(component.profile.investmentType).toBe('');
      });
    });

    describe('resetInvestmentProfile()', () => {
      it('should call resetProfilePreferences()', () => {
        spyOn(component as any, 'resetProfilePreferences').and.stub();
        component.existingProfile = MOCK_INVESTMENT_PROFILE;

        (component as any).resetInvestmentProfile();

        expect((component as any).resetProfilePreferences).toHaveBeenCalledWith();
      });

      describe('when investmentPreferencesComponent exists', () => {
        beforeEach(() => {
          component.profile = cloneDeep(MOCK_INVESTMENT_PROFILE);
          component.investmentPreferencesComponent = TestBed.createComponent(PanoInvestmentPreferencesComponent)
            .componentInstance as PanoInvestmentPreferencesComponent;

          component.existingProfile = undefined;
          spyOn(component as any, 'resetProfilePreferences').and.stub();

          (component as any).resetInvestmentProfile();
        });

        it('should setup noInvestmentObjectivesChecked as false', () => {
          expect(component.investmentPreferencesComponent.noInvestmentObjectivesChecked).toBeFalse();
        });

        it('should setup noInvestmentTimeframesChecked as false', () => {
          expect(component.investmentPreferencesComponent.noInvestmentTimeframesChecked).toBeFalse();
        });
      });
    });

    describe('saveInvestmentProfile()', () => {
      it('should mark investmentTypesComponent form control investmenyType touched', () => {
        component.profile = cloneDeep(MOCK_INVESTMENT_PROFILE);
        component.investmentTypesComponent = TestBed.createComponent(TestPanoInvestmentTypesComponent)
          .componentInstance as PanoInvestmentTypesComponent;
        const touchedSpy = spyOn(component.investmentTypesComponent.form.controls.investmentType, 'markAsTouched');

        component.saveInvestmentProfile();

        expect(touchedSpy).toHaveBeenCalled();
      });

      it('should update investment objectives state if investmentPreferencesComponent exists', () => {
        component.profile = cloneDeep(MOCK_INVESTMENT_PROFILE);
        component.investmentPreferencesComponent = TestBed.createComponent(PanoInvestmentPreferencesComponent)
          .componentInstance as PanoInvestmentPreferencesComponent;
        component.investmentTypesComponent = TestBed.createComponent(TestPanoInvestmentTypesComponent)
          .componentInstance as PanoInvestmentTypesComponent;
        const updateInvestmentObjectivesStateSpy = spyOn(
          component.investmentPreferencesComponent,
          'updateInvestmentObjectivesState'
        );
        spyOn(component.investmentPreferencesComponent, 'updateInvestmentTimeframesState').and.stub();

        component.saveInvestmentProfile();

        expect(updateInvestmentObjectivesStateSpy).toHaveBeenCalled();
      });

      it('should update investment timeframes state if investmentPreferencesComponent exists', () => {
        component.profile = cloneDeep(MOCK_INVESTMENT_PROFILE);
        component.investmentPreferencesComponent = TestBed.createComponent(PanoInvestmentPreferencesComponent)
          .componentInstance as PanoInvestmentPreferencesComponent;
        component.investmentTypesComponent = TestBed.createComponent(TestPanoInvestmentTypesComponent)
          .componentInstance as PanoInvestmentTypesComponent;
        spyOn(component.investmentPreferencesComponent, 'updateInvestmentObjectivesState').and.stub();
        const updateInvestmentTimeframesStateSpy = spyOn(
          component.investmentPreferencesComponent,
          'updateInvestmentTimeframesState'
        );

        component.saveInvestmentProfile();

        expect(updateInvestmentTimeframesStateSpy).toHaveBeenCalled();
      });

      describe('when investmentType is ALL_INVESTMENT_TYPES', () => {
        beforeEach(() => {
          component.profile = cloneDeep(MOCK_INVESTMENT_PROFILE);
          component.profile.investmentType = INVESTMENT_TYPES.ALL_INVESTMENT_TYPES;

          fixture.detectChanges();

          component.investmentTypesComponent = TestBed.createComponent(TestPanoInvestmentTypesComponent)
            .componentInstance as PanoInvestmentTypesComponent;
          spyOn(component.saveProfile, 'emit').and.stub();

          component.saveInvestmentProfile();
        });

        it('should call transformInvestmentPreferencesToTextValue', () => {
          const profile: InvestmentProfile = {
            accountId: 'test this.accountId',
            investmentType: 'test this.profile.investmentType',
            investmentObjectives: [InvestmentObjective.CAPITAL_GROWTH],
            investmentTimeframes: [InvestmentTimeframe.LONG]
          };
          spyOn(component as any, 'transformInvestmentPreferencesToTextValue').and.returnValue(profile);

          component.saveInvestmentProfile();

          expect((component as any).transformInvestmentPreferencesToTextValue).toHaveBeenCalled();
        });

        it('should call saveProfile.emit() if investmentObjectives and investmentTimeframes are not emtpy', () => {
          const profile: InvestmentProfile = {
            accountId: 'test this.accountId',
            investmentType: 'test this.profile.investmentType',
            investmentObjectives: [InvestmentObjective.CAPITAL_GROWTH],
            investmentTimeframes: [InvestmentTimeframe.LONG]
          };
          spyOn(component as any, 'transformInvestmentPreferencesToTextValue').and.returnValue(profile);

          component.saveInvestmentProfile();

          expect(component.saveProfile.emit).toHaveBeenCalled();
        });

        it('should NOT call saveProfile.emit() if investmentObjectives and investmentTimeframes are not emtpy', () => {
          component.investmentObjectives = [];
          component.investmentTimeframes = [];

          component.saveInvestmentProfile();

          expect(component.saveProfile.emit).not.toHaveBeenCalled();
        });
      });

      describe('when investmentType is SHARES_AND_ETFS', () => {
        beforeEach(() => {
          component.profile = cloneDeep(MOCK_INVESTMENT_PROFILE);
          component.profile.investmentType = INVESTMENT_TYPES.SHARES_AND_ETFS;

          fixture.detectChanges();

          component.investmentTypesComponent = TestBed.createComponent(TestPanoInvestmentTypesComponent)
            .componentInstance as PanoInvestmentTypesComponent;
          spyOn(component.saveProfile, 'emit').and.stub();
          spyOn(component as any, 'transformInvestmentPreferencesToTextValue').and.stub();

          component.saveInvestmentProfile();
        });

        it('should NOT call transformInvestmentPreferencesToTextValue if investmentType is SHARES_AND_ETFS', () => {
          expect((component as any).transformInvestmentPreferencesToTextValue).not.toHaveBeenCalled();
        });

        it('should call saveProfile.emit() if investmentType is SHARES_AND_ETFS ', () => {
          expect(component.saveProfile.emit).toHaveBeenCalled();
        });
      });

      describe('when investmentType is invalid', () => {
        beforeEach(() => {
          component.profile = cloneDeep(MOCK_INVESTMENT_PROFILE);
          component.profile.investmentType = undefined;

          fixture.detectChanges();

          component.investmentTypesComponent = TestBed.createComponent(TestPanoInvestmentTypesComponent)
            .componentInstance as PanoInvestmentTypesComponent;
          spyOn(component.saveProfile, 'emit').and.stub();
          spyOn(component as any, 'transformInvestmentPreferencesToTextValue').and.stub();

          component.saveInvestmentProfile();
        });

        it('should NOT call transformInvestmentPreferencesToTextValue if investmentType is invalid', () => {
          expect((component as any).transformInvestmentPreferencesToTextValue).not.toHaveBeenCalled();
        });

        it('should NOT call saveProfile.emit() if investmentType is invalid ', () => {
          expect(component.saveProfile.emit).not.toHaveBeenCalled();
        });
      });
    });

    describe('resetProfilePreferences()', () => {
      it('should init investment prefereces with init values if isInit is true', () => {
        (component as any).resetProfilePreferences(true);

        expect(component.investmentObjectives).toEqual(INVESTMENT_OBJECTIVES);
        expect(component.investmentTimeframes).toEqual(INVESTMENT_TIMEFRAMES);
        expect(component.riskReturnObjectives).toEqual(RISK_SLIDER);
        expect(component.redemptionFrequencies).toEqual(LIQUIDITY_NEED_SLIDER);
      });

      it('should reset investment prefereces with previsous transformed preferecess if isInit is true', () => {
        component.transformedInvestmentObjectives = MOCK_INVESTMENT_OBJECTIVES;
        component.transformedInvestmentTimeframes = MOCK_INVESTMENT_TIMEFRAMES;
        component.transformedReturnObjectives = MOCK_RETURN_OBJECTIVES;
        component.transformedRedemptionFrequencies = MOCK_REDEMPTION_FREQUENCIES;

        (component as any).resetProfilePreferences();

        expect(component.investmentObjectives).toEqual(MOCK_INVESTMENT_OBJECTIVES);
        expect(component.investmentTimeframes).toEqual(MOCK_INVESTMENT_TIMEFRAMES);
        expect(component.riskReturnObjectives).toEqual(MOCK_RETURN_OBJECTIVES);
        expect(component.redemptionFrequencies).toEqual(MOCK_REDEMPTION_FREQUENCIES);
      });
    });

    describe('saveTransformedProfilePreferences()', () => {
      it('should save investment prefereces', () => {
        component.investmentObjectives = MOCK_INVESTMENT_OBJECTIVES;
        component.investmentTimeframes = MOCK_INVESTMENT_TIMEFRAMES;
        component.riskReturnObjectives = MOCK_RETURN_OBJECTIVES;
        component.redemptionFrequencies = MOCK_REDEMPTION_FREQUENCIES;

        (component as any).saveTransformedProfilePreferences();

        expect(component.transformedInvestmentObjectives).toEqual(MOCK_INVESTMENT_OBJECTIVES);
        expect(component.transformedInvestmentTimeframes).toEqual(MOCK_INVESTMENT_TIMEFRAMES);
        expect(component.transformedReturnObjectives).toEqual(MOCK_RETURN_OBJECTIVES);
        expect(component.transformedRedemptionFrequencies).toEqual(MOCK_REDEMPTION_FREQUENCIES);
      });
    });

    describe('transformInvestmentPreferencesFromTextValue()', () => {
      beforeEach(() => {
        component.existingProfile = cloneDeep(MOCK_INVESTMENT_PROFILE);
        (component as any).resetProfilePreferences();
      });

      it('should transform investmentObjectives from text value corretly', () => {
        (component as any).transformInvestmentPreferencesFromTextValue(component.existingProfile);

        expect(component.investmentObjectives).toBeTruthy();

        component.existingProfile.investmentObjectives.forEach(objectiveIn =>
          expect(component.investmentObjectives.find(objective => objective.name === objectiveIn).value).toBeTrue()
        );
      });

      it('should transform investmentTimeframes from text value corretly', () => {
        (component as any).transformInvestmentPreferencesFromTextValue(component.existingProfile);

        expect(component.investmentTimeframes).toBeTruthy();
        component.existingProfile.investmentTimeframes.forEach(timeFrameIn =>
          expect(component.investmentTimeframes.find(timeFrame => timeFrame.name === timeFrameIn).value).toBeTrue()
        );
      });

      describe('transform riskReturnObjectives()', () => {
        it('should transform riskReturnObjectives from text value corretly if riskReturnObjectives have two values', () => {
          (component as any).transformInvestmentPreferencesFromTextValue(component.existingProfile);

          expect(component.riskReturnObjectives).toBeTruthy();

          const expectedReturnObjectiveValue = Object.values(ReturnObjective).findIndex(
            returnObjective => returnObjective === component.existingProfile.riskReturnObjectives[0]
          );
          expect(component.riskReturnObjectives.minValue).toBe(expectedReturnObjectiveValue);

          const expectedReturnObjectiveHighValue = Object.values(ReturnObjective).findIndex(
            returnObjective => returnObjective === component.existingProfile.riskReturnObjectives[1]
          );
          expect(component.riskReturnObjectives.maxValue).toBe(expectedReturnObjectiveHighValue);
        });

        it('should transform riskReturnObjectives from text value corretly if riskReturnObjectives only have one value', () => {
          component.existingProfile.riskReturnObjectives.splice(1);

          (component as any).transformInvestmentPreferencesFromTextValue(component.existingProfile);

          expect(component.riskReturnObjectives).toBeTruthy();

          const expectedReturnObjectiveValue = Object.values(ReturnObjective).findIndex(
            returnObjective => returnObjective === component.existingProfile.riskReturnObjectives[0]
          );
          expect(component.riskReturnObjectives.minValue).toBe(expectedReturnObjectiveValue);
          expect(component.riskReturnObjectives.maxValue).toBe(component.riskReturnObjectives.minValue);
        });
      });

      describe('transform redemptionFrequencies()', () => {
        it('should transform redemptionFrequencies from text value corretly if redemptionFrequencies have two values', () => {
          (component as any).transformInvestmentPreferencesFromTextValue(component.existingProfile);

          expect(component.redemptionFrequencies).toBeTruthy();

          const expectedRedemptionFrequencyValue = Object.values(RedemptionFrequency).findIndex(
            redemptionFrequency => redemptionFrequency === component.existingProfile.redemptionFrequencies[0]
          );
          expect(component.redemptionFrequencies.minValue).toBe(expectedRedemptionFrequencyValue);

          const expectedRedemptionFrequencyHighValue = Object.values(RedemptionFrequency).findIndex(
            redemptionFrequency => redemptionFrequency === component.existingProfile.redemptionFrequencies[1]
          );
          expect(component.redemptionFrequencies.maxValue).toBe(expectedRedemptionFrequencyHighValue);
        });

        it('should transform redemptionFrequencies from text value corretly if redemptionFrequencies only have one value', () => {
          component.existingProfile.redemptionFrequencies.splice(1);

          (component as any).transformInvestmentPreferencesFromTextValue(component.existingProfile);

          expect(component.redemptionFrequencies).toBeTruthy();

          const expectedRedemptionFrequencyValue = Object.values(RedemptionFrequency).findIndex(
            redemptionFrequency => redemptionFrequency === component.existingProfile.redemptionFrequencies[0]
          );
          expect(component.redemptionFrequencies.minValue).toBe(expectedRedemptionFrequencyValue);
          expect(component.redemptionFrequencies.maxValue).toBe(component.redemptionFrequencies.minValue);
        });
      });
    });

    describe('transformInvestmentPreferencesToTextValue()', () => {
      it('should set up investmentObjectives with text value', () => {
        const profile: InvestmentProfile = { accountId: 'test', investmentType: 'test' };
        component.investmentObjectives = cloneDeep(MOCK_INVESTMENT_OBJECTIVES);

        const newProfile = (component as any).transformInvestmentPreferencesToTextValue(profile);
        expect(newProfile.investmentObjectives).toBeTruthy();
        expect(newProfile.investmentObjectives.length).toBe(2);
        expect(newProfile.investmentObjectives[0]).toBe('REGULAR_INCOME');
        expect(newProfile.investmentObjectives[1]).toBe('CAPITAL_GUARANTEED');
      });

      it('should set up investmentTimeframes with text value', () => {
        const profile: InvestmentProfile = { accountId: 'test', investmentType: 'test' };
        component.investmentTimeframes = cloneDeep(MOCK_INVESTMENT_TIMEFRAMES);

        const newProfile = (component as any).transformInvestmentPreferencesToTextValue(profile);

        expect(newProfile.investmentTimeframes).toBeTruthy();
        expect(newProfile.investmentTimeframes.length).toBe(2);
        expect(newProfile.investmentTimeframes[0]).toBe('SHORT');
        expect(newProfile.investmentTimeframes[1]).toBe('MEDIUM');
      });

      it('should setup riskReturnObjectives with text value', () => {
        const profile: InvestmentProfile = { accountId: 'test', investmentType: 'test' };
        component.riskReturnObjectives = cloneDeep(MOCK_RETURN_OBJECTIVES);

        const newProfile = (component as any).transformInvestmentPreferencesToTextValue(profile);

        expect(newProfile.riskReturnObjectives).toBeTruthy();
        expect(newProfile.riskReturnObjectives.length).toBe(2);
        expect(newProfile.riskReturnObjectives[0]).toBe('LOW');
        expect(newProfile.riskReturnObjectives[1]).toBe('MEDIUM');

        component.riskReturnObjectives.minValue = component.riskReturnObjectives.maxValue;

        const newProfileWithOneReturnObjectiveValue = (component as any).transformInvestmentPreferencesToTextValue(
          profile
        );

        expect(newProfileWithOneReturnObjectiveValue.riskReturnObjectives).toBeTruthy();
        expect(newProfileWithOneReturnObjectiveValue.riskReturnObjectives.length).toBe(1);
        expect(newProfileWithOneReturnObjectiveValue.riskReturnObjectives[0]).toBe('MEDIUM');
      });

      it('should setup redemptionFrequencies with text value', () => {
        const profile: InvestmentProfile = { accountId: 'test', investmentType: 'test' };
        component.redemptionFrequencies = cloneDeep(MOCK_REDEMPTION_FREQUENCIES);

        const newProfile = (component as any).transformInvestmentPreferencesToTextValue(profile);

        expect(newProfile.redemptionFrequencies).toBeTruthy();
        expect(newProfile.redemptionFrequencies.length).toBe(2);
        expect(newProfile.redemptionFrequencies[0]).toBe('DAILY');
        expect(newProfile.redemptionFrequencies[1]).toBe('WEEKLY');

        component.redemptionFrequencies.minValue = component.redemptionFrequencies.maxValue;

        const newProfileWithOneRedemptionFrequency = (component as any).transformInvestmentPreferencesToTextValue(
          profile
        );

        expect(newProfileWithOneRedemptionFrequency.redemptionFrequencies).toBeTruthy();
        expect(newProfileWithOneRedemptionFrequency.redemptionFrequencies.length).toBe(1);
        expect(newProfileWithOneRedemptionFrequency.redemptionFrequencies[0]).toBe('WEEKLY');
      });
    });
  });

  describe('view', () => {
    describe('when it has existing profile', () => {
      beforeEach(() => {
        component.profile = MOCK_INVESTMENT_PROFILE;
        component.ngOnInit();
        fixture.detectChanges();
      });

      it('should NOT have profile setup title', () => {
        const title = fixture.debugElement.query(By.css('.js-test-profile-setup-title'));
        expect(title).toBeFalsy();
      });

      it('should NOT have profile setup icon', () => {
        const icon = fixture.debugElement.query(By.css('bt-icon'));
        expect(icon).toBeFalsy();
      });

      it('should NOT have profile setup description', () => {
        const description = fixture.debugElement.query(By.css('.js-test-profile-setup-description'));
        expect(description).toBeFalsy();
      });

      it('should NOT show set up investment profile button ', () => {
        const button = fixture.debugElement.query(By.css('.js-test-init-investment-profile-button'));
        expect(button).toBeFalsy();
      });

      describe('when existing profile investment type is allInvestmentTypes', () => {
        beforeEach(() => {
          component.profile.investmentType = component.allInvestmentTypes;
          fixture.detectChanges();
        });

        it('should show investment types component with right input property value', () => {
          const investmentTypes = fixture.debugElement.query(By.css('pano-inv-types'));
          expect(investmentTypes).toBeTruthy();
          expect(investmentTypes.properties.investmentType).toBe(component.allInvestmentTypes);
        });

        it('should show investment preferences component', () => {
          const investmentpPreferences = fixture.debugElement.query(By.css('pano-inv-pref'));
          expect(investmentpPreferences).toBeTruthy();
        });

        it('should show investment profile confirmation text', () => {
          const investmentProfileConfirmation = fixture.debugElement.query(
            By.css('.js-test-profile-setup-confirmation')
          );
          expect(investmentProfileConfirmation.nativeElement.innerHTML.trim()).toBe(
            component.setUpInvestmentProfileConfirmation
          );
        });

        it('should show investment profile save button', () => {
          spyOn(component, 'saveInvestmentProfile').and.stub();

          const saveButton = fixture.debugElement.query(By.css('.js-test-profile-save-button'));
          expect(saveButton).toBeTruthy();
          expect(saveButton.properties.config).toBe(component.saveInvestmentProfileButton);

          saveButton.triggerEventHandler('btClick', '');
          fixture.detectChanges();
          expect(component.saveInvestmentProfile).toHaveBeenCalled();
        });

        it('should show investment profile reset button', () => {
          spyOn(component as any, 'resetInvestmentProfile').and.stub();

          const resetButton = fixture.debugElement.query(By.css('.js-test-profile-reset-button'));
          expect(resetButton).toBeTruthy();
          expect(resetButton.properties.config).toBe((component as any).resetInvestmentProfileButton);

          resetButton.triggerEventHandler('btClick', '');
          fixture.detectChanges();
          expect((component as any).resetInvestmentProfile).toHaveBeenCalled();
        });
      });

      describe('when existing profile investment type is NOT allInvestmentTypes', () => {
        beforeEach(() => {
          component.profile.investmentType = INVESTMENT_TYPES.SHARES_AND_ETFS;
          fixture.detectChanges();
        });

        it('should show investment types component with right input property value', () => {
          const investmentTypes = fixture.debugElement.query(By.css('pano-inv-types'));

          expect(investmentTypes).toBeTruthy();
          expect(investmentTypes.properties.investmentType).toBe(INVESTMENT_TYPES.SHARES_AND_ETFS);
        });

        it('should NOT show investment preferences component', () => {
          const investmentPreferences = fixture.debugElement.query(By.css('pano-inv-pref'));
          expect(investmentPreferences).toBeFalsy();
        });

        it('should NOT show investment profile confirmation text', () => {
          const investmentProfileConfirmation = fixture.debugElement.query(
            By.css('.js-test-profile-setup-confirmation')
          );
          expect(investmentProfileConfirmation).toBeFalsy();
        });

        it('should show investment profile save button', () => {
          spyOn(component, 'saveInvestmentProfile').and.stub();

          const saveButton = fixture.debugElement.query(By.css('.js-test-profile-save-button'));
          expect(saveButton).toBeTruthy();
          expect(saveButton.properties.config).toBe(component.saveInvestmentProfileButton);

          saveButton.triggerEventHandler('btClick', '');
          fixture.detectChanges();
          expect(component.saveInvestmentProfile).toHaveBeenCalled();
        });

        it('should NOT show investment profile reset button', () => {
          const resetButton = fixture.debugElement.query(By.css('.js-test-profile-reset-button'));
          expect(resetButton).toBeFalsy();
        });
      });
    });

    describe('when it has NO existing profile', () => {
      beforeEach(() => {
        component.profile = undefined;
        component.ngOnInit();
        fixture.detectChanges();
      });

      it('should show profile setup title', () => {
        const title = fixture.debugElement.query(By.css('.js-test-profile-setup-title'));
        expect(title.nativeElement.textContent.trim()).toBe(component.setUpInvestmentProfileTitle);
      });

      it('should show profile setup description', () => {
        const description = fixture.debugElement.query(By.css('.js-test-profile-setup-description'));
        expect(description.nativeElement.textContent.trim()).toBe(component.setUpInvestmentProfileDescription);
      });

      it('should toggle set up investment profile button', () => {
        spyOn(component, 'initInvestmentProfile');

        const button = fixture.debugElement.query(By.css('.js-test-init-investment-profile-button'));
        expect(button.properties.config).toBe(component.setUpInvestmentProfileButton);

        button.triggerEventHandler('btClick', '');
        fixture.detectChanges();

        expect(component.initInvestmentProfile).toHaveBeenCalled();

        component.profile = MOCK_INVESTMENT_PROFILE;
        fixture.detectChanges();

        const setupButton = fixture.debugElement.query(By.css('.js-test-init-investment-profile-button'));
        expect(setupButton).toBeFalsy();
      });

      it('should NOT show investment types component', () => {
        const investmentTypes = fixture.debugElement.query(By.css('pano-inv-types'));
        expect(investmentTypes).toBeFalsy();
      });

      it('should NOT show investment preferences component', () => {
        const investmentpPreferences = fixture.debugElement.query(By.css('pano-inv-pref'));
        expect(investmentpPreferences).toBeFalsy();
      });

      it('should NOT show investment profile save button', () => {
        const saveButton = fixture.debugElement.query(By.css('.js-test-profile-save-button'));
        expect(saveButton).toBeFalsy();
      });

      it('should NOT show investment profile reset button', () => {
        const resetButton = fixture.debugElement.query(By.css('.js-test-profile-reset-button'));
        expect(resetButton).toBeFalsy();
      });
    });
  });
});
