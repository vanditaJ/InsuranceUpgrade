import { Button } from '@bt/components/button';

import { CheckboxField } from './pano-inv-pref/pano-inv-pref.interface';
import { RangeSliderModel } from './pano-inv-profile-setup.interface';

export const RESET_INVESTMENT_PROFILE_BUTTON: Button = {
  action: 'button',
  label: 'Reset',
  size: 'large',
  type: 'outline',
  shapeModifier: 'square',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Reset'
  }
};

export const SAVE_INVESTMENT_PROFILE_BUTTON: Button = {
  action: 'button',
  label: 'Save',
  size: 'large',
  type: 'solid',
  shapeModifier: 'square',
  colourModifier: 'primary'
};

export const SET_UP_INVESTMENT_PROFILE_BUTTON: Button = {
  action: 'button',
  label: 'Set up investment profile',
  size: 'large',
  type: 'solid',
  shapeModifier: 'square',
  colourModifier: 'primary'
};

export const INVESTMENT_OBJECTIVES: CheckboxField[] = [
  { name: 'REGULAR_INCOME', value: false, descripton: 'Regular income' },
  { name: 'CAPITAL_GUARANTEED', value: false, descripton: 'Capital guaranteed' },
  { name: 'CAPITAL_PRESERVATION', value: false, descripton: 'Capital preservation' },
  { name: 'CAPITAL_GROWTH', value: false, descripton: 'Capital growth' }
];

export const INVESTMENT_TIMEFRAMES: CheckboxField[] = [
  { name: 'SHORT', value: false, descripton: 'Short (less than 2 years)' },
  { name: 'MEDIUM', value: false, descripton: 'Medium (2 to 8 years)' },
  { name: 'LONG', value: false, descripton: 'Long (8 or more years)' }
];

export const RISK_SLIDER: RangeSliderModel = {
  minValue: 0,
  maxValue: 0,
  options: {
    floor: 0,
    ceil: 3,
    showTicksValues: true,
    translate: (value: number): string => {
      switch (value) {
        case 0:
          return 'Low';
        case 1:
          return 'Medium';
        case 2:
          return 'High';
        case 3:
          return 'Very High';
        default:
          return '';
      }
    }
  }
};

export const LIQUIDITY_NEED_VALUES: string[] = ['Daily', 'Weekly', 'Monthly', 'Quarterly', 'Annually or longer'];
export const LIQUIDITY_NEED_POSITIONS: number[] = [0, 0.2, 0.4, 0.6, 1];

export const LIQUIDITY_NEED_SLIDER: RangeSliderModel = {
  minValue: 0,
  maxValue: 0,
  options: {
    floor: 0,
    ceil: 4,
    showTicksValues: true,
    customValueToPosition: (val: number): number => {
      return LIQUIDITY_NEED_POSITIONS[val];
    },
    customPositionToValue: (percent: number): number => {
      if (percent < 0.15) {
        return 0;
      }
      if (percent >= 0.15 && percent < 0.25) {
        return 1;
      }
      if (percent >= 0.25 && percent < 0.45) {
        return 2;
      }
      if (percent >= 0.45 && percent < 0.65) {
        return 3;
      }
      if (percent >= 0.65 && percent < 1.5) {
        return 4;
      }
    },
    translate: (value: number): string => {
      return LIQUIDITY_NEED_VALUES[value];
    }
  }
};

export const SET_UP_INVESTMENT_PROFILE_TITLE: string = 'Set up investment profile for this account';
export const SET_UP_INVESTMENT_PROFILE_DESCRIPTION: string =
  'To set up your profile, we will need to ask a few questions about your investment needs and objectives. Based on your answers, we can then show you options that align with your preferences. This should take you less than 5 minutes to complete.';
export const SET_UP_INVESTMENT_PROFILE_CONFIRMATION: string =
  'By saving this profile, I confirm that the answers I have provided are true and correct to the best of my knowledge.';
