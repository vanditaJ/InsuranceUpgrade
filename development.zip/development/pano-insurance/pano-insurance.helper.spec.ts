import { findContentByKey } from './pano-insurance.helper';

describe('PanoInsuranceHelper', () => {
  describe('findContentByKey', () => {
    const mockContents: any = [
      {
        type: 'title_link',
        id: 'important-super-changes',
        data: {
          headerText: 'insurance_info',
          description: 'insurance_info content'
        }
      },
      {
        type: 'title_link',
        id: 'important-super-changes',
        data: {
          headerText: 'cancel_cover_selection_useful_info',
          description: 'cancel_cover_selection_useful_info content'
        }
      }
    ];

    it('should return the correct content based on key', () => {
      expect(findContentByKey(mockContents, 'insurance_info')).toEqual('insurance_info content');
      expect(findContentByKey(mockContents, 'cancel_cover_selection_useful_info')).toEqual(
        'cancel_cover_selection_useful_info content'
      );
    });

    it('should return null when there is no content for the key', () => {
      expect(findContentByKey(mockContents, 'fake_news')).toBeUndefined();
    });
  });
});
