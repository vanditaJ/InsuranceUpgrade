import { Button } from '@bt/components/button';

export type ChangeCoverMode = 'change' | 'decrease' | 'decrease_request';

export enum CoverMode {
  CHANGE = 'change',
  DECREASE = 'decrease',
  CANCEL = 'cancel',
  DECREASE_REQUEST = 'decrease_request'
}

export type ChangeCoverState = 'preview' | 'confirmation' | 'options';

export enum CoverState {
  PREVIEW = 'preview',
  CONFIRMATION = 'confirmation',
  OPTIONS = 'options'
}

export interface CoverAmountOptions {
  policyType: string;
  coverLevel: string;
  coverTypeSelected: CoverTypeSelected[];
}

export interface CoverTypeSelected {
  coverType: 'DEATH' | 'DEATH_AND_TPD';
  coverLevels: Array<'Single' | 'Double' | 'Triple'>;
}

export interface SelectCoverType {
  policyName: string;
  policyType: string;
  description: string;
}
export interface SelectCoverAmount {
  coverSubTypeId: string;
  coverAmountName: string;
  coverAmountType: string;
  coverAmount: null | number;
  premium: string;
  increase: boolean;
}

export interface InsuranceRate {
  coverOptionId: string;
  policyType: string;
  policyName: string;
  coverLevel: string;
  coverAmount: number;
  premium: string;
  increase: boolean;
}

export interface PanoHintInlineButtons {
  [key: string]: Button;
}
