import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

import { CLOSE_DIALOG_BUTTON, CLOSE_DIALOG_BUTTON_ICON } from './pano-pref-dialog.constant';

@Component({
  selector: 'pano-pref-dialog',
  templateUrl: './pano-pref-dialog.component.html'
})
export class PanoInvestmentPreferenceDialogComponent {
  readonly closeButton: Button = CLOSE_DIALOG_BUTTON;
  readonly closeButtonIcon: Button = CLOSE_DIALOG_BUTTON_ICON;

  constructor(
    private readonly dialogRef: MatDialogRef<PanoInvestmentPreferenceDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      title: string;
      description: string;
    }
  ) {}

  closeDialog(): void {
    this.dialogRef.close();
  }
}
