import { Component, OnInit } from '@angular/core';
import { Icon } from '@bt/components/icon';
import { finalize, take } from 'rxjs/operators';

import { NEW_WINDOW_ICON } from '../pano-learn-about-investments.constants';

import { Tile } from './pano-learn-about-investments-tiles.interface';
import { PanoLearnAboutInvestmentsTilesService } from './pano-learn-about-investments-tiles.service';

@Component({
  selector: 'pano-learn-about-investments-tiles',
  templateUrl: './pano-learn-about-investments-tiles.html',
  styleUrls: ['../pano-learn-about-investments.component.scss']
})
export class PanoLearnAboutInvestmentsTilesComponent implements OnInit {
  tiles: Tile[] = [];
  loading: boolean = true;

  readonly newWindowIcon: Icon = NEW_WINDOW_ICON;

  constructor(private readonly learnAboutInvestmentsTilesService: PanoLearnAboutInvestmentsTilesService) {}

  ngOnInit(): void {
    this.loadTiles();
  }

  private loadTiles() {
    this.learnAboutInvestmentsTilesService
      .getTileContent()
      .pipe(take(1))
      .pipe(
        finalize(() => {
          this.loading = false;
        })
      )
      .subscribe(
        (tiles: Tile[]) => {
          this.tiles = tiles;
        },
        () => {
          this.tiles = [];
        }
      );
  }
}
