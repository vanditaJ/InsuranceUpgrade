import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';
import * as moment from 'moment-timezone';

import { InsurancePolicy, PolicyStatus, PolicyType } from '../../pano-insurance.interface';
import { CoverAmountOptions, SelectCoverType } from '../pano-change-cover-insurance.interface';
import { NEW_COVER_TYPE } from '../pano-change-cover-review/pano-change-cover-review.component.spec.constants';

export const CURRENT_COVER_TYPE: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Double',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Triple', 'Single']
    },
    {
      coverType: PolicyType.DEATH_AND_TPD,
      coverLevels: ['Single', 'Double', 'Triple']
    }
  ]
};

export const TRIPLE_DEATH_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Income Protection',
  policyNumber: '5273590',
  qualifierName: 'Salary continuance cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Triple',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const TRIPLE_DEATH_CURRENT_COVER_TYPE: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Triple',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single', 'Double']
    },
    {
      coverType: PolicyType.DEATH_AND_TPD,
      coverLevels: ['Single', 'Double', 'Triple']
    }
  ]
};

export const SELECTED_COVER_TYPES: SelectCoverType[] = [
  {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH,
    description:
      'Retains Death cover only and cancels your TPD if you have bundled Death and TPD cover. Death cover pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.'
  }
];

export const ALL_SELECTED_COVER_TYPES: SelectCoverType[] = [
  {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH,
    description: ''
  },
  {
    policyName: 'Death and TPD cover',
    policyType: PolicyType.DEATH_AND_TPD,
    description: ''
  }
];

export const INSURANCE_POLICY_DEATH_TRIPLE: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Income Protection',
  policyNumber: '5273590',
  qualifierName: 'Salary continuance cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Triple',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const MOCK_AEM_CONTENT_OPTIONS: AemContent[] = [
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'exclusions_modal',
      description: 'mock content for exclusions_modal'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'pre_existing_conditions_modal',
      description: 'mock content for pre_existing_conditions_modal'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'customised_cover_modal',
      description: 'mock content for customised_cover_modal'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_decrease_message',
      description: 'mock content for decrease_cover_decrease_message'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_selection_sum_summary',
      description: 'mock content for decrease_selection_sum_summary'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_selection_units_summary',
      description: 'mock content for decrease_selection_units_summary'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_selection_sci_summary',
      description: 'mock content for decrease_selection_sci_summary'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'sci_hint_message',
      description: 'mock content for sci_hint_message'
    }
  }
];

export const MOCK_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: moment().tz('Australia/Sydney'),
  owners: [
    {
      age: 50,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Female',
      lastName: 'LastName'
    }
  ],
  pdsStatus: 'WGP_CEASED',
  product: {}
};

export const MOCK_CHANGE_COVER_SELECTION_POLICIES: InsurancePolicy[] = [
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    policyNumber: '5273590',
    qualifierName: 'Standard cover',
    premium: '0.00',
    status: PolicyStatus.REQUESTED,
    commencementDate: '2021-03-01T00:00:00.000+11:00',
    sumInsured: 4521,
    coverSubTypeId: 21,
    ageNextBirthday: 67,
    customised: true,
    customerType: 'PCS',
    employerFunded: false,
    pmifDetails: {
      optInDate: '2020-03-01T00:00:00.000+11:00',
      lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
    }
  },
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    policyNumber: '5273590',
    qualifierName: 'Standard cover',
    premium: '0.00',
    status: PolicyStatus.PENDING,
    commencementDate: '2021-03-01T00:00:00.000+11:00',
    sumInsured: 4521,
    coverSubTypeId: 21,
    ageNextBirthday: 50,
    customised: false,
    customerType: 'Retail',
    employerFunded: false,
    pmifDetails: {
      optInDate: '2021-08-01T00:00:00.000+11:00',
      lowBalanceThresholdDate: '2021-09-01T00:00:00.000+11:00'
    }
  }
];

export const MOCK_CHANGE_COVER_SELECTION_ACC: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountNumber: '1234',
  accountName: 'account name',
  firstMoneyReceivedDate: '2020-11-04T16:00:00.000Z',
  pdsStatus: 'WGP_CURRENT',
  owners: [
    {
      age: 25,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Female',
      lastName: 'LastName'
    }
  ],
  product: {},
  productDescription: 'BT Super'
};
