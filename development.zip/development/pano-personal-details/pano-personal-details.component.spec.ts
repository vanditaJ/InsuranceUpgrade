import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ErrorType } from '@bt/components/error';
import { DataModule } from '@bt/services/data';
import { UserProfile } from '@investor/account/pano-shared/interfaces';
import { LayoutModule } from '@panorama/components/layout';
import { YourDetailsComponent, YourDetailsModule } from '@panorama/your-details';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeUserService } from '@upgrade/upgrade.services';
import { PanoUpgradePermissionService } from '@upgrade/upgrade.services';

import { PanoPersonalDetailsComponent } from './pano-personal-details.component';
import { INVESTOR_ERROR_STATE } from './pano-personal-details.constants';

describe('PanoPersonalDetailsComponent', () => {
  let fixture: ComponentFixture<PanoPersonalDetailsComponent>;
  let component: PanoPersonalDetailsComponent;
  let userService: PanoUpgradeUserService;
  let permissionService: PanoUpgradePermissionService;
  let uiRouter: UIRouter;

  const MOCK_USER_PROFILE: UserProfile = {
    username: '1234'
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoPersonalDetailsComponent],
        imports: [DataModule, HttpClientTestingModule, LayoutModule, YourDetailsModule],
        schemas: [NO_ERRORS_SCHEMA],
        providers: [
          {
            provide: PanoUpgradeUserService,
            useValue: {
              getProfile: jasmine.createSpy().and.returnValue(MOCK_USER_PROFILE)
            }
          },
          {
            provide: PanoUpgradePermissionService,
            useValue: {
              hasPermission: jasmine.createSpy()
            }
          },
          {
            provide: UIRouter,
            useValue: {
              stateService: {
                go: jasmine.createSpy()
              }
            }
          }
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoPersonalDetailsComponent);
    component = fixture.componentInstance;
    userService = TestBed.inject(PanoUpgradeUserService);
    permissionService = TestBed.inject(PanoUpgradePermissionService);
    uiRouter = TestBed.inject(UIRouter);
  });

  describe('Component', () => {
    it('should be defined', () => {
      expect(component).toBeDefined();
    });

    describe('ngOnInit', () => {
      it('should set current user profile', () => {
        permissionService.hasPermission
          .withArgs('user.detail.investor.wplusermessage.view', 'base')
          .and.returnValue(true);
        permissionService.hasPermission.withArgs('emulating', 'base').and.returnValue(false);
        permissionService.hasPermission
          .withArgs('feature.investor.personalDetails.address.update', 'base')
          .and.returnValue(true);
        permissionService.hasPermission
          .withArgs('feature.investor.personalDetails.primary.email.update', 'base')
          .and.returnValue(true);
        permissionService.hasPermission
          .withArgs('feature.investor.personalDetails.additional.contact.update', 'base')
          .and.returnValue(true);
        permissionService.hasPermission
          .withArgs('feature.investor.personalDetails.additional.contact.view', 'base')
          .and.returnValue(true);
        permissionService.hasPermission
          .withArgs('feature.investor.personalDetails.username.update', 'base')
          .and.returnValue(true);
        permissionService.hasPermission
          .withArgs('feature.investor.personalDetails.password.update', 'base')
          .and.returnValue(true);

        component.ngOnInit();

        expect(userService.getProfile).toHaveBeenCalledTimes(1);
        expect(component.userProfile).toEqual(MOCK_USER_PROFILE);
        expect(component.personalDetailsPermissions.hasWestpacLive).toBe(true);
        expect(component.personalDetailsPermissions.emulating).toBe(false);
        expect(component.personalDetailsPermissions.addessUpdate).toBe(true);
        expect(component.personalDetailsPermissions.additionalContactUpdate).toBe(true);
        expect(component.personalDetailsPermissions.additionalContactDetailsView).toBe(true);
        expect(component.personalDetailsPermissions.primaryEmailUpdate).toBe(true);
        expect(component.personalDetailsPermissions.userNameUpdate).toBe(true);
        expect(component.personalDetailsPermissions.passwordUpdate).toBe(true);
      });
    });

    describe('handleError', () => {
      it('should navigate to the generic investor error page if the your-details module reports an error', () => {
        component.handleError(true);

        expect(uiRouter.stateService.go).toHaveBeenCalledWith(INVESTOR_ERROR_STATE, {
          type: ErrorType.generic
        });
      });

      it('should remain on the current page if the your-details module does not report an error', () => {
        component.handleError(false);

        expect(uiRouter.stateService.go).not.toHaveBeenCalled();
      });
    });
  });

  describe('View', () => {
    beforeEach(() => {
      component.userProfile = MOCK_USER_PROFILE;
      fixture.detectChanges();
    });

    it('your-details screen component should be displayed', () => {
      const child = fixture.debugElement.query(By.directive(YourDetailsComponent)).componentInstance;
      expect(child).toBeDefined();
      expect(child.userProfile).toEqual(MOCK_USER_PROFILE);
    });
  });
});
