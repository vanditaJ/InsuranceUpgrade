import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { find } from 'lodash-es';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

import { LIFE_STAGE_FUND } from './pano-investments-overview.constants';
import { Investment, Investments } from './pano-investments-overview.interface';
import { PanoInvestmentsOverviewService } from './pano-investments-overview.service';

export function panoLifestageInvestmentResolver($transition$): Promise<Investment> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const investmentOverviewService = $transition$.injector().get(PanoInvestmentsOverviewService);

  const observable: Observable<Investment> = new Observable<Investment>(observer => {
    investmentOverviewService
      .getCurrentInvestments(accountService.getAccountId())
      .pipe(take(1))
      .subscribe(
        (investments: Investments) => {
          const fullyAllocatedLifestageInvestment = find(
            investments.investments,
            (investment: Investment) =>
              investment.allocationPercentage === 100 &&
              investment.balance > 0 &&
              investment.fundName.includes(LIFE_STAGE_FUND)
          );

          if (fullyAllocatedLifestageInvestment) {
            observer.next(fullyAllocatedLifestageInvestment);
          } else {
            observer.error({ msg: 'Fully allocated lifestage fund not found!' });
          }
        },
        error => observer.error(error),
        () => observer.complete()
      );
  });

  return observable.toPromise();
}
