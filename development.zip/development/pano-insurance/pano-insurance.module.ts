import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { IconModule } from '@bt/components/icon';
import { LinkModule } from '@bt/components/link';
import { LoadingModule } from '@bt/components/loading';
import { SnackBarTemplateComponent, SnackBarTemplateModule } from '@bt/components/snack-bar-template';
import { AccessibleFormDirectiveModule } from '@bt/directives/accessible-form';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { OrDashPipeModule } from '@bt/pipes/or-dash';
import { TotalOfPipeModule } from '@bt/pipes/total-of';
import { LayoutModule } from '@panorama/components/layout';
import { CMS_CONFIG } from '@panorama/services/cms';
import { PanoCmsService } from '@panorama/services/cms';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { NgxMaskModule } from 'ngx-mask';
import { NgxPageScrollCoreModule } from 'ngx-page-scroll-core';

import { PanoCancelInsuranceComponent } from './pano-cancel-insurance/pano-cancel-insurance.component';
import { PanoChangeCoverConfirmationComponent } from './pano-change-cover-insurance/pano-change-cover-confirmation/pano-change-cover-confirmation.component';
import { PanoChangeCoverInsuranceCommonUtil } from './pano-change-cover-insurance/pano-change-cover-insurance-common.util';
import { PanoChangeCoverInsuranceComponent } from './pano-change-cover-insurance/pano-change-cover-insurance.component';
import { PanoChangeCoverOptionsComponent } from './pano-change-cover-insurance/pano-change-cover-options/pano-change-cover-options.component';
import { PanoContentDialogComponent } from './pano-change-cover-insurance/pano-change-cover-options/pano-content-dialog/pano-content-dialog.component';
import { PanoChangeCoverReviewComponent } from './pano-change-cover-insurance/pano-change-cover-review/pano-change-cover-review.component';
import { PanoDecreaseRequestOptionsComponent } from './pano-change-cover-insurance/pano-decrease-request-options/pano-decrease-request-options.component';
import { PanoActivateInsuranceDialogComponent } from './pano-insurance-policies/pano-activate-insurance-dialog/pano-activate-insurance-dialog.component';
import { PanoIncreaseEyCoverDialogComponent } from './pano-insurance-policies/pano-increase-ey-cover-dialog/pano-increase-ey-cover-dialog.component';
import { PanoInsuranceAlertModalComponent } from './pano-insurance-policies/pano-insurance-alert-modal/pano-insurance-alert-modal.component';
import { PanoInsuranceExitSiteDialogComponent } from './pano-insurance-policies/pano-insurance-exit-site-dialog/pano-insurance-exit-site-dialog.component';
import { PanoInsuranceLinksComponent } from './pano-insurance-policies/pano-insurance-links/pano-insurance-links.component';
import { PanoInsurancePoliciesComponent } from './pano-insurance-policies/pano-insurance-policies.component';
import { PanoInsurancePoliciesUtil } from './pano-insurance-policies/pano-insurance-policies.util';
import { PanoInsuranceTablesComponent } from './pano-insurance-policies/pano-insurance-tables/pano-insurance-tables.component';
import { PanoInsuranceTilesComponent } from './pano-insurance-policies/pano-insurance-tiles/pano-insurance-tiles.component';
import { PanoPysOptInAllComponent } from './pano-insurance-policies/pano-pys-optin-all/pano-pys-opt-in-all.component';
import { panoInsuranceContentResolver } from './pano-insurance-resolvers/pano-insurance-content.resolver';
import { panoInsurancePermissionResolver } from './pano-insurance-resolvers/pano-insurance-permission.resolver';
import { panoInsurancePolicyResolver } from './pano-insurance-resolvers/pano-insurance.resolver';
import { PanoInsuranceSharedLinkService } from './pano-insurance-shared-link/pano-insurance-shared-link.service';
import { CMS_CONTEXT_PATH } from './pano-insurance.constants';
import { PanoInsuranceService } from './pano-insurance.service';
import { PanoInsuranceUtil } from './pano-insurance.util';

@NgModule({
  declarations: [
    PanoCancelInsuranceComponent,
    PanoChangeCoverInsuranceComponent,
    PanoChangeCoverReviewComponent,
    PanoChangeCoverConfirmationComponent,
    PanoChangeCoverOptionsComponent,
    PanoDecreaseRequestOptionsComponent,
    PanoInsurancePoliciesComponent,
    PanoPysOptInAllComponent,
    PanoInsuranceTablesComponent,
    PanoInsuranceLinksComponent,
    PanoInsuranceTilesComponent,
    PanoInsuranceExitSiteDialogComponent,
    PanoContentDialogComponent,
    PanoActivateInsuranceDialogComponent,
    PanoInsuranceAlertModalComponent,
    PanoIncreaseEyCoverDialogComponent
  ],
  imports: [
    AccessibleFormDirectiveModule,
    AlertModule,
    ButtonModule,
    CopyMatrixPipeModule,
    IconModule,
    LinkModule,
    LoadingModule,
    OrDashPipeModule,
    PopoverModule,
    CommonModule,
    LayoutModule,
    ButtonModule,
    AlertModule,
    MatInputModule,
    MatRadioModule,
    MatSelectModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    SnackBarTemplateModule,
    TotalOfPipeModule,
    MatSnackBarModule,
    NgxMaskModule.forRoot({}),
    NgxPageScrollCoreModule.forRoot({}),
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.cancelInsurance',
          url: '/cancel-insurance/:policyNumber',
          component: PanoCancelInsuranceComponent,
          resolve: {
            cmsContent: ['$transition$', panoInsuranceContentResolver]
          },
          params: {
            insurance: null,
            associatedTpdCovers: null
          }
        },
        {
          name: 'app.investor.account.changeCoverInsurance',
          url: '/change-cover-insurance/:policyNumber/:mode',
          component: PanoChangeCoverInsuranceComponent,
          resolve: {
            cmsContent: ['$transition$', panoInsuranceContentResolver]
          },
          params: {
            insurance: null
          }
        },
        {
          name: 'app.investor.account.insurancePolicies',
          url: '/insurance-policies',
          component: PanoInsurancePoliciesComponent,
          resolve: {
            policies: ['$transition$', panoInsurancePolicyResolver],
            cmsContent: ['$transition$', panoInsuranceContentResolver],
            insurancePermissions: ['$transition$', panoInsurancePermissionResolver]
          },
          params: {
            state: null
          }
        }
      ]
    }),
    MatFormFieldModule,
    MatExpansionModule,
    MatMenuModule
  ],
  providers: [
    PanoInsuranceService,
    PanoInsuranceSharedLinkService,
    PanoChangeCoverInsuranceCommonUtil,
    PanoInsurancePoliciesUtil,
    PanoInsuranceUtil,
    PanoCmsService,
    {
      provide: CMS_CONFIG,
      useValue: {
        contextPath: CMS_CONTEXT_PATH
      }
    }
  ],
  entryComponents: [
    SnackBarTemplateComponent,
    PanoInsuranceExitSiteDialogComponent,
    PanoPysOptInAllComponent,
    PanoContentDialogComponent,
    PanoActivateInsuranceDialogComponent,
    PanoInsuranceAlertModalComponent,
    PanoIncreaseEyCoverDialogComponent
  ]
})
export class PanoInsuranceModule {}
