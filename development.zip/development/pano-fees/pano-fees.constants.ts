import { Alert } from '@bt/components/alert';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Tooltip } from '@bt/components/tooltip';
import { Optionals } from '@bt/services/data';

export const AEM_CONTENT_URL: string =
  '/content/secure/panorama/_services/fees/content/_jcr_content.getAggr.getContentPage.json';

export const RETAIL: string = 'RETAIL';
export const WGP: string = 'WGP';
export const WGP_LSEP_COHORT: string = 'LSEP';
export const WGP_PLUM_COHORT: string = 'PLUM';
export const WGP_WSSP_COHORT: string = 'WSSP';

export const EXTERNAL_LINK_ANNOUNCEMENT: string = 'open in new tab.';

export const ONGOING_FEES_LINK_NO_ICON: Link = {
  isLinkExternal: true,
  openNewTab: false,
  label: 'Ongoing fees',
  link: '',
  colourModifier: 'primary',
  type: 'flat',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'Ongoing fees'
  }
};

export const BUY_SELL_SPREADS_LINK_NO_ICON: Link = {
  isLinkExternal: true,
  openNewTab: true,
  label: 'Buy-sell spreads',
  link: '',
  colourModifier: 'primary',
  type: 'flat',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'Buy-sell spreads, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

export const ADMINISTRATION_FEE_TOOLTIP: Tooltip = {
  a11yProps: {
    ariaLabel: 'Administration fee tooltip ',
    title: 'Administration fee'
  },
  type: 'primary',
  message: ''
};

export const INVESTMENT_FEE_TOOLTIP: Tooltip = {
  a11yProps: {
    ariaLabel: 'Investment fee tooltip ',
    title: 'Investment fee'
  },
  type: 'primary',
  message: ''
};

export const INDIRECT_COST_RATIO_TOOLTIP: Tooltip = {
  a11yProps: {
    ariaLabel: 'Indirect cost ratio tooltip',
    title: 'Indirect cost ratio'
  },
  type: 'primary',
  message: ''
};

export const BUY_SELL_SPREADS_TOOLTIP: Tooltip = {
  a11yProps: {
    ariaLabel: 'Buy-sell spreads tooltip ',
    title: 'Buy-sell spreads'
  },
  type: 'primary',
  message: ''
};

export const LOADING_SPINNER: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const NEW_WINDOW_ICON: Icon = {
  name: 'icon-external-link',
  size: 'x-small',
  type: 'info'
};

export const GENERIC_ERROR_ALERT: Alert = {
  type: 'error',
  messages: 'We seem to be having some technical difficulties. Please reload this page or try again later.',
  outline: true,
  showCodes: false
};

export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0344' };

// CMS keys
export const FEES_DESCRIPTION: string = 'fees_description';

export const ONGOING_INVESTMENT_INFO: string = 'fees_charges_info_ongoing_investment_fees';
export const LIFESTAGE_INVESTMENT_INFO: string = 'fees_charges_info_lifestage_investment';
export const LEGACY_ADMIN_FEE: string = 'fees_charges_info_legacy_admin_fee';
export const BUY_SELL_SPREAD_INFO: string = 'fees_charges_info_buy_sell_spread';

export const TOOLTIP_ADMIN_FEE: string = 'fees_tooltip_admin_fee';
export const TOOLTIP_INVESTMENT_FEE: string = 'fees_tooltip_investment_fee';
export const TOOLTIP_INDIRECT_COST_RATIO: string = 'fees_tooltip_indirect_cost_ratio';
export const TOOLTIP_BUY_SELL_SPREAD: string = 'fees_tooltip_buy_sell_spread';

export const ADMIN_FEE: any = {
  WGP: 'fees_table_summary_wgp_admin_fee',
  RETAIL: 'fees_table_summary_retail_admin_fee'
};
export const INVESTMENT_FEE: any = {
  WGP: 'fees_table_summary_wgp_investment_fee',
  RETAIL: 'fees_table_summary_retail_investment_fee'
};
export const INDIRECT_COST_RATIO: any = {
  WGP: 'fees_table_summary_wgp_indirect_cost_ratio',
  RETAIL: 'fees_table_summary_retail_indirect_cost_ratio'
};
export const BUY_SELL_SPREAD: any = {
  WGP: 'fees_table_summary_wgp_buy_sell_spread',
  RETAIL: 'fees_table_summary_retail_buy_sell_spread'
};

export const EXAMPLE_DESCRIPTION: string = 'example_description';
export const EXAMPLE_FOOTNOTE: string = 'example_footnote';

export const EXAMPLE_ADMIN_RATE: any = {
  WGP: 'example_table_summary_wgp_admin_rate',
  RETAIL: 'example_table_summary_retail_admin_rate'
};
export const EXAMPLE_ADMIN_FEE: any = {
  WGP: 'example_table_summary_wgp_admin_fee',
  RETAIL: 'example_table_summary_retail_admin_fee'
};
export const EXAMPLE_INVESTMENT_RATE: any = {
  WGP: 'example_table_summary_wgp_investment_rate',
  RETAIL: 'example_table_summary_retail_investment_rate'
};
export const EXAMPLE_INVESTMENT_FEE: any = {
  WGP: 'example_table_summary_wgp_investment_fee',
  RETAIL: 'example_table_summary_retail_investment_fee'
};
export const EXAMPLE_INDIRECT_COST_RATE: any = {
  WGP: 'example_table_summary_wgp_indirect_cost_rate',
  RETAIL: 'example_table_summary_retail_indirect_cost_rate'
};
export const EXAMPLE_INDIRECT_COST_RATIO: any = {
  WGP: 'example_table_summary_wgp_indirect_cost_ratio',
  RETAIL: 'example_table_summary_retail_indirect_cost_ratio'
};
export const EXAMPLE_TOTAL_RATE: any = {
  WGP: 'example_table_summary_wgp_total_cost_rate',
  RETAIL: 'example_table_summary_retail_total_cost_rate'
};
export const EXAMPLE_TOTAL_COST: any = {
  WGP: 'example_table_summary_wgp_total_cost',
  RETAIL: 'example_table_summary_retail_total_cost'
};
