import { CommonModule, Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, flush, TestBed, waitForAsync } from '@angular/core/testing';
import { FormArray, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SnackBarTemplateComponent, SnackBarTemplateModule } from '@bt/components/snack-bar-template';
import { EntitlementDirectiveTestingModule } from '@bt/directives/entitlement/testing';
import { ToggleClassByBreakpointDirectiveModule } from '@bt/directives/toggle-class-by-breakpoint';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { cloneDeep } from 'lodash-es';
import * as moment from 'moment-timezone';
import { PageScrollService } from 'ngx-page-scroll-core';
import { of, throwError, timer } from 'rxjs';
import 'zone.js/dist/fake-async-test';

import { PanoConfirmDialogComponent } from './pano-confirm-dialog/pano-confirm-dialog.component';
import {
  ASSET_LIST_CASH,
  EXTERNAL_ASSETS_DETAILS,
  SOFTWARE_DATA_CONNECTED_STATE,
  SOFTWARE_DATA_MANUAL_REQUESTED_STATE,
  SOFTWARE_DATA_MANUAL_STATE,
  SOFTWARE_DATA_PENDING_STATE,
  TEST_ASSET_TYPES,
  TEST_CASH_ASSETS_FORM_ARRAY,
  TEST_DP_ASSETS_FORM_ARRAY,
  TEST_DP_PROPERTY_TYPES,
  TEST_ILS_ASSETS_FORM_ARRAY,
  TEST_LS_ASSETS_FORM_ARRAY,
  TEST_MF_ASSETS_FORM_ARRAY,
  TEST_MP_ASSETS_FORM_ARRAY,
  TEST_OTH_ASSETS_FORM_ARRAY,
  TEST_TD_ASSETS_FORM_ARRAY
} from './pano-external-assets-constants/pano-external-assets-constants.spec.data';
import {
  ACTION_CANCEL,
  ACTION_CONFIRM,
  ASSET_DELETE_DIALOG_DATA_CONFIG,
  ASSET_TYPES,
  CLEAR_ASSETS_CHANGES_BUTTON,
  CLEAR_CHANGES_DIALOG_DATA_CONFIG,
  CONFIRM_CANCELLATION_DIALOG_DATA_CONFIG,
  CONFIRM_DIALOG_CONFIG,
  DEFAULT_ADD_ASSET_PROPS,
  DEFAULT_ASSET_TYPE_TOTAL,
  EXTERNAL_ASSETS_MODULE,
  PAGE_SCROLL_SPEED,
  SAVE_ASSETS_CHANGES_BUTTON,
  SNACK_BAR_EXTERNAL_ASSETS_NO_UNSAVED_CHANGES,
  SNACK_BAR_EXTERNAL_ASSETS_SUCCESS
} from './pano-external-assets-constants/pano-external-assets.constants';
import { PanoExternalAssetsFormCreator } from './pano-external-assets-form-creator';
import { PanoExternalAssetsComponent } from './pano-external-assets.component';
import {
  SMSF_ACCOUNTING_SOFTWARE_READ_ENTITLEMENT,
  SMSF_SERVICES_ALERT,
  SMSF_SERVICE_MODULE_NAME,
  SYSTEM_ERROR_MODULE_NAME
} from './pano-external-assets.constants';
import { AssetTypeTotalMarketValue } from './pano-external-assets.interfaces';
import { PanoExternalAssetsService } from './pano-external-assets.service';

describe('PanoExternalAssetsComponent', () => {
  let externalAssetsFormCreator: PanoExternalAssetsFormCreator;
  let externalAssetService: PanoExternalAssetsService;
  let component: PanoExternalAssetsComponent;
  let fixture: ComponentFixture<PanoExternalAssetsComponent>;
  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy(),
      target: jasmine.createSpy()
    }
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoExternalAssetsComponent],
        providers: [
          Location,
          { provide: LocationStrategy, useClass: PathLocationStrategy },
          PanoExternalAssetsService,
          PanoExternalAssetsFormCreator,
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PageScrollService, useValue: pageScrollService }
        ],
        imports: [
          BrowserAnimationsModule,
          CommonModule,
          DataModule,
          EntitlementDirectiveTestingModule,
          HttpClientTestingModule,
          MatDatepickerModule,
          MatDialogModule,
          MatFormFieldModule,
          MatInputModule,
          MatSnackBarModule,
          PipesTestingModule,
          ReactiveFormsModule,
          ToggleClassByBreakpointDirectiveModule,
          SnackBarTemplateModule
        ],
        schemas: [NO_ERRORS_SCHEMA]
      })
        .overrideModule(BrowserDynamicTestingModule, {
          set: { entryComponents: [PanoExternalAssetsComponent] }
        })
        .compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoExternalAssetsComponent);
    externalAssetsFormCreator = TestBed.inject(PanoExternalAssetsFormCreator);
    component = fixture.componentInstance;
    externalAssetService = TestBed.inject(PanoExternalAssetsService);
    component.softwareData = SOFTWARE_DATA_MANUAL_STATE;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should exists', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize initialLoading flag to true', () => {
      expect(component.initialLoading).toBeTruthy();
    });

    describe('ngOnInit()', () => {
      it('should load asset types and external assets for manual/pending screen type', () => {
        spyOn(component, 'setDefaultExternalAssetFormAndTotals');
        spyOn(component, 'loadAssetTypes');
        spyOn(component, 'loadExternalAssets');
        spyOn(component, 'loadPropertyTypes');
        component.softwareData = SOFTWARE_DATA_MANUAL_STATE;
        component.ngOnInit();
        expect(component.setDefaultExternalAssetFormAndTotals).toHaveBeenCalled();
        expect(component.loadExternalAssets).toHaveBeenCalled();
        expect(component.loadAssetTypes).toHaveBeenCalled();
        expect(component.loadPropertyTypes).toHaveBeenCalled();
      });

      it('should not load asset types and external assets screen type connected', () => {
        spyOn(component, 'setDefaultExternalAssetFormAndTotals');
        spyOn(component, 'loadAssetTypes');
        spyOn(component, 'loadExternalAssets');
        spyOn(component, 'loadPropertyTypes');
        component.softwareData = SOFTWARE_DATA_CONNECTED_STATE;
        component.ngOnInit();
        expect(component.setDefaultExternalAssetFormAndTotals).not.toHaveBeenCalled();
        expect(component.loadExternalAssets).not.toHaveBeenCalled();
        expect(component.loadAssetTypes).not.toHaveBeenCalled();
        expect(component.loadPropertyTypes).not.toHaveBeenCalled();
      });
    });

    describe('ngOnDestroy()', () => {
      it('should unsubscribe all subscriptions', () => {
        spyOn((component as any).externalAssetsSubscription, 'unsubscribe');
        spyOn((component as any).assetsTypesSubscription, 'unsubscribe');
        spyOn((component as any).propertyTypesSubscription, 'unsubscribe');
        spyOn((component as any).confirmDialogSubscription, 'unsubscribe');
        spyOn((component as any).externalAssetsSaveSubscription, 'unsubscribe');

        component.ngOnDestroy();

        expect((component as any).externalAssetsSubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).assetsTypesSubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).propertyTypesSubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).confirmDialogSubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).externalAssetsSaveSubscription.unsubscribe).toHaveBeenCalled();
      });
    });

    describe('load all AssetTypes', () => {
      let externalAssetServiceSpy;

      beforeEach(() => {
        externalAssetServiceSpy = spyOn(externalAssetService, 'getAssetTypes');
      });

      afterEach(() => {
        externalAssetServiceSpy.calls.reset();
      });

      it('should set assetTypes using API response results', () => {
        const responseResult = TEST_ASSET_TYPES;

        externalAssetServiceSpy.and.returnValue(of(responseResult));

        component.loadAssetTypes();

        expect(externalAssetService.getAssetTypes).toHaveBeenCalled();
        expect(component.assetTypes).toEqual(responseResult);
      });

      it('should set up error message on API response error', () => {
        const errorMessage = { message: 'my Error msg' };
        externalAssetServiceSpy.and.returnValue(throwError(errorMessage));

        component.loadAssetTypes();

        expect(externalAssetService.getAssetTypes).toHaveBeenCalled();
        expect(component.assetTypes).toBeUndefined();
        expect(component.isGenericError).toBeTruthy();
        expect(component.genericAlert.messages).toEqual(errorMessage);
      });
    });

    describe('load all PropertyTypes', () => {
      let externalAssetServiceSpy;

      beforeEach(() => {
        externalAssetServiceSpy = spyOn(externalAssetService, 'getPropertyTypes');
      });

      afterEach(() => {
        externalAssetServiceSpy.calls.reset();
      });

      it('should set assetTypes using API response results', () => {
        const responseResult = TEST_DP_PROPERTY_TYPES;

        externalAssetServiceSpy.and.returnValue(of(responseResult));

        component.loadPropertyTypes();

        expect(externalAssetService.getPropertyTypes).toHaveBeenCalled();
        expect(component.propertyTypes).toEqual(responseResult);
      });

      it('should set up error message on API response error', () => {
        const errorMessage = { message: 'my Error msg' };
        externalAssetServiceSpy.and.returnValue(throwError(errorMessage));

        component.loadPropertyTypes();

        expect(externalAssetService.getPropertyTypes).toHaveBeenCalled();
        expect(component.propertyTypes).toBeUndefined();
        expect(component.isGenericError).toBeTruthy();
        expect(component.genericAlert.messages).toEqual(errorMessage);
      });
    });

    describe('load external assets', () => {
      let externalAssetServiceSpy;

      beforeEach(() => {
        externalAssetServiceSpy = spyOn(externalAssetService, 'getExternalAssets');
      });

      afterEach(() => {
        externalAssetServiceSpy.calls.reset();
      });

      it('should set external assets using API response results', () => {
        const responseResult = { ...EXTERNAL_ASSETS_DETAILS };
        const accountId: string = '123';

        component.accountId = accountId;
        spyOn(component, 'setExternalAssetsData');
        externalAssetServiceSpy.and.returnValue(of(responseResult));

        component.loadExternalAssets();

        expect(externalAssetService.getExternalAssets).toHaveBeenCalledWith(accountId);
        expect(component.isGenericError).toBeFalsy();
        expect(component.genericAlert.messages).toBe('');
        expect(component.initialLoading).toBeFalsy();
        expect(component.setExternalAssetsData).toHaveBeenCalledWith(responseResult);
      });

      it("should call uiRouter stateService's go method with correct argument on API response error", () => {
        const accountId: string = 'abc';
        const errorMessage = { message: 'my Error msg' };

        component.accountId = accountId;
        externalAssetServiceSpy.and.returnValue(throwError(errorMessage));

        component.loadExternalAssets();

        expect(externalAssetService.getExternalAssets).toHaveBeenCalledWith(accountId);
        expect(component.externalAssets).toBeUndefined();
        expect(component.initialLoading).toBeFalsy();
        expect((component as any).uiRouter.stateService.go).toHaveBeenCalledWith(SYSTEM_ERROR_MODULE_NAME, {
          accountId: component.accountId
        });
      });
    });

    describe('navigateToSMSFService()', () => {
      it("should call uiRouter stateService's go method with correct arguments", () => {
        component.navigateToSMSFService();

        expect((component as any).uiRouter.stateService.go).toHaveBeenCalledWith(SMSF_SERVICE_MODULE_NAME);
      });
    });

    describe('constructAssetTypeForms()', () => {
      it('should call createAssetsFormControl of PanoExternalAssetsFormCreator', () => {
        spyOn(externalAssetsFormCreator, 'createAssetsFormControl');
        component.constructAssetTypeForms({ ...EXTERNAL_ASSETS_DETAILS.assets });
        expect(externalAssetsFormCreator.createAssetsFormControl).toHaveBeenCalled();
      });
    });

    describe('confirmAssetDelete()', () => {
      beforeEach(() => {
        component.externalAssetsForm = createEmptyExternalAssetsForm();
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
        spyOn(component, 'setTotalAssetsCount');
      });

      it('should remove from FormArray and set to deletedExternalAssets array if its a existing asset and also call setTotalAssetsCount', () => {
        expect(component.externalAssetsForm.get('cashFormArray')['controls'].length).toBe(1);
        expect(component.deletedExternalAssets.length).toBe(0);

        const assetDetailsToDelete = {
          index: 0,
          assetTypeCode: 'cash',
          positionId: TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('positionId').value,
          isNewAsset: TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        };
        component.confirmAssetDelete(assetDetailsToDelete);

        expect(component.externalAssetsForm.get('cashFormArray')['controls'].length).toBe(0);
        expect(component.deletedExternalAssets.length).toBe(1);
        expect(component.setTotalAssetsCount).toHaveBeenCalled();
      });

      it('should remove from FormArray and donot set any thing to deletedExternalAssets array when its a newly added asset and also call setTotalAssetsCount', () => {
        expect(component.externalAssetsForm.get('cashFormArray')['controls'].length).toBe(1);
        expect(component.deletedExternalAssets.length).toBe(0);

        const assetDetailsToDelete = {
          index: 0,
          assetTypeCode: 'cash',
          positionId: TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('positionId').value,
          isNewAsset: true
        };
        component.confirmAssetDelete(assetDetailsToDelete);

        expect(component.externalAssetsForm.get('cashFormArray')['controls'].length).toBe(0);
        expect(component.deletedExternalAssets.length).toBe(0);
        expect(component.setTotalAssetsCount).toHaveBeenCalled();
      });
    });

    describe('collectAssetToDelete()', () => {
      beforeEach(() => {
        component.externalAssetsForm = createEmptyExternalAssetsForm();
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
      });

      describe('when collectAssetToDelete is called', () => {
        it("should call matDialog's open method with correct arguments and user confirmed and should call confirmAssetDelete", () => {
          expect(component.externalAssetsForm.get('cashFormArray')['controls'].length).toBe(1);

          (component as any).dialog = {
            open: jasmine.createSpy().and.returnValue({
              afterClosed: jasmine.createSpy().and.returnValue(of(ACTION_CONFIRM))
            })
          };

          const calledWith = {
            ...CONFIRM_DIALOG_CONFIG,
            data: { ...CONFIRM_DIALOG_CONFIG.data, ...ASSET_DELETE_DIALOG_DATA_CONFIG }
          };

          const assetDetailsToDelete = {
            index: 0,
            assetTypeCode: ASSET_TYPES.cash.code,
            positionId: TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('positionId').value,
            isNewAsset: TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
          };

          spyOn(component, 'confirmAssetDelete');
          component.collectAssetToDelete(assetDetailsToDelete);

          expect((component as any).dialog.open).toHaveBeenCalledWith(PanoConfirmDialogComponent, calledWith);
          expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
          expect(component.confirmAssetDelete).toHaveBeenCalledWith(assetDetailsToDelete);
        });

        it("should call matDialog's open method with correct arguments and user canceled, shouldn't call confirmAssetDelete method", () => {
          expect(component.externalAssetsForm.get('cashFormArray')['controls'].length).toBe(1);

          (component as any).dialog = {
            open: jasmine.createSpy().and.returnValue({
              afterClosed: jasmine.createSpy().and.returnValue(of(ACTION_CANCEL))
            })
          };

          const calledWith = {
            ...CONFIRM_DIALOG_CONFIG,
            data: { ...CONFIRM_DIALOG_CONFIG.data, ...ASSET_DELETE_DIALOG_DATA_CONFIG }
          };

          const assetDetailsToDelete = {
            index: 0,
            assetTypeCode: ASSET_TYPES.cash.code,
            positionId: TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('positionId').value,
            isNewAsset: TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
          };

          spyOn(component, 'confirmAssetDelete');
          component.collectAssetToDelete(assetDetailsToDelete);

          expect((component as any).dialog.open).toHaveBeenCalledWith(PanoConfirmDialogComponent, calledWith);
          expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
          expect(component.confirmAssetDelete).not.toHaveBeenCalled();
        });
      });
    });

    describe('getDeletedAssetDetails', () => {
      it('should return position id and quantity as 0 when called with position id', () => {
        const expectedResult = component.getDeletedAssetDetails('1233');

        expect(expectedResult.positionId).toBe('1233');
        expect(expectedResult.quantity).toBe(0);
      });
    });

    describe('collectAssetToAdd', () => {
      it('should call createAssetFormControl, so that new asset get added to respective formArray and also should call setTotalAssetsCount', () => {
        spyOn(externalAssetsFormCreator, 'createAssetFormControl');
        spyOn(component, 'setTotalAssetsCount');
        const newAssetDetails = { ...DEFAULT_ADD_ASSET_PROPS, assetTypeCode: ASSET_TYPES.cash.code };
        component.collectAssetToAdd(newAssetDetails);

        expect(externalAssetsFormCreator.createAssetFormControl).toHaveBeenCalledWith(
          component.externalAssetsForm.get('cashFormArray') as FormArray,
          ASSET_TYPES.cash.code,
          newAssetDetails
        );
        expect(component.setTotalAssetsCount).toHaveBeenCalled();
      });
    });

    describe('updateAssetTotalMarketValue', () => {
      it('should call calculateExternalAssetsTotal and also set the respective asset type total', () => {
        spyOn(component, 'calculateExternalAssetsTotal');
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
        const assetTypeTotalDetails = { assetTypeTotalMarketValue: 200, assetTypeCode: ASSET_TYPES.cash.code };

        component.updateAssetTotalMarketValue(assetTypeTotalDetails);

        expect(component.assetTypeTotals[`${ASSET_TYPES.cash.code}TotalMarketValue`]).toBe(200);
        expect(component.calculateExternalAssetsTotal).toHaveBeenCalled();
      });
      it('should call calculateExternalAssetsTotal and also set the respective asset type total to 0 when formArray is empty', () => {
        spyOn(component, 'calculateExternalAssetsTotal');
        component.externalAssetsForm.setControl('cashFormArray', new FormArray([]));
        const assetTypeTotalDetails = { assetTypeTotalMarketValue: 0, assetTypeCode: ASSET_TYPES.cash.code };

        component.updateAssetTotalMarketValue(assetTypeTotalDetails);

        expect(component.assetTypeTotals[`${ASSET_TYPES.cash.code}TotalMarketValue`]).toBe(0);
        expect(component.calculateExternalAssetsTotal).toHaveBeenCalled();
      });
    });

    describe('calculateExternalAssetsTotal', () => {
      it('should call calculateExternalAssetsTotal and also set the respective asset type total', () => {
        const assetsTotals: AssetTypeTotalMarketValue = {
          cashTotalMarketValue: 5,
          tdTotalMarketValue: 5,
          lsTotalMarketValue: 10,
          ilsTotalMarketValue: 5,
          mfTotalMarketValue: 5,
          mpTotalMarketValue: 10,
          dpTotalMarketValue: 5,
          othTotalMarketValue: 5
        };
        component.totalMarketValue = 0;
        component.assetTypeTotals = assetsTotals;
        component.calculateExternalAssetsTotal();

        expect(component.totalMarketValue).toBe(50);
      });
    });

    describe('saveAssetsChanges', () => {
      beforeEach(() => {
        spyOn(component, 'setDefaultExternalAssetFormAndTotals');
        spyOn(component, 'setExternalAssetsData');
        spyOn(component as any, 'scrollToErrorSection');
      });

      describe('when form is invalid', () => {
        it('should not call getExternalAssetDetailsForSave, externalAssetService.saveExternalAssets, setExternalAssetsData, but should call scrollToErrorSection', () => {
          spyOn(component, 'getExternalAssetDetailsForSave');
          spyOn(externalAssetService, 'saveExternalAssets');
          component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
          component.externalAssetsForm
            .get('cashFormArray')
            ['controls'][0].get('marketValue')
            .setValue(null);

          component.saveAssetsChanges();

          expect(component.getExternalAssetDetailsForSave).not.toHaveBeenCalled();
          expect(externalAssetService.saveExternalAssets).not.toHaveBeenCalled();
          expect(component.setDefaultExternalAssetFormAndTotals).not.toHaveBeenCalled();
          expect(component.setExternalAssetsData).not.toHaveBeenCalled();
          expect((component as any).scrollToErrorSection).toHaveBeenCalled();
        });
      });

      describe('when form is valid', () => {
        describe('when having unsaved change', () => {
          beforeEach(() => {
            component.externalAssetsForm.setControl(
              'cashFormArray',
              cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray
            );
            spyOn<any>(component, 'hasUnsavedChanges').and.returnValue(true);
          });

          it('should set isSaveError to false and saveLoading to true before save api gets resolved', () => {
            spyOn(externalAssetService, 'saveExternalAssets').and.returnValue(timer(1000) as any);
            component.saveAssetsChanges();

            expect(component.isSaveError).toBe(false);
            expect(component.saveLoading).toBe(true);
          });

          it('should call getExternalAssetDetailsForSave, externalAssetService.saveExternalAssets, setExternalAssetsData on save api success', () => {
            const accountId: string = 'abc';
            const mockExternalAssetsSaveDetails = {
              addedAndEdited: {
                cash: [],
                td: [],
                ls: [],
                ils: [],
                mf: [],
                mp: [],
                dp: [],
                oth: []
              },
              deleted: []
            };
            spyOn(component, 'getExternalAssetDetailsForSave').and.returnValue(mockExternalAssetsSaveDetails);
            spyOn(externalAssetService, 'saveExternalAssets').and.returnValue(of({ ...EXTERNAL_ASSETS_DETAILS }));
            spyOn((component as any).snackBar, 'openFromComponent');
            component.accountId = accountId;

            component.saveAssetsChanges();
            expect(component.getExternalAssetDetailsForSave).toHaveBeenCalled();
            expect(externalAssetService.saveExternalAssets).toHaveBeenCalledWith(
              accountId,
              mockExternalAssetsSaveDetails
            );
            expect((component as any).snackBar.openFromComponent).toHaveBeenCalledWith(
              SnackBarTemplateComponent,
              SNACK_BAR_EXTERNAL_ASSETS_SUCCESS
            );
            expect(component.setDefaultExternalAssetFormAndTotals).toHaveBeenCalled();
            expect(component.setExternalAssetsData).toHaveBeenCalled();
            expect(component.saveLoading).toBe(false);
          });

          it('should set up error message and set isSaveError to true on API response error', () => {
            const accountId: string = 'abc';
            const mockExternalAssetsSaveDetails = {
              addedAndEdited: {
                cash: [],
                td: [],
                ls: [],
                ils: [],
                mf: [],
                mp: [],
                dp: [],
                oth: []
              },
              deleted: []
            };
            const errorMessage = { message: 'my Error msg' };

            component.accountId = accountId;
            spyOn(component, 'getExternalAssetDetailsForSave').and.returnValue(mockExternalAssetsSaveDetails);
            spyOn(externalAssetService, 'saveExternalAssets').and.returnValue(throwError(errorMessage));

            component.saveAssetsChanges();

            expect(component.getExternalAssetDetailsForSave).toHaveBeenCalled();
            expect(externalAssetService.saveExternalAssets).toHaveBeenCalledWith(
              accountId,
              mockExternalAssetsSaveDetails
            );
            expect(component.setDefaultExternalAssetFormAndTotals).not.toHaveBeenCalled();
            expect(component.setExternalAssetsData).not.toHaveBeenCalled();
            expect(component.saveLoading).toBe(false);
            expect(component.isSaveError).toBe(true);
          });
        });

        describe('when has no unsaved change', () => {
          beforeEach(() => {
            spyOn<any>(component, 'hasUnsavedChanges').and.returnValue(false);
            component.externalAssetsForm.setControl(
              'cashFormArray',
              cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray
            );
          });

          it("should call snackBar's openFromComponent method with correct arguments", () => {
            spyOn((component as any).snackBar, 'openFromComponent');
            component.saveAssetsChanges();

            expect((component as any).snackBar.openFromComponent).toHaveBeenCalledWith(
              SnackBarTemplateComponent,
              SNACK_BAR_EXTERNAL_ASSETS_NO_UNSAVED_CHANGES
            );
          });

          it("should not call externalAssetService's saveExternalAssets", () => {
            spyOn(externalAssetService, 'saveExternalAssets');
            component.saveAssetsChanges();

            expect(externalAssetService.saveExternalAssets).not.toHaveBeenCalled();
          });
        });
      });
    });

    describe('scrollToErrorSection', () => {
      it('should call getInvalidFormArray and pageScrollService with correct argument', fakeAsync(() => {
        const mockInvalidFormArray = cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray;
        mockInvalidFormArray.controls[0].get('marketValue').setValue(null);
        spyOn(component as any, 'getInvalidFormArray').and.returnValue(mockInvalidFormArray);
        spyOn((component as any).document, 'querySelector').and.returnValue(null);
        const pageScrollOptions = {
          document: (component as any).document,
          speed: PAGE_SCROLL_SPEED,
          scrollTarget: '.cash-form-array-header',
          scrollViews: [null]
        };

        (component as any).scrollToErrorSection();
        flush();
        expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
        expect((component as any).getInvalidFormArray).toHaveBeenCalled();
      }));
    });

    describe('getInvalidFormArray', () => {
      it('should return invalid formArray', () => {
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
        component.externalAssetsForm
          .get('cashFormArray')
          ['controls'][0].get('marketValue')
          .setValue(null);

        const expectedFormArray = (component as any).getInvalidFormArray();
        expect(expectedFormArray).toEqual(component.externalAssetsForm.get('cashFormArray'));
      });

      it('should return undefined when all Form Arrays are valid', () => {
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
        const expectedFormArray = (component as any).getInvalidFormArray();
        expect(expectedFormArray).toBe(undefined);
      });
    });

    describe('getExternalAssetDetailsForSave', () => {
      it('should call getAssetFormArrayValues and return the assetDetails to submit', () => {
        const mockExternalAssetsSaveDetails = {
          addedAndEdited: {
            cash: [],
            td: [],
            ls: [],
            ils: [],
            mf: [],
            mp: [],
            dp: [],
            oth: []
          },
          deleted: [
            {
              positionId: '1122',
              quantity: 0
            }
          ]
        };
        component.deletedExternalAssets = [...mockExternalAssetsSaveDetails.deleted];
        spyOn(component, 'getAssetFormArrayValues').and.returnValue(mockExternalAssetsSaveDetails.addedAndEdited);

        const expectedResult = component.getExternalAssetDetailsForSave();

        expect(expectedResult).toEqual(mockExternalAssetsSaveDetails);
        expect(component.getAssetFormArrayValues).toHaveBeenCalled();
      });
    });

    describe('getAssetFormArrayValues', () => {
      it('should return Assets Details for each assets', () => {
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
        component.externalAssetsForm.setControl('tdFormArray', cloneDeep(TEST_TD_ASSETS_FORM_ARRAY) as FormArray);

        const expectedAssets = component.getAssetFormArrayValues();

        expect(expectedAssets.cash.length).toBe(1);
        expect(expectedAssets.td.length).toBe(1);
        expect(expectedAssets.ls.length).toBe(0);
        expect(expectedAssets.ils.length).toBe(0);
        expect(expectedAssets.mf.length).toBe(0);
        expect(expectedAssets.mp.length).toBe(0);
        expect(expectedAssets.dp.length).toBe(0);
        expect(expectedAssets.oth.length).toBe(0);
      });

      it('should getAssetFormValues for each assets, 8 asset types', () => {
        spyOn(component, 'getAssetFormValues').and.returnValue([]);
        component.getAssetFormArrayValues();

        expect(component.getAssetFormValues).toHaveBeenCalledTimes(8);
      });
    });

    describe('getAssetFormValues', () => {
      it('should return respective assets data from the formArray', () => {
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
        const expectedAssetDetails = component.getAssetFormValues(
          component.externalAssetsForm.get('cashFormArray') as FormArray,
          ASSET_TYPES.cash.editFormControls
        );

        expect(expectedAssetDetails[0]['assetClassCode']).toBe(ASSET_LIST_CASH[0].assetClassCode);
        expect(expectedAssetDetails[0]['assetTypeCode']).toBe(ASSET_LIST_CASH[0].assetTypeCode);
        expect(expectedAssetDetails[0]['marketValue']).toBe(ASSET_LIST_CASH[0].marketValue);
        expect(expectedAssetDetails[0]['isNewAsset']).toBe(ASSET_LIST_CASH[0].isNewAsset);
        expect(expectedAssetDetails[0]['positionId']).toBe(ASSET_LIST_CASH[0].positionId);
        expect(expectedAssetDetails[0]['positionName']).toBe(ASSET_LIST_CASH[0].positionName);
        expect(expectedAssetDetails[0]['source']).toBe(ASSET_LIST_CASH[0].source);
        expect(moment(expectedAssetDetails[0]['valuationDate'], 'DD MMM YYYY').format('DD MMM YYYY')).toBe(
          moment(ASSET_LIST_CASH[0].valuationDate)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
      });

      it('should return respective assets data from the formArray with valuationDate empty', () => {
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);
        component.externalAssetsForm
          .get('cashFormArray')
          ['controls'][0].get('valuationDate')
          .setValue('');
        const expectedAssetDetails = component.getAssetFormValues(
          component.externalAssetsForm.get('cashFormArray') as FormArray,
          ASSET_TYPES.cash.editFormControls
        );

        expect(expectedAssetDetails[0]['assetClassCode']).toBe(ASSET_LIST_CASH[0].assetClassCode);
        expect(expectedAssetDetails[0]['assetTypeCode']).toBe(ASSET_LIST_CASH[0].assetTypeCode);
        expect(expectedAssetDetails[0]['marketValue']).toBe(ASSET_LIST_CASH[0].marketValue);
        expect(expectedAssetDetails[0]['isNewAsset']).toBe(ASSET_LIST_CASH[0].isNewAsset);
        expect(expectedAssetDetails[0]['positionId']).toBe(ASSET_LIST_CASH[0].positionId);
        expect(expectedAssetDetails[0]['positionName']).toBe(ASSET_LIST_CASH[0].positionName);
        expect(expectedAssetDetails[0]['source']).toBe(ASSET_LIST_CASH[0].source);
        expect(expectedAssetDetails[0]['valuationDate']).toBe('');
      });
    });

    describe('setExternalAssetsData', () => {
      it('should set externalAsset data got from api to externalAssets and should call constructAssetTypeForms, setTotalAssetsCount and getExternalAssetDetailsForSave', () => {
        const data = { ...EXTERNAL_ASSETS_DETAILS };
        spyOn(component, 'constructAssetTypeForms');
        spyOn(component, 'setTotalAssetsCount');
        spyOn<any>(component, 'getExternalAssetDetailsForSave').and.returnValue({ detail: {} });

        component.setExternalAssetsData(data);

        expect(component.externalAssets).toEqual(data);
        expect(component.constructAssetTypeForms).toHaveBeenCalledWith(data.assets);
        expect(component.setTotalAssetsCount).toHaveBeenCalled();
        expect(component.getExternalAssetDetailsForSave).toHaveBeenCalled();
        expect((component as any).currentSavedSnapshot).toEqual({ detail: {} });
      });

      it('should not call constructAssetTypeForms when no assets there', () => {
        const data = {
          totalValuation: 0,
          hasAssets: false,
          assets: {
            cash: [],
            td: [],
            ls: [],
            ils: [],
            mf: [],
            mp: [],
            dp: [],
            oth: []
          }
        };

        spyOn(component, 'constructAssetTypeForms');

        component.setExternalAssetsData(data);

        expect(component.externalAssets).toEqual(data);
        expect(component.constructAssetTypeForms).not.toHaveBeenCalled();
      });
    });

    describe('setDefaultExternalAssetFormAndTotals', () => {
      it('should set externalAssetsForm asset Form arrays to empty also set totalMarketValue and assets totals to 0', () => {
        component.setDefaultExternalAssetFormAndTotals();

        checkExternalAssetsFormArrays();
        expect(component.assetTypeTotals).toEqual(DEFAULT_ASSET_TYPE_TOTAL);
        expect(component.totalMarketValue).toBe(0);
        expect(component.deletedExternalAssets).toEqual([]);
        expect(component.totalAssetsCount).toBe(0);
      });
    });

    describe('clearChanges()', () => {
      const calledWith = {
        ...CONFIRM_DIALOG_CONFIG,
        data: { ...CONFIRM_DIALOG_CONFIG.data, ...CLEAR_CHANGES_DIALOG_DATA_CONFIG }
      };

      beforeEach(() => {
        spyOn(component, 'setDefaultExternalAssetFormAndTotals');
        spyOn(component, 'setExternalAssetsData');
      });

      it("should call matDialog's open method with correct arguments and user confirmed and should call setDefaultExternalAssetFormAndTotals and setExternalAssetsData", () => {
        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(ACTION_CONFIRM))
          })
        };
        const data = {
          totalValuation: 0,
          hasAssets: false,
          assets: {
            cash: [],
            td: [],
            ls: [],
            ils: [],
            mf: [],
            mp: [],
            dp: [],
            oth: []
          }
        };

        component.externalAssets = data;
        component.clearChanges();

        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoConfirmDialogComponent, calledWith);
        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.setDefaultExternalAssetFormAndTotals).toHaveBeenCalled();
        expect(component.setExternalAssetsData).toHaveBeenCalledWith(data);
      });

      it("should call matDialog's open method with correct arguments and user canceled, shouldn't call setDefaultExternalAssetFormAndTotals and setExternalAssetsData method", () => {
        (component as any).dialog = {
          open: jasmine.createSpy().and.returnValue({
            afterClosed: jasmine.createSpy().and.returnValue(of(ACTION_CANCEL))
          })
        };

        component.clearChanges();

        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoConfirmDialogComponent, calledWith);
        expect((component as any).dialog.open().afterClosed).toHaveBeenCalled();
        expect(component.setDefaultExternalAssetFormAndTotals).not.toHaveBeenCalled();
        expect(component.setExternalAssetsData).not.toHaveBeenCalled();
      });
    });

    describe('setTotalAssetsCount()', () => {
      it('should set totalAssetsCount based on the number of assets in each form', () => {
        component.externalAssetsForm.setControl('cashFormArray', cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray);

        component.setTotalAssetsCount();
        expect(component.totalAssetsCount).toBe(1);
      });
    });

    describe('uiCanExit()', () => {
      describe('when no unsaved change', () => {
        it('should resolve to true', async () => {
          spyOn(component as any, 'hasUnsavedChanges').and.returnValue(false);

          expect(await component.uiCanExit()).toBe(true);
        });
      });

      describe('when having unsaved changes', () => {
        it('should resolved to return value of dialog close when dialog closed with true', async () => {
          spyOn(component as any, 'hasUnsavedChanges').and.returnValue(true);
          (component as any).dialog = {
            open: jasmine.createSpy().and.returnValue({
              afterClosed: jasmine.createSpy().and.returnValue(of(ACTION_CONFIRM))
            })
          };
          const expectedValue = await component.uiCanExit();

          expect((component as any).dialog.open).toHaveBeenCalledWith(PanoConfirmDialogComponent, {
            ...CONFIRM_DIALOG_CONFIG,
            data: { ...CONFIRM_DIALOG_CONFIG.data, ...CONFIRM_CANCELLATION_DIALOG_DATA_CONFIG }
          });

          expect(expectedValue).toBe(ACTION_CONFIRM);
        });

        it("should call to transition stateService's target method with correct argument when dialog closed with false", async () => {
          spyOn(component as any, 'hasUnsavedChanges').and.returnValue(true);
          (component as any).dialog = {
            open: jasmine.createSpy().and.returnValue({
              afterClosed: jasmine.createSpy().and.returnValue(of(ACTION_CANCEL))
            })
          };

          await component.uiCanExit();

          expect((component as any).dialog.open).toHaveBeenCalledWith(PanoConfirmDialogComponent, {
            ...CONFIRM_DIALOG_CONFIG,
            data: { ...CONFIRM_DIALOG_CONFIG.data, ...CONFIRM_CANCELLATION_DIALOG_DATA_CONFIG }
          });
          expect((component as any).uiRouter.stateService.target).toHaveBeenCalledWith(EXTERNAL_ASSETS_MODULE);
        });
      });

      describe('when accounting software status is connected', () => {
        it('should resolve to true and also should not call hasUnsavedChanges', async () => {
          component.softwareData = SOFTWARE_DATA_CONNECTED_STATE;
          spyOn(component as any, 'hasUnsavedChanges');

          expect(await component.uiCanExit()).toBe(true);
          expect((component as any).hasUnsavedChanges).not.toHaveBeenCalled();
        });
      });
    });

    describe('hasUnsavedChanges()', () => {
      describe('when currentSnapshot truthy', () => {
        it('should return true when having unsaved changes', () => {
          spyOn(component, 'getExternalAssetDetailsForSave').and.returnValue({ x: 1 } as any);
          (component as any).currentSavedSnapshot = { x: 2 };

          expect((component as any).hasUnsavedChanges()).toBe(true);
        });

        it('should return false when having no unsaved changes', () => {
          spyOn(component, 'getExternalAssetDetailsForSave').and.returnValue({ x: 1 } as any);
          (component as any).currentSavedSnapshot = { x: 1 };

          expect((component as any).hasUnsavedChanges()).toBe(false);
        });
      });

      describe('when currentSnapshot falsy', () => {
        it('should return false', () => {
          (component as any).currentSavedSnapshot = undefined;

          expect((component as any).hasUnsavedChanges()).toBe(false);
        });
      });
    });
  });

  describe('view', () => {
    describe('connected screen type', () => {
      it('should be shown if screen type is connected', () => {
        component.softwareData = SOFTWARE_DATA_CONNECTED_STATE;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('pano-external-assets-connected'))).not.toBeNull();
        expect(fixture.debugElement.query(By.css('pano-external-assets-connection-pending'))).toBeNull();
        expect(fixture.debugElement.query(By.css('js-test-external-assets-manual'))).toBeNull();
      });
    });

    describe('pending screen type', () => {
      it('should be shown if screen type is awaiting inside manual screen', () => {
        component.softwareData = SOFTWARE_DATA_PENDING_STATE;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('pano-external-assets-connected'))).toBeNull();
        expect(fixture.debugElement.query(By.css('pano-external-assets-connection-pending'))).not.toBeNull();
        expect(fixture.debugElement.query(By.css('.js-test-external-assets-manual'))).not.toBeNull();
      });
    });

    describe('only manual screen type', () => {
      it('should be shown if screen type is manual', () => {
        component.softwareData = SOFTWARE_DATA_MANUAL_STATE;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('pano-external-assets-connected'))).toBeNull();
        expect(fixture.debugElement.query(By.css('pano-external-assets-connection-pending'))).toBeNull();
        expect(fixture.debugElement.query(By.css('.js-test-external-assets-manual'))).not.toBeNull();
      });
    });

    describe('manual screen type', () => {
      beforeEach(() => {
        component.softwareData = SOFTWARE_DATA_MANUAL_STATE;
      });

      describe('when loading', () => {
        it('should only show title when loading screen', () => {
          fixture.detectChanges();

          const fixtureElement = fixture.debugElement;
          const header = fixtureElement.query(By.css('h1')).nativeElement.innerHTML;

          expect(header).toContain('External assets');
          expect(header).not.toContain('$');

          expect(fixtureElement.query(By.css('bt-loading.js-loading-spinner'))).toBeTruthy();
          expect(fixtureElement.query(By.css('bt-alert.js-generic-error'))).toBeFalsy();
          expect(fixtureElement.query(By.css('.js-disclaimer'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-add-asset'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-cash'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-term-deposit'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-listed-security'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-international-listed-security'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-managed-fund'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-managed-portfolio'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-direct-property'))).toBeFalsy();
          expect(fixtureElement.query(By.css('pano-external-assets-other'))).toBeFalsy();
          expect(fixtureElement.query(By.css('.js-test-extassets-total-market-value-label'))).toBeFalsy();
          expect(fixtureElement.query(By.css('.js-test-extassets-total-market-value'))).toBeFalsy();
          expect(fixtureElement.query(By.css('.js-test-extassets-save-assets-changes-button'))).toBeFalsy();
          expect(fixtureElement.query(By.css('.js-test-extassets-clear-assets-changes-button'))).toBeFalsy();
        });

        it('should hide bt-buttons', () => {
          component.initialLoading = true;
          fixture.detectChanges();

          expect(fixture.debugElement.query(By.css('.js-test-extassets-save-assets-changes-button'))).toBeFalsy();

          expect(fixture.debugElement.query(By.css('.js-test-extassets-clear-assets-changes-button'))).toBeFalsy();
        });
      });

      describe('when not loading', () => {
        beforeEach(() => (component.initialLoading = false));

        describe('common screen elements', () => {
          it('should show no external assets message when isGenericError falsy', () => {
            component.isGenericError = false;
            component.totalAssetsCount = 0;
            component.externalAssets = { ...EXTERNAL_ASSETS_DETAILS, hasAssets: false, totalValuation: 0 };
            fixture.detectChanges();

            const fixtureElement = fixture.debugElement;
            const header = fixtureElement.query(By.css('h1')).nativeElement.innerHTML;

            expect(header).toContain('External assets');
            expect(fixtureElement.query(By.css('h1>span')).nativeElement.innerHTML).toContain('$0');

            const noAssetMessageElement = fixtureElement.query(By.css('.js-no-assets-message'));
            expect(noAssetMessageElement.nativeElement.textContent).toContain('No external assets added.');
            expect(noAssetMessageElement.nativeElement.textContent).toContain('Select from the list to add an asset.');

            expect(fixtureElement.query(By.css('bt-loading.js-loading-spinner'))).toBeFalsy();
            expect(fixtureElement.query(By.css('bt-alert.js-generic-error'))).toBeFalsy();
            expect(fixtureElement.query(By.css('.js-disclaimer'))).toBeTruthy();
          });

          it('should show total amount', () => {
            const totalAmount: number = 123.45;
            component.totalMarketValue = totalAmount;
            component.totalAssetsCount = 1;
            component.externalAssets = { ...EXTERNAL_ASSETS_DETAILS, totalValuation: totalAmount };
            fixture.detectChanges();

            const fixtureElement = fixture.debugElement;
            const header = fixtureElement.query(By.css('h1')).nativeElement.innerHTML;

            expect(header).toContain('External assets');
            expect(fixtureElement.query(By.css('h1>span')).nativeElement.innerHTML).toContain(`${totalAmount}`);

            expect(fixtureElement.query(By.css('.js-no-assets-message'))).toBeFalsy();

            expect(fixtureElement.query(By.css('bt-loading.js-loading-spinner'))).toBeFalsy();
            expect(fixtureElement.query(By.css('.js-generic-error'))).toBeFalsy();
            expect(fixtureElement.query(By.css('.js-disclaimer'))).toBeTruthy();
          });

          it('should have btEntitlement directive on bt-alert with all bells and whistles', () => {
            const totalAmount: number = 123.45;
            component.externalAssets = { ...EXTERNAL_ASSETS_DETAILS, totalValuation: totalAmount };
            (component as any).smsfEntitlement = SMSF_ACCOUNTING_SOFTWARE_READ_ENTITLEMENT;
            fixture.detectChanges();

            const btAlertElement = fixture.debugElement.query(By.css('.js-smsf-entitlement-alert'));
            expect(btAlertElement).toBeTruthy();
            expect(btAlertElement.properties.config).toEqual(SMSF_SERVICES_ALERT);
            expect(btAlertElement.nativeElement.getAttribute('btEntitlement')).toBe(
              SMSF_ACCOUNTING_SOFTWARE_READ_ENTITLEMENT
            );
            expect(btAlertElement.query(By.css('span')).nativeElement.innerHTML).toBe(
              'If you request a connection to accounting software, then that data will replace any external assets you enter. For details see '
            );

            const anchorTag = btAlertElement.query(By.css('a'));
            expect(anchorTag).toBeTruthy();

            spyOn(component, 'navigateToSMSFService');
            anchorTag.nativeElement.dispatchEvent(new Event('click'));

            expect(component.navigateToSMSFService).toHaveBeenCalled();
          });

          it('should show generic error message', () => {
            component.isGenericError = true;
            fixture.detectChanges();

            const fixtureElement = fixture.debugElement;
            const header = fixtureElement.query(By.css('h1')).nativeElement.innerHTML;

            expect(header).toContain('External assets');
            expect(fixtureElement.query(By.css('h1>span'))).toBeTruthy();

            expect(fixtureElement.query(By.css('bt-loading.js-loading-spinner'))).toBeFalsy();
            expect(fixtureElement.query(By.css('bt-alert.js-generic-error'))).toBeTruthy();
            expect(fixtureElement.query(By.css('bt-alert.js-generic-error')).properties.config).toEqual(
              component.genericAlert
            );

            expect(fixtureElement.query(By.css('.js-disclaimer'))).toBeTruthy();
            expect(fixtureElement.query(By.css('pano-add-asset'))).toBeFalsy();
          });

          it('should show disclaimer text', () => {
            fixture.detectChanges();

            const disclaimerElements = fixture.debugElement.queryAll(By.css('.js-disclaimer p'));

            expect(disclaimerElements[0].nativeElement.textContent).toBe(
              'Any information on external assets (including, for example, number of securities held or value of holding) sourced from the connected accounting software or manually entered by you or your financial adviser may not be current at the nominated valuation date. Prior to acting on the information displayed, you should discuss this with your accountant or financial adviser and seek advice to ensure this is appropriate to your circumstances.'
            );
            expect(disclaimerElements[1].nativeElement.textContent).toBe(
              'For external assets manually entered, where these assets are also available for investment on Panorama, the latest available exit price for unlisted managed funds and the latest intraday last sale price (up to 20 minutes delayed) for listed securities are used as the market value, for the report request date. Where manually entered external assets are not available on Panorama the user must maintain the price and value. For external assets displayed utilising accounting software connection the asset price and value is sourced from the accounting software.'
            );
            expect(disclaimerElements[2].nativeElement.textContent).toBe(
              'The information contained in this report is overview only and should not be considered a comprehensive statement on any matter nor relied upon as such. No company in the Westpac Group nor any of their related entities, employees, or directors gives any warranty of reliability or accuracy or accepts any responsibility arising in any other way including by reason of negligence for errors or omissions. In particular, no guarantee or warranty is given in relation to the quality or accuracy of any information provided by third parties (including data from connected accounting software, your accountant and your financial adviser) and no responsibility or liability is accepted for any loss or damage you may suffer arising directly or indirectly as a result of your reliance on, or use of, that information. This disclaimer is subject to any requirement of the law.'
            );
          });
        });

        describe('child component pano-add-asset', () => {
          beforeEach(() => {
            component.assetTypes = TEST_ASSET_TYPES;
            component.propertyTypes = TEST_DP_PROPERTY_TYPES;
            component.totalAssetsCount = 1;
            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for collectAssetToAdd when event get triggered', () => {
            const panoAddAssetComponent = fixture.debugElement.query(By.css('pano-add-asset'));
            expect(panoAddAssetComponent.nativeElement).toBeTruthy();

            expect(panoAddAssetComponent.properties.assetTypes).toEqual(TEST_ASSET_TYPES);
            expect(panoAddAssetComponent.properties.propertyTypes).toEqual(TEST_DP_PROPERTY_TYPES);
            expect(panoAddAssetComponent.properties.totalAssetsCount).toEqual(1);

            spyOn(component, 'collectAssetToAdd');
            panoAddAssetComponent.nativeElement.dispatchEvent(new Event('assetAdd'));

            expect(component.collectAssetToAdd).toHaveBeenCalled();
          });
        });

        describe('should show child components when enough assets are there', () => {
          it('should show child components', () => {
            component.externalAssetsForm = new FormGroup({
              cashFormArray: cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray,
              tdFormArray: cloneDeep(TEST_TD_ASSETS_FORM_ARRAY) as FormArray,
              lsFormArray: cloneDeep(TEST_LS_ASSETS_FORM_ARRAY) as FormArray,
              ilsFormArray: cloneDeep(TEST_ILS_ASSETS_FORM_ARRAY) as FormArray,
              mfFormArray: cloneDeep(TEST_MF_ASSETS_FORM_ARRAY) as FormArray,
              mpFormArray: cloneDeep(TEST_MP_ASSETS_FORM_ARRAY) as FormArray,
              dpFormArray: cloneDeep(TEST_DP_ASSETS_FORM_ARRAY) as FormArray,
              othFormArray: cloneDeep(TEST_OTH_ASSETS_FORM_ARRAY) as FormArray
            });
            component.totalMarketValue = 100;
            fixture.detectChanges();

            expect(fixture.debugElement.query(By.css('pano-external-assets-cash'))).toBeTruthy();
            expect(fixture.debugElement.query(By.css('pano-external-assets-term-deposit'))).toBeTruthy();
            expect(fixture.debugElement.query(By.css('pano-external-assets-listed-security'))).toBeTruthy();
            expect(
              fixture.debugElement.query(By.css('pano-external-assets-international-listed-security'))
            ).toBeTruthy();
            expect(fixture.debugElement.query(By.css('pano-external-assets-managed-fund'))).toBeTruthy();
            expect(fixture.debugElement.query(By.css('pano-external-assets-managed-portfolio'))).toBeTruthy();
            expect(fixture.debugElement.query(By.css('pano-external-assets-direct-property'))).toBeTruthy();
            expect(fixture.debugElement.query(By.css('pano-external-assets-other'))).toBeTruthy();
          });
        });

        describe('total market value', () => {
          it('should show when isGenericError false or totalMarketValue available', () => {
            component.isGenericError = false;
            component.totalMarketValue = 100;
            fixture.detectChanges();

            expect(fixture.debugElement.query(By.css('.js-test-extassets-total-market-value-label'))).toBeTruthy();
            expect(
              fixture.debugElement.query(By.css('.js-test-extassets-total-market-value-label')).nativeElement.innerHTML
            ).toBe('Total external assets');
            expect(fixture.debugElement.query(By.css('.js-test-extassets-total-market-value'))).toBeTruthy();
            expect(
              fixture.debugElement.query(By.css('.js-test-extassets-total-market-value')).nativeElement.innerHTML.trim()
            ).toBe('$100.00');

            component.totalMarketValue = 0;
            fixture.detectChanges();

            expect(fixture.debugElement.query(By.css('.js-test-extassets-total-market-value-label'))).toBeTruthy();
          });

          it('should not show when isGenericError true and totalMarketValue unavailable', () => {
            component.isGenericError = true;
            component.totalMarketValue = 0;
            fixture.detectChanges();

            expect(fixture.debugElement.query(By.css('.js-test-extassets-total-market-value-label'))).toBeFalsy();
          });
        });

        describe('bt-alert - save error', () => {
          it('should show with correct config when isSaveError true', () => {
            component.isSaveError = true;
            fixture.detectChanges();

            const btAlertSaveError = fixture.debugElement.query(By.css('.js-save-error'));
            expect(btAlertSaveError).toBeTruthy();

            expect(btAlertSaveError.properties.config).toEqual(component.genericAlert);
          });

          it('should not show when isSaveError false', () => {
            component.isSaveError = false;
            fixture.detectChanges();

            const btAlertSaveError = fixture.debugElement.query(By.css('.js-save-error'));
            expect(btAlertSaveError).toBeFalsy();
          });
        });

        describe('child component pano-external-assets-cash', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl(
              'cashFormArray',
              cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray
            );

            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for assetDelete when event get triggered', () => {
            expect(component.externalAssetsForm.get('cashFormArray')['controls'].length).toBe(1);

            const panoExternalAssetsCashComponent = fixture.debugElement.query(By.css('pano-external-assets-cash'));
            expect(panoExternalAssetsCashComponent.nativeElement).toBeTruthy();

            expect(panoExternalAssetsCashComponent.properties.cashFormArray).toEqual(
              component.externalAssetsForm.get('cashFormArray')
            );
            expect(panoExternalAssetsCashComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('cashFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            panoExternalAssetsCashComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            panoExternalAssetsCashComponent.nativeElement.dispatchEvent(new Event('assetTotalMarketValueUpdate'));

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('child component pano-external-assets-term-deposit', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl('tdFormArray', cloneDeep(TEST_TD_ASSETS_FORM_ARRAY) as FormArray);
            fixture.detectChanges();
          });

          it('should have the properties passed ', () => {
            expect(component.externalAssetsForm.get('tdFormArray')['controls'].length).toBe(1);

            const PanoExternalAssetsTermDepositComponent = fixture.debugElement.query(
              By.css('pano-external-assets-term-deposit')
            );
            expect(PanoExternalAssetsTermDepositComponent.nativeElement).toBeTruthy();

            expect(PanoExternalAssetsTermDepositComponent.properties.tdFormArray).toEqual(
              component.externalAssetsForm.get('tdFormArray')
            );
            expect(PanoExternalAssetsTermDepositComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('tdFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            PanoExternalAssetsTermDepositComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            PanoExternalAssetsTermDepositComponent.nativeElement.dispatchEvent(
              new Event('assetTotalMarketValueUpdate')
            );

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('child component pano-external-assets-listed-security', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl('lsFormArray', cloneDeep(TEST_LS_ASSETS_FORM_ARRAY) as FormArray);
            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for assetDelete when event get triggered', () => {
            expect(component.externalAssetsForm.get('lsFormArray')['controls'].length).toBe(1);

            const panoExternalAssetsLsComponent = fixture.debugElement.query(
              By.css('pano-external-assets-listed-security')
            );
            expect(panoExternalAssetsLsComponent.nativeElement).toBeTruthy();

            expect(panoExternalAssetsLsComponent.properties.lsFormArray).toEqual(
              component.externalAssetsForm.get('lsFormArray')
            );
            expect(panoExternalAssetsLsComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('lsFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            panoExternalAssetsLsComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            panoExternalAssetsLsComponent.nativeElement.dispatchEvent(new Event('assetTotalMarketValueUpdate'));

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('child component pano-external-assets-international-listed-security', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl('ilsFormArray', cloneDeep(TEST_ILS_ASSETS_FORM_ARRAY) as FormArray);
            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for assetDelete when event get triggered', () => {
            expect(component.externalAssetsForm.get('ilsFormArray')['controls'].length).toBe(1);

            const panoExternalAssetsILsComponent = fixture.debugElement.query(
              By.css('pano-external-assets-international-listed-security')
            );
            expect(panoExternalAssetsILsComponent.nativeElement).toBeTruthy();

            expect(panoExternalAssetsILsComponent.properties.ilsFormArray).toEqual(
              component.externalAssetsForm.get('ilsFormArray')
            );
            expect(panoExternalAssetsILsComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('ilsFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            panoExternalAssetsILsComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            panoExternalAssetsILsComponent.nativeElement.dispatchEvent(new Event('assetTotalMarketValueUpdate'));

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('child component pano-external-assets-managed-fund', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl('mfFormArray', cloneDeep(TEST_MF_ASSETS_FORM_ARRAY) as FormArray);
            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for assetDelete when event get triggered', () => {
            expect(component.externalAssetsForm.get('mfFormArray')['controls'].length).toBe(1);

            const panoExternalAssetsManagedFundComponent = fixture.debugElement.query(
              By.css('pano-external-assets-managed-fund')
            );
            expect(panoExternalAssetsManagedFundComponent.nativeElement).toBeTruthy();

            expect(panoExternalAssetsManagedFundComponent.properties.mfFormArray).toEqual(
              component.externalAssetsForm.get('mfFormArray')
            );
            expect(panoExternalAssetsManagedFundComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('mfFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            panoExternalAssetsManagedFundComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            panoExternalAssetsManagedFundComponent.nativeElement.dispatchEvent(
              new Event('assetTotalMarketValueUpdate')
            );

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('child component pano-external-assets-managed-portfolio', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl('mpFormArray', cloneDeep(TEST_MP_ASSETS_FORM_ARRAY) as FormArray);
            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for assetDelete when event get triggered', () => {
            expect(component.externalAssetsForm.get('mpFormArray')['controls'].length).toBe(1);

            const panoExternalAssetsManagedPortfolioComponent = fixture.debugElement.query(
              By.css('pano-external-assets-managed-portfolio')
            );
            expect(panoExternalAssetsManagedPortfolioComponent.nativeElement).toBeTruthy();

            expect(panoExternalAssetsManagedPortfolioComponent.properties.mpFormArray).toEqual(
              component.externalAssetsForm.get('mpFormArray')
            );
            expect(panoExternalAssetsManagedPortfolioComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('mpFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            panoExternalAssetsManagedPortfolioComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            panoExternalAssetsManagedPortfolioComponent.nativeElement.dispatchEvent(
              new Event('assetTotalMarketValueUpdate')
            );

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('child component pano-external-assets-direct-property', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl('dpFormArray', cloneDeep(TEST_DP_ASSETS_FORM_ARRAY) as FormArray);
            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for assetDelete when event get triggered', () => {
            expect(component.externalAssetsForm.get('dpFormArray')['controls'].length).toBe(1);

            const panoExternalAssetsDirectPropertyComponent = fixture.debugElement.query(
              By.css('pano-external-assets-direct-property')
            );
            expect(panoExternalAssetsDirectPropertyComponent.nativeElement).toBeTruthy();

            expect(panoExternalAssetsDirectPropertyComponent.properties.dpFormArray).toEqual(
              component.externalAssetsForm.get('dpFormArray')
            );
            expect(panoExternalAssetsDirectPropertyComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('dpFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            panoExternalAssetsDirectPropertyComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            panoExternalAssetsDirectPropertyComponent.nativeElement.dispatchEvent(
              new Event('assetTotalMarketValueUpdate')
            );

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('child component pano-external-assets-other', () => {
          beforeEach(() => {
            component.externalAssetsForm = createEmptyExternalAssetsForm();
            component.externalAssetsForm.setControl('othFormArray', cloneDeep(TEST_OTH_ASSETS_FORM_ARRAY) as FormArray);
            fixture.detectChanges();
          });

          it('should have the properties passed and call the event handler for assetDelete when event get triggered', () => {
            expect(component.externalAssetsForm.get('othFormArray')['controls'].length).toBe(1);

            const panoExternalAssetsOtherComponent = fixture.debugElement.query(By.css('pano-external-assets-other'));
            expect(panoExternalAssetsOtherComponent.nativeElement).toBeTruthy();

            expect(panoExternalAssetsOtherComponent.properties.othFormArray).toEqual(
              component.externalAssetsForm.get('othFormArray')
            );
            expect(panoExternalAssetsOtherComponent.properties.assetCount).toBe(
              (component.externalAssetsForm.get('othFormArray') as FormArray).length
            );

            spyOn(component, 'collectAssetToDelete');
            panoExternalAssetsOtherComponent.nativeElement.dispatchEvent(new Event('assetDelete'));

            expect(component.collectAssetToDelete).toHaveBeenCalled();

            spyOn(component, 'updateAssetTotalMarketValue');
            panoExternalAssetsOtherComponent.nativeElement.dispatchEvent(new Event('assetTotalMarketValueUpdate'));

            expect(component.updateAssetTotalMarketValue).toHaveBeenCalled();
          });
        });

        describe('bt-loading component', () => {
          it('should show bt-loading when initialLoading is true and saveLoading is false', () => {
            component.initialLoading = true;
            component.saveLoading = false;
            fixture.detectChanges();
            expect(fixture.debugElement.query(By.css('bt-loading.js-loading-spinner'))).toBeTruthy();
          });

          it('should show bt-loading when saveLoading is true and initialLoading is false', () => {
            component.saveLoading = true;

            fixture.detectChanges();
            expect(fixture.debugElement.query(By.css('bt-loading.js-loading-spinner'))).toBeTruthy();
          });

          it('should hide bt-loading when saveLoading is false and initialLoading is false', () => {
            component.saveLoading = false;

            fixture.detectChanges();
            expect(fixture.debugElement.query(By.css('bt-loading.js-loading-spinner'))).toBeFalsy();
          });
        });

        describe('bt-buttons', () => {
          it('should show bt-buttons with correct config values when hasAssets is true', () => {
            component.externalAssets = {
              totalValuation: 0,
              hasAssets: true,
              assets: {
                cash: [],
                td: [],
                ls: [],
                ils: [],
                mf: [],
                mp: [],
                dp: [],
                oth: []
              }
            };
            fixture.detectChanges();

            const saveAssetChangesButton = fixture.debugElement.query(
              By.css('.js-test-extassets-save-assets-changes-button')
            );
            const clearAssetsChangesButton = fixture.debugElement.query(
              By.css('.js-test-extassets-clear-assets-changes-button')
            );

            expect(saveAssetChangesButton).toBeTruthy();
            expect(saveAssetChangesButton.properties.config).toEqual(SAVE_ASSETS_CHANGES_BUTTON);

            expect(clearAssetsChangesButton).toBeTruthy();
            expect(clearAssetsChangesButton.properties.config).toEqual(CLEAR_ASSETS_CHANGES_BUTTON);
          });

          it('should show bt-buttons with correct config values, when totalAssetsCount is greater than 0', () => {
            component.totalAssetsCount = 1;
            fixture.detectChanges();

            const saveAssetChangesButton = fixture.debugElement.query(
              By.css('.js-test-extassets-save-assets-changes-button')
            );
            const clearAssetsChangesButton = fixture.debugElement.query(
              By.css('.js-test-extassets-clear-assets-changes-button')
            );

            expect(saveAssetChangesButton).toBeTruthy();
            expect(saveAssetChangesButton.properties.config).toEqual(SAVE_ASSETS_CHANGES_BUTTON);

            expect(clearAssetsChangesButton).toBeTruthy();
            expect(clearAssetsChangesButton.properties.config).toEqual(CLEAR_ASSETS_CHANGES_BUTTON);
          });

          it('should call Clear bt-button handler clearChanges when btClick event is triggered', () => {
            spyOn(component, 'clearChanges');
            component.totalAssetsCount = 1;
            fixture.detectChanges();

            const clearButtonElement = fixture.debugElement.query(
              By.css('.js-test-extassets-clear-assets-changes-button')
            );
            clearButtonElement.nativeElement.dispatchEvent(new Event('btClick'));

            expect(component.clearChanges).toHaveBeenCalled();
          });
        });
      });
    });

    describe('softwareStatus is requested', () => {
      beforeEach(() => {
        component.softwareData = SOFTWARE_DATA_MANUAL_REQUESTED_STATE;
        fixture.detectChanges();
      });

      it('should not show the smsf alert element', () => {
        expect(fixture.debugElement.query(By.css('.js-smsf-entitlement-alert'))).toBeFalsy();
      });

      it('should show connection pending element', () => {
        expect(fixture.debugElement.query(By.css('pano-external-assets-connection-pending'))).toBeTruthy();
      });
    });
  });

  function checkExternalAssetsFormArrays() {
    expect(component.externalAssetsForm.get('cashFormArray').value).toEqual([]);
    expect(component.externalAssetsForm.get('tdFormArray').value).toEqual([]);
    expect(component.externalAssetsForm.get('lsFormArray').value).toEqual([]);
    expect(component.externalAssetsForm.get('ilsFormArray').value).toEqual([]);
    expect(component.externalAssetsForm.get('mfFormArray').value).toEqual([]);
    expect(component.externalAssetsForm.get('mpFormArray').value).toEqual([]);
    expect(component.externalAssetsForm.get('dpFormArray').value).toEqual([]);
    expect(component.externalAssetsForm.get('othFormArray').value).toEqual([]);
  }

  function createEmptyExternalAssetsForm() {
    return new FormGroup({
      cashFormArray: new FormArray([]),
      tdFormArray: new FormArray([]),
      lsFormArray: new FormArray([]),
      ilsFormArray: new FormArray([]),
      mfFormArray: new FormArray([]),
      mpFormArray: new FormArray([]),
      dpFormArray: new FormArray([]),
      othFormArray: new FormArray([])
    });
  }
});
