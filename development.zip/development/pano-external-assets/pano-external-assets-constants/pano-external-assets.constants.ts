import { ValidatorFn, Validators } from '@angular/forms';
import { MatDialogConfig } from '@angular/material/dialog';
import { MatSnackBarConfig, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Icon } from '@bt/components/icon';
import { Loading } from '@bt/components/loading';
import { SNACK_BAR_ACTION, SNACK_BAR_DEFAULT_CONFIG } from '@bt/components/snack-bar-template';
import { BREAKPOINTS } from '@bt/directives/common';
import { ToggleClassByBreakpoint } from '@bt/directives/toggle-class-by-breakpoint';

import {
  alphaNumericValidator,
  assetCodeValidator,
  assetSelectedValidator
} from '../pano-external-assets-custom-validator';
import {
  AssetTypeTotalMarketValue,
  DialogDataConfig,
  ExternalAsset,
  ExternalAssetDelete
} from '../pano-external-assets.interfaces';

export enum DIRECT_PROPERTY_TYPES {
  RES = 'Residential',
  COMM = 'Commercial'
}

export const PANO_DATE_FORMATS = {
  parse: {
    dateInput: 'DD MMM YYYY'
  },
  display: {
    dateInput: 'DD MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

export const API_INVESTOR_ACCOUNTS_BASE_URL: string = '../api/v1/investor/accounts/';
export const API_GET_EXTERNAL_ASSETS_DETAILED_URL: string = '/external-assets/detailed-view';
export const API_POST_EXTERNAL_ASSETS_URL: string = '/external-assets';
export const API_GET_ACCOUNTING_SOFTWARE_URL: string = '/accounting-software';
export const API_GET_EXTERNAL_ASSETS_SUMMARY_URL: string = '/external-assets/summary-view';
export const API_GET_ASSETS_URL: string = '/assets';
export const API_INVESTOR_ASSET_BASE_URL: string = '../api/v1/investor/asset/';
export const API_GET_INVESTOR_ASSET_TYPES: string = '../api/v1/investor/asset-types';
export const API_GET_INVESTOR_PROPERTY_TYPES: string = '../api/v1/investor/property-types';

export const ACTION_CONFIRM: boolean = true;
export const ACTION_CANCEL: boolean = false;
export const ASSET_DELETE_CONFIRM_HEADER: string = 'Remove this asset?';
export const ASSET_DELETE_CONFIRM_DESCRIPTION: string = `This asset will only be permanently removed when you select 'Save changes'.`;
export const CONFIRM_CANCELLATION_DESCRIPTION: string =
  'Are you sure you want to leave this page? All your entries will be lost.';
export const CLEAR_CHANGES_CONFIRM_HEADER: string = 'Revert all changes?';
export const CLEAR_CHANGES_CONFIRM_DESCRIPTION: string = 'Changes you made so far will not be saved.';
export const MAX_ASSET_ALERT_HEADER: string = 'Maximum reached';
export const ADD_ASSET_FORM_ALERT_HEADER: string = 'You have a new entry in progress';
export const ADD_ASSET_FORM_ALERT_TEXT: string = 'Please add or cancel the new external asset before saving.';

export const MAX_ASSET_COUNT: number = 50;

export const DEFAULT_ASSET_DELETE: ExternalAssetDelete = {
  positionId: '',
  quantity: 0
};

export const OTHER_ASSET_QUANTITY_REGEX = new RegExp(/^\d+(?:\.\d{1,3})?$/);
export const MANAGED_FUND_ASSET_QUANTITY_REGEX = new RegExp(/^\d+(?:\.\d{1,4})?$/);

export const MARKET_VALUE_VALIDATORS: Array<ValidatorFn> = [
  Validators.required,
  Validators.min(0.01),
  Validators.max(99999999999.99),
  Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
];

export const ASSET_TYPES = {
  cash: {
    code: 'cash',
    label: 'Cash',
    assetClass: 'cash',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'cash' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'assetClassCode', type: 'text', defaultValue: 'cash' }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'source', type: 'text' }
    ]
  },
  td: {
    code: 'td',
    label: 'Term deposit',
    assetClass: 'cash',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'td' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'assetClassCode', type: 'text', defaultValue: 'cash' },
      { name: 'maturityDate', type: 'date', validators: [Validators.required] }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'maturityDate', type: 'date', validators: [Validators.required] },
      { name: 'source', type: 'text' }
    ]
  },
  ls: {
    code: 'ls',
    label: 'Australian shares',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'ls' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'isPanoramaAsset', type: 'boolean', defaultValue: false },
      {
        name: 'panoramaAssetDetails',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, assetSelectedValidator],
        updateOn: 'change'
      },
      { name: 'assetId', type: 'text', defaultValue: null },
      {
        name: 'positionCode',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, alphaNumericValidator()]
      },
      { name: 'assetClassCode', type: 'text', defaultValue: null, validators: [Validators.required] },
      {
        name: 'quantity',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.min(1), Validators.maxLength(15), Validators.pattern(/^[0-9]*$/)]
      }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'assetId', type: 'text' },
      { name: 'isPanoramaAsset', type: 'boolean' },
      { name: 'positionCode', type: 'text' },
      {
        name: 'quantity',
        type: 'text',
        validators: [Validators.required, Validators.min(1), Validators.pattern(/^[0-9]*$/)]
      },
      { name: 'source', type: 'text' }
    ]
  },
  ils: {
    code: 'ils',
    label: 'International shares',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'ils' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'positionCode', type: 'text', defaultValue: null, validators: [alphaNumericValidator()] },
      { name: 'assetClassCode', type: 'text', defaultValue: null, validators: [Validators.required] },
      {
        name: 'quantity',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.min(1), Validators.maxLength(15), Validators.pattern(/^[0-9]*$/)]
      }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'isPanoramaAsset', type: 'boolean' },
      { name: 'positionCode', type: 'text' },
      {
        name: 'quantity',
        type: 'text',
        validators: [Validators.required, Validators.min(1), Validators.pattern(/^[0-9]*$/)]
      },
      { name: 'source', type: 'text' }
    ]
  },
  mf: {
    code: 'mf',
    label: 'Managed fund',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'mf' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'isPanoramaAsset', type: 'boolean', defaultValue: false },
      {
        name: 'panoramaAssetDetails',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, assetSelectedValidator],
        updateOn: 'change'
      },
      { name: 'assetId', type: 'text', defaultValue: null },
      {
        name: 'positionCode',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, alphaNumericValidator(), assetCodeValidator()]
      },
      { name: 'assetClassCode', type: 'text', defaultValue: null, validators: [Validators.required] },
      {
        name: 'quantity',
        type: 'text',
        defaultValue: null,
        validators: [
          Validators.required,
          Validators.min(1),
          Validators.maxLength(15),
          Validators.pattern(MANAGED_FUND_ASSET_QUANTITY_REGEX)
        ]
      }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'assetId', type: 'text' },
      { name: 'isPanoramaAsset', type: 'boolean' },
      { name: 'positionCode', type: 'text' },
      {
        name: 'quantity',
        type: 'text',
        validators: [Validators.required, Validators.min(1), Validators.pattern(MANAGED_FUND_ASSET_QUANTITY_REGEX)]
      },
      { name: 'source', type: 'text' }
    ]
  },
  mp: {
    code: 'mp',
    label: 'Managed portfolio',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'mp' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      {
        name: 'positionCode',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(9), alphaNumericValidator(), assetCodeValidator()]
      },
      { name: 'assetClassCode', type: 'text', defaultValue: null, validators: [Validators.required] }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'assetId', type: 'text' },
      { name: 'isPanoramaAsset', type: 'boolean' },
      { name: 'positionCode', type: 'text' },
      { name: 'source', type: 'text' }
    ]
  },
  dp: {
    code: 'dp',
    label: 'Direct property',
    assetClass: 'realest_au',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'dp' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'propertyType', type: 'text', defaultValue: 'RES', validators: [Validators.required] },
      { name: 'assetClassCode', type: 'text', defaultValue: 'realest_au' }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'isPanoramaAsset', type: 'boolean' },
      { name: 'propertyType', type: 'text' }
    ]
  },
  oth: {
    code: 'oth',
    label: 'Other',
    addFormControls: [
      { name: 'assetTypeCode', type: 'text', defaultValue: 'oth' },
      {
        name: 'positionName',
        type: 'text',
        defaultValue: null,
        validators: [Validators.required, Validators.maxLength(200)]
      },
      { name: 'source', type: 'text', defaultValue: null, validators: [Validators.maxLength(120)] },
      { name: 'marketValue', type: 'amount', defaultValue: null, validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'positionCode', type: 'text', defaultValue: null, validators: [alphaNumericValidator()] },
      { name: 'assetClassCode', type: 'text', defaultValue: null, validators: [Validators.required] },
      {
        name: 'quantity',
        type: 'text',
        defaultValue: null,
        validators: [Validators.min(1), Validators.maxLength(15), Validators.pattern(OTHER_ASSET_QUANTITY_REGEX)]
      }
    ],
    editFormControls: [
      { name: 'assetClassCode', type: 'text' },
      { name: 'assetTypeCode', type: 'text' },
      { name: 'isNewAsset', type: 'boolean' },
      { name: 'positionId', type: 'text' },
      { name: 'positionName', type: 'text' },
      { name: 'marketValue', type: 'amount', validators: MARKET_VALUE_VALIDATORS },
      { name: 'valuationDate', type: 'date', validators: [Validators.required] },
      { name: 'isPanoramaAsset', type: 'boolean' },
      { name: 'positionCode', type: 'text' },
      {
        name: 'quantity',
        type: 'text',
        validators: [Validators.min(1), Validators.maxLength(15), Validators.pattern(OTHER_ASSET_QUANTITY_REGEX)]
      },
      { name: 'source', type: 'text' }
    ]
  }
};

export const ASSET_TYPES_ORDER = ['cash', 'td', 'ls', 'ils', 'mf', 'mp', 'dp', 'oth'];
export const PAGE_SCROLL_SPEED: number = 1500;

export const DATE_PICKER_ICON: Icon = {
  name: 'icon-calendar',
  size: 'small'
};

export const DELETE_ICON: Icon = {
  name: 'icon-bin'
};

export const DELETE_BUTTON: Button = {
  icon: DELETE_ICON,
  type: 'outline',
  colourModifier: 'basic',
  shapeModifier: 'square',
  size: 'medium',
  action: 'button'
};

export const MAGNIFY_ICON: Icon = {
  name: 'icon-magnifying-glass',
  size: 'small'
};

export const ARROW_RIGHT_ICON: Icon = {
  name: 'icon-arrow-right',
  size: 'x-small'
};

export const ADD_ASSET_BUTTON: Button = {
  type: 'solid',
  action: 'submit',
  label: 'Add',
  colourModifier: 'primary',
  size: 'medium'
};

export const CANCEL_ADD_ASSET_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'primary',
  action: 'button',
  label: 'Cancel',
  size: 'medium'
};

export const CONFIRM_DELETE_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'invert',
  action: 'button',
  label: 'Remove',
  size: 'large'
};

export const CANCEL_DELETE_BUTTON: Button = {
  type: 'solid',
  colourModifier: 'invert',
  action: 'button',
  label: 'Cancel',
  size: 'large'
};

export const CONFIRM_CANCELLATION_YES_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'invert',
  action: 'button',
  label: 'Yes',
  size: 'large'
};

export const CONFIRM_CANCELLATION_NO_BUTTON: Button = {
  type: 'solid',
  colourModifier: 'invert',
  action: 'button',
  label: 'No',
  size: 'large'
};

export const SAVE_ASSETS_CHANGES_BUTTON: Button = {
  type: 'solid',
  action: 'submit',
  label: 'Save changes',
  size: 'large',
  colourModifier: 'primary',
  disableInEmulationMode: true
};

export const CLEAR_ASSETS_CHANGES_BUTTON: Button = {
  type: 'outline',
  action: 'button',
  label: 'Clear changes',
  colourModifier: 'primary',
  size: 'large'
};

export const CONFIRM_CLEAR_CHANGES_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'invert',
  action: 'button',
  label: 'Revert',
  size: 'large'
};

export const CANCEL_CLEAR_CHANGES_BUTTON: Button = {
  type: 'solid',
  colourModifier: 'invert',
  action: 'button',
  label: 'Cancel',
  size: 'large'
};

export const EXIT_MANUAL_BUTTON: Button = {
  action: 'button',
  label: 'Exit manual entry',
  type: 'solid'
};

export const MAX_ASSET_ALERT_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'invert',
  action: 'button',
  label: 'Ok',
  size: 'large'
};

export const ADD_ASSET_FORM_ALERT_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'invert',
  action: 'button',
  label: 'Ok',
  size: 'large'
};

export const DEFAULT_ADD_ASSET_PROPS: ExternalAsset = {
  assetClassCode: '',
  assetTypeCode: '',
  isNewAsset: true,
  isPanoramaAsset: false,
  marketValue: '',
  positionCode: '',
  positionId: null,
  positionName: '',
  quantity: '',
  source: '',
  valuationDate: ''
};

export const DEFAULT_ASSET_TYPE_TOTAL: AssetTypeTotalMarketValue = {
  cashTotalMarketValue: 0,
  tdTotalMarketValue: 0,
  lsTotalMarketValue: 0,
  ilsTotalMarketValue: 0,
  mfTotalMarketValue: 0,
  mpTotalMarketValue: 0,
  dpTotalMarketValue: 0,
  othTotalMarketValue: 0
};

export const SNACK_BAR_EXTERNAL_ASSETS_SUCCESS: MatSnackBarConfig<{ header: string; action: string }> = {
  data: {
    header: 'Changes saved',
    action: SNACK_BAR_ACTION.SUCCESS
  },
  duration: SNACK_BAR_DEFAULT_CONFIG.DURATION,
  panelClass: SNACK_BAR_DEFAULT_CONFIG.PANEL_CLASS,
  verticalPosition: SNACK_BAR_DEFAULT_CONFIG.VERTICAL_POSITION as MatSnackBarVerticalPosition
};

export const SNACK_BAR_EXTERNAL_ASSETS_NO_UNSAVED_CHANGES: MatSnackBarConfig<{ header: string; action: string }> = {
  data: {
    header: 'You have not made any changes.',
    action: SNACK_BAR_ACTION.INFO
  },
  duration: SNACK_BAR_DEFAULT_CONFIG.DURATION,
  panelClass: SNACK_BAR_DEFAULT_CONFIG.PANEL_CLASS,
  verticalPosition: SNACK_BAR_DEFAULT_CONFIG.VERTICAL_POSITION as MatSnackBarVerticalPosition
};

export const MANUAL_OPTIONS: Array<string> = ['No results found.', "Can't find the asset? Enter manually"];
export const SR_ONLY_BREAKPOINTS: ToggleClassByBreakpoint = { breakpoints: [BREAKPOINTS.MD], classNames: ['sr-only'] };

export const EXTERNAL_ASSETS_MODULE: string = 'app.investor.account.externalAssets';

export const CONFIRM_DIALOG_CONFIG: MatDialogConfig = {
  ...DIALOG_CONFIG.ALT,
  autoFocus: true,
  disableClose: true,
  data: {
    actionConfirm: ACTION_CONFIRM,
    actionCancel: ACTION_CANCEL
  }
};

export const CONFIRM_CANCELLATION_DIALOG_DATA_CONFIG: DialogDataConfig = {
  headerText: '',
  descriptionText: CONFIRM_CANCELLATION_DESCRIPTION,
  confirmButton: CONFIRM_CANCELLATION_YES_BUTTON,
  cancelButton: CONFIRM_CANCELLATION_NO_BUTTON
};
export const ASSET_DELETE_DIALOG_DATA_CONFIG: DialogDataConfig = {
  headerText: ASSET_DELETE_CONFIRM_HEADER,
  descriptionText: ASSET_DELETE_CONFIRM_DESCRIPTION,
  confirmButton: CONFIRM_DELETE_BUTTON,
  cancelButton: CANCEL_DELETE_BUTTON
};
export const CLEAR_CHANGES_DIALOG_DATA_CONFIG: DialogDataConfig = {
  headerText: CLEAR_CHANGES_CONFIRM_HEADER,
  descriptionText: CLEAR_CHANGES_CONFIRM_DESCRIPTION,
  confirmButton: CONFIRM_CLEAR_CHANGES_BUTTON,
  cancelButton: CANCEL_CLEAR_CHANGES_BUTTON
};

export const ADD_ASSET_FORM_ALERT_DIALOG_DATA_CONFIG: DialogDataConfig = {
  headerText: ADD_ASSET_FORM_ALERT_HEADER,
  descriptionText: ADD_ASSET_FORM_ALERT_TEXT,
  alertButton: ADD_ASSET_FORM_ALERT_BUTTON
};

export const PAGE_LOADING: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const CONTENT_LOADING: Loading = {
  type: 'content',
  spinnerSize: 'large'
};

export const DEBOUNCE_TIME: number = 500;
