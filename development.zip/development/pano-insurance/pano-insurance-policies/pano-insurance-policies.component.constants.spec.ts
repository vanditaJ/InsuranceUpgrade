import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';

import { PRODUCT } from '../pano-insurance.constants';
import {
  InsurancePolicy,
  Permission,
  PersonBenefitDetails,
  PolicyStatus,
  PolicyType
} from '../pano-insurance.interface';

export const MOCK_POLICIES: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.ACTIVE,
  commencementDate: '2080-02-03T00:00:00.000+10:00',
  endDate: '2021-03-03T00:00:00.000+10:00',
  external: true,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: true,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 65,
  customerType: 'Retail',
  personBenefitDetails: [
    {
      benefits: [
        {
          waitingPeriod: '90',
          benefitPeriodFactor: 'Years',
          benefitPeriodTerm: '2',
          benefits: [
            {
              frequency: 'MONTHLY',
              occupationClass: 'N/A'
            }
          ]
        }
      ]
    }
  ]
};

export const MOCK_PERMISSIONS: Permission = {
  'insurance.aia.showManageInsurancePanel': 'true'
};

export const MOCK_POLICIES_LIST: InsurancePolicy[] = [
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2080-02-03T00:00:00.000+10:00',
    endDate: '2021-03-03T00:00:00.000+10:00',
    external: true,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: true,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 65,
    customerType: 'Retail',
    personBenefitDetails: [
      {
        benefits: [
          {
            waitingPeriod: '90',
            benefitPeriodFactor: 'Years',
            benefitPeriodTerm: '2',
            benefits: [
              {
                frequency: 'MONTHLY',
                occupationClass: 'N/A'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.INACTIVE,
    commencementDate: '2080-02-03T00:00:00.000+10:00',
    endDate: '2021-03-03T00:00:00.000+10:00',
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: true,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 65,
    customerType: 'Retail',
    personBenefitDetails: [
      {
        benefits: [
          {
            waitingPeriod: '90',
            benefitPeriodFactor: 'Years',
            benefitPeriodTerm: '2',
            benefits: [
              {
                frequency: 'MONTHLY',
                occupationClass: 'N/A'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.DECLINED,
    commencementDate: '2080-02-03T00:00:00.000+10:00',
    endDate: '2021-03-03T00:00:00.000+10:00',
    external: true,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: true,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 65,
    customerType: 'Retail',
    personBenefitDetails: [
      {
        benefits: [
          {
            waitingPeriod: '90',
            benefitPeriodFactor: 'Years',
            benefitPeriodTerm: '2',
            benefits: [
              {
                frequency: 'MONTHLY',
                occupationClass: 'N/A'
              }
            ]
          }
        ]
      }
    ]
  }
];

export const MOCK_VISIBLE_POLICIES_LIST: InsurancePolicy[] = [
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.TPD,
    policyName: 'Total & Permanent Disablement (TPD) cover',
    external: true,
    premium: '1.19',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-06-03T00:00:00.000+10:00',
    endDate: null,
    sumInsured: 7000,
    policyNumber: '56300',
    westpacGroupPlan: false,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 101,
    qualifierName: 'Employer Cover'
  },
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.DEATH_AND_TPD,
    policyName: 'Death & TPD cover',
    external: false,
    premium: '21.78',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-03-31T00:00:00.000+10:00',
    endDate: null,
    sumInsured: 24500,
    policyNumber: '5659522',
    westpacGroupPlan: true,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 180,
    qualifierName: 'Standard Cover'
  }
];

export const MOCK_POLICY_NOT_ACTIVE: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '109587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.PENDING,
  commencementDate: '2080-02-03T00:00:00.000+10:00',
  endDate: '2021-03-03T00:00:00.000+10:00',
  external: true,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: true,
  applicableNotes: 'TT1',
  coverSubTypeId: 260,
  qualifierName: 'Employee Salary Continuance Insurance',
  personBenefitDetails: [
    {
      benefits: [
        {
          waitingPeriod: '90',
          benefitPeriodFactor: 'Years',
          benefitPeriodTerm: '2',
          benefits: [
            {
              frequency: 'MONTHLY',
              occupationClass: 'N/A'
            }
          ]
        }
      ]
    }
  ]
};

export const PERSONAL_BENEFIT_DETAILS: PersonBenefitDetails[] = [
  {
    benefits: [
      {
        benefitPeriodTerm: '4',
        waitingPeriod: '1',
        benefitPeriodFactor: 'years',
        benefits: [
          {
            frequency: 'FORTNIGHTLY',
            occupationClass: 'Blue Collar'
          }
        ]
      }
    ]
  }
];

export const MOCK_POLICIES_SHOW_INSURANCE_PANEL: InsurancePolicy[] = [
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2080-02-03T00:00:00.000+10:00',
    endDate: '2021-03-03T00:00:00.000+10:00',
    external: true,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: true,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    personBenefitDetails: [
      {
        benefits: [
          {
            waitingPeriod: '90',
            benefitPeriodFactor: 'Years',
            benefitPeriodTerm: '2',
            benefits: [
              {
                frequency: 'MONTHLY',
                occupationClass: 'N/A'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    premium: '1.19',
    status: PolicyStatus.PENDING,
    commencementDate: null,
    endDate: null,
    sumInsured: 7000,
    policyNumber: '12300',
    westpacGroupPlan: true,
    smokerStatus: 'Not applicable',
    employerFunded: null,
    customised: false,
    external: false,
    applicableNotes: 'FN1,FN2',
    coverSubTypeId: 14,
    qualifierName: 'Employee Tailored Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS
  },
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.TPD,
    policyName: 'Total & Permanent Disablement (TPD) cover',
    external: true,
    premium: '1.19',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-06-03T00:00:00.000+10:00',
    endDate: null,
    sumInsured: 7000,
    policyNumber: '56300',
    westpacGroupPlan: false,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 101,
    qualifierName: 'Employer Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS
  },
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.DEATH_AND_TPD,
    policyName: 'Death & TPD cover',
    external: true,
    premium: '21.78',
    status: PolicyStatus.ACTIVE,
    commencementDate: null,
    endDate: '2021-03-31T00:00:00.000+10:00',
    sumInsured: 24500,
    policyNumber: '5659522',
    westpacGroupPlan: true,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 180,
    qualifierName: 'Standard Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS
  }
];

export const MOCK_AEM_CONTENT_POLICIES: AemContent[] = [
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'generic_insurance_info',
      description: 'mock content for generic_insurance_info'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'insurance_info',
      description: 'mock content for insurance_info'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'insurance_info_byo',
      description: 'mock content for insurance_info_byo'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'no_insurance_info_ey',
      description: 'mock content for no_insurance_info_ey'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'no_insurance_info_wgp',
      description: 'mock content for no_insurance_info_wgp'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'no_insurance_info_bts',
      description: 'mock content for no_insurance_info_bts'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'no_insurance_info_btsfl',
      description: 'mock content for no_insurance_info_btsfl'
    }
  }
];

export const MOCK_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2021-02-04T16:00:00.000Z',
  pdsStatus: 'DEFAULT',
  product: {}
};

export const MOCK_BTS_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2021-02-04T16:00:00.000Z',
  pdsStatus: 'DEFAULT',
  product: {},
  productDescription: PRODUCT.BT_SUPER
};

export const MOCK_BTS_WGP_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2021-02-04T16:00:00.000Z',
  pdsStatus: 'WGP_CURRENT',
  product: {},
  productDescription: PRODUCT.BT_SUPER
};

export const MOCK_BTSFL_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2021-02-04T16:00:00.000Z',
  pdsStatus: 'DEFAULT',
  product: {},
  productDescription: PRODUCT.BT_SUPER_FOR_LIFE
};

export const MOCK_BTS_EY_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2021-02-04T16:00:00.000Z',
  pdsStatus: 'EY',
  product: {},
  productDescription: PRODUCT.BT_SUPER
};
