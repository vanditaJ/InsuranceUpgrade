import { TestBed, waitForAsync } from '@angular/core/testing';
import { get, groupBy } from 'lodash-es';
import * as moment from 'moment-timezone';

import { PolicyType } from '../pano-insurance.interface';
import {
  EXPECTED_OPTIONS_DEATH_CHANGE,
  EXPECTED_OPTIONS_DEATH_DECREASE,
  EXPECTED_OPTIONS_DEATH_MISSING,
  INSURANCE_RATES
} from '../pano-insurance.service.spec.constants';

import { PanoChangeCoverInsuranceCommonUtil } from './pano-change-cover-insurance-common.util';
import { CHANGE_COVER_ACC } from './pano-change-cover-insurance.component.spec.constants';
import { CoverAmountOptions, CoverMode, CoverTypeSelected } from './pano-change-cover-insurance.interface';

describe('PanoChangeCoverInsuranceCommonUtil ', () => {
  let panoChangeCoverInsuranceCommonUtil: PanoChangeCoverInsuranceCommonUtil;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        providers: [PanoChangeCoverInsuranceCommonUtil]
      });
    })
  );
  beforeEach(() => {
    panoChangeCoverInsuranceCommonUtil = TestBed.inject(PanoChangeCoverInsuranceCommonUtil);
  });

  describe('getCurrentCoverType ', () => {
    it('when current cover type DEATH and change insurance, should return all cover types', () => {
      const result: CoverAmountOptions = panoChangeCoverInsuranceCommonUtil.getCoverAmountOptions(
        CoverMode.CHANGE,
        PolicyType.DEATH,
        'Triple',
        INSURANCE_RATES
      );
      expect(result).toEqual(EXPECTED_OPTIONS_DEATH_CHANGE);
    });

    it('when current cover type DEATH and decrease insurance, should return decrease cover types', () => {
      const result: CoverAmountOptions = panoChangeCoverInsuranceCommonUtil.getCoverAmountOptions(
        CoverMode.DECREASE,
        PolicyType.DEATH,
        'Triple',
        INSURANCE_RATES
      );
      expect(result).toEqual(EXPECTED_OPTIONS_DEATH_DECREASE);
    });

    it('when insurance rates missing, cover types will be missing', () => {
      const result: CoverAmountOptions = panoChangeCoverInsuranceCommonUtil.getCoverAmountOptions(
        CoverMode.DECREASE,
        PolicyType.DEATH,
        'Triple',
        []
      );
      expect(result).toEqual(EXPECTED_OPTIONS_DEATH_MISSING);
    });
  });

  describe('getCoverTypes ', () => {
    it('when decrease insurance, should return decrease cover types', () => {
      const coverTypes = groupBy(
        INSURANCE_RATES.filter(rate => !rate.increase),
        'policyType'
      );

      let result: CoverTypeSelected = panoChangeCoverInsuranceCommonUtil.getCoverTypes(coverTypes.DEATH);
      expect(result.coverLevels.length).toEqual(1);

      result = panoChangeCoverInsuranceCommonUtil.getCoverTypes(coverTypes.DEATH_AND_TPD);
      expect(result.coverLevels.length).toEqual(0);
    });

    it('when change insurance, should return all cover types', () => {
      const coverTypes = groupBy(INSURANCE_RATES, 'policyType');

      let result: CoverTypeSelected = panoChangeCoverInsuranceCommonUtil.getCoverTypes(coverTypes.DEATH);
      expect(result.coverLevels.length).toEqual(2);

      result = panoChangeCoverInsuranceCommonUtil.getCoverTypes(coverTypes.DEATH_AND_TPD);
      expect(result.coverLevels.length).toEqual(3);
    });
  });

  describe('getAccountActivationDays ', () => {
    it('should return correct number of activation days', () => {
      const firstMoneyReceivedDate = get(CHANGE_COVER_ACC, 'firstMoneyReceivedDate');
      const firstMoneyReceived = moment(firstMoneyReceivedDate);
      const toBeRes = moment()
        .tz('Australia/Sydney')
        .diff(firstMoneyReceived, 'days');

      const result: number = panoChangeCoverInsuranceCommonUtil.getAccountActivationDays(CHANGE_COVER_ACC);

      expect(result).toEqual(toBeRes);
    });
  });
});
