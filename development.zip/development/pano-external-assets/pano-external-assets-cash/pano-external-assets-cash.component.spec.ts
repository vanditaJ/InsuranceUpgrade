import { Component, NO_ERRORS_SCHEMA, SimpleChange } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormArray, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import { cloneDeep, each } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import { TEST_CASH_ASSETS_FORM_ARRAY } from '../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { ASSET_TYPES, PANO_DATE_FORMATS } from '../pano-external-assets-constants/pano-external-assets.constants';

import { PanoExternalAssetsCashComponent } from './pano-external-assets-cash.component';

@Component({
  template: `
    <pano-external-assets-cash
      [cashFormArray]="cashFormArray"
      [assetCount]="assetCount"
      (assetDelete)="testAssetDelete($event)"
      (assetTotalMarketValueUpdate)="testAssetTotalMarketValue($event)"
    >
    </pano-external-assets-cash>
  `
})
class TestHostComponent {
  assetDetail = null;
  assetTotal = null;
  cashFormArray: FormArray = TEST_CASH_ASSETS_FORM_ARRAY as FormArray;
  assetCount: number = TEST_CASH_ASSETS_FORM_ARRAY['controls'].length;

  testAssetDelete(assetDetail): void {
    this.assetDetail = assetDetail;
  }
  testAssetTotalMarketValue(assetTotal): void {
    this.assetTotal = assetTotal;
  }
}

describe('PanoExternalAssetsCashComponent', () => {
  let component: PanoExternalAssetsCashComponent;
  let fixture: ComponentFixture<PanoExternalAssetsCashComponent>;
  let panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoExternalAssetsCashComponent, TestHostComponent],
        providers: [
          PanoExternalAssetsCommonUtil,
          { provide: MAT_DATE_FORMATS, useValue: PANO_DATE_FORMATS },
          { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] }
        ],
        imports: [
          MatDatepickerModule,
          MatInputModule,
          MatMomentDateModule,
          NoopAnimationsModule,
          ReactiveFormsModule,
          DataModule,
          PipesTestingModule
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoExternalAssetsCashComponent);
    panoExtAssetsCommonUtil = TestBed.inject(PanoExternalAssetsCommonUtil);
    component = fixture.componentInstance;
  });

  describe('component', () => {
    beforeEach(() => {
      component.cashFormArray = cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray;
    });

    it('should accept the inputs and transmit the outputs correctly', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const hostComponent: TestHostComponent = hostFixture.componentInstance;
      hostFixture.detectChanges();

      const mockFormArray = TEST_CASH_ASSETS_FORM_ARRAY as FormArray;
      const cmp = hostFixture.debugElement.query(By.directive(PanoExternalAssetsCashComponent)).componentInstance;
      expect(cmp.cashFormArray).toEqual(mockFormArray);
      expect(cmp.assetCount).toBe(mockFormArray['controls'].length);

      const assetToDelete = {
        index: 0,
        assetTypeCode: ASSET_TYPES.cash.code,
        positionId: mockFormArray['controls'][0].get('positionId').value,
        isNewAsset: mockFormArray['controls'][0].get('isNewAsset').value
      };
      const assetTotalMarketValueUpdate = {
        assetTypeTotalMarketValue: 12,
        assetTypeCode: ASSET_TYPES.cash.code
      };

      spyOn(hostComponent, 'testAssetDelete');
      cmp.assetDelete.emit(assetToDelete);
      expect(hostComponent.testAssetDelete).toHaveBeenCalledWith(assetToDelete);

      spyOn(hostComponent, 'testAssetTotalMarketValue');
      cmp.assetTotalMarketValueUpdate.emit(assetTotalMarketValueUpdate);
      expect(hostComponent.testAssetTotalMarketValue).toHaveBeenCalledWith(assetTotalMarketValueUpdate);
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('ngOnDestroy()', () => {
      it('should unsubscribe all subscriptions', () => {
        spyOn(component, 'calculateTotal');
        spyOn(component, 'unregisterControlsValueChanges');

        component.ngOnDestroy();

        expect(component.calculateTotal).toHaveBeenCalled();
        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
      });
    });

    describe('on changes', () => {
      beforeEach(() => {
        spyOn(component, 'unregisterControlsValueChanges');
        spyOn(component, 'registerControlsValueChanges');
        spyOn(component, 'calculateTotal');
      });
      it('should call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when assetCount get changed, that is add, delete an asset', () => {
        component.ngOnChanges({ assetCount: new SimpleChange(0, 1, true) });

        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
        expect(component.registerControlsValueChanges).toHaveBeenCalled();
        expect(component.calculateTotal).toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when assetCount is not changed', () => {
        component.ngOnChanges({ assetCount: new SimpleChange(1, 1, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });

      it('should call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when FormArray get changed, that is on componet init or save api gives new data', () => {
        component.ngOnChanges({ cashFormArray: new SimpleChange([], cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY), true) });

        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
        expect(component.registerControlsValueChanges).toHaveBeenCalled();
        expect(component.calculateTotal).toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when FormArray is not changed', () => {
        const mockFormArray = [];
        component.ngOnChanges({ cashFormArray: new SimpleChange(mockFormArray, mockFormArray, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when any other input get changed', () => {
        component.ngOnChanges({ someother: new SimpleChange(1, 2, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });
    });

    describe('registerControlsValueChanges', () => {
      it('should registerAssetEditMarketValueControlsValueChanges of PanoExternalAssetsCommonUtil to add marketValue valueChanges subscriptions to controlsValueChangesSubscriptions', () => {
        spyOn(panoExtAssetsCommonUtil, 'registerAssetEditMarketValueControlsValueChanges').and.returnValue([
          of(null).subscribe()
        ]);
        expect((component as any).controlsValueChangesSubscriptions.length).toBe(0);

        component.registerControlsValueChanges();

        expect((component as any).controlsValueChangesSubscriptions.length).toBe(1);
        expect(panoExtAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges).toHaveBeenCalledWith(
          component.cashFormArray as FormArray,
          jasmine.any(Function)
        );
      });
    });

    describe('unregisterControlsValueChanges', () => {
      it('should call unregisterAssetEditControlsValueChanges of PanoExternalAssetsCommonUtil to unsubscribe all valuechange subcribtion of controlsValueChangesSubscriptions', () => {
        spyOn(panoExtAssetsCommonUtil, 'unregisterAssetEditControlsValueChanges').and.returnValue([]);

        component.unregisterControlsValueChanges();

        expect(panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges).toHaveBeenCalledWith(
          (component as any).controlsValueChangesSubscriptions
        );
        expect((component as any).controlsValueChangesSubscriptions.length).toBe(0);
      });
    });

    describe('deleteCash', () => {
      it('should call deleteAsset', () => {
        spyOn(panoExtAssetsCommonUtil, 'deleteAsset');
        expect(component.cashFormArray.length).toBe(1);

        const deletedFormGroup = TEST_CASH_ASSETS_FORM_ARRAY.controls[0] as FormGroup;

        component.deleteCash(0, deletedFormGroup.get('positionId').value, deletedFormGroup.get('isNewAsset').value);

        expect(panoExtAssetsCommonUtil.deleteAsset).toHaveBeenCalledWith(
          {
            index: 0,
            assetTypeCode: ASSET_TYPES.cash.code,
            positionId: deletedFormGroup.get('positionId').value,
            isNewAsset: deletedFormGroup.get('isNewAsset').value
          },
          component.assetDelete
        );
      });
    });

    describe('calculateTotal', () => {
      it('should call calculateAssetTypeTotalMarketValue of PanoExternalAssetsCommonUtil', () => {
        spyOn(panoExtAssetsCommonUtil, 'calculateAssetTypeTotalMarketValue').and.returnValue(300);

        component.calculateTotal();

        expect(panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue).toHaveBeenCalledWith(
          component.cashFormArray,
          ASSET_TYPES.cash.code,
          component.assetTotalMarketValueUpdate
        );
        expect(component.totalMarketValue).toBe(300);
      });
    });
  });

  describe('view', () => {
    it('should hide the section element when no controls are there', () => {
      expect(fixture.debugElement.query(By.css('section'))).toBeFalsy();
    });

    it('should hide the section element when FormArray is empty', () => {
      component.cashFormArray = new FormArray([]);
      expect(fixture.debugElement.query(By.css('section'))).toBeFalsy();
    });

    describe('btToggleClassByBreakpoint', () => {
      beforeEach(() => {
        const mockFormArray = cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY);
        component.cashFormArray = mockFormArray as FormArray;
        fixture.detectChanges();
      });

      it('it should have btToggleClassByBreakpoint directive on "Source" header column', () => {
        const sourceColEl = fixture.debugElement.query(By.css('th:nth-child(2)'));
        expect(sourceColEl.properties.btToggleClassByBreakpoint).toEqual({
          breakpoints: ['md'],
          classNames: ['sr-only']
        });
      });

      it('it should have btToggleClassByBreakpoint directive on "Source" cell', () => {
        const sourceColEls = fixture.debugElement.queryAll(By.css('tbody tr td:nth-child(2)'));
        each(sourceColEls, el =>
          expect(el.properties.btToggleClassByBreakpoint).toEqual({ breakpoints: ['md'], classNames: ['sr-only'] })
        );
      });
    });

    describe('when controls are available', () => {
      beforeEach(() => {
        component.cashFormArray = TEST_CASH_ASSETS_FORM_ARRAY as FormArray;
        fixture.detectChanges();
      });

      it('should show the section, header and table when controls are available', () => {
        expect(fixture.debugElement.query(By.css('section'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-cash-header'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-cash-table'))).toBeTruthy();
      });

      it('should show the header label and table headings and total market value label when assets are available', () => {
        expect(fixture.debugElement.query(By.css('.js-test-extassets-cash-header')).nativeElement.innerHTML).toBe(
          'Cash'
        );
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-cash-table-header-investment')).nativeElement.innerHTML
        ).toBe('Asset');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-cash-table-header-source')).nativeElement.innerHTML
        ).toBe('Source');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-cash-table-header-valuation-date')).nativeElement
            .innerHTML
        ).toBe('Valuation date');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-cash-table-header-balance')).nativeElement.innerHTML
        ).toBe('Balance');
        expect(fixture.debugElement.query(By.css('.js-test-extassets-cash-total-label')).nativeElement.innerHTML).toBe(
          'Total cash'
        );
      });

      it('should hide all Errors by default', () => {
        expect(fixture.debugElement.queryAll(By.css('mat-error')).length).toBe(0);
      });

      it('should show the data', () => {
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-cash-table-row-cell-asset-name-0')).nativeElement
            .innerHTML
        ).toBe(TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('positionName').value);
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-cash-table-row-cell-source-0')).nativeElement.innerHTML
        ).toBe(TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('source').value);
        expect(
          moment(
            fixture.debugElement.query(By.css('.js-test-extassets-cash-form-input-value-date-0')).nativeElement.value,
            'DD MMM YYYY'
          ).format('DD MMM YYYY')
        ).toBe(
          moment(TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value, 'DD MMM YYYY').format(
            'DD MMM YYYY'
          )
        );
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-cash-form-input-market-value-0')).nativeElement.value
        ).toBe(TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value);
        expect(fixture.debugElement.query(By.css('.js-test-extassets-cash-table-row-cell-delete-0'))).toBeTruthy();
      });

      it('should show the total cash', () => {
        component.totalMarketValue = 300;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-cash-total')).nativeElement.innerHTML).toBe(
          '$300.00'
        );
      });

      describe('delete button', () => {
        it('should show with the correct config and event handlers attached', () => {
          const button = fixture.debugElement.query(By.css('.js-test-extassets-cash-table-row-cell-delete-0'));
          const deletedFormGroup = TEST_CASH_ASSETS_FORM_ARRAY.controls[0] as FormGroup;

          expect(button.nativeElement).toBeTruthy();
          expect(button.properties.config).toEqual(component.deleteButton);

          spyOn(component, 'deleteCash');
          button.nativeElement.dispatchEvent(new Event('click'));
          expect(component.deleteCash).toHaveBeenCalledWith(
            0,
            deletedFormGroup.get('positionId').value,
            deletedFormGroup.get('isNewAsset').value
          );
        });
      });
    });

    describe('validate form control', () => {
      beforeEach(() => {
        const mockFormArray = cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY);
        component.cashFormArray = mockFormArray as FormArray;
        component.cashFormArray.markAllAsTouched();
        fixture.detectChanges();
      });

      describe('validate marketValue', () => {
        it('should show error message when no value entered', () => {
          component.cashFormArray.controls[0].get('marketValue').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-cash-form-market-value-required-error-0')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1235');
        });

        it('should not show error message when valid value entered', () => {
          component.cashFormArray.controls[0].get('marketValue').setValue(12);
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-cash-form-market-value-required-error-0'))
          ).toBeFalsy();
        });

        it('should show error message when minimum number is entered', () => {
          component.cashFormArray.controls[0].get('marketValue').setValue('0.');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-cash-form-market-value-min-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1233');
        });

        it('should show error message when maximum number length is entered', () => {
          component.cashFormArray.controls[0].get('marketValue').setValue('999999999999');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-cash-form-market-value-max-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1227');
        });

        it('should show error message when invalid number is entered', () => {
          component.cashFormArray.controls[0].get('marketValue').setValue('12.3.5');
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-cash-form-market-value-pattern-error-0')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1236');
        });
      });

      describe('validate valuationDate', () => {
        it('should show error message when no value is entered', () => {
          component.cashFormArray.controls[0].get('valuationDate').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-cash-form-value-date-required-error-0')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
        });

        it('should not show error message when valid value is entered', () => {
          component.cashFormArray.controls[0].get('valuationDate').setValue(moment().tz('Australia/Sydney'));
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-cash-form-value-date-required-error-0'))
          ).toBeFalsy();
        });

        it('should show error message when future date is entered', () => {
          component.cashFormArray.controls[0].get('valuationDate').setValue(
            moment()
              .add(4, 'day')
              .tz('Australia/Sydney')
          );
          component.cashFormArray.controls[0].get('valuationDate').markAsTouched();
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-cash-form-value-date-max-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0386');
        });
      });
    });
  });
});
