import { Component, Input, OnInit } from '@angular/core';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';
import { StateParams } from '@upgrade/upgrade.services';
import * as moment from 'moment-timezone';
import { finalize, take } from 'rxjs/operators';

import { DEFAULT_PAGE_LOADING, NEW_WINDOW_ICON } from './pano-learn-about-investments.constants';
import { PanoLearnAboutInvestmentsService } from './pano-learn-about-investments.service';

@Component({
  selector: 'pano-learn-about-investments',
  templateUrl: './pano-learn-about-investments.component.html',
  styleUrls: ['./pano-learn-about-investments.component.scss']
})
export class PanoLearnAboutInvestmentsComponent implements OnInit {
  @Input()
  account: Account;

  investmentOptionsLink: Link;
  performanceLink: Link;
  unitPricesWgpLink: Link;
  unitPricesNonWgpLink: Link;
  feesLink: Link;
  publicFeesLink: Link;
  spreadLink: Link;

  content: object;
  disclaimer: string;
  date: moment;
  loading: boolean = true;

  readonly loadingSpinner: Loading = DEFAULT_PAGE_LOADING;
  readonly newWindowIcon: Icon = NEW_WINDOW_ICON;

  constructor(
    private readonly learnAboutInvestmentsService: PanoLearnAboutInvestmentsService,
    private readonly linkService: PanoSuperLinkService,
    private readonly disclaimerService: PanoDisclaimersService,
    private stateParams: StateParams
  ) {}

  ngOnInit(): void {
    this.date = moment(new Date()).format('D MMM YYYY');
    this.disclaimer = this.disclaimerService.evaluateDisclaimer(this.account);
    this.configureLinks();
    this.loadContent();
  }

  private loadContent() {
    this.learnAboutInvestmentsService
      .getTextContent()
      .pipe(take(1))
      .pipe(
        finalize(() => {
          this.loading = false;
        })
      )
      .subscribe((content: object) => (this.content = content));
  }

  private configureLinks() {
    const accountId = this.stateParams.accountId;
    this.investmentOptionsLink = this.linkService.getLink(LinkType.INVESTMENT_OPTIONS, accountId, this.account);
    this.performanceLink = this.linkService.getLink(LinkType.PAST_PERFORMANCE_INFORMATION, accountId, this.account);
    this.unitPricesWgpLink = this.linkService.getLink(LinkType.UNIT_PRICES_WGP, accountId, this.account);
    this.unitPricesNonWgpLink = this.linkService.getLink(LinkType.UNIT_PRICES_NON_WGP, accountId, this.account);
    this.feesLink = this.linkService.getLink(LinkType.INVESTMENT_FEES, accountId, this.account);
    this.publicFeesLink = this.linkService.getLink(LinkType.PUBLIC_INVESTMENT_FEES, accountId, this.account);
    this.spreadLink = this.linkService.getLink(LinkType.BUY_SELL_SPREADS, accountId, this.account);
  }
}
