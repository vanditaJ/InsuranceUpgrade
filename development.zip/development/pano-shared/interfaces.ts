export interface Email {
  email: string;
}

export interface Owner {
  age: number;
  dateOfBirth: string;
  emails: Array<Email>;
  firstName: string;
  gender: string;
  lastName: string;
}

export interface Product {
  productSubType?: 'PERSONAL_SUPER' | 'CORPORATE_SUPER';
}

export interface AccountKey {
  accountId: string;
}

export interface Account {
  key: AccountKey;
  accountName: string;
  accountNumber: string;
  firstMoneyReceivedDate: string;
  heritageCohort?: string;
  investmentOptionsGroup?: string;
  owners?: Owner[];
  pdsStatus: 'WGP_CURRENT' | 'WGP_CEASED' | 'EY' | 'DEFAULT';
  product: Product;
  productDescription?: string;
}

export interface TitleLinkComponent {
  type: string;
  id: string;
  data: {
    headerText: string;
    description: string;
  };
}

export interface AemTitleLink {
  details: TitleLinkComponent[];
}

export interface UserProfile {
  username: string;
}
