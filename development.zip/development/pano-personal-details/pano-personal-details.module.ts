import { NgModule } from '@angular/core';
import { LayoutModule } from '@panorama/components/layout';
import { YourDetailsModule } from '@panorama/your-details';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';

import { PanoPersonalDetailsComponent } from './pano-personal-details.component';

@NgModule({
  declarations: [PanoPersonalDetailsComponent],
  providers: [],
  entryComponents: [],
  imports: [
    YourDetailsModule,
    LayoutModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.personalDetails',
          url: '/personal-details',
          component: PanoPersonalDetailsComponent,
          data: {
            title: 'Your details'
          }
        }
      ]
    })
  ]
})
export class PanoPersonalDetailsModule {}
