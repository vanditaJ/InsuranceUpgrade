import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';

import { GENERIC_ERROR_ALERT } from '../../pano-insurance.constants';
import { PanoInsuranceService } from '../../pano-insurance.service';

import { CANCEL_BUTTON, DIALOG_CLOSE_BUTTON, SUBMIT_BUTTON } from './pano-pys-opt-in-all.component.constants';

@Component({
  selector: 'pano-pys-opt-in-all',
  templateUrl: './pano-pys-opt-in-all.component.html'
})
export class PanoPysOptInAllComponent implements OnInit {
  pysOptInForm: FormGroup;
  error: boolean = false;
  submitting: boolean = false;

  readonly cancelButton: Button = CANCEL_BUTTON;
  readonly dialogCloseButton: Button = DIALOG_CLOSE_BUTTON;
  readonly submitButton: Button = SUBMIT_BUTTON;
  readonly errorAlert: Alert = GENERIC_ERROR_ALERT;

  constructor(
    readonly dialogRef: MatDialogRef<PanoPysOptInAllComponent>,
    private readonly formBuilder: FormBuilder,
    private readonly panoInsuranceService: PanoInsuranceService,
    @Inject(MAT_DIALOG_DATA) public readonly data: { accountId: string }
  ) {}

  ngOnInit(): void {
    this.pysOptInForm = this.formBuilder.group({
      termsAndCondition: ['', Validators.required]
    });
  }

  submit() {
    this.pysOptInForm.markAllAsTouched();
    if (!this.pysOptInForm.get('termsAndCondition').value) {
      return;
    }

    this.submitting = true;
    this.pysOptInForm.get('termsAndCondition').disable();

    this.panoInsuranceService.submitPysOptInRequest(this.data.accountId, []).subscribe(
      () => {
        this.submitting = false;
        this.pysOptInForm.get('termsAndCondition').enable();
        this.error = false;
        this.dialogRef.close(true);
      },
      () => {
        this.submitting = false;
        this.pysOptInForm.get('termsAndCondition').enable();
        this.error = true;
      }
    );
  }
}
