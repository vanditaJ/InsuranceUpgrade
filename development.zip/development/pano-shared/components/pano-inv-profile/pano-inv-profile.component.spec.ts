import { HarnessLoader } from '@angular/cdk/testing';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';
import { Component, NO_ERRORS_SCHEMA, SimpleChange } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatAccordionHarness, MatExpansionPanelHarness } from '@angular/material/expansion/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { CopyMatrixPipe, CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import * as moment from 'moment-timezone';
import { of, throwError } from 'rxjs';

import { PanoInvestmentProfileLoadingComponent } from './pano-inv-profile-loading/pano-inv-profile-loading.component';
import { PanoInvestmentProfileComponent } from './pano-inv-profile.component';
import { DATE_TIME_FORMAT, TIME_ZONE } from './pano-inv-profile.constants';
import { MOCK_INVESTMENT_PROFILE } from './pano-inv-profile.constants.spec';
import { InvestmentProfile, InvestmentType } from './pano-inv-profile.interface';
import { PanoInvestmentProfileService } from './pano-inv-profile.service';

@Component({
  template: `
    <pano-inv-profile [profile]="profile" [isEditable]="isEditable"> </pano-inv-profile>
  `
})
class TestHostComponent {
  profile: InvestmentProfile = MOCK_INVESTMENT_PROFILE;
  isEditable: boolean = true;
}

class MockPanoInvestmentProfileService {
  setInvestmentProfile() {}
}

describe('PanoInvestmentProfileComponent', () => {
  let component: PanoInvestmentProfileComponent;
  let fixture: ComponentFixture<PanoInvestmentProfileComponent>;
  let profileService: PanoInvestmentProfileService;
  let loader: HarnessLoader;

  const copyMatrixSpy: jasmine.Spy = jasmine.createSpy();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [CopyMatrixPipeModule, MatExpansionModule, MatDialogModule, NoopAnimationsModule],
      providers: [
        {
          provide: PanoInvestmentProfileService,
          useClass: MockPanoInvestmentProfileService
        },
        {
          provide: CopyMatrixPipe,
          useValue: {
            transform: copyMatrixSpy
          }
        }
      ],
      declarations: [PanoInvestmentProfileComponent, TestHostComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentProfileComponent);
    component = fixture.componentInstance;
    profileService = TestBed.inject(PanoInvestmentProfileService);
    fixture.detectChanges();
    loader = TestbedHarnessEnvironment.loader(fixture);
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
      expect(component.isFirstTimeSettingProfile).toBe(undefined);
      expect(component.isSaveProfileFailed).toBe(undefined);
      expect(component.isEditingProfile).toBeFalse();
      expect(component.selectedInvestmentType).toBe(undefined);
    });

    it('should have correct input with its host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const hostComponent = hostFixture.componentInstance;
      const currentComp: PanoInvestmentProfileComponent = hostFixture.debugElement.query(
        By.directive(PanoInvestmentProfileComponent)
      ).componentInstance;

      hostFixture.detectChanges();

      expect(currentComp.profile).toEqual(hostComponent.profile);
      expect(currentComp.isEditable).toEqual(hostComponent.isEditable);
    });

    describe('ngOnChanges', () => {
      beforeEach(() => {
        component.ngOnChanges({ profile: new SimpleChange(0, MOCK_INVESTMENT_PROFILE, true) });
      });

      describe('when it has existing profile', () => {
        it('should setup selectedInvestmentType', () => {
          expect(component.selectedInvestmentType).toBe(InvestmentType[MOCK_INVESTMENT_PROFILE.investmentType]);
        });

        it('should setup lastUpdatedAtTime', () => {
          expect(component.lastUpdatedAtTime).toBe(
            moment(MOCK_INVESTMENT_PROFILE.lastUpdatedAt)
              .tz(TIME_ZONE)
              .format(DATE_TIME_FORMAT.DDMMMYYYYHMMAZ)
          );
        });

        it('should setup isFirstTimeSettingProfile as falsy', () => {
          expect(component.isFirstTimeSettingProfile).toBeFalsy();
        });
      });

      describe('when it has NO existing profile', () => {
        beforeEach(() => {
          component.selectedInvestmentType = undefined;
          component.lastUpdatedAtTime = undefined;
          component.ngOnChanges({ profile: new SimpleChange(0, null, true) });
        });

        it('should NOT setup selectedInvestmentType when null passed in', () => {
          component.ngOnChanges(null);

          expect(component.selectedInvestmentType).toBeFalsy();
        });

        it('should NOT setup selectedInvestmentType when null profile passed in but ', () => {
          component.ngOnChanges({ profile: null });

          expect(component.selectedInvestmentType).toBeFalsy();
        });

        it('should NOT setup selectedInvestmentType when null profile currentValue passed in but ', () => {
          component.ngOnChanges({ profile: new SimpleChange(0, null, true) });

          expect(component.selectedInvestmentType).toBeFalsy();
        });

        it('should NOT setup lastUpdatedAtTime', () => {
          expect(component.lastUpdatedAtTime).toBeFalsy();
        });

        it('should setup isFirstTimeSettingProfile as true', () => {
          expect(component.isFirstTimeSettingProfile).toBeTrue();
        });
      });
    });

    describe('saveInvestmentProfile()', () => {
      it('should call showSavingProfileProgress()', () => {
        spyOn(profileService, 'setInvestmentProfile').and.callFake(() => throwError(''));
        spyOn(component as any, 'showSavingProfileProgress').and.stub();

        component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

        expect((component as any).showSavingProfileProgress).toHaveBeenCalled();
      });

      it('should call PanoInvestmentProfileService.setInvestmentProfile()', () => {
        spyOn(profileService, 'setInvestmentProfile').and.callFake(() => throwError(''));
        spyOn(component as any, 'showSavingProfileProgress').and.stub();

        component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

        expect(profileService.setInvestmentProfile).toHaveBeenCalled();
      });

      describe('when api call success', () => {
        let setInvestmentProfileSpy;
        let setupSaveProfileSuccessMessageSpy;

        beforeEach(() => {
          setInvestmentProfileSpy = spyOn(profileService, 'setInvestmentProfile').and.returnValue(
            of(MOCK_INVESTMENT_PROFILE)
          );
          setupSaveProfileSuccessMessageSpy = spyOn(component as any, 'setupSaveProfileSuccessMessage').and.stub();
          (component as any).invProfileAccordion = {
            closeAll: jasmine.createSpy().and.stub()
          };
        });

        afterEach(() => {
          setInvestmentProfileSpy.calls.reset();
          setupSaveProfileSuccessMessageSpy.calls.reset();
        });

        it('should save profile', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.profile).toEqual(MOCK_INVESTMENT_PROFILE);
        });

        it('should setup selectedInvestmentType', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.selectedInvestmentType).toBe(InvestmentType[MOCK_INVESTMENT_PROFILE.investmentType]);
        });

        it('should setup lastUpdatedAtTime', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.lastUpdatedAtTime).toBe(
            moment(MOCK_INVESTMENT_PROFILE.lastUpdatedAt)
              .tz(TIME_ZONE)
              .format(DATE_TIME_FORMAT.DDMMMYYYYHMMAZ)
          );
        });

        it('should call setupSaveProfileSuccessMessage ', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(setupSaveProfileSuccessMessageSpy).toHaveBeenCalled();
        });

        it('should setup isEditingProfile as false', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.isEditingProfile).toBeFalse();
        });

        it('should setup isSaveProfileSuccess as falsy', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.isSaveProfileFailed).toBeFalsy();
        });

        it('should setup isFirstTimeSettingProfile as false', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.isFirstTimeSettingProfile).toBeFalse();
        });

        it('should call profileChange.emit', () => {
          spyOn(component.profileChange, 'emit').and.stub();

          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.profileChange.emit).toHaveBeenCalled();
        });

        it('should close investment profile accordian', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.invProfileAccordion.closeAll).toHaveBeenCalled();
        });

        it('should call dialog.closeAll()', () => {
          spyOn(component as any, 'showSavingProfileProgress').and.stub();
          (component as any).dialog = {
            closeAll: jasmine.createSpy()
          };

          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect((component as any).dialog.closeAll).toHaveBeenCalled();
        });
      });

      describe('when api call error', () => {
        let setInvestmentProfileSpy;
        let setupSaveProfileSuccessMessageSpy;
        beforeEach(() => {
          setInvestmentProfileSpy = spyOn(profileService, 'setInvestmentProfile').and.callFake(() => throwError(''));
          setupSaveProfileSuccessMessageSpy = spyOn(component as any, 'setupSaveProfileSuccessMessage').and.stub();
        });

        afterEach(() => {
          setInvestmentProfileSpy.calls.reset();
          setupSaveProfileSuccessMessageSpy.calls.reset();
        });

        it('should setup isSaveProfileFailed as true', () => {
          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect(component.isSaveProfileFailed).toBeTrue();
        });

        it('should call dialog.closeAll()', () => {
          spyOn(component as any, 'showSavingProfileProgress').and.stub();
          (component as any).dialog = {
            closeAll: jasmine.createSpy()
          };

          component.saveInvestmentProfile(MOCK_INVESTMENT_PROFILE);

          expect((component as any).dialog.closeAll).toHaveBeenCalled();
        });
      });
    });

    describe('setupSaveProfileSuccessMessage()', () => {
      it('should setup saveProfileSuccessAlert messages', () => {
        const expected = 'test message 10 Feb 2022 11:12am';
        copyMatrixSpy.and.returnValue(expected);
        component.lastUpdatedAtTime = '10 Feb 2022 11:12am';

        (component as any).setupSaveProfileSuccessMessage();

        expect(component.saveProfileSuccessAlert.messages).toBe('test message 10 Feb 2022 11:12am');
      });

      it('should call saveProfileSuccessAlert.visibilitySubject next', () => {
        const nextSpy = spyOn(component.saveProfileSuccessAlert.visibilitySubject, 'next').and.stub();
        const expected = 'test message {1}';
        copyMatrixSpy.and.returnValue(expected);
        component.lastUpdatedAtTime = '10 Feb 2022 11:12am';

        (component as any).setupSaveProfileSuccessMessage();

        expect(nextSpy).toHaveBeenCalled();
      });
    });

    describe('showSavingProfileProgress()', () => {
      it('should call profile loading compoonent dialog', () => {
        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        (component as any).showSavingProfileProgress();

        expect((component as any).dialog.open).toHaveBeenCalledWith(
          PanoInvestmentProfileLoadingComponent,
          jasmine.any(Object)
        );
      });
    });
  });

  describe('View', () => {
    describe('when it has existing profile', () => {
      beforeEach(() => {
        component.profile = MOCK_INVESTMENT_PROFILE;
        fixture.detectChanges();
      });

      it('should show investment profile component title', () => {
        const title = fixture.debugElement.query(By.css('.js-investment-profile-title'));

        expect(title).toBeTruthy();
        expect(title.nativeElement.textContent.trim()).toBe(component.investmentProfileTitle);
      });

      it('should show investment profile interested in', () => {
        component.selectedInvestmentType = 'TEST Selected type';
        fixture.detectChanges();

        const profile = fixture.debugElement.query(By.css('.js-test-investment-profile-interested-in'));
        expect(profile).toBeTruthy();
        expect(profile.nativeElement.textContent.trim()).toContain('Interested in:');
        expect(profile.nativeElement.innerHTML.trim()).toContain(component.selectedInvestmentType);
      });

      it('should show investment profile Last saved on', () => {
        component.lastUpdatedAtTime = 'test time';
        fixture.detectChanges();

        const profile = fixture.debugElement.query(By.css('.js-test-investment-profile-last-saved-on'));

        expect(profile).toBeTruthy();
        expect(profile.nativeElement.textContent.trim()).toContain('Last saved on:');
        expect(profile.nativeElement.textContent.trim()).toContain(component.lastUpdatedAtTime);
      });

      it('should show investment profile edit button', () => {
        const editButton = fixture.debugElement.query(By.css('bt-button'));

        expect(editButton).toBeTruthy();
        expect(editButton.properties.config).toEqual(component.editInvestmentProfileButton);
      });

      it('should NOT show investment profile setup component', () => {
        component.isEditingProfile = false;
        fixture.detectChanges();

        const profileSetup = fixture.debugElement.query(By.css('pano-inv-profile-setup'));
        expect(profileSetup).toBeFalsy();
      });

      describe('Investment profile accordian', () => {
        describe('when isEditable is true', () => {
          beforeEach(() => {
            component.isEditable = true;
            fixture.detectChanges();
          });

          it('should toggle investment profile setup component ', async () => {
            const accordions = await loader.getAllHarnesses(MatAccordionHarness);
            expect(accordions.length).toBe(1);

            const panels = await loader.getAllHarnesses(MatExpansionPanelHarness);
            expect(panels.length).toBe(1);

            expect(await panels[0].isExpanded()).toBe(false);
            const closedProfileSetup = fixture.debugElement.query(By.css('pano-inv-profile-setup'));
            expect(closedProfileSetup).toBeFalsy();

            await panels[0].toggle();
            expect(await panels[0].isExpanded()).toBe(true);

            const openProfileSetup = fixture.debugElement.query(By.css('pano-inv-profile-setup'));
            expect(openProfileSetup).toBeTruthy();
            expect(openProfileSetup.properties.profile).toEqual(component.profile);
          });

          it('should show accordian icon', async () => {
            const panels = await loader.getAllHarnesses(MatExpansionPanelHarness);
            expect(panels.length).toBe(1);

            expect(await panels[0].isExpanded()).toBe(false);
            const accordianIcon = fixture.debugElement.query(By.css('bt-icon'));
            expect(accordianIcon).toBeTruthy();
            expect(accordianIcon.properties.config).toEqual(component.expansionIcon);
          });

          it('should show accordian edit button', async () => {
            const panels = await loader.getAllHarnesses(MatExpansionPanelHarness);
            expect(panels.length).toBe(1);

            expect(await panels[0].isExpanded()).toBe(false);
            const accordianEditButton = fixture.debugElement.query(By.css('bt-button'));
            expect(accordianEditButton).toBeTruthy();
            expect(accordianEditButton.properties.config).toEqual(component.editInvestmentProfileButton);
          });
        });

        describe('when isEditable is false', () => {
          beforeEach(() => {
            component.isEditable = false;
            fixture.detectChanges();
          });

          it('should not show profile setup component', async () => {
            const panels = await loader.getAllHarnesses(MatExpansionPanelHarness);
            expect(panels.length).toBe(1);

            expect(await panels[0].isExpanded()).toBe(false);
            const closedProfileSetup = fixture.debugElement.query(By.css('pano-inv-profile-setup'));
            expect(closedProfileSetup).toBeFalsy();

            await panels[0].toggle();
            expect(await panels[0].isExpanded()).toBe(false);
            const openProfileSetup = fixture.debugElement.query(By.css('pano-inv-profile-setup'));
            expect(openProfileSetup).toBeFalsy();
          });

          it('should not show accordian icon', async () => {
            const panels = await loader.getAllHarnesses(MatExpansionPanelHarness);
            expect(panels.length).toBe(1);

            expect(await panels[0].isExpanded()).toBe(false);
            const accordianIcon = fixture.debugElement.query(By.css('bt-icon'));
            expect(accordianIcon).toBeFalsy();
          });

          it('should not show accordian edit button', async () => {
            const panels = await loader.getAllHarnesses(MatExpansionPanelHarness);
            expect(panels.length).toBe(1);

            expect(await panels[0].isExpanded()).toBe(false);
            const accordianEditButton = fixture.debugElement.query(By.css('bt-button'));
            expect(accordianEditButton.nativeElement.className).toContain('invisible');
          });
        });
      });
    });

    describe('when it has NO existing profile', () => {
      beforeEach(() => {
        component.profile = undefined;
        fixture.detectChanges();
      });

      it('should show investment profile setup component', () => {
        spyOn(component, 'saveInvestmentProfile').and.stub();

        const profileSetupComponent = fixture.debugElement.query(By.css('pano-inv-profile-setup'));
        expect(profileSetupComponent).toBeTruthy();

        profileSetupComponent.triggerEventHandler('saveProfile', MOCK_INVESTMENT_PROFILE);
        fixture.detectChanges();

        expect(component.saveInvestmentProfile).toHaveBeenCalled();
      });

      it('should NOT show investment profile component', () => {
        expect(fixture.debugElement.query(By.css('.js-test-investment-profile'))).toBeFalsy();
      });
    });

    describe('setup profile alert', () => {
      it('should show setup profile alert if isFirstTimeSettingProfile is true', () => {
        component.profile = undefined;
        component.isFirstTimeSettingProfile = true;
        fixture.detectChanges();

        const alert = fixture.debugElement.query(By.css('.js-test-setup-profile-alert'));
        expect(alert).toBeTruthy();
        expect(alert.properties.config).toEqual(component.setUpProfileAlert);
      });

      it('should NOT show setup profile alert if isFirstTimeSettingProfile is false', () => {
        component.profile = undefined;
        component.isFirstTimeSettingProfile = false;
        fixture.detectChanges();

        const alert = fixture.debugElement.query(By.css('.js-test-setup-profile-alert'));
        expect(alert).toBeFalsy();
      });
    });

    describe('save profile success alert', () => {
      it('should show save profile success alert', () => {
        const alert = fixture.debugElement.query(By.css('.js-test-save-profile-success-alert'));
        expect(alert).toBeTruthy();
        expect(alert.properties.config).toEqual(component.saveProfileSuccessAlert);
      });
    });

    describe('save profile failed alert', () => {
      it('should show save profile failed alert if isSaveProfileFailed is true', () => {
        component.isSaveProfileFailed = true;
        fixture.detectChanges();

        const alert = fixture.debugElement.query(By.css('.js-test-save-profile-failed-alert'));
        expect(alert).toBeTruthy();
        expect(alert.properties.config).toEqual(component.saveProfileFailedAlert);
      });

      it('should NOT show save profile failed alert if isSaveProfileFailed is not true', () => {
        component.isSaveProfileFailed = false;
        fixture.detectChanges();

        const alert = fixture.debugElement.query(By.css('.js-test-save-profile-failed-alert'));
        expect(alert).toBeFalsy();

        component.isSaveProfileFailed = undefined;
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-save-profile-failed-alert'))).toBeFalsy();
      });
    });
  });
});
