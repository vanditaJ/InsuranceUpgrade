import { DOCUMENT } from '@angular/common';
import { Component, Inject, Input, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Loading } from '@bt/components/loading';
import { SnackBarTemplateComponent } from '@bt/components/snack-bar-template';
import { BtError } from '@bt/services/data';
import { TargetState, UIRouter } from '@uirouter/core';
import { forEach, isEqual, reduce } from 'lodash-es';
import * as moment from 'moment-timezone';
import { PageScrollService } from 'ngx-page-scroll-core';
import { of, Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { PanoConfirmDialogComponent } from './pano-confirm-dialog/pano-confirm-dialog.component';
import {
  ASSET_DELETE_DIALOG_DATA_CONFIG,
  ASSET_TYPES,
  ASSET_TYPES_ORDER,
  CLEAR_ASSETS_CHANGES_BUTTON,
  CLEAR_CHANGES_DIALOG_DATA_CONFIG,
  CONFIRM_CANCELLATION_DIALOG_DATA_CONFIG,
  CONFIRM_DIALOG_CONFIG,
  DEFAULT_ASSET_DELETE,
  DEFAULT_ASSET_TYPE_TOTAL,
  EXTERNAL_ASSETS_MODULE,
  PAGE_SCROLL_SPEED,
  SAVE_ASSETS_CHANGES_BUTTON,
  SNACK_BAR_EXTERNAL_ASSETS_NO_UNSAVED_CHANGES,
  SNACK_BAR_EXTERNAL_ASSETS_SUCCESS
} from './pano-external-assets-constants/pano-external-assets.constants';
import { PanoExternalAssetsFormCreator } from './pano-external-assets-form-creator';
import {
  GENERIC_ALERT,
  INITIAL_PAGE_LOADING,
  SCREEN_TYPE,
  SMSF_ACCOUNTING_SOFTWARE_READ_ENTITLEMENT,
  SMSF_SERVICES_ALERT,
  SMSF_SERVICE_MODULE_NAME,
  SOFTWARE_STATUS,
  SYSTEM_ERROR_MODULE_NAME
} from './pano-external-assets.constants';
import {
  AssetType,
  AssetTypeTotalDetails,
  AssetTypeTotalMarketValue,
  ExternalAsset,
  ExternalAssetDelete,
  ExternalAssetDeleteDetails,
  ExternalAssetsSaveDetails,
  ExternalAssetsValuationByType,
  ExternalAssetsValuationDetails,
  FormControlsDetails,
  PropertyType,
  SoftwareData
} from './pano-external-assets.interfaces';
import { PanoExternalAssetsService } from './pano-external-assets.service';

@Component({
  selector: 'pano-external-assets',
  templateUrl: './pano-external-assets.component.html',
  styleUrls: ['./pano-external-assets.scss']
})
export class PanoExternalAssetsComponent implements OnInit, OnDestroy {
  @Input()
  accountId: string;
  @Input()
  softwareData: SoftwareData;

  readonly saveAssetsChangesButton: Button = SAVE_ASSETS_CHANGES_BUTTON;
  readonly clearAssetsChangesButton: Button = CLEAR_ASSETS_CHANGES_BUTTON;
  readonly smsfServiceAlert: Alert = SMSF_SERVICES_ALERT;
  readonly loadingSpinner: Loading = INITIAL_PAGE_LOADING;
  readonly screenType = SCREEN_TYPE;
  readonly softwareStatus = SOFTWARE_STATUS;
  readonly smsfEntitlement: string = SMSF_ACCOUNTING_SOFTWARE_READ_ENTITLEMENT;

  genericAlert: Alert = { ...GENERIC_ALERT };

  initialLoading: boolean = true;
  saveLoading: boolean;

  isSaveError: boolean;
  isGenericError: boolean = false;

  assetTypes: AssetType[];
  externalAssets: ExternalAssetsValuationDetails;
  externalAssetsForm: FormGroup;
  deletedExternalAssets: ExternalAssetDelete[] = [];
  assetTypeTotals: AssetTypeTotalMarketValue;
  propertyTypes: PropertyType[];
  totalMarketValue: number;
  totalAssetsCount: number;

  private currentSavedSnapshot: ExternalAssetsSaveDetails;

  private assetsTypesSubscription: Subscription = of(null).subscribe();
  private externalAssetsSubscription: Subscription = of(null).subscribe();
  private confirmDialogSubscription: Subscription = of(null).subscribe();
  private propertyTypesSubscription: Subscription = of(null).subscribe();
  private externalAssetsSaveSubscription: Subscription = of(null).subscribe();

  constructor(
    private readonly externalAssetService: PanoExternalAssetsService,
    private readonly panoExternalAssetsFormCreator: PanoExternalAssetsFormCreator,
    private readonly fb: FormBuilder,
    private readonly dialog: MatDialog,
    private readonly snackBar: MatSnackBar,
    private readonly uiRouter: UIRouter,
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: HTMLDocument
  ) {}

  ngOnInit(): void {
    if (this.softwareData.screenType !== this.screenType.CONNECTED) {
      this.setDefaultExternalAssetFormAndTotals();
      this.loadAssetTypes();
      this.loadExternalAssets();
      this.loadPropertyTypes();
    }
  }

  ngOnDestroy(): void {
    this.assetsTypesSubscription.unsubscribe();
    this.externalAssetsSubscription.unsubscribe();
    this.confirmDialogSubscription.unsubscribe();
    this.propertyTypesSubscription.unsubscribe();
    this.externalAssetsSaveSubscription.unsubscribe();
  }

  loadAssetTypes(): void {
    this.assetsTypesSubscription = this.externalAssetService.getAssetTypes().subscribe(
      (result: AssetType[]) => (this.assetTypes = result),
      (error: BtError) => {
        this.isGenericError = true;
        this.genericAlert.messages = error;
      }
    );
  }

  loadExternalAssets(): void {
    this.externalAssetsSubscription = this.externalAssetService
      .getExternalAssets(this.accountId)
      .pipe(finalize(() => (this.initialLoading = false)))
      .subscribe(
        (data: ExternalAssetsValuationDetails) => this.setExternalAssetsData(data),
        () => this.uiRouter.stateService.go(SYSTEM_ERROR_MODULE_NAME, { accountId: this.accountId })
      );
  }

  loadPropertyTypes(): void {
    this.propertyTypesSubscription = this.externalAssetService.getPropertyTypes().subscribe(
      (result: PropertyType[]) => (this.propertyTypes = result),
      (error: BtError) => {
        this.isGenericError = true;
        this.genericAlert.messages = error;
      }
    );
  }

  navigateToSMSFService(): void {
    this.uiRouter.stateService.go(SMSF_SERVICE_MODULE_NAME);
  }

  constructAssetTypeForms(assets: ExternalAssetsValuationByType): void {
    // tslint:disable-next-line: forin
    for (const prop in assets) {
      this.panoExternalAssetsFormCreator.createAssetsFormControl(this.externalAssetsForm, prop, assets[prop]);
    }
  }

  confirmAssetDelete(assetDetailsToDelete: ExternalAssetDeleteDetails): void {
    (this.externalAssetsForm.get(`${assetDetailsToDelete.assetTypeCode}FormArray`) as FormArray).removeAt(
      assetDetailsToDelete.index
    );
    if (!assetDetailsToDelete.isNewAsset) {
      this.deletedExternalAssets.push(this.getDeletedAssetDetails(assetDetailsToDelete.positionId));
    }
    this.setTotalAssetsCount();
  }

  collectAssetToDelete(event: ExternalAssetDeleteDetails): void {
    this.confirmDialogSubscription = this.dialog
      .open(PanoConfirmDialogComponent, {
        ...CONFIRM_DIALOG_CONFIG,
        data: { ...CONFIRM_DIALOG_CONFIG.data, ...ASSET_DELETE_DIALOG_DATA_CONFIG }
      })
      .afterClosed()
      .subscribe(action => {
        if (action) {
          this.confirmAssetDelete(event);
        }
      });
  }

  getDeletedAssetDetails(positionId: string): ExternalAssetDelete {
    return {
      ...DEFAULT_ASSET_DELETE,
      positionId
    };
  }

  collectAssetToAdd(event: ExternalAsset): void {
    this.panoExternalAssetsFormCreator.createAssetFormControl(
      this.externalAssetsForm.get(`${event.assetTypeCode}FormArray`) as FormArray,
      event.assetTypeCode,
      event
    );
    this.setTotalAssetsCount();
  }

  updateAssetTotalMarketValue(event: AssetTypeTotalDetails): void {
    if ((this.externalAssetsForm.get(`${event.assetTypeCode}FormArray`) as FormArray).controls.length) {
      this.assetTypeTotals[`${event.assetTypeCode}TotalMarketValue`] = event.assetTypeTotalMarketValue;
    } else {
      this.assetTypeTotals[`${event.assetTypeCode}TotalMarketValue`] = 0;
    }
    this.calculateExternalAssetsTotal();
  }

  calculateExternalAssetsTotal(): void {
    this.totalMarketValue = reduce(this.assetTypeTotals, (total, assetTotal) => total + assetTotal, 0);
  }

  saveAssetsChanges(): void {
    this.externalAssetsForm.markAllAsTouched();
    if (this.externalAssetsForm.valid) {
      if (this.hasUnsavedChanges()) {
        this.isSaveError = false;
        this.saveLoading = true;
        this.externalAssetsSaveSubscription = this.externalAssetService
          .saveExternalAssets(this.accountId, this.getExternalAssetDetailsForSave())
          .pipe(finalize(() => (this.saveLoading = false)))
          .subscribe(
            (data: ExternalAssetsValuationDetails) => {
              this.snackBar.openFromComponent(SnackBarTemplateComponent, SNACK_BAR_EXTERNAL_ASSETS_SUCCESS);
              this.setDefaultExternalAssetFormAndTotals();
              this.setExternalAssetsData(data);
            },
            (error: BtError) => {
              this.isSaveError = true;
              this.genericAlert.messages = error;
            }
          );
      } else {
        this.snackBar.openFromComponent(SnackBarTemplateComponent, SNACK_BAR_EXTERNAL_ASSETS_NO_UNSAVED_CHANGES);
      }
    } else {
      this.scrollToErrorSection();
    }
  }

  getExternalAssetDetailsForSave(): ExternalAssetsSaveDetails {
    const externalAssetsSaveDetails: ExternalAssetsSaveDetails = {
      addedAndEdited: {
        ...this.getAssetFormArrayValues()
      },
      deleted: this.deletedExternalAssets
    };
    return externalAssetsSaveDetails;
  }

  getAssetFormArrayValues(): ExternalAssetsValuationByType {
    return reduce(
      ASSET_TYPES,
      (accum, asset) => {
        return {
          ...accum,
          [asset.code]: this.getAssetFormValues(
            this.externalAssetsForm.get(`${asset.code}FormArray`) as FormArray,
            asset.editFormControls
          )
        };
      },
      []
    );
  }

  getAssetFormValues(assetFormArray: FormArray, formControlsNames: FormControlsDetails[]): ExternalAsset[] {
    return assetFormArray.controls.map(fg => {
      return formControlsNames.reduce((accum, field) => {
        const formControlValue = fg.get(field.name).value;
        return {
          ...accum,
          [field.name]:
            field.type === 'date'
              ? formControlValue !== ''
                ? moment(formControlValue).format('DD MMM YYYY')
                : ''
              : formControlValue
        };
      }, {}) as ExternalAsset;
    });
  }

  setExternalAssetsData(externalAssetsData: ExternalAssetsValuationDetails): void {
    this.externalAssets = externalAssetsData;
    if (this.externalAssets.hasAssets) {
      this.constructAssetTypeForms(this.externalAssets.assets);
    }
    this.setTotalAssetsCount();
    this.currentSavedSnapshot = this.getExternalAssetDetailsForSave();
  }

  setDefaultExternalAssetFormAndTotals(): void {
    this.externalAssetsForm = this.fb.group({
      cashFormArray: new FormArray([]),
      tdFormArray: new FormArray([]),
      lsFormArray: new FormArray([]),
      ilsFormArray: new FormArray([]),
      mfFormArray: new FormArray([]),
      mpFormArray: new FormArray([]),
      dpFormArray: new FormArray([]),
      othFormArray: new FormArray([])
    });
    this.assetTypeTotals = { ...DEFAULT_ASSET_TYPE_TOTAL };
    this.totalMarketValue = 0;
    this.deletedExternalAssets = [];
    this.totalAssetsCount = 0;
  }

  clearChanges(): void {
    this.confirmDialogSubscription = this.dialog
      .open(PanoConfirmDialogComponent, {
        ...CONFIRM_DIALOG_CONFIG,
        data: { ...CONFIRM_DIALOG_CONFIG.data, ...CLEAR_CHANGES_DIALOG_DATA_CONFIG }
      })
      .afterClosed()
      .subscribe(action => {
        if (action) {
          this.setDefaultExternalAssetFormAndTotals();
          this.setExternalAssetsData(this.externalAssets);
        }
      });
  }

  setTotalAssetsCount(): void {
    this.totalAssetsCount = reduce(
      this.externalAssetsForm.controls,
      (total: number, assetFormArray: FormArray) => total + assetFormArray['controls'].length,
      0
    );
  }

  uiCanExit(): Promise<boolean | TargetState> {
    return this.softwareData.screenType !== this.screenType.CONNECTED && this.hasUnsavedChanges()
      ? this.dialog
          .open(PanoConfirmDialogComponent, {
            ...CONFIRM_DIALOG_CONFIG,
            data: { ...CONFIRM_DIALOG_CONFIG.data, ...CONFIRM_CANCELLATION_DIALOG_DATA_CONFIG }
          })
          .afterClosed()
          .toPromise()
          .then(
            (response: boolean): boolean | TargetState =>
              response || this.uiRouter.stateService.target(EXTERNAL_ASSETS_MODULE)
          )
      : Promise.resolve(true);
  }

  private hasUnsavedChanges(): boolean {
    return this.currentSavedSnapshot
      ? !isEqual(this.getExternalAssetDetailsForSave(), this.currentSavedSnapshot)
      : false;
  }

  private scrollToErrorSection(): void {
    const invalidFormArray = this.getInvalidFormArray();
    const formIndex = invalidFormArray.controls.findIndex(assetForm => assetForm.invalid);
    const targetElementHeaderClass = `.${invalidFormArray.controls[formIndex].value.assetTypeCode}-form-array-header`;
    // TODO to scroll to invalid Form Row below line can use, due to technical problem we are scrolling to section
    // const targetElementTRClass = `.${inValidFormArray.controls[formIndex].value.assetTypeCode}-form-${formIndex}`;
    setTimeout(() => {
      this.pageScrollService.scroll({
        document: this.document,
        speed: PAGE_SCROLL_SPEED,
        scrollTarget: targetElementHeaderClass,
        scrollViews: [this.document.querySelector('.layout-scroll')]
      });
    });
  }

  private getInvalidFormArray(): FormArray {
    let inValidFormArray: FormArray;
    forEach(ASSET_TYPES_ORDER, value => {
      if ((this.externalAssetsForm.get(`${value}FormArray`) as FormArray).invalid) {
        inValidFormArray = this.externalAssetsForm.get(`${value}FormArray`) as FormArray;
        return false;
      }
    });
    return inValidFormArray;
  }
}
