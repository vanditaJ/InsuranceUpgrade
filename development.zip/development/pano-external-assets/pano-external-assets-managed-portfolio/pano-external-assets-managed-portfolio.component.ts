import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { FormArray } from '@angular/forms';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { Subscription } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import {
  ASSET_TYPES,
  DATE_PICKER_ICON,
  DELETE_BUTTON,
  SR_ONLY_BREAKPOINTS
} from '../pano-external-assets-constants/pano-external-assets.constants';
import { AssetTypeTotalDetails, ExternalAssetDeleteDetails } from '../pano-external-assets.interfaces';

@Component({
  selector: 'pano-external-assets-managed-portfolio',
  templateUrl: './pano-external-assets-managed-portfolio.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoExternalAssetsManagedPortfolioComponent implements OnChanges, OnDestroy {
  @Input() mpFormArray: FormArray;
  @Input() assetCount: number;

  @Output()
  assetDelete: EventEmitter<ExternalAssetDeleteDetails> = new EventEmitter();
  @Output()
  assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails> = new EventEmitter();

  datePickerIcon: Icon = DATE_PICKER_ICON;
  deleteButton: Button = DELETE_BUTTON;
  srOnlyBreakpoints = SR_ONLY_BREAKPOINTS;
  today: Date = moment().tz('Australia/Sydney');
  totalMarketValue: number;

  private controlsValueChangesSubscriptions: Subscription[] = [];

  constructor(private panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil) {}

  ngOnDestroy(): void {
    this.calculateTotal();
    this.unregisterControlsValueChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      get(changes, 'assetCount.currentValue') !== get(changes, 'assetCount.previousValue') ||
      get(changes, 'mpFormArray.currentValue') !== get(changes, 'mpFormArray.previousValue')
    ) {
      this.unregisterControlsValueChanges();
      this.registerControlsValueChanges();
      this.calculateTotal();
    }
  }

  registerControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges(
      this.mpFormArray,
      this.calculateTotal.bind(this)
    );
  }

  unregisterControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges(
      this.controlsValueChangesSubscriptions
    );
  }

  deleteManagedPortfolio(index: number, positionId: string, isNewAsset: boolean): void {
    this.panoExtAssetsCommonUtil.deleteAsset(
      {
        index,
        assetTypeCode: ASSET_TYPES.mp.code,
        positionId,
        isNewAsset
      },
      this.assetDelete
    );
  }

  calculateTotal(): void {
    this.totalMarketValue = this.panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue(
      this.mpFormArray,
      ASSET_TYPES.mp.code,
      this.assetTotalMarketValueUpdate
    );
  }
}
