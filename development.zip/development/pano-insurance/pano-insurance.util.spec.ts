import { TestBed, waitForAsync } from '@angular/core/testing';
import { Account } from '@investor/account/pano-shared/interfaces';
import cloneDeep from 'lodash/cloneDeep';
import * as moment from 'moment-timezone';

import { Insurances } from './pano-insurance-policies/pano-insurance-policies.interface';
import {
  MOCK_ALL_POLICIES,
  MOCK_INSURANCE_DETAILS
} from './pano-insurance-policies/pano-insurance-tables/pano-insurance-tables.component.spec.constants';
import { PanoInsuranceUtil } from './pano-insurance.util';
import {
  MOCK_60_DAY_POLICY,
  MOCK_90_DAY_POLICY,
  MOCK_ACCOUNT,
  MOCK_ACCOUNTS
} from './pano-insurance.util.spec.constants';

describe('PanoInsuranceUtil', () => {
  let panoInsuranceUtil: PanoInsuranceUtil;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        providers: [PanoInsuranceUtil]
      });
    })
  );

  beforeEach(() => {
    panoInsuranceUtil = TestBed.inject(PanoInsuranceUtil);

    jasmine.clock().install();
    jasmine.clock().mockDate(new Date('2021-01-22'));
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  });

  it('should have a util instance', () => {
    expect(panoInsuranceUtil).toBeDefined();
  });

  describe('getDate', () => {
    it('should return moment obj for date passed', () => {
      const date = '2021-02-03';
      const result = panoInsuranceUtil.getDate(date);
      const momentObj = moment(date)
        .tz('Australia/Sydney')
        .startOf('day');

      expect(result).toEqual(momentObj);
    });

    it('should return now moment obj for todays date', () => {
      const result = panoInsuranceUtil.getDate('now');
      const momentObj = moment()
        .tz('Australia/Sydney')
        .startOf('day');

      expect(result).toEqual(momentObj);
    });
  });

  describe('getDaysSince', () => {
    it('should return the days from date passed to todays date when passed date is in past', () => {
      const date = '2020-12-22';
      const result = panoInsuranceUtil.getDaysSince(date);

      expect(result).toBe(31);
    });

    it('should return the days from date passed to todays date when passed date is in future', () => {
      const date = '2021-01-25';
      const result = panoInsuranceUtil.getDaysSince(date);

      expect(result).toBe(-3);
    });

    it('should return the days from date passed to todays date when passed date is same as today', () => {
      const date = '2021-01-22';
      const result = panoInsuranceUtil.getDaysSince(date);

      expect(result).toBe(0);
    });
  });

  describe('getAccountActivationDaysFor90DaysCriteria', () => {
    it('should return account activation days', () => {
      spyOn(panoInsuranceUtil as any, 'getAccountActivationDateFor90DaysCriteria').and.returnValue('2020-12-22');

      const result = panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria(
        MOCK_90_DAY_POLICY[0],
        MOCK_ACCOUNTS[0]
      );

      expect(result).toBe(31);
    });
  });

  describe('getAccountActivationDateFor90DaysCriteria', () => {
    it('should return first money received date when member has opted in pmif and first money received date is later than pmif optin date', () => {
      const account = cloneDeep(MOCK_ACCOUNTS)[0];
      account.owners[0].age = 20;
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor90DaysCriteria(
        MOCK_90_DAY_POLICY[0],
        account
      );

      expect(result).toBe(MOCK_ACCOUNTS[0].firstMoneyReceivedDate);
    });

    it('should return pmif optin date when member has opted in pmif and first money received date is earlier than pmif optin date', () => {
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor90DaysCriteria(
        MOCK_90_DAY_POLICY[0],
        MOCK_ACCOUNTS[1]
      );

      expect(result).toBe(MOCK_90_DAY_POLICY[0].pmifDetails.optInDate);
    });

    it('should return automatic cover date when member has NOT opted in pmif', () => {
      const policy = cloneDeep(MOCK_90_DAY_POLICY)[0];
      policy.pmifDetails.optInDate = null;
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor90DaysCriteria(policy, MOCK_ACCOUNTS[0]);

      expect(result).toBe(MOCK_90_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate);
    });

    it('should return automatic cover date when acd is earlier than pmif date', () => {
      const policy = cloneDeep(MOCK_90_DAY_POLICY)[0];
      policy.pmifDetails.optInDate = '2021-01-14T14:00:00.000Z';
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor90DaysCriteria(policy, MOCK_ACCOUNTS[0]);

      expect(result).toBe(policy.pmifDetails.lowBalanceThresholdDate);
    });
  });

  describe('getAccountActivationDateFor60DaysCriteria', () => {
    it('should return pmif optin date when member has opted in pmif and automatic cover date is later than pmif optin date', () => {
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor60DaysCriteria(
        MOCK_60_DAY_POLICY[0],
        MOCK_ACCOUNTS[0]
      );
      expect(result).toBe(MOCK_60_DAY_POLICY[0].pmifDetails.optInDate);
    });

    it('should return automatic cover date when member has opted in pmif and automatic cover date is earlier than pmif optin date', () => {
      const policy = cloneDeep(MOCK_60_DAY_POLICY)[0];
      policy.pmifDetails.lowBalanceThresholdDate = '2020-06-22T14:00:00.000Z';
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor60DaysCriteria(policy, MOCK_ACCOUNTS[0]);
      expect(result).toBe(policy.pmifDetails.lowBalanceThresholdDate);
    });

    it('should return automatic cover date when member has NOT opted in pmif', () => {
      const policy = cloneDeep(MOCK_60_DAY_POLICY)[0];
      policy.pmifDetails.optInDate = null;
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor60DaysCriteria(policy, MOCK_ACCOUNTS[0]);
      expect(result).toBe(MOCK_60_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate);
    });

    it('should return automatic cover date when acd is earlier than pmif date', () => {
      const policy = cloneDeep(MOCK_60_DAY_POLICY)[0];
      policy.pmifDetails.optInDate = '2021-01-14T14:00:00.000Z';
      const result = (panoInsuranceUtil as any).getAccountActivationDateFor60DaysCriteria(policy, MOCK_ACCOUNTS[0]);

      expect(result).toBe(policy.pmifDetails.lowBalanceThresholdDate);
    });
  });

  describe('getAccountActivationDaysFor60DaysCriteria', () => {
    it('should return 0 if the accountActivationDate is null', () => {
      const result = (panoInsuranceUtil as any).getAccountActivationDaysFor60DaysCriteria(
        MOCK_60_DAY_POLICY[1],
        MOCK_ACCOUNTS[0]
      );
      expect(result).toBe(0);
    });
  });

  describe('getAutomaticCoverDate', () => {
    it('should return low balance threshold date if member age is > 25 and member has reached low balance threshold', () => {
      const result = (panoInsuranceUtil as any).getAutomaticCoverDate(
        MOCK_ACCOUNTS[0],
        MOCK_90_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate
      );

      expect(result).toBe(MOCK_90_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate);
    });

    it('should return low balance threshold date if member age is 25 and member has reached lbt and lbt is greater than 25th birthday', () => {
      const result = (panoInsuranceUtil as any).getAutomaticCoverDate(
        MOCK_ACCOUNTS[2],
        MOCK_90_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate
      );

      expect(result).toBe(MOCK_90_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate);
    });

    it('should return 25th birthday if member age is 25 and member has reached lbt and 25th birthday is greater than lbt', () => {
      const result = (panoInsuranceUtil as any).getAutomaticCoverDate(
        MOCK_ACCOUNTS[4],
        MOCK_90_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate
      );

      expect(result).toBe(
        moment(MOCK_ACCOUNTS[4].owners[0].dateOfBirth)
          .add(25, 'years')
          .format('YYYY-MM-DD')
      );
    });

    it('should return members 25th birth date if member age is < 25 and member has reached low balance threshold', () => {
      const result = (panoInsuranceUtil as any).getAutomaticCoverDate(
        MOCK_ACCOUNTS[1],
        MOCK_90_DAY_POLICY[0].pmifDetails.lowBalanceThresholdDate
      );

      expect(result).toBeUndefined();
    });

    it('should return undefined if member has not reached low balance threshold', () => {
      const result = (panoInsuranceUtil as any).getAutomaticCoverDate(MOCK_ACCOUNTS[0], null);

      expect(result).toBeUndefined();
    });
  });

  describe('isBTSFLMember', () => {
    let account: Account;
    beforeEach(() => {
      account = MOCK_ACCOUNT;
    });

    it('should return true for BTSFL', () => {
      account.productDescription = 'BT Super for Life';
      const result = panoInsuranceUtil.isBTSFLMember(account);
      expect(result).toBe(true);
    });

    it('should return false not BTSFL', () => {
      account.productDescription = 'BT Super';
      const result = panoInsuranceUtil.isBTSFLMember(account);
      expect(result).toBe(false);
    });
  });

  describe('isSuperMember', () => {
    let account: Account;
    beforeEach(() => {
      account = MOCK_ACCOUNT;
    });

    it('should return true for BT Super', () => {
      account.productDescription = 'BT Super';
      const result = panoInsuranceUtil.isBTSuperMember(account);
      expect(result).toBe(true);
    });

    it('should return false not BT Super', () => {
      account.productDescription = 'BT Super for Life';
      const result = panoInsuranceUtil.isBTSuperMember(account);
      expect(result).toBe(false);
    });
  });

  describe('getDeathAssociatedTPDPolicies', () => {
    it('should return policies if policy type is TPD, insurance associatedTpd includes policy coverSubTypeId and both insurance and policy status are not Active^ or request received', () => {
      const visiblePolicies = [MOCK_ALL_POLICIES[1], MOCK_ALL_POLICIES[2]];
      const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[0];

      const result = panoInsuranceUtil.getDeathAssociatedTPDPolicies(visiblePolicies, insurance);

      expect(result.length).toBeGreaterThan(0);
    });

    it('should not return policies if policy associatedTpd is empty', () => {
      const visiblePolicies = [MOCK_ALL_POLICIES[1], MOCK_ALL_POLICIES[2]];
      const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[1];

      const result = panoInsuranceUtil.getDeathAssociatedTPDPolicies(visiblePolicies, insurance);

      expect(result.length).toBe(0);
    });

    it('should not return policies if associated policy status is Active^ or request received', () => {
      const visiblePolicies = [MOCK_ALL_POLICIES[1], MOCK_ALL_POLICIES[8]];
      const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[0];

      const result = panoInsuranceUtil.getDeathAssociatedTPDPolicies(visiblePolicies, insurance);

      expect(result.length).toBe(0);
    });
  });

  describe('isPolicyAvailableForInsuranceTable', () => {
    it('should return true when policy is inactive and endDate is at end of the month', () => {
      const showPolicy = panoInsuranceUtil.isPolicyAvailableForInsuranceTable(MOCK_ALL_POLICIES[3]);
      expect(showPolicy).toBeTruthy();
    });

    it('should return true when policy is active and endDate is null and days since commencement is gt zero', () => {
      spyOn(panoInsuranceUtil, 'getDaysSince').and.returnValue(40);
      const showPolicy = panoInsuranceUtil.isPolicyAvailableForInsuranceTable(MOCK_ALL_POLICIES[2]);
      expect(showPolicy).toBeTruthy();
    });

    it('should return false when policy is active and endDate is null and start date is in the future', () => {
      const showPolicy = panoInsuranceUtil.isPolicyAvailableForInsuranceTable(MOCK_ALL_POLICIES[6]);
      expect(showPolicy).toBeFalsy();
    });

    it('should return true when policy is pending and endDate is null', () => {
      const showPolicy = panoInsuranceUtil.isPolicyAvailableForInsuranceTable(MOCK_ALL_POLICIES[1]);
      expect(showPolicy).toBeTruthy();
    });

    it('should return false when none of the condition is satisfied', () => {
      const showPolicy = panoInsuranceUtil.isPolicyAvailableForInsuranceTable(MOCK_ALL_POLICIES[0]);
      expect(showPolicy).toBeFalsy();
    });

    it('should return true when policy is not active', () => {
      const showPolicy = panoInsuranceUtil.isPolicyAvailableForInsuranceTable(MOCK_ALL_POLICIES[4]);
      expect(showPolicy).toBeTruthy();
    });

    it('should return true when policy is request received', () => {
      const showPolicy = panoInsuranceUtil.isPolicyAvailableForInsuranceTable(MOCK_ALL_POLICIES[5]);
      expect(showPolicy).toBeTruthy();
    });
  });

  describe('isEndOfTheMonth', () => {
    it('should set to true when the given date is at the end of the month', () => {
      expect(
        panoInsuranceUtil.isEndOfTheMonth(
          moment()
            .tz('Australia/Sydney')
            .endOf('month')
            .format()
        )
      ).toBeTruthy();
    });
  });
});
