import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Optionals } from '@bt/services/data';

export const AEM_TEXT_URL: string =
  '/content/secure/panorama/_services/learn-about-investments/ongoing-fees-text/_jcr_content.getAggr.getContentPage.json';

export const AEM_DATA_URL: string =
  '/content/secure/panorama/_services/learn-about-investments/ongoing-fees-table/_jcr_content.getAggr.getContentPage.json';

export const DEFAULT_COHORT: string = 'DEFAULT';

export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0344' };

export const INVESTOR_ACCOUNT_ERROR_STATE = 'app.investor.account.systemError';

export const DEFAULT_PAGE_LOADING: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const LEARN_ABOUT_INVESTMENTS_LINK: Link = {
  icon: {
    name: 'icon-chevron-left-circle-solid'
  },
  isLinkExternal: true,
  label: 'Learn about investments',
  link: '',
  openNewTab: false,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false
};

export const ACCORDION_HEADER_ICON: Icon = {
  name: 'icon-chevron-right-circle-outline',
  size: 'medium'
};

export const NEW_WINDOW_ICON: Icon = {
  name: 'icon-external-link',
  size: 'x-small',
  type: 'info'
};

export const MAX_COLLAPSED_WIDTH: number = 768;
