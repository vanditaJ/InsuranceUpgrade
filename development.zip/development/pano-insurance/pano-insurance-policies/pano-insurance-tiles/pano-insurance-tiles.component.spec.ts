import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { LayoutModule } from '@panorama/components/layout';

import { PanoInsuranceTilesComponent } from './pano-insurance-tiles.component';
import { INSURANCE_TILES } from './pano-insurance-tiles.constants';

describe('PanoInsuranceTilesComponent', () => {
  let component: PanoInsuranceTilesComponent;
  let fixture: ComponentFixture<PanoInsuranceTilesComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInsuranceTilesComponent],
        imports: [LayoutModule, RouterTestingModule],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsuranceTilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should set correct tiles data', () => {
      expect(component.tiles).toBe(INSURANCE_TILES);
    });
  });

  describe('Template', () => {
    it('3 tiles are present on the insurance screen', () => {
      expect(fixture.debugElement.queryAll(By.css('.js-card-insurance-content')).length).toBe(3);
    });

    describe('show icons', () => {
      let el;
      beforeEach(() => {
        el = fixture.debugElement.queryAll(By.css('.js-card-insurance-content-icon'));
      });
      it('should have Death cover icon', () => {
        expect(el[0].properties.config).toBe(INSURANCE_TILES[0].icon);
      });

      it('should have Total and Permanent Disablement (TPD) cover icon', () => {
        expect(el[1].properties.config).toBe(INSURANCE_TILES[1].icon);
      });

      it('should have Salary Continuance Insurance (SCI) icon', () => {
        expect(el[2].properties.config).toBe(INSURANCE_TILES[2].icon);
      });
    });

    describe('should adjust spacing for the content inside the info boxes', () => {
      it('should have the same css class for all the elements in mobile view', () => {
        const el = fixture.debugElement.queryAll(By.css('.hidden-lg'));
        expect(el[0].nativeElement.className).toContain('tile-heading');
        expect(el[1].nativeElement.className).toContain('tile-heading');
        expect(el[2].nativeElement.className).toContain('tile-heading');
      });

      it('should adjust css class accordindly for larger screens', () => {
        const el = fixture.debugElement.queryAll(By.css('.visible-lg'));
        expect(el[0].nativeElement.className).toContain('tile-heading-first-element');
        expect(el[1].nativeElement.className).toContain('tile-heading');
        expect(el[2].nativeElement.className).toContain('tile-heading');
      });
    });

    describe('show titles', () => {
      let el;
      beforeEach(() => {
        el = fixture.debugElement.queryAll(By.css('.js-card-insurance-content-title'));
      });

      it('should have Death cover title', () => {
        expect(el[0].nativeElement.innerHTML).toBe(INSURANCE_TILES[0].heading);
      });

      it('should have Total and Permanent Disablement (TPD) cover title', () => {
        expect(el[1].nativeElement.innerHTML).toBe(INSURANCE_TILES[1].heading);
      });

      it('should have Salary Continuance Insurance (SCI) title', () => {
        expect(el[2].nativeElement.innerHTML).toBe(INSURANCE_TILES[2].heading);
      });
    });

    describe('show description', () => {
      let el;
      beforeEach(() => {
        el = fixture.debugElement.queryAll(By.css('p'));
      });

      it('should have Death cover description', () => {
        expect(el[0].nativeElement.innerHTML).toBe(INSURANCE_TILES[0].description);
      });

      it('should have Total and Permanent Disablement (TPD) cover description', () => {
        expect(el[1].nativeElement.innerHTML).toBe(INSURANCE_TILES[1].description);
      });

      it('should have Salary Continuance Insurance (SCI) description', () => {
        expect(el[2].nativeElement.innerHTML).toBe(INSURANCE_TILES[2].description);
      });
    });
  });
});
