import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

import { CLOSE_ICON_BUTTON, CLOSE_TEXT_BUTTON, EXCLUSIONS_HEADER } from '../pano-change-cover-options.constants';

import { PanoContentDialogComponent } from './pano-content-dialog.component';

describe('PanoContentDialogComponent', () => {
  let component: PanoContentDialogComponent;
  let fixture: ComponentFixture<PanoContentDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [MatDialogModule],
        declarations: [PanoContentDialogComponent],
        providers: [
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          {
            provide: MAT_DIALOG_DATA,
            useValue: {
              headerText: EXCLUSIONS_HEADER,
              descriptionText: 'Sample text',
              closeButton: CLOSE_TEXT_BUTTON,
              closeIcon: CLOSE_ICON_BUTTON
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [PanoContentDialogComponent]
        }
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoContentDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('closeDialog()', () => {
      it('should close dialog', () => {
        component.closeDialog();

        expect(component.dialogRef.close).toHaveBeenCalled();
      });
    });
  });

  describe('view', () => {
    it('should have header if data.headerText exists', () => {
      expect(fixture.debugElement.query(By.css('h1'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.ts-header')).nativeElement.innerHTML).toMatch(EXCLUSIONS_HEADER);
    });

    it('should not have header if data.headerText is empty', () => {
      component.data.headerText = '';
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.ts-header'))).toBeFalsy();
    });

    it('should have description if data.descriptionText exists', () => {
      expect(fixture.debugElement.query(By.css('.ts-body')).nativeElement.innerHTML).toContain('Sample text');
    });

    it('should not have description if data.descriptionText is empty', () => {
      component.data.descriptionText = '';
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.ts-body'))).toBeFalsy();
    });

    it('should have main close button if data.closeButton exists', () => {
      expect(fixture.debugElement.query(By.css('.ts-close')).properties.config).toEqual(CLOSE_TEXT_BUTTON);

      fixture.debugElement.query(By.css('.ts-close')).nativeElement.dispatchEvent(new Event('btClick', null));
      expect(component.dialogRef.close).toHaveBeenCalled();
    });

    it('should not have main close button if data.closeButton is empty', () => {
      component.data.closeButton = null;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.ts-close'))).toBeFalsy();
    });

    it('should have close button with X icon if data.closeIcon exists', () => {
      expect(fixture.debugElement.query(By.css('.ts-close-icon')).properties.config).toEqual(CLOSE_ICON_BUTTON);

      fixture.debugElement.query(By.css('.ts-close-icon')).nativeElement.dispatchEvent(new Event('btClick', null));
      expect(component.dialogRef.close).toHaveBeenCalled();
    });

    it('should not have close button with X icon if data.closeIcon is empty', () => {
      component.data.closeIcon = null;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.ts-close-icon'))).toBeFalsy();
    });
  });
});
