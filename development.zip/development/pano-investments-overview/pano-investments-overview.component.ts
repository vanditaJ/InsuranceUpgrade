import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoUpgradePermissionService, StateParams } from '@upgrade/upgrade.services';
import { find, map } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of } from 'rxjs';
import { Subscription } from 'rxjs/internal/Subscription';
import { finalize, take } from 'rxjs/operators';

import { PanoInvestmentOverviewInfoDialogComponent } from './pano-investment-overview-info-dialoq/pano-investment-overview-info-dialog.component';
import { PanoInvestmentsOverviewVideoModalComponent } from './pano-investments-overview-video-modal/pano-investments-overview-video-modal.component';
import {
  CHANGE_INVESTMENT_STRATEGY_BUTTON,
  CMS_CONTENT_KEYS,
  CMS_ROR_KEYS,
  DEFAULT_PAGE_LOADING,
  DIY_INVESTMENTS_LINK,
  HOW_ARE_THESE_CALCULATED_BUTTON,
  INVESTMENTS_BUTTON_LINK,
  INVESTMENT_OPTIONS_SHOW_ROR_FEATURE,
  LIFE_STAGE_FUND,
  NEW_WINDOW_ICON,
  OVERVIEW_PAGE_BUTTON,
  SIMPLE_INVESTMENTS_LINK,
  VIDEO_MODAL_DIALOG_CONFIG
} from './pano-investments-overview.constants';
import {
  CmsContent,
  ContentItem,
  Investment,
  InvestmentAllocation,
  Investments,
  PersonalRateOfReturn
} from './pano-investments-overview.interface';
import { PanoInvestmentsOverviewService } from './pano-investments-overview.service';

@Component({
  selector: 'pano-investments-overview',
  templateUrl: './pano-investments-overview.component.html',
  styleUrls: ['./pano-investments-overview.component.scss']
})
export class PanoInvestmentsOverviewComponent implements OnInit {
  constructor(
    private investmentsOverviewService: PanoInvestmentsOverviewService,
    private sharedDisclaimerService: PanoDisclaimersService,
    private stateParams: StateParams,
    private sanitizer: DomSanitizer,
    private readonly dialog: MatDialog,
    private permissionService: PanoUpgradePermissionService
  ) {}
  @Input()
  account: Account;
  investment: Investment;

  showRorPermission: false;

  happy: string = 'unanswered';

  videoModalSubscription: Subscription = of(null).subscribe();

  disclaimer: string;
  date: moment;

  loading: boolean = true;
  personalReturnLoading: boolean = true;
  commonCmsContentLoading: boolean = true;
  assetCmsContentLoading: boolean = true;
  australianTopTenCmsContentLoading: boolean = true;
  australianSectorWeightsLoading: boolean = true;
  internationalTopTenLoading: boolean = true;
  internationalRegionWeightsLoading: boolean = true;

  showError: boolean = false;
  emulating: boolean = false;

  personalRateOfReturn: PersonalRateOfReturn;

  cmsContentKeys: Array<string> = CMS_CONTENT_KEYS;
  cmsContent: Array<any> = [];
  australianTopTenShares: InvestmentAllocation[] = [];
  australianSectorWeights: InvestmentAllocation[] = [];
  internationalTopTenShares: InvestmentAllocation[] = [];
  internationalRegionWeights: InvestmentAllocation[] = [];

  readonly simpleInvestmentsLink: Link = SIMPLE_INVESTMENTS_LINK;
  readonly diyInvestmentsLink: Link = DIY_INVESTMENTS_LINK;
  readonly howAreTheseCalculatedButton: Button = HOW_ARE_THESE_CALCULATED_BUTTON;
  readonly investmentsButtonLink: Button = INVESTMENTS_BUTTON_LINK;
  readonly loadingSpinner: Loading = DEFAULT_PAGE_LOADING;
  readonly changeInvestmentStrategyButton: Button = CHANGE_INVESTMENT_STRATEGY_BUTTON;
  readonly overviewPageButton: Button = OVERVIEW_PAGE_BUTTON;
  readonly newWindowIcon: Icon = NEW_WINDOW_ICON;

  ngOnInit(): void {
    this.showRorPermission = this.permissionService.hasPermission(
      INVESTMENT_OPTIONS_SHOW_ROR_FEATURE,
      this.stateParams.accountId
    );
    this.date = moment(new Date()).format('D MMM YYYY');
    this.disclaimer = this.sharedDisclaimerService.evaluateDisclaimer(this.account);

    this.getCurrentInvestment();
    this.emulating = this.permissionService.hasPermission('emulating', 'base');

    this.diyInvestmentsLink.link = this.cmsContent[CMS_CONTENT_KEYS.fullInvestmentLink]
      ? this.cmsContent[CMS_CONTENT_KEYS.fullInvestmentLink]
      : 'https://www.bt.com.au/personal/superannuation/super-investments/investment-options.html';
    this.simpleInvestmentsLink.link = this.cmsContent[CMS_CONTENT_KEYS.simpleInvestmentLink]
      ? this.cmsContent[CMS_CONTENT_KEYS.simpleInvestmentLink]
      : 'https://www.bt.com.au/personal/superannuation/super-investments/investment-options/explore-simple-investment-menu.html';
  }

  public showRorCalculationInfoDialog(): void {
    this.howAreTheseCalculatedClicked();
    this.dialog.open(PanoInvestmentOverviewInfoDialogComponent, {
      ariaLabelledBy: 'More information on how rate of return numbers are calculated',
      autoFocus: true,
      ...DIALOG_CONFIG.DEFAULT,
      data: {
        headerText: this.cmsContent[CMS_ROR_KEYS.HOW_ROR_CALCULATED_HEADING],
        bodyText: this.cmsContent[CMS_ROR_KEYS.HOW_ROR_CALCULATED_BODY]
      }
    });
  }

  private getCurrentInvestment() {
    this.investmentsOverviewService
      .getCurrentInvestments(this.stateParams.accountId)
      .pipe(take(1))
      .subscribe((investments: Investments) => {
        const fullyAllocatedLifestageInvestment = find(
          investments.investments,
          (investment: Investment) =>
            investment.allocationPercentage === 100 &&
            investment.balance > 0 &&
            investment.fundName.includes(LIFE_STAGE_FUND)
        );

        if (fullyAllocatedLifestageInvestment) {
          this.investment = fullyAllocatedLifestageInvestment;

          this.getCommonCmsContent();
          this.getAssetSpecificCmsContent();
          this.getPersonalRateOfReturn();
        }
      });
  }

  private getPersonalRateOfReturn() {
    const endDate: Date = moment()
      .tz('Australia/Sydney')
      .subtract(1, 'd');
    const startDate: Date = moment()
      .tz('Australia/Sydney')
      .subtract(12, 'M');

    this.investmentsOverviewService
      .getPersonalRateOfReturn(this.stateParams.accountId, this.investment.apirCode, startDate, endDate)
      .pipe(
        take(1),
        finalize(() => {
          this.personalReturnLoading = false;
          this.isLoading();
        })
      )
      .subscribe((personalRateOfReturnData: PersonalRateOfReturn) =>
        this.setPersonalRateOfReturn(personalRateOfReturnData)
      );
  }

  private setPersonalRateOfReturn(personalRateOfReturnData: PersonalRateOfReturn) {
    this.personalRateOfReturn = personalRateOfReturnData;
    this.personalRateOfReturn.startDate = moment(new Date(personalRateOfReturnData.startDate)).format('DD MMM YYYY');
    this.personalRateOfReturn.endDate = moment(new Date(personalRateOfReturnData.endDate)).format('DD MMM YYYY');
  }

  private getCommonCmsContent() {
    this.investmentsOverviewService
      .getCommonCmsContent()
      .pipe(
        take(1),
        finalize(() => {
          this.commonCmsContentLoading = false;
          this.isLoading();
        })
      )
      .subscribe((cmsContent: CmsContent) => this.updateCmsContent(cmsContent));
  }

  private getAssetSpecificCmsContent() {
    this.investmentsOverviewService
      .getAssetSpecificCmsContent(this.investment.apirCode)
      .pipe(
        take(1),
        finalize(() => {
          this.assetCmsContentLoading = false;
          this.isLoading();
        })
      )
      .subscribe((cmsContent: CmsContent) => this.updateCmsContent(cmsContent));

    this.subscribeToAllocationContent(
      this,
      'getAustralianSharesTopTenCmsContent',
      'australianTopTenCmsContentLoading',
      'australianTopTenShares'
    );
    this.subscribeToAllocationContent(
      this,
      'getAustralianSectorWeights',
      'australianSectorWeightsLoading',
      'australianSectorWeights'
    );
    this.subscribeToAllocationContent(
      this,
      'getInternationalTopTen',
      'internationalTopTenLoading',
      'internationalTopTenShares'
    );
    this.subscribeToAllocationContent(
      this,
      'getInternationalRegionWeights',
      'internationalRegionWeightsLoading',
      'internationalRegionWeights'
    );
  }

  private subscribeToAllocationContent(ref, observableFunction: string, loadingFlag: string, allocations: string) {
    this.investmentsOverviewService[observableFunction](this.investment.apirCode)
      .pipe(
        take(1),
        finalize(() => {
          ref[loadingFlag] = false;
          ref.isLoading();
        })
      )
      .subscribe((investmentAllocations: InvestmentAllocation[]) => (ref[allocations] = investmentAllocations));
  }

  private updateCmsContent(cmsContent: CmsContent) {
    map(cmsContent.details, (contentItem: ContentItem) => {
      if (
        contentItem.data.headerText === CMS_CONTENT_KEYS.whereYourMoneyIsInvestedPanelImage ||
        contentItem.data.headerText === CMS_CONTENT_KEYS.whereYourMoneyIsInvestedOverallTabContent ||
        contentItem.data.headerText === CMS_CONTENT_KEYS.videoIframe ||
        contentItem.data.headerText === CMS_CONTENT_KEYS.fundName
      ) {
        const temp: HTMLDivElement = document.createElement('div');
        temp.innerHTML = contentItem.data.description.replace(/<p[^>]*>/g, '').replace(/<\/p>/g, '');
        this.cmsContent[contentItem.data.headerText] = this.sanitizer.bypassSecurityTrustHtml(
          temp.childNodes[0].nodeValue
        );
        if (contentItem.data.headerText === CMS_CONTENT_KEYS.videoIframe) {
          const iframeTemp: HTMLDivElement = document.createElement('div');
          iframeTemp.innerHTML = contentItem.data.description
            .replace(/<p[^>]*>/g, '')
            .replace(/<\/p>/g, '')
            .replace(/height[^\s]+/, 'height="400"');
          this.cmsContent[contentItem.data.headerText + 'Modal'] = this.sanitizer.bypassSecurityTrustHtml(
            iframeTemp.childNodes[0].nodeValue
          );
        }
      } else if (contentItem.data.headerText === CMS_CONTENT_KEYS.performanceRate1WGPValue && this.isWgpAccount()) {
        this.cmsContent[CMS_CONTENT_KEYS.performanceRate1Value] = contentItem.data.description;
      } else if (contentItem.data.headerText === CMS_CONTENT_KEYS.performanceRate2WGPValue && this.isWgpAccount()) {
        this.cmsContent[CMS_CONTENT_KEYS.performanceRate2Value] = contentItem.data.description;
      } else if (
        contentItem.data.headerText === CMS_ROR_KEYS.HOW_ROR_CALCULATED_HEADING ||
        contentItem.data.headerText === CMS_ROR_KEYS.HOW_ROR_CALCULATED_BODY
      ) {
        this.cmsContent[contentItem.data.headerText] = contentItem.data.description;
      } else {
        this.cmsContent[contentItem.data.headerText] = this.sanitizer.bypassSecurityTrustHtml(
          contentItem.data.description
        );
      }
    });
  }

  private isLoading(): void {
    this.loading =
      this.personalReturnLoading ||
      this.commonCmsContentLoading ||
      this.assetCmsContentLoading ||
      this.australianTopTenCmsContentLoading ||
      this.australianSectorWeightsLoading ||
      this.internationalTopTenLoading ||
      this.internationalRegionWeightsLoading;
  }

  private isWgpAccount(): boolean {
    return this.account.pdsStatus === 'WGP_CEASED' || this.account.pdsStatus === 'WGP_CURRENT';
  }

  navigateToChangeInvestments(): void {
    this.investmentsOverviewService.navigateAndLog(
      'app.investor.account.changeInvestments.investmentForm',
      { addNew: true },
      'clicked: change investment strategy',
      this.happy,
      this.investment.apirCode,
      this.account.accountNumber,
      this.emulating
    );
  }

  navigateAndLog(linkClicked: string): void {
    let state = 'app.investor.account.investments';
    if (linkClicked.includes('overview')) {
      state = 'app.investor.account.overview';
    }
    this.investmentsOverviewService.navigateAndLog(
      state,
      {},
      'clicked: ' + linkClicked,
      this.happy,
      this.investment.apirCode,
      this.account.accountNumber,
      this.emulating
    );
  }

  exploreInvestmentOptions(investmentOption: string): void {
    this.investmentsOverviewService.logActivity(
      'none',
      'clicked: investment option: ' + investmentOption,
      this.happy,
      this.investment.apirCode,
      this.account.accountNumber,
      this.emulating
    );
  }

  howAreTheseCalculatedClicked(): void {
    this.investmentsOverviewService.logActivity(
      'none',
      'clicked: how are these calculated',
      this.happy,
      this.investment.apirCode,
      this.account.accountNumber,
      this.emulating
    );
  }

  showVideoModal(): void {
    this.videoModalSubscription = this.dialog
      .open(PanoInvestmentsOverviewVideoModalComponent, {
        ...VIDEO_MODAL_DIALOG_CONFIG,
        data: {
          content: this.cmsContent[CMS_CONTENT_KEYS.videoIframe + 'Modal'],
          heading: this.cmsContent[CMS_CONTENT_KEYS.videoHeading]
        }
      })
      .afterClosed()
      .subscribe(() =>
        this.investmentsOverviewService.logActivity(
          'none',
          'clicked: close video',
          this.happy,
          this.investment?.apirCode,
          this.account.accountNumber,
          this.emulating
        )
      );
  }
}
