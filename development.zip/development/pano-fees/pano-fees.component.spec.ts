import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Link } from '@bt/components/link';
import { DataModule, DataService } from '@bt/services/data';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PipeModule } from '@investor/account/pano-shared/pipes/pipe.module';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { PanoUpgradePermissionService, StateParams } from '@upgrade/upgrade.services';
import { of, throwError } from 'rxjs';

import { PanoFeesComponent } from './pano-fees.component';
import {
  BTSFL_RETAIL_ACCOUNT,
  BTSLF_WGP_LEGACY_LSEP_ACCOUNT,
  BTSLF_WGP_OPEN_ACCOUNT,
  MOCK_ACCOUNT_ID,
  MOCK_AEM_CONTENT_TEST,
  TEST_LINK
} from './pano-fees.component.spec.constants';
import { AEM_CONTENT_URL, GENERIC_OPTIONS } from './pano-fees.constants';
import { PanoFeesService } from './pano-fees.service';

describe('PanoFees', () => {
  let component: PanoFeesComponent;
  let fixture: ComponentFixture<PanoFeesComponent>;
  let service: PanoFeesService;
  let disclaimerService: PanoDisclaimersService;
  let linkService: PanoSuperLinkService;

  const dataService = {
    retrieve: jasmine.createSpy().and.returnValue(
      of({
        details: []
      })
    )
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoFeesComponent],
        imports: [DataModule, HttpClientTestingModule, PipeModule],
        providers: [
          {
            provide: DataService,
            useValue: dataService
          },
          PanoFeesService,
          PanoDisclaimersService,
          {
            provide: PanoUpgradePermissionService,
            useValue: { hasPermission: jasmine.createSpy() }
          },
          PanoSuperLinkService,
          {
            provide: StateParams,
            useValue: {
              accountId: MOCK_ACCOUNT_ID
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoFeesComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(PanoFeesService);
    disclaimerService = TestBed.inject(PanoDisclaimersService);
    spyOn(disclaimerService, 'evaluateDisclaimer').and.returnValue('disclaimer');
    linkService = TestBed.inject(PanoSuperLinkService);

    spyOn(linkService, 'getUrl').and.returnValue('url');
    spyOn(linkService, 'getLinks').and.returnValue([TEST_LINK as Link]);
  });

  function initWithAccount(account: Partial<Account>, throwServiceError: boolean) {
    if (throwServiceError) {
      spyOn(service, 'getAemContent').and.returnValue(throwError('error'));
    } else {
      spyOn(service, 'getAemContent').and.returnValue(of(MOCK_AEM_CONTENT_TEST));
    }
    component.account = account as Account;
    component.ngOnInit();
    fixture.detectChanges();
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Component', () => {
    it('should populate date and disclaimer', () => {
      initWithAccount(BTSFL_RETAIL_ACCOUNT, false);

      expect(component.date).toBeTruthy();
      expect(component.disclaimer).toBeTruthy();
    });

    it('should correctly configure tooltips', () => {
      initWithAccount(BTSFL_RETAIL_ACCOUNT, false);

      expect(component.adminFeeTooltip.message).toContain(
        'Administration fee is a fee that relates to the administration or operation of a superannuation entity'
      );
      expect(component.investmentFeeTooltip.message).toContain(
        'Investment fee is the cost of managing the investments within your chosen investment option.'
      );
      expect(component.indirectCostRatioTooltip.message).toContain(
        'Indirect cost ratio is the ratio of the total of the indirect costs to the total average'
      );
      expect(component.buySellSpreadTooltip.message).toContain(
        'A Buy-sell spread is a fee to recover transaction costs incurred by the trustee'
      );
    });

    describe('should correctly configure links', () => {
      beforeEach(() => {
        initWithAccount(BTSFL_RETAIL_ACCOUNT, false);
      });

      it('should populate references links', () => {
        expect(component.navigationLinks).toEqual([TEST_LINK as Link]);
      });

      it('populate the manual links', () => {
        expect(component.ongoingFeesLinkNoIcon.link).toEqual('url');
        expect(component.buySellSpreadLinkNoIcon.link).toEqual('url');
      });
    });
  });

  describe('Service', () => {
    beforeEach(() => {
      dataService.retrieve.calls.reset();
      dataService.retrieve.and.returnValue(
        of({
          details: [
            {
              type: 'title_text_link',
              id: 'general',
              data: {
                headerText: 'headerText',
                description: '\u003cp\u003eheaderText\u003c/p\u003e\r\n'
              }
            }
          ]
        })
      );
    });

    it('should load the text from aem', () => {
      service.getAemContent();
      expect(dataService.retrieve).toHaveBeenCalledWith(AEM_CONTENT_URL, GENERIC_OPTIONS);
    });
  });

  describe('View', () => {
    it('should have disclaimer', () => {
      initWithAccount(BTSFL_RETAIL_ACCOUNT, false);

      expect(fixture.debugElement.query(By.css('.ts-test-date-disclaimer'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.ts-test-cohort-disclaimer'))).toBeTruthy();
    });

    it('should display error alert if there is an error', () => {
      initWithAccount(BTSFL_RETAIL_ACCOUNT, true);

      expect(fixture.debugElement.query(By.css('.ts-test-error-alert'))).toBeTruthy();
    });

    describe('Fees section', () => {
      it('should have heading, introduction and table', () => {
        initWithAccount(BTSFL_RETAIL_ACCOUNT, false);

        expect(fixture.debugElement.query(By.css('.ts-test-fees-title'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.ts-test-fees-intro')).nativeElement.innerText).toContain(
          'This table is a summary of the fees that you may be charged'
        );
        expect(fixture.debugElement.query(By.css('.ts-test-fees-table'))).toBeTruthy();
      });

      it('should have tooltips', () => {
        initWithAccount(BTSFL_RETAIL_ACCOUNT, false);

        expect(fixture.debugElement.query(By.css('.ts-test-admin-fee-tooltip'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.ts-test-investment-fee-tooltip'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.ts-test-indirect-cost-ratio-tooltip'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.ts-test-buy-sell-spreads-tooltip'))).toBeTruthy();
      });

      it('table should have correct content', () => {
        initWithAccount(BTSFL_RETAIL_ACCOUNT, false);

        expect(fixture.debugElement.query(By.css('.ts-test-you-pay-admin-fee')).nativeElement.innerText).toContain(
          'A flat fee of $9.00 per month is deducted from your account balance'
        );
        expect(fixture.debugElement.query(By.css('.ts-test-you-pay-investment-fee')).nativeElement.innerText).toContain(
          'Between 0.10% and 1.38% paper annum depending on your investment option'
        );
        expect(
          fixture.debugElement.query(By.css('.ts-test-you-pay-indirect-cost-ratio')).nativeElement.innerText
        ).toContain('Between 0.05% and 0.49% paper annum depending on your investment option');
        expect(fixture.debugElement.query(By.css('.ts-test-you-pay-buy-sell-spreads')).nativeElement.innerText).toEqual(
          'Between 0% and 0.60% paper annum depending on your investment option'
        );
      });

      describe('How you will be charged information should display correctly based on account type', () => {
        it('BTSFL non-WGP accounts should see ongoing fees and buy sell spread information only', () => {
          initWithAccount(BTSFL_RETAIL_ACCOUNT, false);

          expect(fixture.debugElement.query(By.css('.ts-test-fees-ongoing-fees-info'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-lifestage-investment-info'))).toBeNull();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-legacy-fee-info'))).toBeNull();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-buy-sell-info'))).toBeTruthy();
        });

        it('non-legacy cohort (e.g. OPEN) WGP accounts should see ongoing fees, lifestage investment and buy sell spread information only', () => {
          initWithAccount(BTSLF_WGP_OPEN_ACCOUNT, false);

          expect(fixture.debugElement.query(By.css('.ts-test-fees-ongoing-fees-info'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-lifestage-investment-info'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-legacy-fee-info'))).toBeNull();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-buy-sell-info'))).toBeTruthy();
        });

        it('legacy cohort (e.g. PLUM) WGP accounts should see ongoing fees, lifestage investment, legacy fee and buy sell spread information', () => {
          initWithAccount(BTSLF_WGP_LEGACY_LSEP_ACCOUNT, false);

          expect(fixture.debugElement.query(By.css('.ts-test-fees-ongoing-fees-info'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-lifestage-investment-info'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-legacy-fee-info'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.ts-test-fees-buy-sell-info'))).toBeTruthy();
        });
      });
    });

    describe('Example of annual fees and costs section', () => {
      beforeEach(() => {
        initWithAccount(BTSFL_RETAIL_ACCOUNT, false);
      });

      it('should have heading, introduction, table and additional info', () => {
        expect(fixture.debugElement.query(By.css('.ts-test-example-fees-title'))).toBeTruthy();
        expect(
          fixture.debugElement.query(By.css('.ts-test-example-fees-description')).nativeElement.innerText
        ).toContain(
          'This table gives an example of how the fees and costs for the 1980s BT Lifestage investment option'
        );
        expect(fixture.debugElement.query(By.css('.ts-test-example-fees-table'))).toBeTruthy();
        expect(
          fixture.debugElement.query(By.css('.ts-test-example-fees-additional-info')).nativeElement.innerText
        ).toContain('Estimated indirect costs above include an estimated Regulatory Change Expense Recovery ');
      });

      it('table should have correct content', () => {
        expect(fixture.debugElement.query(By.css('.ts-test-rate-admin-fee')).nativeElement.innerText).toContain(
          '$9.00 per month ($108 paper annum)'
        );
        expect(fixture.debugElement.query(By.css('.ts-test-charge-admin-fee')).nativeElement.innerText).toContain(
          'You will be charged $108 each year regardless of your balance'
        );

        expect(fixture.debugElement.query(By.css('.ts-test-rate-investment-fee')).nativeElement.innerText).toEqual(
          '0.50% paper annum'
        );
        expect(fixture.debugElement.query(By.css('.ts-test-charge-investment-fee')).nativeElement.innerText).toEqual(
          '$250 each year will be deducted from your investment'
        );

        expect(fixture.debugElement.query(By.css('.ts-test-rate-indirect-cost-ratio')).nativeElement.innerText).toEqual(
          '0.15% paper annum'
        );
        expect(
          fixture.debugElement.query(By.css('.ts-test-charge-indirect-cost-ratio')).nativeElement.innerText
        ).toContain('Indirect costs of $75 each year will be deducted from your investment');

        expect(fixture.debugElement.query(By.css('.ts-test-rate-total-cost')).nativeElement.innerText).toContain(
          '$9.00 per month'
        );
        expect(fixture.debugElement.query(By.css('.ts-test-charge-total-cost')).nativeElement.innerText).toContain(
          'you will be charged fees of $573'
        );
      });
    });

    describe('Related information section', () => {
      beforeEach(() => {
        initWithAccount(BTSFL_RETAIL_ACCOUNT, false);
      });

      it('should render related information', () => {
        const links = fixture.debugElement.queryAll(By.css('.ts-test-related-info-link'));
        expect(links[0]).toBeTruthy();
      });
    });
  });
});
