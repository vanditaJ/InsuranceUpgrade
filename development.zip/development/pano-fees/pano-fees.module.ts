import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatListModule } from '@angular/material/list';
import { AlertModule } from '@bt/components/alert';
import { IconModule } from '@bt/components/icon';
import { LinkModule } from '@bt/components/link';
import { LoadingModule } from '@bt/components/loading';
import { TooltipModule } from '@bt/components/tooltip';
import { PipeModule } from '@investor/account/pano-shared/pipes/pipe.module';
import { panoAccountResolver } from '@investor/account/pano-shared/resolvers';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';

import { PanoFeesComponent } from './pano-fees.component';
import { PanoFeesService } from './pano-fees.service';

@NgModule({
  declarations: [PanoFeesComponent],
  providers: [PanoFeesService],
  entryComponents: [],
  imports: [
    LayoutModule,
    CommonModule,
    LinkModule,
    LoadingModule,
    IconModule,
    TooltipModule,
    PipeModule,
    AlertModule,
    MatListModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.composerFees',
          url: '/pano-fees',
          component: PanoFeesComponent,
          data: {
            title: 'Fees',
            requiredPermissions: {
              rule: 'account.fees.v1.view',
              targetId: 'a'
            }
          },
          resolve: {
            account: ['$transition$', panoAccountResolver]
          }
        }
      ]
    }),
    PipeModule
  ]
})
export class PanoFeesModule {}
