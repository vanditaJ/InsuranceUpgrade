import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';
import * as moment from 'moment-timezone';

import { InsurancePolicy, PersonBenefitDetails, PolicyStatus, PolicyType } from '../pano-insurance.interface';

export const PERSONAL_BENEFIT_DETAILS: PersonBenefitDetails[] = [
  {
    benefits: [
      {
        benefitPeriodTerm: '4',
        waitingPeriod: '1',
        benefitPeriodFactor: 'years',
        benefits: [
          {
            frequency: 'MONTHLY',
            occupationClass: 'Blue Collar'
          }
        ]
      }
    ]
  }
];

export const POLICIES: Array<InsurancePolicy> = [
  {
    policyNumber: '5273590',
    coverSubTypeId: 21,
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Income Protection',
    sumInsured: 3434634,
    premium: '43635',
    commencementDate: '2020-02-11',
    status: PolicyStatus.ACTIVE,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    qualifierName: 'Standard cover',
    coverLevel: 'Triple',
    ageNextBirthday: 50,
    newCoverType: null,
    customised: null,
    customerType: 'Retail',
    employerFunded: false,
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS
  },
  {
    policyNumber: '5273591',
    coverSubTypeId: 21,
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Income Protection',
    sumInsured: 3434634,
    premium: '43635',
    commencementDate: '2020-02-11',
    status: PolicyStatus.PENDING,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    qualifierName: 'Standard cover',
    coverLevel: 'Triple',
    ageNextBirthday: 50,
    newCoverType: null,
    customised: null,
    customerType: 'Retail',
    employerFunded: false,
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS
  },
  {
    policyNumber: '5273592',
    coverSubTypeId: 21,
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    sumInsured: 3434634,
    premium: '58996',
    commencementDate: '11-02-2020',
    status: PolicyStatus.ACTIVE,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    qualifierName: 'Standard cover',
    coverLevel: 'Single',
    ageNextBirthday: 50,
    newCoverType: null,
    customised: null,
    customerType: 'Retail',
    employerFunded: true,
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS
  },
  {
    policyNumber: '5273593',
    coverSubTypeId: 21,
    policyType: PolicyType.TPD,
    policyName: 'Total Permanent Disability/Disablement (TPD)',
    sumInsured: 64894116,
    premium: '156976',
    commencementDate: '11-02-2020',
    status: PolicyStatus.ACTIVE,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    qualifierName: 'Standard cover',
    coverLevel: 'Single',
    ageNextBirthday: 50,
    newCoverType: null,
    customised: null,
    customerType: 'Retail',
    employerFunded: true,
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS
  }
];

export const PARAMS = {
  policyNumber: '5273590',
  status: PolicyStatus.ACTIVE,
  currentStartDate: '2020-02-11'
};

export const DEATH_AND_TPD_INSURANCE_POLICY_NOT_ACTIVE: InsurancePolicy = {
  policyType: PolicyType.DEATH_AND_TPD,
  policyName: 'Death and Total Permanent Disability/Disablement (TPD)',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.NOT_ACTIVE,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Single',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const MOCK_AEM_CONTENT_CANCEL: AemContent[] = [
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'cancel_cover_review_useful_info_active',
      description: 'mock content for cancel_cover_review_useful_info_active'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'cancel_cover_review_confirm_check_active',
      description: 'mock content for cancel_cover_review_confirm_check_active'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'cancel_cover_review_useful_info_pending',
      description: 'mock content for cancel_cover_review_useful_info_pending'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'cancel_cover_review_confirm_check_pending',
      description: 'mock content for cancel_cover_review_confirm_check_pending'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'cancel_cover_confirm_useful_info_active',
      description: 'mock content for cancel_cover_confirm_useful_info_active'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'cancel_cover_confirm_useful_info_pending',
      description: 'mock content for cancel_cover_confirm_useful_info_pending'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'tpd_cancel_warning_death_tpd',
      description: 'mock content for tpd_cancel_warning_death_tpd'
    }
  }
];

export const MOCK_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2020-08-04T16:00:00.000Z',
  owners: [
    {
      age: 50,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Female',
      lastName: 'LastName'
    }
  ],
  pdsStatus: 'DEFAULT',
  product: {}
};

export const MOCK_CANCEL_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: moment().tz('Australia/Sydney'),
  owners: [
    {
      age: 12,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Female',
      lastName: 'LastName'
    }
  ],
  pdsStatus: 'WGP_CEASED',
  product: {}
};
