import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'perAnnumScreenReader' })
export class PerAnnumScreenReaderPipe implements PipeTransform {
  constructor() {}

  transform(content: string): string {
    const accessibleHTML = "<span aria-hidden='true'>pa</span><span class='sr-only'>per annum</span>";
    return content.replace(/\bpa\b/, accessibleHTML);
  }
}
