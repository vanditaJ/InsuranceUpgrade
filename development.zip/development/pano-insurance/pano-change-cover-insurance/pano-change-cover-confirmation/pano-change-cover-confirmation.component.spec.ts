import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { DataModule } from '@bt/services/data';
import { PageScrollService } from 'ngx-page-scroll-core';

import { PolicyStatus } from '../../pano-insurance.interface';
import { PanoInsuranceService } from '../../pano-insurance.service';
import { INSURANCE_POLICY } from '../../pano-insurance.service.spec.constants';
import { CoverMode } from '../pano-change-cover-insurance.interface';
import { NEW_COVER_TYPE } from '../pano-change-cover-review/pano-change-cover-review.component.spec.constants';
import { INSURANCE_POLICY_SCI } from '../pano-decrease-request-options/pano-decrease-request-options.component.spec.constants';

import { PanoChangeCoverConfirmationComponent } from './pano-change-cover-confirmation.component';
import { MOCK_AEM_CONTENT_CONFIRMATION } from './pano-change-cover-confirmation.component.spec.constants';
import { SUCCESS_DECREASE_REQUEST_COVER_ALERT } from './pano-change-cover-confirmation.constants';

describe('PanoChangeCoverConfirmationComponent', () => {
  let component: PanoChangeCoverConfirmationComponent;
  let fixture: ComponentFixture<PanoChangeCoverConfirmationComponent>;
  let insuranceService: PanoInsuranceService;
  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          AlertModule,
          ButtonModule,
          BrowserDynamicTestingModule,
          BrowserAnimationsModule,
          DataModule,
          RouterTestingModule,
          HttpClientTestingModule
        ],
        declarations: [PanoChangeCoverConfirmationComponent],
        providers: [
          { provide: PanoInsuranceService, useValue: { navigateToOverview: () => jasmine.createSpy() } },
          { provide: PageScrollService, useValue: pageScrollService }
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoChangeCoverConfirmationComponent);
    component = fixture.componentInstance;
    component.cmsContent = MOCK_AEM_CONTENT_CONFIRMATION;
    insuranceService = TestBed.inject(PanoInsuranceService);
  });

  describe('Component', () => {
    beforeEach(() => {
      component.insurance = INSURANCE_POLICY;
      component.newCoverType = NEW_COVER_TYPE;
      fixture.detectChanges();
    });

    describe('ngOnInit', () => {
      it('should create a correct termsAndCondition Form', () => {
        component.ngOnInit();

        const pageScrollOptions = {
          document: (component as any).document,
          scrollTarget: '.top-scroll',
          duration: 200
        };
        expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
      });

      it('should show decrease request confirmation success', () => {
        component.mode = CoverMode.DECREASE_REQUEST;

        component.ngOnInit();

        expect(component.successCoverAlert).toBe(SUCCESS_DECREASE_REQUEST_COVER_ALERT);
      });
    });

    describe('ngAfterViewInit', () => {
      it('asks parent to reset focus', () => {
        spyOn(component.resetFocus, 'emit');

        component.ngAfterViewInit();

        expect(component.resetFocus.emit).toHaveBeenCalled();
      });
    });

    describe('setAemMessages', () => {
      it('should populate correct messages when changing an active policy to increase cover', () => {
        component.mode = CoverMode.CHANGE;
        component.insurance.status = PolicyStatus.ACTIVE;
        component.isIncrease = true;

        component.setAemMessages();

        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CONFIRMATION[0].data.description);
      });

      it('should populate correct messages when changing an active policy to decrease cover', () => {
        component.mode = CoverMode.CHANGE;
        component.insurance.status = PolicyStatus.ACTIVE;
        component.isIncrease = false;

        component.setAemMessages();

        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CONFIRMATION[1].data.description);
      });

      it('should populate correct messages when changing a pending policy', () => {
        component.mode = CoverMode.CHANGE;
        component.insurance.status = PolicyStatus.PENDING;

        component.setAemMessages();

        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CONFIRMATION[2].data.description);
      });

      it('should populate correct messages when decreasing an active policy', () => {
        component.mode = CoverMode.DECREASE;
        component.insurance.status = PolicyStatus.ACTIVE;

        component.setAemMessages();

        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CONFIRMATION[3].data.description);
      });

      it('should populate correct messages when decreasing request', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insurance.status = PolicyStatus.ACTIVE;
        component.insurance.policyType = 'DEATH';

        component.setAemMessages();

        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CONFIRMATION[4].data.description);
      });

      it('should populate correct messages when decreasing request sci', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insurance.status = PolicyStatus.ACTIVE;
        component.insurance.policyType = 'INCOME_PROTECTION';

        component.setAemMessages();

        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CONFIRMATION[5].data.description);
      });
    });
  });

  describe('View', () => {
    describe('non SCI', () => {
      beforeEach(() => {
        component.insurance = INSURANCE_POLICY;
        component.newCoverType = NEW_COVER_TYPE;
        fixture.detectChanges();
      });

      it('should show all the details correctly', () => {
        const policyName = fixture.debugElement.query(By.css('.ts-new-cover-policy-name'));
        expect(policyName.nativeElement.innerText).toEqual('Death cover');

        const coverAmountNameEl = fixture.debugElement.query(By.css('.ts-new-cover-type-name'));
        expect(coverAmountNameEl.nativeElement.innerText).toEqual('Single cover');

        const newCoverAmountNameEl = fixture.debugElement.query(By.css('.ts-new-cover-amount-name'));
        expect(newCoverAmountNameEl.nativeElement.innerText).toEqual('Cover amount');
      });

      it('should not show premium if its field is not defined', () => {
        component.newCoverType.coverAmountType.premium = undefined;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.ts-new-cover-amount-premium'))).toBeFalsy();
        expect(fixture.debugElement.query(By.css('.ts-new-cover-amount-premium-name'))).toBeFalsy();
      });

      it('show show premium if its field is defined', () => {
        component.newCoverType.coverAmountType.premium = '4586';
        fixture.detectChanges();
        const newCoverAmountPremiumEl = fixture.debugElement.query(By.css('.ts-new-cover-amount-premium'));
        expect(newCoverAmountPremiumEl.nativeElement.innerText).toEqual('$4,586.00');
      });

      it('should show returnInsuranceOverview button', () => {
        const returnInsuranceButton = fixture.debugElement.query(By.css('bt-button'));
        expect(returnInsuranceButton).toBeTruthy();

        spyOn(insuranceService, 'navigateToOverview');
        returnInsuranceButton.triggerEventHandler('btClick', null);
        fixture.detectChanges();

        expect(insuranceService.navigateToOverview).toHaveBeenCalled();
      });
    });

    describe('for SCI Cover', () => {
      beforeEach(() => {
        component.insurance = INSURANCE_POLICY_SCI;
        component.newCoverType = NEW_COVER_TYPE;
        component.mode = CoverMode.DECREASE_REQUEST;
        fixture.detectChanges();
      });

      it('should show waiting period, benefit period and benefit amount', () => {
        const benefitAmountEl = fixture.debugElement.query(By.css('.ts-new-cover-amount-name'));
        const waitingPeriodEl = fixture.debugElement.query(By.css('.ts-insurance-waiting-period'));
        const benefitPeriodEl = fixture.debugElement.query(By.css('.ts-insurance-benefit-period'));

        expect(benefitAmountEl.nativeElement.innerText).toBe('Benefit amount');
        expect(waitingPeriodEl).toBeTruthy();
        expect(benefitPeriodEl).toBeTruthy();
      });
    });
  });
});
