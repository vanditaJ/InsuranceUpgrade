import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoCmsService } from '@panorama/services/cms';
import { PanoUpgradeAccountService, PanoUpgradeEnvService } from '@upgrade/upgrade.services';
import { of } from 'rxjs';

import { panoInsuranceContentResolver } from './pano-insurance-content.resolver';

describe('panoInsuranceContentResolver', () => {
  let accountServiceSpyObj: jasmine.SpyObj<PanoUpgradeAccountService>;
  let panoCMSServiceObj: jasmine.SpyObj<PanoCmsService>;
  let envServiceObj: jasmine.SpyObj<PanoUpgradeEnvService>;
  let transition;
  const getObj: any = { get: () => {} };

  beforeEach(() => {
    accountServiceSpyObj = jasmine.createSpyObj('PanoUpgradeAccountService', ['getAccountId', 'sessionStorage']);
    panoCMSServiceObj = jasmine.createSpyObj('PanoCmsService', ['getContent']);
    envServiceObj = jasmine.createSpyObj('PanoUpgradeEnvService', ['getEnv']);
    transition = {
      injector: () => getObj
    };
  });

  describe('panoInsuranceContentResolver', () => {
    let getSpy: jasmine.Spy;
    let accountId: string;
    let account: Account;
    let store;
    let mockContents;

    beforeEach(() => {
      getSpy = spyOn(getObj, 'get');
      getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
      getSpy.withArgs(PanoCmsService).and.returnValue(panoCMSServiceObj);
      getSpy.withArgs(PanoUpgradeEnvService).and.returnValue(envServiceObj);

      accountId = '1234';
      account = {
        accountNumber: '1234',
        accountName: 'account name',
        key: { accountId: 'DE03554AD' },
        pdsStatus: 'WGP_CEASED',
        firstMoneyReceivedDate: '2021-02-04T16:00:00.000Z',
        product: {},
        productDescription: 'BT Super'
      };
      store = {
        1234: JSON.stringify(account)
      };
      mockContents = {
        details: [
          {
            type: 'title_link',
            id: 'important-super-changes',
            data: {
              headerText: 'insurance_info',
              description: 'insurance_info'
            }
          },
          {
            type: 'title_link',
            id: 'important-super-changes',
            data: {
              headerText: 'cancel_cover_selection_useful_info',
              description: 'cancel_cover_selection_useful_info'
            }
          }
        ]
      };
    });

    it('calls cms service with correct parameters when cmsHost not available', async () => {
      spyOn(sessionStorage, 'getItem').and.callFake(key => {
        return store[key];
      });
      accountServiceSpyObj.getAccountId.and.returnValue(accountId);
      envServiceObj.getEnv.and.returnValue('');
      panoCMSServiceObj.getContent.and.returnValue(of(mockContents));

      const promise = panoInsuranceContentResolver(transition);
      const contents = await promise;

      expect(panoCMSServiceObj.getContent).toHaveBeenCalledWith('');
      expect(contents).toEqual(mockContents);
    });

    it('calls cms service with correct parameters when cmsHost is available', async () => {
      spyOn(sessionStorage, 'getItem').and.callFake(key => {
        return store[key];
      });
      accountServiceSpyObj.getAccountId.and.returnValue(accountId);
      envServiceObj.getEnv.and.returnValue({
        cmsHostForAem: 'cmsHost'
      });
      panoCMSServiceObj.getContent.and.returnValue(of(mockContents));

      const promise = panoInsuranceContentResolver(transition);
      const contents = await promise;

      expect(panoCMSServiceObj.getContent).toHaveBeenCalledWith('cmsHost');
      expect(contents).toEqual(mockContents);
    });
  });
});
