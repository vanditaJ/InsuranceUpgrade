import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { DataModule } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { PageScrollService } from 'ngx-page-scroll-core';

import { IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES } from '../../pano-insurance.constants.spec';
import { PanoInsuranceService } from '../../pano-insurance.service';
import { PanoInsuranceUtil } from '../../pano-insurance.util';
import { CoverMode } from '../pano-change-cover-insurance.interface';
import { MOCK_AEM_CONTENT_OPTIONS } from '../pano-change-cover-options/pano-change-cover-options.component.spec.constants';
import { INSURANCE_POLICY_DEATH_AND_TPD } from '../pano-change-cover-review/pano-change-cover-review.component.spec.constants';

import { PanoDecreaseRequestOptionsComponent } from './pano-decrease-request-options.component';
import {
  INSURANCE_OPTIONS_DATA,
  INSURANCE_POLICY,
  INSURANCE_POLICY_SCI,
  INSURANCE_POLICY_UNITS,
  MOCK_ACCOUNT,
  MOCK_PERSONAL_BENEFIT_DETAILS,
  NEW_COVER_TYPE_AMOUNT,
  NEW_COVER_TYPE_SCI,
  NEW_COVER_TYPE_UNITS
} from './pano-decrease-request-options.component.spec.constants';

describe('PanoDecreaseRequestOptionsComponent', () => {
  let component: PanoDecreaseRequestOptionsComponent;
  let fixture: ComponentFixture<PanoDecreaseRequestOptionsComponent>;
  const panoInsuranceUtil = jasmine.createSpyObj('panoInsuranceUtil', {
    getAccountActivationDaysFor90DaysCriteria: jasmine.createSpy()
  });
  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });
  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy(),
      target: jasmine.createSpy(),
      params: {
        mode: CoverMode.DECREASE_REQUEST
      }
    }
  };
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          ButtonModule,
          AlertModule,
          BrowserDynamicTestingModule,
          DataModule,
          RouterTestingModule,
          MatFormFieldModule,
          MatSelectModule,
          MatInputModule,
          ReactiveFormsModule,
          HttpClientTestingModule,
          NoopAnimationsModule,
          MatDialogModule
        ],
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradeAccountService },
          PanoInsuranceService,
          { provide: PanoInsuranceUtil, useValue: panoInsuranceUtil },
          { provide: PageScrollService, useValue: pageScrollService }
        ],
        declarations: [PanoDecreaseRequestOptionsComponent],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoDecreaseRequestOptionsComponent);
    component = fixture.componentInstance;
    component.account = MOCK_ACCOUNT;
    component.insurance = INSURANCE_POLICY;
    component.cmsContent = MOCK_AEM_CONTENT_OPTIONS;
  });

  describe('Component', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    describe('ngOnInit', () => {
      it('should scroll to top of page', () => {
        component.ngOnInit();
        const pageScrollOptions = {
          document: (component as any).document,
          scrollTarget: '.top-scroll',
          duration: 200
        };
        expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
      });

      it('should prepopulate values in form for sum insured request', () => {
        component.ngOnInit();

        expect(component.decreaseRequestSelection.controls.requestCoverAmount.value).toEqual('');
      });

      it('should prepopulate values in form for new cover type sum insured', () => {
        component.newCoverType = NEW_COVER_TYPE_AMOUNT;
        component.ngOnInit();

        expect(component.decreaseRequestSelection.controls.requestCoverAmount.value).toEqual(3000);
      });

      it('should prepopulate values and ranges in form for units of cover request', () => {
        component.insurance = INSURANCE_POLICY_UNITS;

        component.ngOnInit();

        expect(component.decreaseRequestSelection.controls.requestUnitsCover.value).toEqual('');
        expect(component.unitsOfCoversRange).toEqual([1, 2]);
      });

      it('should prepopulate values and ranges in form for new cover type units of cover request', () => {
        component.insurance = INSURANCE_POLICY_UNITS;
        component.newCoverType = NEW_COVER_TYPE_UNITS;

        component.ngOnInit();

        expect(component.decreaseRequestSelection.controls.requestUnitsCover.value).toEqual(3);
        expect(component.calculatedCoverAmount).toEqual(3000);
      });

      describe('SCI policies', () => {
        beforeEach(() => {
          component.insurance = INSURANCE_POLICY_SCI;
          component.insuranceOptions = INSURANCE_OPTIONS_DATA;
        });

        it('should prepopulate values in form for waiting period drop down', () => {
          component.ngOnInit();

          expect(component.decreaseRequestSelection.controls.requestWaitingPeriod.value).toEqual('');
        });

        it('should prepopulate values in form for benefit period drop down', () => {
          component.ngOnInit();

          expect(component.decreaseRequestSelection.controls.requestBenefitPeriod.value).toEqual('');
        });

        it('should not prepopulate values in form when not insurance option', () => {
          component.insuranceOptions = undefined;
          component.ngOnInit();

          expect(component.hasError).toBe(true);
        });

        it('should prepopulate values and ranges in form for new cover type SCI request', () => {
          component.newCoverType = NEW_COVER_TYPE_SCI;

          component.ngOnInit();

          expect(component.decreaseRequestSelection.controls.requestWaitingPeriod.value).toEqual('90 days');
          expect(component.decreaseRequestSelection.controls.requestBenefitPeriod.value).toEqual('5 years');
        });
      });
    });

    describe('setCalculatedCoverAmount', () => {
      it('should set calculate cover amount for unit selected', () => {
        component.insurance = INSURANCE_POLICY_UNITS;

        component.setCalculatedCoverAmount(2);

        expect(component.calculatedCoverAmount).toEqual(3000);
      });
    });

    describe('setAemMessages', () => {
      it('should populate correct messages', () => {
        component.insurance.unitsOfCover = undefined;
        component.setAemMessages();

        expect(component.decreaseRequestAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[4].data.description);
      });

      it('should populate correct messages for units of cover', () => {
        component.insurance = INSURANCE_POLICY_UNITS;

        component.setAemMessages();

        expect(component.decreaseRequestAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[5].data.description);
      });

      it('should populate correct messages for sci cover', () => {
        component.insurance = INSURANCE_POLICY_SCI;

        component.setAemMessages();

        expect(component.decreaseRequestAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[6].data.description);
        expect(component.sciHintAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[7].data.description);
      });
    });

    describe('ngAfterViewInit', () => {
      it('asks parent to reset focus', () => {
        spyOn(component.resetFocus, 'emit');

        component.ngAfterViewInit();

        expect(component.resetFocus.emit).toHaveBeenCalled();
      });
    });
    describe('validateAndSubmitForm', () => {
      it('should call submitForm if the form is valid', () => {
        const controls = component.decreaseRequestSelection.controls;
        for (const control in controls) {
          if (Object.prototype.hasOwnProperty.call(controls, control)) {
            const ctrl = controls[control];
            ctrl.clearValidators();
            ctrl.updateValueAndValidity({ onlySelf: true });
          }
        }
        component.decreaseRequestSelection.updateValueAndValidity();
        spyOn(component, 'submitForm');
        component.validateAndSubmitForm();

        expect(component.submitForm).toHaveBeenCalled();
      });
    });

    describe('submitForm', () => {
      describe('for non sci policies', () => {
        it('should call emit function of reviewComplete output event for Decrease request', () => {
          component.mode = CoverMode.DECREASE_REQUEST;
          panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
          spyOn(component.reviewComplete, 'emit');

          component.submitForm();

          expect(component.reviewComplete.emit).toHaveBeenCalled();
        });
      });

      describe('for non sci policies with units', () => {
        it('should call emit function of reviewComplete output event for Decrease request units of cover', () => {
          component.mode = CoverMode.DECREASE_REQUEST;
          component.insurance = INSURANCE_POLICY_UNITS;
          panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
          spyOn(component.reviewComplete, 'emit');

          component.submitForm();

          expect(component.reviewComplete.emit).toHaveBeenCalled();
        });
      });

      describe('for sci policies', () => {
        it('should call emit function of reviewComplete output event for Decrease request for sci cover', () => {
          component.mode = CoverMode.DECREASE_REQUEST;
          component.insurance = INSURANCE_POLICY_SCI;
          panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
          spyOn(component.reviewComplete, 'emit');

          component.submitForm();

          expect(component.reviewComplete.emit).toHaveBeenCalled();
        });
      });
    });

    describe('cancel', () => {
      it('should call emit function of navigate output event', () => {
        spyOn(component.navigate, 'emit');

        component.cancel();

        expect(component.navigate.emit).toHaveBeenCalled();
      });
    });

    describe('setWaitingPeriodOptions', () => {
      it('should set right options to drop down', () => {
        const waitingPeriodOptions = ['30 days', '90 days', '180 days', '720 days'];

        component.insurance = INSURANCE_POLICY_SCI;
        component.insuranceOptions = INSURANCE_OPTIONS_DATA;
        component.setWaitingPeriodOptions();

        expect(component.waitingPeriodOptions).toEqual(waitingPeriodOptions);
      });
    });

    describe('updateBenefitPeriodOptions', () => {
      beforeEach(() => {
        component.insurance = INSURANCE_POLICY_SCI;
        component.insuranceOptions = INSURANCE_OPTIONS_DATA;
      });

      it('should set right value when waiting period is 30 days', () => {
        const benefitPeriodOptions = ['2 years', '5 years', 'Age 65'];

        component.updateBenefitPeriodOptions('30 days');

        expect(component.benefitPeriodOptions).toEqual(benefitPeriodOptions);
      });

      it('should set right value when waiting period is 90 days', () => {
        const benefitPeriodOptions = ['2 years', '5 years', 'Age 65'];

        component.updateBenefitPeriodOptions('90 days');

        expect(component.benefitPeriodOptions).toEqual(benefitPeriodOptions);
      });

      it('should set right value when waiting period is 180 days', () => {
        const benefitPeriodOptions = ['Age 65'];

        component.updateBenefitPeriodOptions('180 days');

        expect(component.benefitPeriodOptions).toEqual(benefitPeriodOptions);
      });

      it('should set right value when waiting period is 720 days', () => {
        const benefitPeriodOptions = ['Age 65'];

        component.updateBenefitPeriodOptions('720 days');

        expect(component.benefitPeriodOptions).toEqual(benefitPeriodOptions);
      });
    });

    describe('validateRequestUnitsCover', () => {
      it('should set right value and validators to form controls for units cover', () => {
        component.insurance = INSURANCE_POLICY_UNITS;
        component.validateRequestUnitsCover();

        const unitCoverControl = component.decreaseRequestSelection.controls.requestUnitsCover;

        expect(unitCoverControl.value).toBe('');

        unitCoverControl.setValue = null;
        unitCoverControl.updateValueAndValidity({ onlySelf: true });
        expect(unitCoverControl.errors).not.toBeNull();
      });
    });

    describe('validateRequestCoverAmount', () => {
      it('should set right value and validators to form controls sum insured', () => {
        component.insurance = INSURANCE_POLICY_DEATH_AND_TPD;
        component.validateRequestCoverAmount();

        const coverAmountControl = component.decreaseRequestSelection.controls.requestCoverAmount;

        expect(coverAmountControl.value).toBe('');

        coverAmountControl.setValue = null;
        coverAmountControl.updateValueAndValidity({ onlySelf: true });
        expect(coverAmountControl.errors).not.toBeNull();
      });
    });

    describe('validateDecreaseRequestForSCI', () => {
      it('should set right value and validators to form controls for SCI', () => {
        component.insurance = INSURANCE_POLICY_SCI;
        component.validateDecreaseRequestForSCI();

        const waitingPeriodControl = component.decreaseRequestSelection.controls.requestWaitingPeriod;
        const benefitPeriodControl = component.decreaseRequestSelection.controls.requestBenefitPeriod;
        const benefitAmountControl = component.decreaseRequestSelection.controls.requestCoverAmount;

        expect(waitingPeriodControl.value).toBe('');
        expect(benefitPeriodControl.value).toBe('');
        expect(benefitAmountControl.value).toBe('');

        waitingPeriodControl.setValue = null;
        waitingPeriodControl.updateValueAndValidity({ onlySelf: true });
        expect(waitingPeriodControl.errors).not.toBeNull();

        benefitPeriodControl.setValue = null;
        benefitPeriodControl.updateValueAndValidity({ onlySelf: true });
        expect(benefitPeriodControl.errors).not.toBeNull();

        benefitAmountControl.setValue = null;
        benefitAmountControl.updateValueAndValidity({ onlySelf: true });
        expect(benefitAmountControl.errors).not.toBeNull();
      });
    });
  });

  describe('View', () => {
    describe('non sci sum insured', () => {
      beforeEach(() => {
        component.account = MOCK_ACCOUNT;
        component.insurance = INSURANCE_POLICY;
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insurance.personBenefitDetails = MOCK_PERSONAL_BENEFIT_DETAILS;
        fixture.detectChanges();
      });

      it('should show all the insurance details correctly', () => {
        expect(fixture.debugElement.query(By.css('.ts-insurance-policy-name')).nativeElement.innerHTML).toEqual(
          'Death'
        );
        expect(
          fixture.debugElement.query(By.css('.ts-insurance-policy-qualifier-name')).nativeElement.innerHTML
        ).toEqual('Essential cover');
        expect(fixture.debugElement.query(By.css('.ts-insurance-sumInsured')).nativeElement.innerText).toEqual(
          '$4,521.00'
        );
        expect(fixture.debugElement.query(By.css('.ts-insurance-premium')).nativeElement.innerText).toEqual(
          'Not applicable'
        );
      });

      it('should show Cover amount input when the insurance not having unitsOfCover', () => {
        expect(fixture.debugElement.query(By.css('.ts-cover-amount-label1'))).toBeTruthy();
      });

      it('should show monthly premium as Not applicable if its 0 for BYO cover', () => {
        component.insurance = IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[0];
        fixture.detectChanges();

        const premiumEl = fixture.debugElement.query(By.css('.ts-insurance-premium'));

        expect(premiumEl.nativeElement.innerText).toBe('Not applicable');
      });

      it('should not show monthly premium as Not applicable if its not 0 or not BYO cover', () => {
        component.insurance = IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[1];
        fixture.detectChanges();

        const premiumEl = fixture.debugElement.query(By.css('.ts-insurance-premium'));

        expect(premiumEl.nativeElement.innerText).toBe('$1.00');
      });
    });

    describe('non sci units', () => {
      beforeEach(() => {
        component.account = MOCK_ACCOUNT;
        component.insurance = INSURANCE_POLICY_UNITS;
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insurance.personBenefitDetails = MOCK_PERSONAL_BENEFIT_DETAILS;
        fixture.detectChanges();
      });

      it('should show select Units when the insurance having unitsOfCover', () => {
        expect(fixture.debugElement.query(By.css('.ts-select-unit-label')).nativeElement.innerHTML).toEqual(
          'Select units'
        );
        expect(fixture.debugElement.query(By.css('.ts-cover-amount-label')).nativeElement.innerHTML).toEqual(
          'Cover amount'
        );
      });
    });

    describe('sci sum insured', () => {
      beforeEach(() => {
        component.account = MOCK_ACCOUNT;
        component.insurance = INSURANCE_POLICY_SCI;
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insuranceOptions = INSURANCE_OPTIONS_DATA;
        fixture.detectChanges();
      });

      it('should have Benefit amount, waiting period and benefit period for SCI policy decrease request', () => {
        const benefitAmount = fixture.debugElement.query(By.css('.ts-insurance-sumInsured-name'));
        const waitingPeriod = fixture.debugElement.query(By.css('.ts-insurance-waiting-period'));
        const benefitPeriod = fixture.debugElement.query(By.css('.ts-insurance-benefit-period'));

        expect(benefitAmount.nativeElement.innerText).toBe('Benefit amount');
        expect(waitingPeriod).toBeTruthy();
        expect(benefitPeriod).toBeTruthy();
      });

      it('should show benefit period, waiting period drop down and benefit amount input box for SCI policy', () => {
        const waitingPeriodDD = fixture.debugElement.query(By.css('.ts-test-decrease-request-waiting-period-value'));
        const benefitPeriodDD = fixture.debugElement.query(By.css('.ts-test-decrease-request-benefit-period-value'));
        const benefitAmountInput = fixture.debugElement.query(
          By.css('.ts-test-decrease-request-new-cover-amount-value')
        );

        expect(waitingPeriodDD).toBeTruthy();
        expect(benefitPeriodDD).toBeTruthy();
        expect(benefitAmountInput).toBeTruthy();
      });

      it('should show sci hint text', () => {
        const hintText = fixture.debugElement.query(By.css('.ts-test-sci-hint'));

        expect(hintText).toBeTruthy();
      });
    });
  });
});
