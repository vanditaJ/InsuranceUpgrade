import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { of, throwError } from 'rxjs';

import { PanoInsuranceService } from '../pano-insurance.service';
import { INSURANCE_OPTIONS, INSURANCE_RATES } from '../pano-insurance.service.spec.constants';
import { PanoInsuranceUtil } from '../pano-insurance.util';

import { PanoChangeCoverInsuranceCommonUtil } from './pano-change-cover-insurance-common.util';
import { PanoChangeCoverInsuranceComponent } from './pano-change-cover-insurance.component';
import {
  COVER_AMOUNT_OPTIONS,
  COVER_AMOUNT_OPTIONS_MULTI,
  DEATH_AND_TPD_INSURANCE_POLICY,
  DEATH_INSURANCE_POLICY,
  MOCK_AEM_CONTENT_CHANGE,
  NEW_COVER_TYPE,
  SCI_INSURANCE_POLICY,
  TRIPLE_DEATH_AND_TPD_INSURANCE_POLICY,
  TRIPLE_DEATH_INSURANCE_POLICY
} from './pano-change-cover-insurance.component.spec.constants';
import { CoverMode, CoverState } from './pano-change-cover-insurance.interface';

describe('PanoChangeCoverInsuranceComponent', () => {
  let component: PanoChangeCoverInsuranceComponent;
  let fixture: ComponentFixture<PanoChangeCoverInsuranceComponent>;
  let service: PanoInsuranceService;
  let disclaimerService: PanoDisclaimersService;
  let util: PanoChangeCoverInsuranceCommonUtil;

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy(),
      target: jasmine.createSpy(),
      params: {
        mode: CoverMode.DECREASE
      }
    }
  };

  const mockAccountService = {
    getAccountId: jasmine.createSpy()
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoChangeCoverInsuranceComponent],
        imports: [HttpClientTestingModule, ReactiveFormsModule, DataModule, RouterTestingModule, PipesTestingModule],
        providers: [
          Location,
          { provide: LocationStrategy, useClass: PathLocationStrategy },
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradeAccountService, useValue: mockAccountService },
          PanoInsuranceService,
          PanoDisclaimersService,
          PanoChangeCoverInsuranceCommonUtil,
          PanoInsuranceUtil
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoChangeCoverInsuranceComponent);
    component = fixture.componentInstance;
    component.cmsContent = MOCK_AEM_CONTENT_CHANGE;
    service = TestBed.inject(PanoInsuranceService);
    util = TestBed.inject(PanoChangeCoverInsuranceCommonUtil);
    disclaimerService = TestBed.inject(PanoDisclaimersService);
    component.account = {
      key: {
        accountId: 'DE03554AD'
      },
      accountNumber: '1234',
      accountName: 'account name',
      firstMoneyReceivedDate: '2020-11-04T16:00:00.000Z',
      owners: [
        {
          age: 54,
          dateOfBirth: '03 Apr 1967',
          emails: [],
          firstName: 'Name',
          gender: 'Female',
          lastName: 'LastName'
        }
      ],
      pdsStatus: 'DEFAULT',
      product: {},
      productDescription: 'BT Super'
    };
    spyOn(disclaimerService, 'evaluateDisclaimer').and.returnValue('disclaimer');
  });

  describe('Component', () => {
    describe('ngOnInit', () => {
      beforeEach(() => {
        spyOn(component, 'setNewCoverType');
      });

      it('should populate the date and disclaimer', () => {
        component.ngOnInit();
        expect(component.date).toBeTruthy();
        expect(component.disclaimer).toBeTruthy();
      });

      it('should call getInsurance service and set current cover type', () => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE;
        spyOn(service, 'getInsuranceRates').and.returnValue(of(INSURANCE_RATES));
        spyOn(service, 'getInsurance').and.returnValue(of(DEATH_INSURANCE_POLICY));
        spyOn(util, 'getCoverAmountOptions').and.returnValue(COVER_AMOUNT_OPTIONS);

        component.ngOnInit();

        expect(component.insurance).toEqual(DEATH_INSURANCE_POLICY);
        expect(component.currentCoverType).toEqual(COVER_AMOUNT_OPTIONS);
      });

      it('should default the new cover when in decrease mode for a Death policy with minimum cover', () => {
        spyOn(service, 'getInsuranceRates').and.returnValue(of(INSURANCE_RATES));
        spyOn(service, 'getInsurance').and.returnValue(of(DEATH_INSURANCE_POLICY));
        spyOn(util, 'getCoverAmountOptions').and.returnValue(COVER_AMOUNT_OPTIONS);
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE;
        component.ngOnInit();

        expect(component.setNewCoverType).toHaveBeenCalled();
      });

      it('should default the new cover when in decrease mode for a Death and TPD policy with minimum cover', () => {
        spyOn(service, 'getInsuranceRates').and.returnValue(of(INSURANCE_RATES));
        spyOn(service, 'getInsurance').and.returnValue(of(DEATH_AND_TPD_INSURANCE_POLICY));
        spyOn(util, 'getCoverAmountOptions').and.returnValue(COVER_AMOUNT_OPTIONS);
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE;
        component.ngOnInit();

        expect(component.setNewCoverType).toHaveBeenCalled();
      });

      it('should not default the new cover when in decrease mode for a Death policy above minimum cover', () => {
        spyOn(service, 'getInsuranceRates').and.returnValue(of(INSURANCE_RATES));
        spyOn(service, 'getInsurance').and.returnValue(of(TRIPLE_DEATH_INSURANCE_POLICY));
        spyOn(util, 'getCoverAmountOptions').and.returnValue(COVER_AMOUNT_OPTIONS_MULTI);
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE;
        component.ngOnInit();

        expect(component.setNewCoverType).not.toHaveBeenCalled();
        expect(component.state).toEqual(CoverState.OPTIONS);
      });

      it('should not default the new cover when in decrease mode for a Death and TPD policy above minimum cover', () => {
        spyOn(service, 'getInsuranceRates').and.returnValue(of(INSURANCE_RATES));
        spyOn(service, 'getInsurance').and.returnValue(of(TRIPLE_DEATH_AND_TPD_INSURANCE_POLICY));
        spyOn(util, 'getCoverAmountOptions').and.returnValue(COVER_AMOUNT_OPTIONS_MULTI);

        component.ngOnInit();

        expect(component.setNewCoverType).not.toHaveBeenCalled();
        expect(component.state).toEqual(CoverState.OPTIONS);
      });

      it('should not default the new cover when in change mode', () => {
        spyOn(service, 'getInsuranceRates').and.returnValue(of(INSURANCE_RATES));
        (component as any).uiRouter.stateService.params.mode = CoverMode.CHANGE;

        component.ngOnInit();

        expect(component.setNewCoverType).not.toHaveBeenCalled();
        expect(component.state).toEqual(CoverState.OPTIONS);
      });

      it('should set up error message on API response error', () => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE;
        spyOn(service, 'getInsuranceRates').and.returnValue(throwError('error'));
        spyOn(service, 'getInsurance').and.returnValue(of(DEATH_INSURANCE_POLICY));
        spyOn(util, 'getCoverAmountOptions').and.returnValue(COVER_AMOUNT_OPTIONS);

        component.ngOnInit();

        expect(component.genericError).toBeTruthy();
      });

      it('should call getInsuranceOptions service for sci decrease request', () => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE_REQUEST;
        spyOn(service, 'getInsurance').and.returnValue(of(SCI_INSURANCE_POLICY));
        spyOn(service, 'getInsuranceOptions').and.returnValue(of(INSURANCE_OPTIONS));

        component.ngOnInit();

        expect(service.getInsuranceOptions).toHaveBeenCalled();
        expect(component.insuranceOptions).toEqual(INSURANCE_OPTIONS);
      });

      it('should not call getInsuranceOptions service and options not set for decrease request', () => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE_REQUEST;
        spyOn(service, 'getInsurance').and.returnValue(of(SCI_INSURANCE_POLICY));
        spyOn(service, 'getInsuranceOptions').and.returnValue(throwError('error'));

        component.ngOnInit();

        expect(component.genericError).toBeTruthy();
      });

      it('should not call getInsuranceOptions service for non sci decrease request', () => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE_REQUEST;
        spyOn(service, 'getInsurance').and.returnValue(of(DEATH_INSURANCE_POLICY));

        component.ngOnInit();

        expect(component.loading).toBeFalsy();
      });
    });

    describe('setAemMessages', () => {
      it('should populate correct messages when changing a policy', () => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.CHANGE;

        component.setAemMessages();

        expect(component.selectCoverTypes[0].description).toBe(MOCK_AEM_CONTENT_CHANGE[0].data.description);
        expect(component.selectCoverTypes[1].description).toBe(MOCK_AEM_CONTENT_CHANGE[1].data.description);
      });

      it('should populate correct messages when decreasing a policy', () => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE;

        component.setAemMessages();

        expect(component.selectCoverTypes[0].description).toBe(MOCK_AEM_CONTENT_CHANGE[2].data.description);
        expect(component.selectCoverTypes[1].description).toBe(MOCK_AEM_CONTENT_CHANGE[3].data.description);
      });
    });

    describe('setNewCoverType', () => {
      it('should set correct new cover type', () => {
        component.insurance = DEATH_INSURANCE_POLICY;
        component.insuranceRates = INSURANCE_RATES;
        component.ngOnInit();

        component.setNewCoverType(COVER_AMOUNT_OPTIONS.coverTypeSelected[0]);

        expect(component.formValue['coverType']).toEqual(NEW_COVER_TYPE.coverType);
        expect(component.formValue['coverAmountType']).toEqual({
          coverSubTypeId: '93',
          coverAmountName: 'Single cover',
          coverAmountType: 'Single',
          coverAmount: 37500,
          premium: '2.61',
          increase: false
        });
        expect(component.state).toEqual(CoverState.PREVIEW);
      });
    });

    describe('showPreview', () => {
      it('should set state to preview', () => {
        component.showPreview({});

        expect(component.state).toEqual(CoverState.PREVIEW);
        expect(component.formValue).toEqual({});
      });
    });

    describe('navigateToOverview', () => {
      it('should navigate to overview screen', () => {
        component.navigateToOverview();

        expect((component as any).uiRouter.stateService.go).toHaveBeenCalledWith(
          'app.investor.account.insurancePolicies'
        );
      });
    });

    describe('resetFocus', () => {
      it('should move focus to main header', () => {
        component.mainHeader = { nativeElement: { focus: jasmine.createSpy() } };

        component.resetFocus();

        expect(component.mainHeader.nativeElement.focus).toHaveBeenCalled();
      });
    });

    describe('setSelectedCoverLabel', () => {
      it('should set state the selectedCoverLevel to the event object that is received', () => {
        component.setSelectedCoverLabel(['Single', 'Double']);

        expect(component.selectedCoverLevel).toEqual(['Single', 'Double']);
      });
    });

    describe('updateState', () => {
      it('should set state the selectedCoverLevel to the event object that is received', () => {
        component.updateState(CoverState.PREVIEW);

        expect(component.state).toEqual(CoverState.PREVIEW);
      });
    });
  });

  describe('View', () => {
    describe('when insurance rates are loading', () => {
      beforeEach(() => {
        component.loading = true;
        fixture.detectChanges();
      });

      it('should display loading spinner', () => {
        const loadingSpinner = fixture.debugElement.query(By.css('bt-loading.js-loading-spinner'));
        expect(loadingSpinner).toBeTruthy();
      });

      it('should not show form group', () => {
        const formGroup = fixture.debugElement.query(By.css('.form-field-group'));
        expect(formGroup).toBeFalsy();
      });
    });

    describe('when insurance rates are loaded', () => {
      beforeEach(() => {
        (component as any).uiRouter.stateService.params.mode = CoverMode.DECREASE;
        component.loading = false;
        fixture.detectChanges();
      });

      it('should not display loading spinner', () => {
        const loadingSpinner = fixture.debugElement.query(By.css('bt-loading.js-loading-spinner'));
        expect(loadingSpinner).toBeFalsy();
      });

      it('should show correct heading based on mode', () => {
        const headingField = fixture.debugElement.query(By.css('.ts-heading'));
        expect(headingField.nativeElement.innerHTML).toContain('Decrease your cover');
      });

      it('should show the correct component based on state', () => {
        component.state = CoverState.OPTIONS;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.ts-change-cover-option-component'))).toBeTruthy();

        component.state = CoverState.PREVIEW;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.ts-change-cover-review-component'))).toBeTruthy();

        component.state = CoverState.CONFIRMATION;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.ts-change-cover-confirmation'))).toBeTruthy();
      });
    });
  });
});
