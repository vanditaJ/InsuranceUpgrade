import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Icon } from '@bt/components/icon';
import { TotalOfPipe } from '@bt/pipes/total-of';
import { WINDOW } from '@bt/tokens';
import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';
import { UIRouter } from '@uirouter/core';
import {
  PanoUpgradeAccountService,
  PanoUpgradeFeatureService,
  PanoUpgradePermissionService
} from '@upgrade/upgrade.services';
import {
  compact,
  concat,
  find,
  get,
  groupBy,
  has,
  includes,
  inRange,
  isNull,
  orderBy,
  remove,
  size,
  some
} from 'lodash-es';
import * as moment from 'moment-timezone';

import { CoverMode } from '../../pano-change-cover-insurance/pano-change-cover-insurance.interface';
import { PanoInsuranceSharedLinkService } from '../../pano-insurance-shared-link/pano-insurance-shared-link.service';
import { LinkType } from '../../pano-insurance-shared-link/pano-insurance-shared-link.service.constants';
import { ESSENTIAL_COVER, RETAIL, STANDARD_COVER, TAILORED_COVER } from '../../pano-insurance.constants';
import { findContentByKey } from '../../pano-insurance.helper';
import {
  InsurancePolicy,
  PMIFDetails,
  PolicyDisplayName,
  PolicyStatus,
  PolicyType
} from '../../pano-insurance.interface';
import { PanoIncreaseEyCoverDialogComponent } from '../pano-increase-ey-cover-dialog/pano-increase-ey-cover-dialog.component';
import { PanoInsuranceAlertModalComponent } from '../pano-insurance-alert-modal/pano-insurance-alert-modal.component';
import { PanoInsuranceExitSiteDialogComponent } from '../pano-insurance-exit-site-dialog/pano-insurance-exit-site-dialog.component';
import {
  INSURANCE_SSO_AIA_FEATURE,
  INVESTOR_BTSUPER_IISCOP,
  INVESTOR_BTSUPER_PMIF,
  INVESTOR_BTSUPER_UPDATE,
  INVESTOR_INSURANCE_PYSOPTIN
} from '../pano-insurance-policies.constants';
import {
  InsuranceDetail,
  Insurances,
  ModalObj,
  PoliciesInScope,
  Range,
  TableTitle
} from '../pano-insurance-policies.interface';
import { PanoInsurancePoliciesUtil } from '../pano-insurance-policies.util';

import {
  ACTION_BUTTON,
  BASIC_ALERT,
  BENEFIT_FREQUENCY,
  BT_60_DAY_POLICIES_IN_SCOPE,
  BT_POLICIES_IN_SCOPE,
  CANCEL_COVER_BUTTON,
  CANCEL_COVER_DEATH_MODAL_AEM_KEY,
  CANCEL_INSURANCE_STATE,
  CHANGE_COVER_AGE_MODAL_AEM_KEY,
  CHANGE_COVER_BUTTON,
  CHANGE_COVER_POLICY_TYPE,
  CHANGE_INSURANCE_STATE,
  DAYS_BASED_ALERT_STATUS,
  EY_INSURER_CODE,
  EY_PDS_STATUS,
  INACTIVE_FOOTNOTE,
  INCREASE_COVER_EY_MODAL_AEM_KEY,
  INSURANCE_DETAILS,
  NOT_OPTED_IN,
  NO_OCCUPATION_CODE_INLINE_ALERT,
  PENDING_FOOTNOTE,
  PENDING_POLICY_ALERT,
  PMIF_NOT_ACTIVE_GT_30_DAYS_ALERT,
  PMIF_PENDING_STATUS_ALERT,
  POLICY_GT_60_DAYS_ALERT,
  POLICY_LT_90_DAYS_ALERT,
  POLICY_STATUS,
  POPOVER_ICON,
  SHOW_ACTION_MENU,
  SHOW_ACTION_MENU_AMEND,
  VIEW_COVER_60_DAYS_AEM_KEY,
  VIEW_COVER_90_DAYS_AEM_KEY,
  VIEW_COVER_NO_OCCUPATION_CODE_AEM_KEY,
  VIEW_COVER_TAILORED_60_DAYS_AEM_KEY
} from './pano-insurance-tables.component.constants';

@Component({
  selector: 'pano-insurance-tables',
  templateUrl: './pano-insurance-tables.component.html'
})
export class PanoInsuranceTablesComponent implements OnInit {
  @Input() account: Account;
  @Input() policies: InsurancePolicy[];
  @Input() cmsContent: AemContent[];

  showMenuActionPermission: boolean = false;
  isIntegrationToAiaEnabled: boolean = false;
  insuranceDetails: InsuranceDetail[] = INSURANCE_DETAILS;
  visiblePolicies: InsurancePolicy[] = [];
  pendingPolicies: InsurancePolicy[] = [];
  dataObj: ModalObj;
  viewCover90DaysAemMessage: string;
  viewCoverNoOccupationCodeAemMessage: string;
  cancelCoverModalAemMessage: string;
  changeCoverModalAemMessage: string;
  increaseCoverEyModalAemMessage: string;
  isAvailableForPmifPysOptIn: boolean = false;
  isAvailableForPysOptIn: boolean = false;
  pmifPermission: boolean = false;
  iiscopPermission: boolean = false;

  readonly superPolicyScope: PoliciesInScope = BT_POLICIES_IN_SCOPE;
  readonly super60dayPolicyScope: PoliciesInScope = BT_60_DAY_POLICIES_IN_SCOPE;
  readonly policyStatusLabels = POLICY_STATUS;
  readonly benefitFrequencyLabels = BENEFIT_FREQUENCY;
  readonly notOptedIn = NOT_OPTED_IN;
  readonly popoverIcon: Icon = POPOVER_ICON;
  readonly basicAlert: Alert = BASIC_ALERT;
  readonly pendingPolicyAlert: Alert = PENDING_POLICY_ALERT;
  readonly policyGT60DaysAlert: Alert = POLICY_GT_60_DAYS_ALERT;
  readonly policyLT90DaysAlert: Alert = POLICY_LT_90_DAYS_ALERT;
  readonly noOccupationCodeAlert: Alert = NO_OCCUPATION_CODE_INLINE_ALERT;
  readonly actionButton: Button = ACTION_BUTTON;
  readonly changeCoverButton: Button = CHANGE_COVER_BUTTON;
  readonly cancelCoverButton: Button = CANCEL_COVER_BUTTON;
  readonly policyStatus = PolicyStatus;
  readonly policyType = PolicyType;
  readonly policyDisplayName = PolicyDisplayName;
  readonly coverMode = CoverMode;
  readonly pmifNotActive: Alert = PMIF_PENDING_STATUS_ALERT;
  readonly pmifNotActiveGT30DaysAlert: Alert = PMIF_NOT_ACTIVE_GT_30_DAYS_ALERT;
  readonly inactiveFootnote: string = INACTIVE_FOOTNOTE;
  readonly pendingFootnote: string = PENDING_FOOTNOTE;

  constructor(
    private readonly router: UIRouter,
    private readonly permissionService: PanoUpgradePermissionService,
    private accountService: PanoUpgradeAccountService,
    private featureService: PanoUpgradeFeatureService,
    private dialog: MatDialog,
    private totalOfPipe: TotalOfPipe,
    private panoInsurancePoliciesUtil: PanoInsurancePoliciesUtil,
    private linkService: PanoInsuranceSharedLinkService,
    @Inject(WINDOW) private readonly window: Window
  ) {}

  ngOnInit(): void {
    const accountId = this.accountService.getAccountId();
    this.pmifPermission = this.permissionService.hasPermission(INVESTOR_BTSUPER_PMIF, accountId);
    this.iiscopPermission = this.permissionService.hasPermission(INVESTOR_BTSUPER_IISCOP, accountId);
    this.showMenuActionPermission = this.permissionService.hasPermission(INVESTOR_BTSUPER_UPDATE, accountId);
    this.policies = this.panoInsurancePoliciesUtil.checkPmifPolicy(this.policies, this.pmifPermission);
    this.visiblePolicies = this.policies.filter((policy: InsurancePolicy) =>
      this.panoInsurancePoliciesUtil.isPolicyAvailableForInsuranceTable(policy)
    );
    const isPysOptInInvestor = this.featureService.hasAccess(INVESTOR_INSURANCE_PYSOPTIN);
    this.isAvailableForPmifPysOptIn = this.panoInsurancePoliciesUtil.pysAndPMIFOptInRequired(this.policies);
    const isPysOptInRequired = this.panoInsurancePoliciesUtil.pysOptInRequiredForPolicies(this.policies);
    const hasActivePolicies =
      this.policies.filter((policy: InsurancePolicy) => this.panoInsurancePoliciesUtil.checkActive(policy)).length > 0;
    this.isAvailableForPysOptIn =
      hasActivePolicies && !this.isAvailableForPmifPysOptIn && isPysOptInRequired && isPysOptInInvestor;
    this.insuranceDetails = this.insuranceDetails.map((detail: InsuranceDetail) => this.getInsuranceTableData(detail));
    this.setPendingPolicies(this.policies);
    this.isIntegrationToAiaEnabled =
      this.permissionService.hasPermission(INSURANCE_SSO_AIA_FEATURE, 'base') ||
      this.permissionService.hasPermission(INSURANCE_SSO_AIA_FEATURE, accountId);
    this.setAemMessages();
  }

  setAemMessages() {
    this.viewCover90DaysAemMessage = findContentByKey(this.cmsContent, VIEW_COVER_90_DAYS_AEM_KEY);
    this.cancelCoverModalAemMessage = findContentByKey(this.cmsContent, CANCEL_COVER_DEATH_MODAL_AEM_KEY);
    this.changeCoverModalAemMessage = findContentByKey(this.cmsContent, CHANGE_COVER_AGE_MODAL_AEM_KEY);
    this.viewCoverNoOccupationCodeAemMessage = findContentByKey(this.cmsContent, VIEW_COVER_NO_OCCUPATION_CODE_AEM_KEY);
    this.increaseCoverEyModalAemMessage = findContentByKey(this.cmsContent, INCREASE_COVER_EY_MODAL_AEM_KEY);
  }

  checkConditionAndOpenAlertModal(action: CoverMode, insurance: Insurances) {
    if (action === CoverMode.CHANGE) {
      if (
        this.getCustomerType(insurance) === RETAIL &&
        (insurance.policyType === this.policyType.DEATH || insurance.policyType === this.policyType.DEATH_AND_TPD) &&
        !insurance.customised &&
        insurance.ageNextBirthday >= 60
      ) {
        this.openAlertModal(action);
      } else {
        this.navigateToChangeOrDecreaseCover(insurance, action);
      }
    } else if (action === CoverMode.CANCEL) {
      const associatedTpdCovers = this.panoInsurancePoliciesUtil.getDeathAssociatedTPDPolicies(
        this.visiblePolicies,
        insurance
      );
      if (
        insurance.policyType === this.policyType.DEATH &&
        insurance.associatedTpd.length > 0 &&
        associatedTpdCovers.length > 0
      ) {
        this.openAlertModal(action, insurance, associatedTpdCovers);
      } else {
        this.navigateToCancelCover(insurance);
      }
    }
  }

  openAlertModal(action: CoverMode, insurance?: Insurances, associatedTpdCovers?: InsurancePolicy[]) {
    const dialogData: ModalObj = this.setData(action);
    this.dialog
      .open(PanoInsuranceAlertModalComponent, {
        ...DIALOG_CONFIG.DEFAULT,
        autoFocus: false,
        ariaLabel: `Open ${dialogData.heading} alert dialog`,
        maxHeight: '500px',
        data: dialogData
      })
      .afterClosed()
      .subscribe(res => {
        if (res === 'continue') {
          this.navigateToCancelCover(insurance, associatedTpdCovers);
        }
      });
  }

  setData(action: CoverMode): ModalObj {
    if (action === CoverMode.CHANGE) {
      this.dataObj = {
        heading: 'Change cover',
        description: this.changeCoverModalAemMessage
      };
    } else if (action === CoverMode.CANCEL) {
      this.dataObj = {
        heading: 'Cancel your cover',
        description: this.cancelCoverModalAemMessage,
        showContinueButton: true
      };
    }
    return this.dataObj;
  }

  navigateToChangeOrDecreaseCover(insurance: Insurances, mode): void {
    const decreaseCoverRequest = this.showIISCOPDecreaseMenuAction(insurance);
    if (decreaseCoverRequest) {
      mode = CoverMode.DECREASE_REQUEST;
    }
    if (
      (this.panoInsurancePoliciesUtil.getAccountActivationDaysFor90DaysCriteria(insurance, this.account) <= 90 &&
        mode === this.coverMode.CHANGE) ||
      (this.panoInsurancePoliciesUtil.getAccountActivationDaysFor90DaysCriteria(insurance, this.account) > 90 &&
        mode === this.coverMode.DECREASE) ||
      decreaseCoverRequest
    ) {
      this.router.stateService.go(CHANGE_INSURANCE_STATE, { insurance, policyNumber: insurance.policyNumber, mode });
    }
  }

  navigateToCancelCover(insurance: Insurances, associatedTpdCovers?: InsurancePolicy[]): void {
    let params: { insurance: InsurancePolicy; associatedTpdCovers?: InsurancePolicy[]; policyNumber: string } = {
      insurance,
      policyNumber: insurance.policyNumber
    };

    if (associatedTpdCovers) {
      params = { insurance, associatedTpdCovers, policyNumber: insurance.policyNumber };
    }

    this.router.stateService.go(CANCEL_INSURANCE_STATE, params);
  }

  navigateToPds(pdsLink: string): void {
    this.window.open(pdsLink, '_blank');
  }

  openExitSiteDialog(): void {
    this.dialog.open(PanoInsuranceExitSiteDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: false,
      ariaLabel: 'Open exit website dialog'
    });
  }

  openIncreaseEyCoverDialog(): void {
    this.dialog.open(PanoIncreaseEyCoverDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: false,
      ariaLabel: 'Open increase cover dialog',
      maxHeight: '500px',
      data: { description: this.increaseCoverEyModalAemMessage }
    });
  }

  private getInsuranceTableData(detail: InsuranceDetail): InsuranceDetail {
    const filteredPolicies: InsurancePolicy[] = this.visiblePolicies.filter(
      (policy: InsurancePolicy) => policy.policyType === detail.type
    );

    detail.insurances = this.setBenefits(filteredPolicies);
    const nonPendingPolicies = this.getNonPendingPolicies(detail);
    detail.totalCoverAmount = this.totalOfPipe.transform(nonPendingPolicies, 'sumInsured');
    detail.totalPremiumAmount = this.totalOfPipe.transform(nonPendingPolicies, 'premium');
    detail.showDeathFootNote = this.showApplicableNote(detail, 'FN1');
    detail.showInsuranceFootNote = this.showApplicableNote(detail, 'FN2');
    detail.showPendingFootNote = this.showStatusFootNote(detail, '*');
    detail.showInactiveFootNote = this.showStatusFootNote(detail, '^');
    detail.showWhoPays = size(find(detail.insurances, 'westpacGroupPlan')) > 0;
    detail.showSmokerStatus = size(find(detail.insurances, 'customised')) > 0;
    detail.availableTableTitles = this.removeTableTitles(detail);

    return this.sortInsurances(detail);
  }

  private removeTableTitles(detail: InsuranceDetail): TableTitle[] {
    const filteredTitles: TableTitle[] = [...detail.tableTitles];
    remove(filteredTitles, title => {
      const showSmokerStatusColumn: boolean =
        detail.showSmokerStatus && size(find(detail.insurances, 'smokerStatus')) > 0;
      let removeTitle = false;
      if (has(title, 'smoking') && !showSmokerStatusColumn) {
        detail.showSmokerStatus = false;
        removeTitle = true;
      } else if (has(title, 'whoPays') && !detail.showWhoPays) {
        detail.showWhoPays = false;
        removeTitle = true;
      }
      return removeTitle;
    });
    return filteredTitles;
  }

  private getNonPendingPolicies(detail: InsuranceDetail): Insurances[] {
    return detail.insurances.filter(
      (insurance: Insurances) =>
        insurance.status !== PolicyStatus.PENDING &&
        insurance.status !== PolicyStatus.NOT_ACTIVE &&
        insurance.status !== PolicyStatus.REQUESTED
    );
  }

  private setBenefits(filteredPolicies: InsurancePolicy[]): Insurances[] {
    const benefitPath = 'personBenefitDetails[0].benefits[0]';
    const insurances: Insurances[] = [];
    filteredPolicies.forEach((policy: InsurancePolicy) => {
      if (this.panoInsurancePoliciesUtil.isPolicyAvailableForInsuranceTable(policy)) {
        const insuranceData = Object.assign(
          {
            benefits: get(policy, benefitPath),
            occupationClass: get(policy, `${benefitPath}.benefits[0].occupationClass`),
            policyStatusLabel: this.setStatusLabel(policy),
            optInDateLabel: this.setOptInDateLabel(policy),
            benefitFrequencyLabel: find(
              this.benefitFrequencyLabels,
              freq => freq.type === get(policy, `${benefitPath}.benefits[0].frequency`)
            ).name,
            popoverText: policy.applicableNotes && this.setPopoverText(policy),
            showMenuAction: this.showMenuAction(policy),
            showChangeMenuAction: this.showMenuActionPermission && this.showChangeMenuAction(policy),
            showDecreaseMenuAction:
              (this.showMenuActionPermission && this.showDecreaseMenuAction(policy)) ||
              this.showIISCOPDecreaseMenuAction(policy),
            showIncreaseMenuAction: this.showIncreaseMenuAction(policy),
            showEyIncreaseMenuAction: this.showEyIncreaseMenuAction(policy),
            policyGT60DaysMessage: this.showPolicyGT60DaysAlert(policy) ? this.policyGT60DaysMessage(policy) : null,
            showPolicyLT90DaysAlert: this.showPolicyLT90DaysAlert(policy),
            showPmifNotActiveGT30DaysAlert: this.showPmifNotActiveGT30DaysAlert(policy),
            icon: this.setIcon(policy),
            isOccupationCodeAbsent: this.panoInsurancePoliciesUtil.isPolicySuitableForNoOccupationCodeAlert(policy),
            pdsLink: this.setPdsLink(policy)
          },
          policy
        );
        insurances.push(insuranceData);
      }
    });
    return insurances;
  }

  private setIcon(policy: InsurancePolicy): string {
    if (policy.status === PolicyStatus.INACTIVE && this.panoInsurancePoliciesUtil.isEndOfTheMonth(policy.endDate)) {
      return '^';
    } else if (policy.status === PolicyStatus.PENDING && isNull(policy.endDate)) {
      return '*';
    }
    return null;
  }

  private setPdsLink(policy: InsurancePolicy): string {
    return this.linkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, policy, this.account);
  }

  private setStatusLabel(policy: InsurancePolicy) {
    if (policy.status === PolicyStatus.INACTIVE && this.panoInsurancePoliciesUtil.isEndOfTheMonth(policy.endDate)) {
      return 'Active';
    }
    return find(this.policyStatusLabels, status => status.type === get(policy, 'status')).name;
  }

  private showMenuAction(policy: InsurancePolicy): boolean {
    const status = SHOW_ACTION_MENU.includes(get(policy, 'status'));
    if (policy.status === PolicyStatus.INACTIVE && this.panoInsurancePoliciesUtil.isEndOfTheMonth(policy.endDate)) {
      return false;
    }
    return status;
  }

  private showChangeMenuAction(policy: InsurancePolicy): boolean {
    const policyType = CHANGE_COVER_POLICY_TYPE.includes(get(policy, 'policyType'));
    return (
      this.showMenuActionAmend(policy) &&
      policyType &&
      (this.getAge(policy) > 60 ||
        this.panoInsurancePoliciesUtil.getAccountActivationDaysFor90DaysCriteria(policy, this.account) <= 90)
    );
  }

  private showDecreaseMenuAction(policy: InsurancePolicy): boolean {
    const policyType = get(policy, 'policyType');
    return (
      this.showMenuActionAmend(policy) &&
      this.getAge(policy) < 60 &&
      this.panoInsurancePoliciesUtil.getAccountActivationDaysFor90DaysCriteria(policy, this.account) > 90 &&
      (policyType === PolicyType.DEATH_AND_TPD ||
        (policyType === PolicyType.DEATH && get(policy, 'coverLevel') !== 'Single'))
    );
  }

  private showMenuActionAmend(policy: InsurancePolicy): boolean {
    const customised = get(policy, 'customised');
    const status = SHOW_ACTION_MENU_AMEND.includes(get(policy, 'status'));
    const retail = this.getCustomerType(policy) === RETAIL;
    return !customised && status && retail;
  }

  private showIISCOPDecreaseMenuAction(policy: InsurancePolicy): boolean {
    return this.iiscopPermission && policy.decreaseAvailable;
  }

  private showIncreaseMenuAction(policy: InsurancePolicy): boolean {
    return !this.isEy() && policy.status === PolicyStatus.ACTIVE && this.isPolicyValid(policy);
  }

  private showEyIncreaseMenuAction(policy: InsurancePolicy): boolean {
    return (
      this.isEy() &&
      policy.insurerCode === EY_INSURER_CODE &&
      (policy.status === PolicyStatus.ACTIVE || policy.status === PolicyStatus.PENDING)
    );
  }

  private isPolicyValid(policy: InsurancePolicy): boolean {
    return (
      this.isPolicyInScope(this.superPolicyScope, policy) ||
      (this.isPolicyInScope(this.super60dayPolicyScope, policy) &&
        this.panoInsurancePoliciesUtil.getAccountActivationDaysFor60DaysCriteria(policy, this.account) > 60)
    );
  }

  private isPolicyInScope(productScope: PoliciesInScope, policy: InsurancePolicy): boolean {
    return (
      some(productScope.coverSubTypeIds, (coverSubTypeId: number) => policy.coverSubTypeId === coverSubTypeId) ||
      some(productScope.coverSubTypeIdRange, (coverSubTypeIdRange: Range) =>
        inRange(policy.coverSubTypeId, coverSubTypeIdRange.start, coverSubTypeIdRange.end + 1)
      )
    );
  }

  private policyGT60DaysMessage(policy: InsurancePolicy): string {
    return policy.qualifierName === ESSENTIAL_COVER
      ? findContentByKey(this.cmsContent, VIEW_COVER_60_DAYS_AEM_KEY)
      : findContentByKey(this.cmsContent, VIEW_COVER_TAILORED_60_DAYS_AEM_KEY);
  }

  private showPolicyGT60DaysAlert(policy: InsurancePolicy): boolean {
    const hasGroupInsurance = policy.groupInsurance;
    const isNonSCIPolicy = policy.policyType !== PolicyType.INCOME_PROTECTION;
    const status = DAYS_BASED_ALERT_STATUS.includes(get(policy, 'status'));
    const isPolicyCover = policy.qualifierName === ESSENTIAL_COVER || policy.qualifierName === TAILORED_COVER;

    return (
      hasGroupInsurance &&
      isNonSCIPolicy &&
      status &&
      isPolicyCover &&
      this.getCustomerType(policy) !== 'BT Super – Retail' &&
      this.getAge(policy) < 60 &&
      this.getAccountActivationDaysFor60DaysAlert(policy) < 60
    );
  }

  private showPolicyLT90DaysAlert(policy: InsurancePolicy): boolean {
    const status = DAYS_BASED_ALERT_STATUS.includes(get(policy, 'status'));

    return (
      status &&
      this.getCustomerType(policy) === RETAIL &&
      policy.qualifierName === STANDARD_COVER &&
      this.account.owners[0].age < 60 &&
      this.panoInsurancePoliciesUtil.getAccountActivationDaysFor90DaysCriteria(policy, this.account) <= 90
    );
  }

  private getCustomerType(policy: InsurancePolicy): string {
    return get(policy, 'customerType');
  }

  private setOptInDateLabel(policy: InsurancePolicy): string {
    const optInDate = get(policy, 'pysDetails.optInDate');
    const riskCommencementDate = get(policy, 'riskCommencementDate');
    if (
      (!optInDate ||
        (riskCommencementDate &&
          this.panoInsurancePoliciesUtil.getDate(optInDate) <
            this.panoInsurancePoliciesUtil.getDate(riskCommencementDate))) &&
      ((this.pmifPermission && this.isAvailableForPmifPysOptIn) || this.isAvailableForPysOptIn)
    ) {
      return this.notOptedIn;
    } else {
      return optInDate
        ? moment(optInDate)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        : this.notOptedIn;
    }
  }

  private getAge(policy: InsurancePolicy): number {
    return get(policy, 'ageNextBirthday');
  }

  //#region getAccountActivationDaysFor60DaysAlert
  private getAccountActivationDaysFor60DaysAlert(policy: InsurancePolicy): number {
    const accountActivationDate = this.getAccountActivationDateFor60DaysAlert(policy);
    return this.panoInsurancePoliciesUtil.getDaysSince(accountActivationDate);
  }

  private getAccountActivationDateFor60DaysAlert(policy: InsurancePolicy): string {
    const pmifDetail = this.getPMIFDetails(policy);
    if (pmifDetail) {
      const automaticCoverDate = this.panoInsurancePoliciesUtil.getAutomaticCoverDate(
        this.account,
        pmifDetail.lowBalanceThresholdDate
      );

      if (
        !pmifDetail.optInDate ||
        this.panoInsurancePoliciesUtil.getDate(automaticCoverDate) <
          this.panoInsurancePoliciesUtil.getDate(pmifDetail.optInDate)
      ) {
        return automaticCoverDate || null;
      } else {
        return pmifDetail.optInDate;
      }
    } else {
      return null;
    }
  }
  //#endregion

  private getPMIFDetails(policy: InsurancePolicy): PMIFDetails {
    return get(policy, 'pmifDetails');
  }

  private sortInsurances(detail: InsuranceDetail): InsuranceDetail {
    if (
      detail.type === PolicyType.DEATH ||
      detail.type === PolicyType.TPD ||
      detail.type === PolicyType.DEATH_AND_TPD
    ) {
      const groupByType = groupBy(detail.insurances, 'status');
      groupByType.IN_FORCE = orderBy(groupByType.IN_FORCE, ['coverSubTypeId'], ['asc']);
      detail.insurances = compact(
        concat(
          groupByType.NOT_ACTIVE,
          groupByType.REQUESTED,
          groupByType.IN_FORCE,
          groupByType.CANCELLED,
          groupByType.PROPOSAL
        )
      );
    }
    return detail;
  }

  private setPopoverText(policy: InsurancePolicy): string {
    let popoverTextId = '';
    if (policy.applicableNotes.indexOf('TT1') !== -1) {
      popoverTextId = 'Help-IP-0334';
    } else if (policy.applicableNotes.indexOf('TT2') !== -1) {
      popoverTextId = 'Help-IP-0335';
    } else if (policy.applicableNotes.indexOf('TT3') !== -1) {
      popoverTextId = 'Help-IP-0336';
    }
    return popoverTextId;
  }

  private showApplicableNote(detail: InsuranceDetail, noteId: string): boolean {
    return size(find(detail.insurances, insurance => includes(insurance.applicableNotes, noteId))) > 1;
  }

  private showStatusFootNote(detail: InsuranceDetail, icon: string): boolean {
    return size(find(detail.insurances, ['icon', icon])) > 1;
  }

  private setPendingPolicies(policies: InsurancePolicy[]): void {
    this.pendingPolicies = policies.filter(
      (policy: InsurancePolicy) =>
        policy.status === PolicyStatus.ACTIVE &&
        this.panoInsurancePoliciesUtil.getDaysSince(policy.commencementDate) < 0
    );
  }

  private showPmifNotActiveGT30DaysAlert(policy: InsurancePolicy): boolean {
    const optInDate = get(policy, 'pmifDetails.optInDate');
    const riskCommencementDate = get(policy, 'riskCommencementDate');
    return (
      this.panoInsurancePoliciesUtil.automaticCoverMessageRequired(policy) &&
      (!optInDate ||
        (riskCommencementDate &&
          this.panoInsurancePoliciesUtil.getDate(optInDate) <
            this.panoInsurancePoliciesUtil.getDate(riskCommencementDate)))
    );
  }

  private isEy(): boolean {
    return this.account.pdsStatus === EY_PDS_STATUS;
  }
}
