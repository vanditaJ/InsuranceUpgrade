import { AemTitleLink } from '@investor/account/pano-shared/interfaces';

import { FaqContent } from './pano-investments-overview-questions.interface';

export const MOCK_AEM_CONTENT: AemTitleLink = {
  details: [
    {
      type: 'title_text_link',
      id: 'general',
      data: {
        headerText: 'faq one',
        description: 'description one'
      }
    },
    {
      type: 'title_text_link',
      id: 'general',
      data: {
        headerText: 'faq two',
        description: 'description two'
      }
    }
  ]
};

export const FAQ_CONTENT: FaqContent[] = [
  {
    header: MOCK_AEM_CONTENT.details[0].data.headerText,
    description: MOCK_AEM_CONTENT.details[0].data.description
  },
  {
    header: MOCK_AEM_CONTENT.details[1].data.headerText,
    description: MOCK_AEM_CONTENT.details[1].data.description
  }
];

export const MOCK_APIR_CODE: string = 'BTA0292AU';
