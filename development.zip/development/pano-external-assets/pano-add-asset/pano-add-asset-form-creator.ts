import { Injectable } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { attachDynamicValidators } from '@bt/helpers/attach-dynamic-validators';
import * as moment from 'moment-timezone';

import { ASSET_TYPES, MARKET_VALUE_VALIDATORS } from '../pano-external-assets-constants/pano-external-assets.constants';
import { assetSelectedValidator } from '../pano-external-assets-custom-validator';

@Injectable()
export class PanoAddAssetFormCreator {
  attachDynamicValidators = attachDynamicValidators;

  constructor(private fb: FormBuilder) {}

  createAddAssetForm(assetType: string) {
    return this.fb.group(
      ASSET_TYPES[assetType].addFormControls.reduce((accum, field) => {
        return {
          ...accum,
          [field.name]: new FormControl(field.type === 'date' ? moment().tz('Australia/Sydney') : field.defaultValue, {
            validators: field.validators ? [...field.validators] : [],
            updateOn: field.updateOn ? field.updateOn : 'blur'
          })
        };
      }, {})
    );
  }

  reAssignValidatorsForMarketValueAndValuationDate(assetDetailsFormGroup: FormGroup, enableValidator: boolean): void {
    this.attachDynamicValidators(
      assetDetailsFormGroup.controls['valuationDate'],
      enableValidator ? [Validators.required] : []
    );
    this.attachDynamicValidators(
      assetDetailsFormGroup.controls['marketValue'],
      enableValidator ? [...MARKET_VALUE_VALIDATORS] : []
    );
  }

  reAssignValidatorsForPanoramaAssetDetails(assetDetailsFormGroup: FormGroup, enableValidator: boolean): void {
    this.attachDynamicValidators(
      assetDetailsFormGroup.controls['panoramaAssetDetails'],
      enableValidator ? [Validators.required, assetSelectedValidator] : []
    );
  }
}
