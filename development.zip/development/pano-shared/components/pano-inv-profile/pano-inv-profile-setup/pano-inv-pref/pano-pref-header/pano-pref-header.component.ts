import { Component, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DIALOG_CONFIG } from '@bt/components/common';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';

import { InvestmentPreferenceHeader } from '../pano-inv-pref.interface';

import { PanoInvestmentPreferenceDialogComponent } from './pano-pref-dialog/pano-pref-dialog.component';

@Component({
  selector: 'pano-pref-header',
  templateUrl: './pano-pref-header.component.html'
})
export class PanoInvestmentPreferenceHeaderComponent {
  @Input() headerConfig: InvestmentPreferenceHeader;

  constructor(private readonly dialog: MatDialog, private readonly copyMatrixPipe: CopyMatrixPipe) {}

  showLearnMoreDialog(helpInfoId: string): void {
    this.dialog.open(PanoInvestmentPreferenceDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      maxHeight: '900px',
      autoFocus: true,
      disableClose: false,
      data: {
        title: this.headerConfig.title,
        description: this.copyMatrixPipe.transform(helpInfoId)
      }
    });
  }
}
