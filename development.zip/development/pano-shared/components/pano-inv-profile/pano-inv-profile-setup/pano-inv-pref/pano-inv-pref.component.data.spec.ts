import { LIQUIDITY_NEED_SLIDER, RISK_SLIDER } from '../pano-inv-profile-setup.constants';
import { RangeSliderModel } from '../pano-inv-profile-setup.interface';

import { CheckboxField } from './pano-inv-pref.interface';

export const MOCK_INVESTMENT_OBJECTIVES: CheckboxField[] = [
  {
    name: 'LOW',
    descripton: 'TEST LOW',
    value: false
  },
  {
    name: 'MEDIUM',
    descripton: 'TEST MEDIUM',
    value: false
  }
];

export const MOCK_INVESTMENT_TIMEFRAMES: CheckboxField[] = [
  {
    name: 'DAILY',
    descripton: 'TEST DAILY',
    value: false
  },
  {
    name: 'WEEKLY',
    descripton: 'TEST WEEKLY',
    value: false
  }
];

export const MOCK_RETURN_OBJECTIVES: RangeSliderModel = RISK_SLIDER;

export const MOCK_REDEMPTION_FREQUENCIES: RangeSliderModel = LIQUIDITY_NEED_SLIDER;
