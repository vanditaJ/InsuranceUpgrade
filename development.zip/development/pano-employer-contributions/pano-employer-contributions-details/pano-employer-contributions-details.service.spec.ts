import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DataModule, DataService } from '@bt/services/data';
import { PanoUpgradeAccountService, PanoUpgradeUserService } from '@upgrade/upgrade.services';
import { of } from 'rxjs';

import {
  NOTIFICATION_TYPE_DO_IT_FOR_ME,
  SUBMIT_NOTIFICATION_OPTIONALS,
  SUBMIT_NOTIFICATION_URL
} from './pano-employer-contributions-details.constants';
import { TEST_NOTIFICATION_RESPONSE, TEST_PROFILE } from './pano-employer-contributions-details.constants.spec';
import { NotificationResponse } from './pano-employer-contributions-details.interfaces';
import { PanoEmployerContributionsDetailsService } from './pano-employer-contributions-details.service';

describe('EmployerContributionDetailsService', () => {
  let service: PanoEmployerContributionsDetailsService;
  let dataService: DataService<NotificationResponse>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [HttpClientTestingModule, DataModule, RouterTestingModule],
        providers: [
          PanoEmployerContributionsDetailsService,
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccountId: () => '12345'
            }
          },
          {
            provide: PanoUpgradeUserService,
            useValue: {
              getProfile: () => TEST_PROFILE
            }
          }
        ]
      });
    })
  );

  beforeEach(() => {
    service = TestBed.inject(PanoEmployerContributionsDetailsService);
    dataService = TestBed.inject(DataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('submitNotification', () => {
    it(
      'should call data service with correct params and return receipt ID',
      waitForAsync(() => {
        spyOn(dataService, 'update').and.returnValue(of(TEST_NOTIFICATION_RESPONSE));

        service
          .submitNotification(
            NOTIFICATION_TYPE_DO_IT_FOR_ME,
            'firstName',
            'lastName',
            'dateOfBirth',
            'employerContactName',
            'employer@email.com',
            'my@email.com'
          )
          .subscribe((response: NotificationResponse) => {
            expect(response).toEqual(TEST_NOTIFICATION_RESPONSE);
          });

        const notificationRequest = {
          clientId: TEST_PROFILE.clientId,
          notificationType: NOTIFICATION_TYPE_DO_IT_FOR_ME,
          firstName: 'firstName',
          lastName: 'lastName',
          dateOfBirth: 'dateOfBirth',
          employerContactName: 'employerContactName',
          employerEmailAddress: 'employer@email.com',
          emailAddress: 'my@email.com'
        };

        expect(dataService.update).toHaveBeenCalledWith(
          SUBMIT_NOTIFICATION_URL + '/12345',
          notificationRequest,
          SUBMIT_NOTIFICATION_OPTIONALS
        );
      })
    );
  });
});
