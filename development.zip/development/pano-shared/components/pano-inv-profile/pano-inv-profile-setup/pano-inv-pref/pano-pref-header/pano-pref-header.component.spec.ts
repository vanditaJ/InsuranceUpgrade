import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';

import { InvestmentPreferenceHeader } from '../pano-inv-pref.interface';

import { PanoInvestmentPreferenceDialogComponent } from './pano-pref-dialog/pano-pref-dialog.component';
import { PanoInvestmentPreferenceHeaderComponent } from './pano-pref-header.component';
import { MOCK_HEADER_CONFIG } from './pano-pref-header.component.data.spec';

@Component({
  template: `
    <pano-pref-header [headerConfig]="headerConfig"> </pano-pref-header>
  `
})
class TestHostComponent {
  headerConfig: InvestmentPreferenceHeader = MOCK_HEADER_CONFIG;
}

describe('PanoInvestmentPreferenceHeaderComponent', () => {
  let component: PanoInvestmentPreferenceHeaderComponent;
  let fixture: ComponentFixture<PanoInvestmentPreferenceHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [MatDialogModule, NoopAnimationsModule],
      providers: [{ provide: CopyMatrixPipe, useValue: { transform: () => {} } }],
      declarations: [PanoInvestmentPreferenceHeaderComponent, TestHostComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentPreferenceHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct input with its host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const hostComponent = hostFixture.componentInstance;

      const currentComp: PanoInvestmentPreferenceHeaderComponent = hostFixture.debugElement.query(
        By.directive(PanoInvestmentPreferenceHeaderComponent)
      ).componentInstance;

      hostFixture.detectChanges();

      expect(currentComp.headerConfig).toEqual(hostComponent.headerConfig);
    });

    describe('showLearnMoreDialog()', () => {
      it('should open dialog PanoInvestmentPreferenceDialogComponent ', () => {
        spyOn((component as any).copyMatrixPipe, 'transform').and.returnValue('test description');

        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        component.headerConfig = MOCK_HEADER_CONFIG;
        component.showLearnMoreDialog('test');

        expect((component as any).dialog.open).toHaveBeenCalledWith(
          PanoInvestmentPreferenceDialogComponent,
          jasmine.any(Object)
        );
      });
    });
  });

  describe('view', () => {
    it('should render header icon', () => {
      component.headerConfig = { ...MOCK_HEADER_CONFIG };

      fixture.detectChanges();

      const icon = fixture.debugElement.query(By.css('bt-icon'));
      expect(icon.properties.config).toEqual(component.headerConfig.icon);
    });

    it('should render header text', () => {
      component.headerConfig = { ...MOCK_HEADER_CONFIG };

      fixture.detectChanges();

      const headerText = fixture.debugElement.query(By.css('.js-test-header-text'));
      expect(headerText.nativeElement.textContent).toEqual(component.headerConfig.title);
    });

    it('should render learn more button', () => {
      component.headerConfig = { ...MOCK_HEADER_CONFIG };
      spyOn(component, 'showLearnMoreDialog').and.stub();

      fixture.detectChanges();

      const button = fixture.debugElement.query(By.css('bt-button'));
      expect(button.properties.config).toEqual(component.headerConfig.learnMore);

      button.triggerEventHandler('btClick', '');
      fixture.detectChanges();

      expect(component.showLearnMoreDialog).toHaveBeenCalled();
    });
  });
});
