import { Icon } from '@bt/components/icon';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';

import { InsuranceLink } from './pano-insurance-links.interface';

export const HEADING_TEXT: string = 'Important information and documents';

export const SUB_HEADING_TEXT: string = 'Find out more about available ';

export const EXPANSION_ICON: Icon = {
  name: 'icon-chevron-right',
  size: 'x-small'
};

export const INCREASE_COVER_TITLE: string = 'How to increase or apply for insurance';

export const CHANGE_COVER_TITLE: string = 'How to change or cancel your existing cover';

export const MAKE_A_CLAIM_TITLE: string = 'How to make a claim';

export const OCCUPATION_CATEGORY_INFO_TITLE: string = 'Information about occupation categories';

export const TRANSFER_INSURANCE_TITLE: string = 'How to transfer your insurance';

export const INSURANCE_LINKS: InsuranceLink[] = [
  {
    title: INCREASE_COVER_TITLE,
    content: 'You can apply to increase your existing cover or apply for new cover by completing the ',
    linkType: LinkType.INSURANCE_APPLICATION_FORM,
    index: 1,
    applicableNote: 'II1'
  },
  {
    title: CHANGE_COVER_TITLE,
    content:
      'You can change or cancel your existing cover by selecting the <strong>Actions</strong> menu next to your cover',
    index: 2,
    applicableNote: 'II1'
  },
  {
    title: MAKE_A_CLAIM_TITLE,
    content: `You can make a claim by calling us. We understand you may be going through a difficult time,
      so you'll be given a dedicated Claims Manager to help you through the process`,
    index: 3,
    applicableNote: 'II1'
  },
  {
    title: OCCUPATION_CATEGORY_INFO_TITLE,
    content: '{information} Refer to the ',
    linkType: LinkType.INSURANCE_GUIDE,
    contentAfterLink: ' for more information',
    index: 4,
    applicableNote: 'II1'
  },
  {
    title: TRANSFER_INSURANCE_TITLE,
    content: `You can apply to transfer your non-BT super insurance cover to your BT super account at any time by completing the `,
    linkType: LinkType.INSURANCE_TRANSFER_FORM,
    index: 5,
    applicableNote: 'II2'
  }
];

export const ADDITIONAL_INFORMATION_BOOKLET_LABEL: string = 'Additional Information Booklet';

export const INSURANCE_GUIDE_LABEL: string = 'Insurance Guide';

export const TAKEOVER_FORM_LABEL: string = 'Takeover Terms Application Form';

export const TRANSFER_FORM_LABEL: string = 'Insurance Transfer Form';

export const CONSOLIDATION_FORM_LABEL: string = 'Insurance Consolidation Application Form';

export const OCCUPATION_CATEGORY_INFO_GENERIC: string = `The premium amounts are based on your age and gender, and occupation.`;

export const OCCUPATION_CATEGORY_INFO_BTSFL: string = `<p>The premium amounts for Standard Death and TPD policies are based on your age and gender,
  and do not account for your occupation. The occupation category in the table next to your cover will display as 'Not applicable'.</p>
  All other Customised Death and TPD or SCI policies may also include additional loadings based on your occupation or lifestyle.`;

export const BT_SUPER_LIFETIME_INSURANCE_GUIDE_URL: string =
  'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/forms/BT-Super-Lifetime-Insurance-Guide.pdf';
