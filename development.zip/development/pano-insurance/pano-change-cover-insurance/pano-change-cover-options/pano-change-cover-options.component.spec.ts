import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatRadioModule } from '@angular/material/radio';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { DataModule } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { PageScrollService } from 'ngx-page-scroll-core';

import { PolicyType } from '../../pano-insurance.interface';
import { PanoInsuranceService } from '../../pano-insurance.service';
import { INSURANCE_RATES } from '../../pano-insurance.service.spec.constants';
import { PanoInsuranceUtil } from '../../pano-insurance.util';
import {
  CHANGE_COVER_ACC,
  SINGLE_DEATH_AND_TPD_INSURANCE_POLICY,
  SINGLE_DEATH_INSURANCE_POLICY,
  TRIPLE_DEATH_AND_TPD_INSURANCE_POLICY,
  TRIPLE_DEATH_INSURANCE_POLICY_AGE_67
} from '../pano-change-cover-insurance.component.spec.constants';
import { SELECT_COVER_TYPES } from '../pano-change-cover-insurance.constants';
import {
  CoverAmountOptions,
  CoverMode,
  CoverTypeSelected,
  SelectCoverAmount
} from '../pano-change-cover-insurance.interface';
import { INSURANCE_POLICY } from '../pano-change-cover-review/pano-change-cover-review.component.spec.constants';

import { PanoChangeCoverOptionsComponent } from './pano-change-cover-options.component';
import {
  ALL_SELECTED_COVER_TYPES,
  CURRENT_COVER_TYPE,
  INSURANCE_POLICY_DEATH_TRIPLE,
  MOCK_ACCOUNT,
  MOCK_AEM_CONTENT_OPTIONS,
  MOCK_CHANGE_COVER_SELECTION_ACC,
  MOCK_CHANGE_COVER_SELECTION_POLICIES,
  TRIPLE_DEATH_INSURANCE_POLICY
} from './pano-change-cover-options.component.spec.constants';
import {
  CLOSE_ICON_BUTTON,
  CLOSE_TEXT_BUTTON,
  CUSTOMISED_INSURANCE_HEADER,
  EXCLUSIONS_HEADER,
  PRE_EXISTING_CONDITIONS_HEADER
} from './pano-change-cover-options.constants';
import { PanoContentDialogComponent } from './pano-content-dialog/pano-content-dialog.component';

describe('PanoChangeCoverOptionsComponent', () => {
  let component: PanoChangeCoverOptionsComponent;
  let fixture: ComponentFixture<PanoChangeCoverOptionsComponent>;
  const panoInsuranceUtil = jasmine.createSpyObj('panoInsuranceUtil', {
    getAccountActivationDaysFor90DaysCriteria: jasmine.createSpy()
  });
  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });
  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy(),
      target: jasmine.createSpy(),
      params: {
        mode: CoverMode.DECREASE
      }
    }
  };
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          ButtonModule,
          AlertModule,
          BrowserDynamicTestingModule,
          DataModule,
          RouterTestingModule,
          MatFormFieldModule,
          MatRadioModule,
          ReactiveFormsModule,
          HttpClientTestingModule,
          NoopAnimationsModule,
          MatDialogModule
        ],
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradeAccountService },
          PanoInsuranceService,
          { provide: PanoInsuranceUtil, useValue: panoInsuranceUtil },
          { provide: PageScrollService, useValue: pageScrollService }
        ],
        declarations: [PanoChangeCoverOptionsComponent],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoChangeCoverOptionsComponent);
    component = fixture.componentInstance;
    component.cmsContent = MOCK_AEM_CONTENT_OPTIONS;
    fixture.detectChanges();
  });

  describe('Component', () => {
    describe('ngOnInit', () => {
      it('should create a correct changeCoverSelection Form', () => {
        spyOn(component, 'checkCoverAmount');
        component.ngOnInit();

        const coverTypeControl = component.changeCoverSelection.controls['coverType'];
        coverTypeControl.setValue('');
        expect(coverTypeControl.valid).toBeFalsy();

        coverTypeControl.setValue('test');
        expect(coverTypeControl.valid).toBeTruthy();

        const coverAmountControl = component.changeCoverSelection.controls['coverAmountType'];
        coverAmountControl.setValue('');
        expect(coverAmountControl.valid).toBeFalsy();

        coverAmountControl.setValue('test');
        expect(coverAmountControl.valid).toBeTruthy();
        expect(component.checkCoverAmount).toHaveBeenCalled();

        const pageScrollOptions = {
          document: (component as any).document,
          scrollTarget: '.top-scroll',
          duration: 200
        };
        expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
      });

      it('should scroll to top of page', () => {
        spyOn(component, 'checkCoverAmount');
        component.ngOnInit();

        const pageScrollOptions = {
          document: (component as any).document,
          scrollTarget: '.top-scroll',
          duration: 200
        };
        expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
      });

      it('should prepopulate values in form', () => {
        spyOn(component, 'checkCoverAmount');
        const coverType = {
          policyName: 'name',
          policyType: 'type',
          description: 'desc'
        };
        const coverAmount = {
          coverSubTypeId: 'id',
          coverAmount: 0,
          coverAmountName: 'name',
          coverAmountType: 'type',
          premium: '0',
          increase: true
        };
        component.newCoverType = {
          coverType,
          coverAmountType: coverAmount
        };

        component.ngOnInit();

        expect(component.changeCoverSelection.controls.coverType.value).toEqual(coverType);
        expect(component.changeCoverSelection.controls.coverAmountType.value).toEqual(coverAmount);
      });

      it('should set flag relating to mode', () => {
        component.mode = CoverMode.CHANGE;
        component.ngOnInit();

        expect(component.isChangeMode).toBe(true);

        component.mode = CoverMode.DECREASE;
        component.ngOnInit();

        expect(component.isChangeMode).toBe(false);
      });

      it('should call getShowChangeMsg', () => {
        spyOn(component, 'getShowChangeMsg');

        component.ngOnInit();

        expect(component.getShowChangeMsg).toHaveBeenCalled();
      });
    });

    describe('setAemMessages', () => {
      it('should populate correct messages', () => {
        component.setAemMessages();

        expect(component.exclusionsAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[0].data.description);
        expect(component.preExistingConditionsAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[1].data.description);
        expect(component.customisedInsuranceAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[2].data.description);
        expect(component.decreaseSelectionAemMessage).toBe(MOCK_AEM_CONTENT_OPTIONS[3].data.description);
      });
    });

    describe('ngAfterViewInit', () => {
      it('asks parent to reset focus', () => {
        spyOn(component.resetFocus, 'emit');

        component.ngAfterViewInit();

        expect(component.resetFocus.emit).toHaveBeenCalled();
      });
    });

    describe('checkCoverAmount', () => {
      beforeEach(() => {
        component.ngOnInit();
      });

      it('should detect form changes', () => {
        component.insuranceRates = INSURANCE_RATES;
        component.insurance = INSURANCE_POLICY;
        const coverTypeFormValue = {
          description:
            'Retains Death cover only and cancels your TPD if you have bundled Death and TPD cover. Death cover pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.',
          policyName: 'Death cover',
          policyType: PolicyType.DEATH
        };
        const selectedCoverLevel: CoverTypeSelected['coverLevels'] = ['Triple', 'Single'];
        const selectedCoverAmounts: SelectCoverAmount[] = [
          {
            coverSubTypeId: '93',
            coverAmountName: 'Single cover',
            coverAmountType: 'Single',
            coverAmount: 37500,
            premium: '2.61',
            increase: false
          },
          {
            coverSubTypeId: '95',
            coverAmountName: 'Triple cover',
            coverAmountType: 'Triple',
            coverAmount: 112500,
            premium: '7.82',
            increase: true
          }
        ];
        const currentCoverType: CoverAmountOptions = {
          policyType: PolicyType.DEATH,
          coverLevel: 'Double',
          coverTypeSelected: [
            {
              coverType: PolicyType.DEATH,
              coverLevels: ['Triple', 'Single']
            },
            {
              coverType: PolicyType.DEATH_AND_TPD,
              coverLevels: ['Single', 'Double', 'Triple']
            }
          ]
        };
        component.currentCoverType = currentCoverType;
        const preExistingControl = component.changeCoverSelection.controls['coverType'];
        component.changeCoverSelection.controls.coverAmountType.setValue('Double');
        preExistingControl.setValue(coverTypeFormValue);
        expect(preExistingControl.valid).toBeTruthy();
        expect(component.selectCoverAmounts).toEqual(selectedCoverAmounts);
        expect(component.selectedCoverLevel).toEqual(selectedCoverLevel);
        expect(component.changeCoverSelection.controls.coverAmountType.value).toEqual('');
      });
    });

    describe('setSelectedCoverTypes', () => {
      beforeEach(() => {
        component.selectCoverTypes = ALL_SELECTED_COVER_TYPES;
      });

      it('it should filter selected cover types', () => {
        component.currentCoverType = CURRENT_COVER_TYPE;

        component.setSelectedCoverTypes();

        expect(component.selectCoverTypes.length).toEqual(2);
      });

      it('it should not filter cover types when not current cover types', () => {
        component.currentCoverType = undefined;

        component.setSelectedCoverTypes();

        expect(component.selectCoverTypes.length).toEqual(2);
      });

      it('it should not filter cover types when not select cover types', () => {
        component.currentCoverType = CURRENT_COVER_TYPE;
        component.currentCoverType.coverTypeSelected = undefined;

        component.setSelectedCoverTypes();

        expect(component.selectCoverTypes.length).toEqual(2);
      });
    });

    describe('getShowDecreaseMsg', () => {
      beforeEach(() => {
        component.account = MOCK_ACCOUNT;
        component.insurance = INSURANCE_POLICY_DEATH_TRIPLE;
      });

      it('it should update showDecreaseMsg flag as true for decrease mode', () => {
        component.mode = CoverMode.DECREASE;
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(91);
        component.getShowDecreaseMsg();
        expect(component.showDecreaseMsg).toBe(true);
      });

      it('it should update showDecreaseMsg flag as false for change mode', () => {
        component.mode = CoverMode.CHANGE;
        component.getShowDecreaseMsg();
        expect(component.showDecreaseMsg).toBe(false);
      });
    });

    describe('showDecreaseMsgStatus ', () => {
      it('decrease show msg status should return true for triple death cover with all satified conditions', () => {
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
        const result: boolean = component.showDecreaseMsgStatus(TRIPLE_DEATH_INSURANCE_POLICY, CHANGE_COVER_ACC);
        expect(result).toBe(true);
      });

      it('decrease show msg status should return false for single death cover with all satified conditions', () => {
        const result: boolean = component.showDecreaseMsgStatus(SINGLE_DEATH_INSURANCE_POLICY, CHANGE_COVER_ACC);
        expect(result).toBe(false);
      });

      it('decrease show msg status should return true for triple death and TPD cover with all satified conditions', () => {
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
        const result: boolean = component.showDecreaseMsgStatus(
          TRIPLE_DEATH_AND_TPD_INSURANCE_POLICY,
          CHANGE_COVER_ACC
        );
        expect(result).toBe(true);
      });

      it('decrease show msg status should return false for single death and TPD cover with all satified conditions', () => {
        const result: boolean = component.showDecreaseMsgStatus(
          SINGLE_DEATH_AND_TPD_INSURANCE_POLICY,
          CHANGE_COVER_ACC
        );
        expect(result).toBe(false);
      });

      it('decrease show msg status should return false if age is greater than 60', () => {
        const result: boolean = component.showDecreaseMsgStatus(TRIPLE_DEATH_INSURANCE_POLICY_AGE_67, CHANGE_COVER_ACC);
        expect(result).toBe(false);
      });

      it('decrease show msg status should return false if activation date is less than 90 days', () => {
        const changeAcc = MOCK_ACCOUNT;

        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(85);
        const result: boolean = component.showDecreaseMsgStatus(TRIPLE_DEATH_AND_TPD_INSURANCE_POLICY, changeAcc);
        expect(result).toBe(false);
      });
    });

    describe('getShowChangeMsg', () => {
      beforeEach(() => {
        component.account = MOCK_ACCOUNT;
        component.insurance = MOCK_CHANGE_COVER_SELECTION_POLICIES[1];
      });

      it('it should update showChangeMsg flag as true for change mode', () => {
        component.mode = CoverMode.CHANGE;
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(80);
        component.getShowChangeMsg();
        expect(component.showChangeMsg).toBe(true);
      });

      it('it should update showChangeMsg flag as false for decrease mode', () => {
        component.mode = CoverMode.DECREASE;
        component.getShowChangeMsg();
        expect(component.showChangeMsg).toBe(false);
      });
    });

    describe('showChangeMsgStatus ', () => {
      it('should return false if age is greater than 60, policy is customised, customer type is not retail, status is not IN_FORCE or PENDING', () => {
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(50);
        const result = component.showChangeMsgStatus(
          MOCK_CHANGE_COVER_SELECTION_POLICIES[0],
          MOCK_CHANGE_COVER_SELECTION_ACC
        );
        expect(result).toBe(false);
      });

      it('should return true if age is less than 60, policy is not customised, customer type is retail, status is IN_FORCE or PENDING', () => {
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(50);
        const result = component.showChangeMsgStatus(
          MOCK_CHANGE_COVER_SELECTION_POLICIES[1],
          MOCK_CHANGE_COVER_SELECTION_ACC
        );
        expect(result).toBe(true);
      });

      it('should return false if activation date is not within 90 days', () => {
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
        const result: boolean = component.showChangeMsgStatus(
          MOCK_CHANGE_COVER_SELECTION_POLICIES[1],
          MOCK_CHANGE_COVER_SELECTION_ACC
        );
        expect(result).toBe(false);
      });

      it('should return true if activation date is within 90 days', () => {
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(85);
        const result: boolean = component.showChangeMsgStatus(
          MOCK_CHANGE_COVER_SELECTION_POLICIES[1],
          MOCK_CHANGE_COVER_SELECTION_ACC
        );
        expect(result).toBe(true);
      });
    });

    describe('submitForm', () => {
      it('should call emit function of reviewComplete output event for Change Cover', () => {
        component.mode = CoverMode.CHANGE;
        spyOn(component.reviewComplete, 'emit');

        component.submitForm();

        expect(component.reviewComplete.emit).toHaveBeenCalled();
      });

      it('should call emit function of reviewComplete output event for Decrease Cover', () => {
        component.mode = CoverMode.DECREASE;
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
        spyOn(component.reviewComplete, 'emit');

        component.submitForm();

        expect(component.reviewComplete.emit).toHaveBeenCalled();
      });
    });

    describe('cancel', () => {
      it('should call emit function of navigate output event', () => {
        spyOn(component.navigate, 'emit');

        component.cancel();

        expect(component.navigate.emit).toHaveBeenCalled();
      });
    });

    describe('openExclusionsDialog', () => {
      it('should open dialog with expected settings', () => {
        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        const expectedConfig = {
          ...DIALOG_CONFIG.DEFAULT,
          autoFocus: false,
          ariaLabel: 'Open exclusions information dialog',
          data: {
            headerText: EXCLUSIONS_HEADER,
            descriptionText: MOCK_AEM_CONTENT_OPTIONS[0].data.description,
            closeButton: CLOSE_TEXT_BUTTON,
            closeIcon: CLOSE_ICON_BUTTON
          }
        };

        component.openExclusionsDialog();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoContentDialogComponent, expectedConfig);
      });
    });

    describe('openPreExistingConditionsDialog', () => {
      it('should open dialog with expected settings', () => {
        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        const expectedConfig = {
          ...DIALOG_CONFIG.DEFAULT,
          autoFocus: false,
          ariaLabel: 'Open pre-existing conditions information dialog',
          data: {
            headerText: PRE_EXISTING_CONDITIONS_HEADER,
            descriptionText: MOCK_AEM_CONTENT_OPTIONS[1].data.description,
            closeButton: CLOSE_TEXT_BUTTON,
            closeIcon: CLOSE_ICON_BUTTON
          }
        };

        component.openPreExistingConditionsDialog();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoContentDialogComponent, expectedConfig);
      });
    });

    describe('openCustomisedInsuranceDialog', () => {
      it('should open dialog with expected settings', () => {
        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        const expectedConfig = {
          ...DIALOG_CONFIG.DEFAULT,
          autoFocus: false,
          ariaLabel: 'Open customised cover information dialog',
          data: {
            headerText: CUSTOMISED_INSURANCE_HEADER,
            descriptionText: MOCK_AEM_CONTENT_OPTIONS[2].data.description,
            closeButton: CLOSE_TEXT_BUTTON,
            closeIcon: CLOSE_ICON_BUTTON
          }
        };

        component.openCustomisedInsuranceDialog();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoContentDialogComponent, expectedConfig);
      });
    });
  });

  describe('View', () => {
    beforeEach(() => {
      component.account = MOCK_ACCOUNT;
      component.account.firstMoneyReceivedDate = '2020-10-04T16:00:00.000Z';
      component.insurance = INSURANCE_POLICY;
      component.mode = CoverMode.CHANGE;
      component.currentCoverType = CURRENT_COVER_TYPE;
      component.selectCoverTypes = SELECT_COVER_TYPES;
      const coverType = {
        policyName: 'name',
        policyType: 'type',
        description: 'desc'
      };
      const coverAmount = {
        coverSubTypeId: 'id',
        coverAmount: 0,
        coverAmountName: 'name',
        coverAmountType: 'type',
        premium: '0',
        increase: true
      };
      component.newCoverType = {
        coverType,
        coverAmountType: coverAmount
      };
      component.insuranceRates = INSURANCE_RATES;
      fixture.detectChanges();
    });

    it('should show all the insurance details correctly', () => {
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-name')).nativeElement.innerHTML).toEqual(
        'Income Protection'
      );
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-qualifier-name')).nativeElement.innerHTML).toEqual(
        'Salary continuance cover'
      );
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-cover-level')).nativeElement.innerHTML).toEqual(
        'Double cover'
      );
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-sum-insured')).nativeElement.innerText).toEqual(
        '$4,521.00'
      );
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-premium')).nativeElement.innerHTML).toEqual(
        '$0.00'
      );
    });

    it('should have cover Amount Change As Get Older Link', () => {
      const el = fixture.debugElement.query(By.css('.js-test-cover-amount-change-as-get-older-link'));

      expect(el.nativeElement.innerText).toBeTruthy();
    });

    it('should have pre existing conditions button', () => {
      const el = fixture.debugElement.query(By.css('.js-test-pre-existing-conditions'));

      expect(el.nativeElement.innerText).toBe('pre-existing conditions');
    });

    it('should have not be covered for certain events button', () => {
      const el = fixture.debugElement.query(By.css('.js-test-no-be-covered'));

      expect(el.nativeElement.innerText).toBe('not be covered for certain events');
    });

    it('should have customised cover button', () => {
      panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);
      component.mode = 'change';
      component.ngOnInit();
      fixture.detectChanges();
      const elPara = fixture.debugElement.query(By.css('p'));
      const elBtn = fixture.debugElement.query(By.css('.js-test-customised-cover'));

      expect(elPara).toBeTruthy();
      expect(elBtn.nativeElement.innerText).toBe('Customised cover');
    });

    it('should show the correct options on radio button', () => {
      const firstRadioButton = fixture.debugElement.queryAll(By.css('mat-radio-button'))[0];
      const secondRadioButton = fixture.debugElement.queryAll(By.css('mat-radio-button'))[1];

      expect(firstRadioButton.nativeElement.innerHTML).toContain(
        'Death and Total &amp; Permanent Disability/Disablement (TPD)'
      );
      expect(secondRadioButton.nativeElement.innerHTML).toContain('Death cover');
    });

    it('should hide details if insurance rates have not loaded', () => {
      component.insuranceRates = undefined;
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-name'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-qualifier-name'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-cover-level'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-sum-insured'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.ts-insurance-policy-premium'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-no-rates-cancel'))).not.toBeNull();
    });
  });
});
