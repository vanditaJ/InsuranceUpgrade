export interface AemFeesContent {
  type: string;
  data: AemCohort[];
}

export interface AemCohort {
  type: string;
  name: string;
  data: AemInvestmentFee[];
}

export interface AemInvestmentFee {
  cohort: string;
  investmentName: string;
  apirCode: string;
  indirectCosts: number;
  otherFees: number;
  borrowingCosts: number;
  lifestage: boolean;
}

export interface AemRichTextItem {
  data?: string;
}

export interface AemTextItem {
  data: {
    headerText: string;
    description: string;
  };
}
