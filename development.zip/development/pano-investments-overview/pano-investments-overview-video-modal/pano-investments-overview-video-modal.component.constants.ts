import { Button } from '@bt/components/button';

export const DIALOG_CLOSE_BUTTON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  size: 'medium',
  colourModifier: 'basic'
};
