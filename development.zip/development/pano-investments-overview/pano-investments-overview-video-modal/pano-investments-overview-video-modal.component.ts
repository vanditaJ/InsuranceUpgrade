import { Component, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

import { DIALOG_CLOSE_BUTTON } from '../../pano-insurance/pano-insurance-policies/pano-pys-optin-all/pano-pys-opt-in-all.component.constants';

@Component({
  selector: 'pano-investments-overview-video-modal',
  templateUrl: './pano-investments-overview-video-modal.component.html'
})
export class PanoInvestmentsOverviewVideoModalComponent {
  @Input() apirCode: string;
  readonly dialogCloseButton: Button = DIALOG_CLOSE_BUTTON;

  constructor(
    readonly dialogRef: MatDialogRef<PanoInvestmentsOverviewVideoModalComponent>,
    @Inject(MAT_DIALOG_DATA)
    public readonly data: {
      content: string;
      heading: string;
    }
  ) {}
}
