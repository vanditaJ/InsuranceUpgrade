import { Button } from '@bt/components/button';

export const CLOSE_DIALOG_BUTTON: Button = {
  action: 'button',
  label: 'Close',
  size: 'large',
  type: 'outline',
  shapeModifier: 'square',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Close'
  }
};

export const CLOSE_DIALOG_BUTTON_ICON: Button = {
  action: 'button',
  icon: { name: 'icon-cross' },
  size: 'small',
  colourModifier: 'basic',
  type: 'flat'
};
