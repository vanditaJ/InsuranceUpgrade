import { CommonModule, Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, NO_ERRORS_SCHEMA, SimpleChange } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormArray, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import { cloneDeep, each } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of, throwError } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import {
  ASSET_PRICE_VALUATION_DETAILS,
  TEST_LS_ASSETS_FORM_ARRAY
} from '../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { ASSET_TYPES, PANO_DATE_FORMATS } from '../pano-external-assets-constants/pano-external-assets.constants';
import { PanoExternalAssetsService } from '../pano-external-assets.service';

import { PanoExternalAssetsListedSecurityComponent } from './pano-external-assets-listed-security.component';

@Component({
  template: `
    <pano-external-assets-listed-security
      [lsFormArray]="lsFormArray"
      [assetCount]="assetCount"
      (assetDelete)="testAssetDelete($event)"
      (assetTotalMarketValueUpdate)="testAssetTotalMarketValue($event)"
    >
    </pano-external-assets-listed-security>
  `
})
class TestHostComponent {
  assetDetail = null;
  assetTotal = null;
  lsFormArray: FormArray = TEST_LS_ASSETS_FORM_ARRAY as FormArray;
  assetCount: number = TEST_LS_ASSETS_FORM_ARRAY['controls'].length;

  testAssetDelete(assetDetail): void {
    this.assetDetail = assetDetail;
  }
  testAssetTotalMarketValue(assetTotal): void {
    this.assetTotal = assetTotal;
  }
}

describe('PanoExternalAssetsListedSecurityComponent', () => {
  let component: PanoExternalAssetsListedSecurityComponent;
  let externalAssetService: PanoExternalAssetsService;
  let fixture: ComponentFixture<PanoExternalAssetsListedSecurityComponent>;
  let panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoExternalAssetsListedSecurityComponent, TestHostComponent],
        providers: [
          Location,
          { provide: LocationStrategy, useClass: PathLocationStrategy },
          PanoExternalAssetsService,
          PanoExternalAssetsCommonUtil,
          { provide: MAT_DATE_FORMATS, useValue: PANO_DATE_FORMATS },
          { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] }
        ],
        imports: [
          CommonModule,
          HttpClientTestingModule,
          MatDatepickerModule,
          MatInputModule,
          MatMomentDateModule,
          NoopAnimationsModule,
          ReactiveFormsModule,
          DataModule,
          PipesTestingModule
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoExternalAssetsListedSecurityComponent);
    externalAssetService = TestBed.inject(PanoExternalAssetsService);
    panoExtAssetsCommonUtil = TestBed.inject(PanoExternalAssetsCommonUtil);
    component = fixture.componentInstance;
  });

  describe('component', () => {
    beforeEach(() => {
      component.lsFormArray = cloneDeep(TEST_LS_ASSETS_FORM_ARRAY) as FormArray;
    });

    it('should accept the inputs and transmit the outputs correctly', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const hostComponent: TestHostComponent = hostFixture.componentInstance;
      hostFixture.detectChanges();

      const mockFormArray = TEST_LS_ASSETS_FORM_ARRAY as FormArray;
      const cmp = hostFixture.debugElement.query(By.directive(PanoExternalAssetsListedSecurityComponent))
        .componentInstance;
      expect(cmp.lsFormArray).toEqual(mockFormArray);
      expect(cmp.assetCount).toBe(mockFormArray['controls'].length);

      const assetToDelete = {
        index: 0,
        assetType: ASSET_TYPES.ls.code,
        positionId: mockFormArray['controls'][0].get('positionId').value,
        isNewAsset: mockFormArray['controls'][0].get('isNewAsset').value
      };
      const assetTotalMarketValueUpdate = {
        assetTypeTotalMarketValue: 12,
        assetTypeCode: ASSET_TYPES.ls.code
      };

      spyOn(hostComponent, 'testAssetDelete');
      cmp.assetDelete.emit(assetToDelete);
      expect(hostComponent.testAssetDelete).toHaveBeenCalledWith(assetToDelete);

      spyOn(hostComponent, 'testAssetTotalMarketValue');
      cmp.assetTotalMarketValueUpdate.emit(assetTotalMarketValueUpdate);
      expect(hostComponent.testAssetTotalMarketValue).toHaveBeenCalledWith(assetTotalMarketValueUpdate);
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('ngOnDestroy()', () => {
      it('should unsubscribe all subscriptions', () => {
        spyOn(component, 'calculateTotal');
        spyOn(component, 'unregisterControlsValueChanges');
        spyOn((component as any).assetLatestPriceSubscription, 'unsubscribe');

        component.ngOnDestroy();

        expect(component.calculateTotal).toHaveBeenCalled();
        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
        expect((component as any).assetLatestPriceSubscription.unsubscribe).toHaveBeenCalled();
      });
    });

    describe('on changes', () => {
      beforeEach(() => {
        spyOn(component, 'unregisterControlsValueChanges');
        spyOn(component, 'registerControlsValueChanges');
        spyOn(component, 'calculateTotal');
      });
      it('should call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when assetCount get changed, that is add, delete an asset', () => {
        component.ngOnChanges({ assetCount: new SimpleChange(0, 1, true) });

        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
        expect(component.registerControlsValueChanges).toHaveBeenCalled();
        expect(component.calculateTotal).toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when assetCount is not changed', () => {
        component.ngOnChanges({ assetCount: new SimpleChange(1, 1, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });

      it('should call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when FormArray get changed, that is on componet init or save api gives new data', () => {
        component.ngOnChanges({ lsFormArray: new SimpleChange([], cloneDeep(TEST_LS_ASSETS_FORM_ARRAY), true) });

        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
        expect(component.registerControlsValueChanges).toHaveBeenCalled();
        expect(component.calculateTotal).toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when FormArray is not changed', () => {
        const mockFormArray = [];
        component.ngOnChanges({ lsFormArray: new SimpleChange(mockFormArray, mockFormArray, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when any other input get changed', () => {
        component.ngOnChanges({ someother: new SimpleChange(1, 2, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });
    });

    describe('registerControlsValueChanges', () => {
      describe('when asset is not panorama asset, isPanoramaAsset false', () => {
        beforeEach(() => {
          component.lsFormArray = cloneDeep(TEST_LS_ASSETS_FORM_ARRAY) as FormArray;
          component.lsFormArray.controls[0].get('isPanoramaAsset').setValue(false);
        });
        it('should add marketValue valueChanges subscriptions to controlsValueChangesSubscriptions', () => {
          expect((component as any).controlsValueChangesSubscriptions.length).toBe(0);

          component.registerControlsValueChanges();

          expect((component as any).controlsValueChangesSubscriptions.length).toBe(1);
        });

        it('should call calculateTotal when marketValue get changed', () => {
          spyOn(component, 'calculateTotal');
          component.registerControlsValueChanges();

          component.lsFormArray.controls[0].get('marketValue').setValue(10);
          expect(component.calculateTotal).toHaveBeenCalled();
        });

        it('should not  calculateTotal when marketValue get changed as an invalid value', () => {
          spyOn(component, 'calculateTotal');
          component.registerControlsValueChanges();

          component.lsFormArray.controls[0].get('marketValue').setValue('adasd');
          expect(component.calculateTotal).not.toHaveBeenCalled();
        });
      });

      describe('when asset is panorama asset, isPanoramaAsset true', () => {
        beforeEach(() => {
          component.lsFormArray = cloneDeep(TEST_LS_ASSETS_FORM_ARRAY) as FormArray;
          component.lsFormArray.controls[0].get('isPanoramaAsset').setValue(true);
        });
        it('should add quantity valueChanges subscriptions to controlsValueChangesSubscriptions', () => {
          expect((component as any).controlsValueChangesSubscriptions.length).toBe(0);

          component.registerControlsValueChanges();

          expect((component as any).controlsValueChangesSubscriptions.length).toBe(1);
        });

        it('should call updateAssetDetails when quantity get changed, also set isLastPriceLoading to true and disable the formgroup', () => {
          spyOn(component, 'updateAssetDetails');
          component.registerControlsValueChanges();

          component.lsFormArray.controls[0].get('quantity').setValue(5);
          expect(component.updateAssetDetails).toHaveBeenCalled();
          expect(component.lsFormArray.controls[0].disabled).toBe(true);
          expect(component.lsFormArray.controls[0].get('isLastPriceLoading').value).toBe(true);
        });

        it('should not call updateAssetDetails when quantity get changed as an invalid quantity', () => {
          spyOn(component, 'updateAssetDetails');
          component.registerControlsValueChanges();

          component.lsFormArray.controls[0].get('quantity').setValue('asdad');
          expect(component.updateAssetDetails).not.toHaveBeenCalled();
        });
      });
    });

    describe('unregisterControlsValueChanges', () => {
      it('should call unregisterAssetEditControlsValueChanges of PanoExternalAssetsCommonUtil to unsubscribe all valuechange subcribtion of controlsValueChangesSubscriptions', () => {
        spyOn(panoExtAssetsCommonUtil, 'unregisterAssetEditControlsValueChanges').and.returnValue([]);

        component.unregisterControlsValueChanges();

        expect(panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges).toHaveBeenCalledWith(
          (component as any).controlsValueChangesSubscriptions
        );
        expect((component as any).controlsValueChangesSubscriptions.length).toBe(0);
      });
    });

    describe('deleteListedSecurity', () => {
      it('should call deleteAsset', () => {
        spyOn(panoExtAssetsCommonUtil, 'deleteAsset');
        expect(component.lsFormArray.length).toBe(1);

        const deletedFormGroup = TEST_LS_ASSETS_FORM_ARRAY.controls[0] as FormGroup;

        component.deleteListedSecurity(
          0,
          deletedFormGroup.get('positionId').value,
          deletedFormGroup.get('isNewAsset').value
        );

        expect(panoExtAssetsCommonUtil.deleteAsset).toHaveBeenCalledWith(
          {
            index: 0,
            assetTypeCode: ASSET_TYPES.ls.code,
            positionId: deletedFormGroup.get('positionId').value,
            isNewAsset: deletedFormGroup.get('isNewAsset').value
          },
          component.assetDelete
        );
      });
    });

    describe('calculateTotal', () => {
      it('should call calculateAssetTypeTotalMarketValue of PanoExternalAssetsCommonUtil', () => {
        spyOn(panoExtAssetsCommonUtil, 'calculateAssetTypeTotalMarketValue').and.returnValue(300);

        component.calculateTotal();

        expect(panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue).toHaveBeenCalledWith(
          component.lsFormArray,
          ASSET_TYPES.ls.code,
          component.assetTotalMarketValueUpdate
        );
        expect(component.totalMarketValue).toBe(300);
      });
    });

    describe('updateAssetDetails', () => {
      let externalAssetServiceSpy;
      let mockFormGroup;

      beforeEach(() => {
        spyOn(component, 'calculateTotal');
        externalAssetServiceSpy = spyOn(externalAssetService, 'getAssetLatestPrice');
        mockFormGroup = cloneDeep(TEST_LS_ASSETS_FORM_ARRAY.controls[0]);
      });

      afterEach(() => {
        externalAssetServiceSpy.calls.reset();
      });

      it('should set marketValue, valuationDate using API response results, call calculateTotal and set isLastPriceLoading of that asset to false and enable the formgroup', () => {
        const responseResult = ASSET_PRICE_VALUATION_DETAILS;

        externalAssetServiceSpy.and.returnValue(of(responseResult));

        component.updateAssetDetails(mockFormGroup);

        const newMarketValue = (responseResult.lastPrice * mockFormGroup.get('quantity').value).toFixed(2);
        expect(externalAssetService.getAssetLatestPrice).toHaveBeenCalled();
        expect(mockFormGroup.get('marketValue').value).toBe(newMarketValue);
        expect(mockFormGroup.get('valuationDate').value).toEqual(
          moment(responseResult.valuationDate).tz('Australia/Sydney')
        );
        expect(component.calculateTotal).toHaveBeenCalled();
        expect(component.lsFormArray.controls[0].enabled).toBe(true);
        expect(component.lsFormArray.controls[0].get('isLastPriceLoading').value).toBe(false);
      });

      it('should set up error message on API response error', () => {
        externalAssetServiceSpy.and.returnValue(throwError(null));

        component.updateAssetDetails(mockFormGroup);

        expect(externalAssetService.getAssetLatestPrice).toHaveBeenCalled();
        expect(mockFormGroup.get('marketValue').value).toBe('');
        expect(mockFormGroup.get('valuationDate').value).toBe('');
        expect(component.calculateTotal).toHaveBeenCalled();
      });
    });

    describe('formatDateForDisplay', () => {
      it('should return formated date', () => {
        const expectedResult = component.formatDateForDisplay(
          TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('valuationDate')
        );
        expect(expectedResult).toBe(
          moment(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value).format('DD MMM YYYY')
        );
      });
    });
  });

  describe('view', () => {
    it('should hide the section element when no controls are there', () => {
      expect(fixture.debugElement.query(By.css('section'))).toBeFalsy();
    });

    it('should hide the section element when FormArray is empty', () => {
      component.lsFormArray = new FormArray([]);
      expect(fixture.debugElement.query(By.css('section'))).toBeFalsy();
    });

    describe('btToggleClassByBreakpoint', () => {
      beforeEach(() => {
        const mockFormArray = cloneDeep(TEST_LS_ASSETS_FORM_ARRAY);
        component.lsFormArray = mockFormArray as FormArray;
        fixture.detectChanges();
      });

      it('it should have btToggleClassByBreakpoint directive on "Source" header column', () => {
        const sourceColEl = fixture.debugElement.query(By.css('th:nth-child(2'));
        expect(sourceColEl.properties.btToggleClassByBreakpoint).toEqual({
          breakpoints: ['md'],
          classNames: ['sr-only']
        });
      });

      it('it should have btToggleClassByBreakpoint directive on "Source" cell', () => {
        const sourceColEls = fixture.debugElement.queryAll(By.css('tbody tr td:nth-child(2)'));
        each(sourceColEls, el =>
          expect(el.properties.btToggleClassByBreakpoint).toEqual({ breakpoints: ['md'], classNames: ['sr-only'] })
        );
      });
    });

    describe('when controls are available', () => {
      beforeEach(() => {
        component.lsFormArray = cloneDeep(TEST_LS_ASSETS_FORM_ARRAY) as FormArray;
        fixture.detectChanges();
      });

      it('should show the section, header and table when controls are available', () => {
        expect(fixture.debugElement.query(By.css('section'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-header'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-table'))).toBeTruthy();
      });

      it('should show the header label and table headings and total market value label when assets are available', () => {
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-header')).nativeElement.innerHTML).toBe(
          'Australian shares'
        );
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-header-investment')).nativeElement.innerHTML
        ).toBe('Asset');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-header-source')).nativeElement.innerHTML
        ).toBe('Source');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-header-valuation-date')).nativeElement
            .innerHTML
        ).toBe('Valuation date');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-header-quantity')).nativeElement.innerHTML
        ).toBe('Quantity');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-header-market-value')).nativeElement.innerHTML
        ).toBe('Market value');
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-total-label')).nativeElement.innerHTML).toBe(
          'Total australian shares'
        );
      });

      it('should hide all Errors by default', () => {
        expect(fixture.debugElement.queryAll(By.css('mat-error')).length).toBe(0);
      });

      it('should show the data', () => {
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-row-cell-asset-name-0')).nativeElement
            .innerHTML
        ).toBe(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('positionName').value);
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-row-cell-asset-code-0')).nativeElement
            .innerHTML
        ).toBe(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('positionCode').value);
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-table-row-cell-source-0')).nativeElement.innerHTML
        ).toBe(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('source').value);
        expect(
          moment(
            fixture.debugElement.query(By.css('.js-test-extassets-ls-form-input-value-date-0')).nativeElement.value,
            'DD MMM YYYY'
          ).format('DD MMM YYYY')
        ).toBe(
          moment(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value, 'DD MMM YYYY').format('DD MMM YYYY')
        );
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-form-label-value-date-0'))).toBeFalsy();
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-form-input-quantity-0')).nativeElement.value
        ).toBe(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('quantity').value);
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-ls-form-input-market-value-0')).nativeElement.value
        ).toBe(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value);
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-form-label-market-value-0'))).toBeFalsy();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-table-row-cell-delete-0'))).toBeTruthy();
      });

      it('should show the total marketvalue', () => {
        component.totalMarketValue = 26.84;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-total')).nativeElement.innerHTML).toBe(
          '$26.84'
        );
      });

      describe('bt-button', () => {
        it('should show with the correct config and event handlers attached', () => {
          const button = fixture.debugElement.query(By.css('.js-test-extassets-ls-table-row-cell-delete-0'));
          const deletedFormGroup = TEST_LS_ASSETS_FORM_ARRAY.controls[0] as FormGroup;

          expect(button.nativeElement).toBeTruthy();
          expect(button.properties.config).toEqual(component.deleteButton);
          expect(button.properties.disabled).toBe(false);

          spyOn(component, 'deleteListedSecurity');
          button.nativeElement.dispatchEvent(new Event('btClick'));
          expect(component.deleteListedSecurity).toHaveBeenCalledWith(
            0,
            deletedFormGroup.get('positionId').value,
            deletedFormGroup.get('isNewAsset').value
          );
        });

        it('should disable bt-button when isLastPriceLoading is true', () => {
          component.lsFormArray.controls[0].get('isLastPriceLoading').setValue(true);
          fixture.detectChanges();

          const button = fixture.debugElement.query(By.css('.js-test-extassets-ls-table-row-cell-delete-0'));

          expect(button.nativeElement).toBeTruthy();
          expect(button.properties.config).toEqual(component.deleteButton);
          expect(button.properties.disabled).toBe(true);
        });
      });

      describe('when asset is Panorama Asset', () => {
        it('should hide valuation date and marketValue controls, show labels when asset is Panorama Asset and show as text', () => {
          component.lsFormArray.controls[0].get('isPanoramaAsset').setValue(true);
          fixture.detectChanges();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-form-input-value-date-0'))).toBeFalsy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-form-input-market-value-0'))).toBeFalsy();

          const elementValueDateLabel = fixture.debugElement.query(
            By.css('.js-test-extassets-ls-form-label-value-date-0')
          );
          const elementMarketValueLabel = fixture.debugElement.query(
            By.css('.js-test-extassets-ls-form-label-market-value-0')
          );
          expect(elementValueDateLabel).toBeTruthy();
          expect(elementValueDateLabel.nativeElement.innerHTML.trim()).toBe(
            moment(TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value).format('DD MMM YYYY')
          );
          expect(elementMarketValueLabel).toBeTruthy();
          expect(elementMarketValueLabel.nativeElement.innerHTML.trim()).toBe('$26.84');
        });

        it('should hide valuationDate label when valuationDate is empty, that is lastPrice api got failed', () => {
          component.lsFormArray.controls[0].get('isPanoramaAsset').setValue(true);
          component.lsFormArray.controls[0].get('valuationDate').setValue('');
          fixture.detectChanges();

          expect(fixture.debugElement.query(By.css('.js-test-extassets-ls-form-label-value-date-0'))).toBeFalsy();
        });

        it('should show indicator for valuationDate and marketValue when isLastPriceLoading is true ', () => {
          component.lsFormArray.controls[0].get('isPanoramaAsset').setValue(true);
          component.lsFormArray.controls[0].get('isLastPriceLoading').setValue(true);
          fixture.detectChanges();
          const valuationDateElement = fixture.debugElement.query(
            By.css('.js-test-extassets-ls-form-label-value-date-0')
          );
          const marketValueElement = fixture.debugElement.query(
            By.css('.js-test-extassets-ls-form-label-market-value-0')
          );
          expect(valuationDateElement.nativeElement.innerHTML.trim()).toBe('•••');
          expect(marketValueElement.nativeElement.innerHTML.trim()).toBe('$•••');
        });
      });
    });

    describe('validate form control', () => {
      beforeEach(() => {
        const mockFormArray = cloneDeep(TEST_LS_ASSETS_FORM_ARRAY);
        component.lsFormArray = mockFormArray as FormArray;
        component.lsFormArray.markAllAsTouched();
        fixture.detectChanges();
      });

      describe('validate marketValue', () => {
        it('should show error message when no value entered', () => {
          component.lsFormArray.controls[0].get('marketValue').setValue(null);
          fixture.detectChanges();

          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-ls-form-market-value-required-error-0')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1235');
        });

        it('should not show error message when valid value entered', () => {
          component.lsFormArray.controls[0].get('marketValue').setValue(12);
          fixture.detectChanges();

          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-ls-form-market-value-required-error-0'))
          ).toBeFalsy();
        });

        it('should show error message when min number is entered', () => {
          component.lsFormArray.controls[0].get('marketValue').setValue('0.');
          fixture.detectChanges();

          const element = fixture.debugElement.query(By.css('.js-test-extassets-ls-form-market-value-min-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1233');
        });

        it('should show error message when maximum length number is entered', () => {
          component.lsFormArray.controls[0].get('marketValue').setValue('123453457345374568743658445');
          fixture.detectChanges();

          const element = fixture.debugElement.query(By.css('.js-test-extassets-ls-form-market-value-max-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1227');
        });

        it('should show error message when invalid number is entered', () => {
          component.lsFormArray.controls[0].get('marketValue').setValue('12.3.5');
          fixture.detectChanges();

          const element = fixture.debugElement.query(By.css('.js-test-extassets-ls-form-market-value-pattern-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1236');
        });
      });

      describe('validate valuationDate', () => {
        it('should show error message when no value is entered', () => {
          component.lsFormArray.controls[0].get('valuationDate').setValue(null);
          fixture.detectChanges();

          const element = fixture.debugElement.query(By.css('.js-test-extassets-ls-form-value-date-required-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
        });

        it('should not show error message when valid value is entered', () => {
          component.lsFormArray.controls[0].get('valuationDate').setValue(moment().tz('Australia/Sydney'));
          fixture.detectChanges();

          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-ls-form-value-date-required-error-0'))
          ).toBeFalsy();
        });

        it('should show error message when future date is entered', () => {
          component.lsFormArray.controls[0].get('valuationDate').setValue(
            moment()
              .add(4, 'day')
              .tz('Australia/Sydney')
          );
          component.lsFormArray.controls[0].get('valuationDate').markAsTouched();
          fixture.detectChanges();

          const element = fixture.debugElement.query(By.css('.js-test-extassets-ls-form-value-date-max-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0386');
        });
      });

      describe('validate quantity', () => {
        it('should show error message when invalid value entered and getErrorMessagesForQuantity method should have been called', () => {
          spyOn(panoExtAssetsCommonUtil, 'getErrorMessagesForQuantity').and.returnValue('Enter a valid quantity.');
          component.lsFormArray.controls[0].get('quantity').setValue('abcdf');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-ls-form-quantity-invalid-error-0'));
          expect(panoExtAssetsCommonUtil.getErrorMessagesForQuantity).toHaveBeenCalled();
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('Enter a valid quantity.');
        });
      });
    });
  });
});
