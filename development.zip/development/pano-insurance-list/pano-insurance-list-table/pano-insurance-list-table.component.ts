import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { PanoUpgradeFeatureService } from '@upgrade/upgrade.services';
import { PanoInsuranceListOptInComponent } from '../pano-insurance-list-opt-in/pano-insurance-list-opt-in.component';
import {
  CONFIG,
  DIALOG_SUCCESS,
  INVESTOR_INSURANCE_PYSOPTIN,
  KEEP_BTN,
  KEEP_LINK
} from '../pano-insurance-list.constants';
import { IN_FORCE, IN_SUSPENSE, NOT_AVAIL } from '../pano-insurance-list.constants';
import { Policy, RelatedAccounts, StaticData } from '../pano-insurance-list.interface';
import { PanoInsuranceListService } from '../pano-insurance-list.service';

@Component({
  selector: 'pano-insurance-list-table',
  templateUrl: './pano-insurance-list-table.component.html',
  styleUrls: ['./pano-insurance-list-table.component.scss']
})
export class PanoInsuranceListTableComponent implements OnInit {
  @Input() getPolicies: Policy[];
  @Input() getRelatedAccounts: RelatedAccounts[];
  @Input() getStaticData: StaticData[];

  resultList: any;
  success = false;
  filterResultListData: any = [];
  accountId: string;
  isPysOptInInvestor: boolean;
  readonly config: any = CONFIG;
  readonly keepBtn: Button = KEEP_BTN;
  readonly keepLink: any = KEEP_LINK;
  readonly inforce: Icon = IN_FORCE;
  readonly inSuspense: Icon = IN_SUSPENSE;
  readonly notAvailable: Icon = NOT_AVAIL;
  readonly successDialog: any = DIALOG_SUCCESS;

  constructor(
    private featureService: PanoUpgradeFeatureService,
    private panoInsuranceListService: PanoInsuranceListService,
    public dialog: MatDialog
  ) {}

  openModal() {
    this.availablePoliciesForOptIn();
    const dialogRef = this.dialog.open(PanoInsuranceListOptInComponent, {
      data: this.filterResultListData
    });

    dialogRef.afterClosed().subscribe(() => {
      const index = this.panoInsuranceListService.selectedIndex;
      this.resultList.policies[index].pysDetails.optInStatus = 'PENDING';
      setTimeout(() => {
        this.success = true;
      }, 1000);
      this.availablePoliciesForOptIn();
    });
  }
  availablePoliciesForOptIn() {
    this.filterResultListData = this.resultList.policies.filter(policy => {
      if (policy.pysDetails) {
        return (
          policy.status !== 'CANCELLED' &&
          policy.status !== 'DECLINED' &&
          policy.status !== 'NOT_AVAILABLE' &&
          policy.status !== 'PROPOSAL' &&
          !policy.pysDetails.expired &&
          policy.pysDetails.optInStatus !== 'PENDING' &&
          policy.pysDetails.policyStatus !== 'Cancelled' &&
          policy.pysDetails.policyStatus !== 'Declined/Rejected' &&
          policy.pysDetails.policyStatus !== 'Proposal' &&
          policy.pysDetails.optInDate === null
        );
      }
    });
  }
  getData(receiveData: Array<any>): void {
    const result = {
      policies: receiveData[0].resultList,
      relatedAccounts: receiveData[1].resultList,
      getStaticPolicyData: receiveData[2].resultMap
    };
    this.resultList = result;
    this.resultList.policies.map((policy: any) => {
      const policyFrequency = result.getStaticPolicyData.policyStatus.find(e => e.code === policy.status);
      const policyStatus = result.getStaticPolicyData.premiumFrequency.find(e => e.code === policy.policyFrequency);
      policy.policyFrequencyLabel = policyFrequency?.label;
      policy.policyStatusLabel = policyStatus?.label;
    });
    this.resultList.relatedAccounts.map(policy2 => {
      policy2.policyList.map(policy => {
        const policyFrequency = result.getStaticPolicyData.policyStatus.find(e => e.code === policy.status);
        const policyStatus = result.getStaticPolicyData.premiumFrequency.find(e => e.code === policy.policyFrequency);
        policy.policyFrequencyLabel = policyFrequency?.label;
        policy.policyStatusLabel = policyStatus?.label;
      });
    });
    this.availablePoliciesForOptIn();
  }
  ngOnInit(): void {
    this.isPysOptInInvestor = this.featureService.hasAccess(INVESTOR_INSURANCE_PYSOPTIN);
    this.getData([this.getPolicies, this.getRelatedAccounts, this.getStaticData]);
  }
}
