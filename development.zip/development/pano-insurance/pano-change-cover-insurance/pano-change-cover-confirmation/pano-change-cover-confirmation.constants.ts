import { Alert } from '@bt/components/alert';

export const SUCCESS_CHANGE_COVER_ALERT: Alert = {
  type: 'success',
  outline: true,
  messages: {
    message: 'Your change has been completed.'
  },
  a11yProps: {
    ariaRole: 'none'
  }
};

export const SUCCESS_DECREASE_REQUEST_COVER_ALERT: Alert = {
  type: 'success',
  outline: true,
  messages: {
    message: "We've received your request to decrease your cover."
  },
  a11yProps: {
    ariaRole: 'none'
  }
};

export const CHANGE_INCREASE_ACTIVE_COVER_CONFIRM_AEM_KEY: string = 'change_cover_confirm_useful_info_active_increase';

export const CHANGE_REDUCE_ACTIVE_COVER_CONFIRM_AEM_KEY: string = 'change_cover_confirm_useful_info_active_decrease';

export const CHANGE_PENDING_COVER_CONFIRM_AEM_KEY: string = 'change_cover_confirm_useful_info_pending';

export const DECREASE_COVER_CONFIRM_AEM_KEY: string = 'decrease_cover_confirm_useful_info';

export const DECREASE_REQUEST_COVER_CONFIRM_AEM_KEY: string = 'decrease_cover_confirm_useful_info_earthrise';

export const DECREASE_REQUEST_SCI_COVER_CONFIRM_AEM_KEY: string = 'decrease_cover_confirm_useful_info_sci_earthrise';
