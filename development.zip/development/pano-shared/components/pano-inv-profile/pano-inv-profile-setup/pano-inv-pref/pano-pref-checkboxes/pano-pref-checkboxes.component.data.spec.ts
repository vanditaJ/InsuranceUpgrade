import { CheckboxField } from '../pano-inv-pref.interface';

export const MOCK_CHECKBOX_FIELDS: CheckboxField[] = [
  { name: 'SHORT', value: true, descripton: 'Short (less than 2 years)' },
  { name: 'MEDIUM', value: true, descripton: 'Medium (2 to 8 years)' },
  { name: 'LONG', value: false, descripton: 'Long (8 or more years)' }
];
