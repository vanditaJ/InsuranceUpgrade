import { Loading } from '@bt/components/loading';

export const SAVE_PROFILE_LOADING: Loading = {
  type: 'content',
  spinnerSize: 'x-large'
};

export const LOADING_TITLE: string = 'Saving your investment profile';
