import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { AbstractControl, FormArray, FormControl, FormGroup } from '@angular/forms';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of } from 'rxjs';
import { Subscription } from 'rxjs/internal/Subscription';
import { finalize } from 'rxjs/operators';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import {
  ASSET_TYPES,
  DATE_PICKER_ICON,
  DELETE_BUTTON,
  SR_ONLY_BREAKPOINTS
} from '../pano-external-assets-constants/pano-external-assets.constants';
import {
  AssetLatestPrice,
  AssetTypeTotalDetails,
  ExternalAssetDeleteDetails
} from '../pano-external-assets.interfaces';
import { PanoExternalAssetsService } from '../pano-external-assets.service';

@Component({
  selector: 'pano-external-assets-listed-security',
  templateUrl: './pano-external-assets-listed-security.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoExternalAssetsListedSecurityComponent implements OnChanges, OnDestroy {
  @Input() lsFormArray: FormArray;
  @Input() assetCount: number;

  @Output()
  assetDelete: EventEmitter<ExternalAssetDeleteDetails> = new EventEmitter();
  @Output()
  assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails> = new EventEmitter();

  datePickerIcon: Icon = DATE_PICKER_ICON;
  deleteButton: Button = DELETE_BUTTON;
  srOnlyBreakpoints = SR_ONLY_BREAKPOINTS;
  today: Date = moment().tz('Australia/Sydney');
  totalMarketValue: number;

  private controlsValueChangesSubscriptions: Subscription[] = [];
  private assetLatestPriceSubscription: Subscription = of(null).subscribe();

  constructor(
    private externalAssetService: PanoExternalAssetsService,
    private panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil
  ) {}

  ngOnDestroy(): void {
    this.calculateTotal();
    this.unregisterControlsValueChanges();
    this.assetLatestPriceSubscription.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      get(changes, 'assetCount.currentValue') !== get(changes, 'assetCount.previousValue') ||
      get(changes, 'lsFormArray.currentValue') !== get(changes, 'lsFormArray.previousValue')
    ) {
      this.unregisterControlsValueChanges();
      this.registerControlsValueChanges();
      this.calculateTotal();
    }
  }

  registerControlsValueChanges(): void {
    this.lsFormArray.controls.forEach(fg => {
      if (fg.get('isPanoramaAsset').value) {
        this.controlsValueChangesSubscriptions.push(
          fg.get('quantity').valueChanges.subscribe(() => {
            if (fg.get('quantity').valid) {
              fg.disable({ emitEvent: false });
              fg.get('isLastPriceLoading').setValue(true);
              this.updateAssetDetails(fg as FormGroup);
            }
          })
        );
      } else {
        this.controlsValueChangesSubscriptions.push(
          fg.get('marketValue').valueChanges.subscribe(() => {
            if (fg.get('marketValue').valid) {
              this.calculateTotal();
            }
          })
        );
      }
    });
  }

  unregisterControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges(
      this.controlsValueChangesSubscriptions
    );
  }

  deleteListedSecurity(index: number, positionId: string, isNewAsset: boolean): void {
    this.panoExtAssetsCommonUtil.deleteAsset(
      {
        index,
        assetTypeCode: ASSET_TYPES.ls.code,
        positionId,
        isNewAsset
      },
      this.assetDelete
    );
  }

  calculateTotal(): void {
    this.totalMarketValue = this.panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue(
      this.lsFormArray,
      ASSET_TYPES.ls.code,
      this.assetTotalMarketValueUpdate
    );
  }

  updateAssetDetails(assetFormGroup: FormGroup): void {
    this.assetLatestPriceSubscription = this.externalAssetService
      .getAssetLatestPrice(assetFormGroup.get('assetId').value)
      .pipe(
        finalize(() => {
          assetFormGroup.enable({ emitEvent: false });
          assetFormGroup.get('isLastPriceLoading').setValue(false);
          this.calculateTotal();
        })
      )
      .subscribe(
        (result: AssetLatestPrice) => {
          const newMarketValue = (result.lastPrice * assetFormGroup.get('quantity').value).toFixed(2);
          assetFormGroup.get('marketValue').setValue(newMarketValue);
          assetFormGroup.get('valuationDate').setValue(moment(result.valuationDate).tz('Australia/Sydney'));
        },
        () => {
          assetFormGroup.get('marketValue').setValue('');
          assetFormGroup.get('valuationDate').setValue('');
        }
      );
  }

  formatDateForDisplay(dateToFormat: AbstractControl): string {
    return moment(dateToFormat.value).format('DD MMM YYYY');
  }

  getErrorMessagesForQuantity(quantityControl: FormControl): string {
    return this.panoExtAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
  }
}
