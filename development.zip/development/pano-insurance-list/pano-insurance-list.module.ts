import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserModule } from '@angular/platform-browser';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { IconModule } from '@bt/components/icon';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { SydneyDatePipeModule } from '@panorama/pipes/sydney-date';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';

import { PanoInsuranceListOptInComponent } from '../pano-insurance-list/pano-insurance-list-opt-in/pano-insurance-list-opt-in.component';
import { PanoInsuranceListComponent } from '../pano-insurance-list/pano-insurance-list.component';

import { panoInsuranceListPoliciesResolver } from './pano-insurance-list-resolver/pano-insurance-list-policies-resolver';
import { panoInsuranceListRelatedPoliciesResolver } from './pano-insurance-list-resolver/pano-insurance-list-related-policies-resolver';
import { panoInsuranceListStaticPoliciesResolver } from './pano-insurance-list-resolver/pano-insurance-list-static-policies-resolver';
import { PanoInsuranceListTableComponent } from './pano-insurance-list-table/pano-insurance-list-table.component';

@NgModule({
  declarations: [PanoInsuranceListComponent, PanoInsuranceListTableComponent, PanoInsuranceListOptInComponent],
  providers: [],
  imports: [
    CommonModule,
    BrowserModule,
    HttpClientModule,
    ButtonModule,
    AlertModule,
    ReactiveFormsModule,
    IconModule,

    MatCheckboxModule,
    MatDialogModule,
    SydneyDatePipeModule,
    CopyMatrixPipeModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.list',
          url: '/pano-insurance-list',
          component: PanoInsuranceListComponent,
          resolve: {
            policy: ['$transition$', panoInsuranceListPoliciesResolver],
            policyAccounts: ['$transition$', panoInsuranceListRelatedPoliciesResolver],
            policyData: ['$transition$', panoInsuranceListStaticPoliciesResolver]
          }
        }
      ]
    })
  ]
})
export class PanoInsuranceListModule {}
