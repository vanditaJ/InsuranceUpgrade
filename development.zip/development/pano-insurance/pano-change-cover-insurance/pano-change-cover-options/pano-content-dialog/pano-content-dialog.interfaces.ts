import { Button } from '@bt/components/button';

export interface ContentDialogDataConfig {
  headerText: string;
  descriptionText: string;
  closeButton: Button;
  closeIcon: Button;
}
