import { Options } from '@angular-slider/ngx-slider';

export interface RangeSliderModel {
  minValue: number;
  maxValue: number;
  options: Options;
}
