import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import * as moment from 'moment-timezone';

import {
  CHARCTER_LENGTH_TEN,
  TEST_ADD_EXTERNAL_FORM,
  TEST_ADD_TD_EXTERNAL_FORM
} from '../../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { PanoAddAssetFormCreator } from '../pano-add-asset-form-creator';

import { PanoAddAssetTermDepositComponent } from './pano-add-asset-term-deposit.component';

@Component({
  template: `
    <pano-add-asset-term-deposit [addAssetForm]="addAssetForm"> </pano-add-asset-term-deposit>
  `
})
class TestHostComponent {
  addAssetForm: FormGroup = TEST_ADD_TD_EXTERNAL_FORM as FormGroup;
}

describe('PanoAddAssetTermDepositComponent', () => {
  let externalAssetsAddFormCreator: PanoAddAssetFormCreator;
  let component: PanoAddAssetTermDepositComponent;
  let fixture: ComponentFixture<PanoAddAssetTermDepositComponent>;
  let hostFixture: ComponentFixture<TestHostComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoAddAssetTermDepositComponent, TestHostComponent],
        providers: [PanoAddAssetFormCreator],
        imports: [
          MatDatepickerModule,
          MatInputModule,
          MatMomentDateModule,
          NoopAnimationsModule,
          ReactiveFormsModule,
          DataModule,
          PipesTestingModule
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoAddAssetTermDepositComponent);
    externalAssetsAddFormCreator = TestBed.inject(PanoAddAssetFormCreator);
    component = fixture.componentInstance;
    component.addAssetForm = TEST_ADD_EXTERNAL_FORM as FormGroup;
    hostFixture = TestBed.createComponent(TestHostComponent);
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('ngOnInit() should set assetDetails FormGroup with control to the addAssetForm', () => {
      const assetDetailsFormGroup = TEST_ADD_TD_EXTERNAL_FORM as FormGroup;

      spyOn(externalAssetsAddFormCreator, 'createAddAssetForm').and.returnValue(assetDetailsFormGroup);

      component.ngOnInit();

      expect(externalAssetsAddFormCreator.createAddAssetForm).toHaveBeenCalled();
      expect(component.addAssetForm.get('assetDetails')).toBeTruthy();
    });
  });

  describe('view', () => {
    it('should accept the inputs correctly', () => {
      hostFixture.detectChanges();
      const cmp = hostFixture.debugElement.query(By.directive(PanoAddAssetTermDepositComponent)).componentInstance;

      expect(cmp.addAssetForm).toEqual(TEST_ADD_TD_EXTERNAL_FORM);
    });

    it('should show the elements by default', () => {
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-input-position-name'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-input-maturity-date'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-input-market-value'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-input-value-date'))).toBeTruthy();
      expect(
        fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-input-value-date-datepicker-toggle'))
      ).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-input-source'))).toBeTruthy();
    });

    it('should hide all Errors by default', () => {
      expect(fixture.debugElement.queryAll(By.css('mat-error')).length).toBe(0);
    });

    it('should have btClearInput on appropriate inputs', () => {
      expect(
        fixture.debugElement
          .query(By.css('.js-test-extassets-add-td-form-input-position-name'))
          .nativeElement.getAttribute('btClearInput')
      ).toBeDefined();
      expect(
        fixture.debugElement
          .query(By.css('.js-test-extassets-add-td-form-input-source'))
          .nativeElement.getAttribute('btClearInput')
      ).toBeDefined();
    });

    describe('validate form control', () => {
      let assetDetailsFormGroup: FormGroup;
      beforeEach(() => {
        component.ngOnInit();
        fixture.detectChanges();
        assetDetailsFormGroup = component.addAssetForm.get('assetDetails') as FormGroup;
        assetDetailsFormGroup.markAllAsTouched();
      });

      describe('validate positionName', () => {
        it('should show error message ', () => {
          assetDetailsFormGroup.get('positionName').setValue('');
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-td-form-position-name-invalid-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0394');
        });

        it('should show error message when exceeds max length', () => {
          const positionNameTextMoreThanMax = CHARCTER_LENGTH_TEN.repeat(21);
          assetDetailsFormGroup.get('positionName').setValue(positionNameTextMoreThanMax);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-td-form-position-name-invalid-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0394');
        });

        it('should not show error message ', () => {
          assetDetailsFormGroup.get('positionName').setValue('asset name');
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-position-name-invalid-error'))
          ).toBeNull();
        });
      });

      describe('validate maturityDate', () => {
        it('should show error message ', () => {
          assetDetailsFormGroup.get('maturityDate').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-td-form-maturity-date-required-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
        });

        it('should not show error message ', () => {
          assetDetailsFormGroup.get('maturityDate').setValue(moment().tz('Australia/Sydney'));
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-maturity-date-required-error'))
          ).toBeNull();
        });

        it('should show error message when past date is entered', () => {
          assetDetailsFormGroup.get('maturityDate').setValue(
            moment()
              .subtract(4, 'day')
              .tz('Australia/Sydney')
          );
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-maturity-date-min-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0281');
        });
      });

      describe('validate marketValue', () => {
        it('should show error message ', () => {
          assetDetailsFormGroup.get('marketValue').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-td-form-market-value-required-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1235');
        });

        it('should not show error message ', () => {
          assetDetailsFormGroup.get('marketValue').setValue(12);
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-market-value-required-error'))
          ).toBeNull();
        });

        it('should show error message invalid number is entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue('12.3.5');
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-td-form-market-value-pattern-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1236');
        });

        it('should show error message minimum number is entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue('0.');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-market-value-min-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1233');
        });

        it('should show error message maximum number is entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue('999999999999');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-market-value-max-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1227');
        });
      });

      describe('validate valuationDate', () => {
        it('should show error message ', () => {
          assetDetailsFormGroup.get('valuationDate').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-td-form-value-date-required-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
        });

        it('should not show error message ', () => {
          assetDetailsFormGroup.get('valuationDate').setValue(moment().tz('Australia/Sydney'));
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-value-date-required-error'))
          ).toBeNull();
        });

        it('should show error message when future date is entered', () => {
          assetDetailsFormGroup.get('valuationDate').setValue(
            moment()
              .add(4, 'day')
              .tz('Australia/Sydney')
          );
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-value-date-max-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0386');
        });
      });

      describe('validate source', () => {
        it('should show error message when exceeds maximum', () => {
          const sourceTextMoreThanMax = CHARCTER_LENGTH_TEN.repeat(13);
          assetDetailsFormGroup.get('source').setValue(sourceTextMoreThanMax);
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-source-invalid-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1239');
        });

        it('should not show error message ', () => {
          const sourceTextOnMax = CHARCTER_LENGTH_TEN.repeat(12);
          assetDetailsFormGroup.get('source').setValue(sourceTextOnMax);
          fixture.detectChanges();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-td-form-source-invalid-error'))).toBeNull();
        });
      });
    });
  });
});
