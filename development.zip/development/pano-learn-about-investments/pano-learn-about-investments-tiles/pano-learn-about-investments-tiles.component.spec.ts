import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataService } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { of, throwError } from 'rxjs';

import { PanoLearnAboutInvestmentsTilesComponent } from './pano-learn-about-investments-tiles.component';
import { Tile } from './pano-learn-about-investments-tiles.interface';
import { PanoLearnAboutInvestmentsTilesService } from './pano-learn-about-investments-tiles.service';

describe('PanoLearnAboutInvestmentsComponent', () => {
  let component: PanoLearnAboutInvestmentsTilesComponent;
  let service: PanoLearnAboutInvestmentsTilesService;
  let fixture: ComponentFixture<PanoLearnAboutInvestmentsTilesComponent>;

  const TILE_1: Tile = {
    heading: 'VANILLA',
    description: 'VANILLARY',
    link: { link: 'to-there', label: 'go', openNewTab: true }
  };

  const TILE_2: Tile = {
    heading: 'CHOCOLATE',
    description: 'CHOCOLATEY',
    link: { link: 'to-choco-town', label: 'cocoa', openNewTab: true }
  };

  const TILE_LIST: Tile[] = [TILE_1, TILE_2];

  const dataService = {
    retrieve: jasmine.createSpy().and.returnValue(
      of({
        details: []
      })
    )
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoLearnAboutInvestmentsTilesComponent],
        imports: [
          BrowserAnimationsModule,
          MatButtonToggleModule,
          MatFormFieldModule,
          MatInputModule,
          MatRadioModule,
          CopyMatrixPipeModule
        ],
        providers: [
          {
            provide: DataService,
            useValue: dataService
          },
          PanoLearnAboutInvestmentsTilesService,
          {
            provide: UIRouter,
            useValue: {}
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoLearnAboutInvestmentsTilesComponent);
    service = TestBed.inject(PanoLearnAboutInvestmentsTilesService);
    TestBed.inject(DataService);
    component = fixture.componentInstance;
  });

  describe('Component', () => {
    describe('ngOnInit', () => {
      beforeEach(() => {
        spyOn(service, 'getTileContent').and.returnValue(of(TILE_LIST));
      });

      it('should call the service to load the text content', () => {
        component.ngOnInit();

        expect(service.getTileContent).toHaveBeenCalled();
      });

      it('should set the tiles from the service return', () => {
        component.ngOnInit();
        expect(component.tiles).toBeTruthy();
        expect(component.tiles.length).toBe(2);
      });

      it('should set tiles to empty on error loading', () => {
        service.getTileContent = jasmine.createSpy().and.returnValue(throwError('dead'));
        component.ngOnInit();
        expect(component.tiles).toBeTruthy();
        expect(component.tiles.length).toBe(0);
      });
    });
  });

  describe('view', () => {
    beforeEach(() => {
      component.tiles = [];
      fixture.detectChanges();
    });

    it('should show loading spinner while fetching data', () => {
      component.loading = true;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).toBeTruthy();
    });

    it('should show page when loading complete', () => {
      component.tiles = TILE_LIST;
      component.loading = false;
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('bt-loading'))).toBeFalsy();
      expect(fixture.debugElement.queryAll(By.css('.js-test-learn-about-investments-tile')).length).toEqual(2);
      expect(
        fixture.debugElement.queryAll(By.css('.js-test-learn-about-investments-tile h3'))[0].nativeElement.innerHTML
      ).toEqual('VANILLA');
      expect(
        fixture.debugElement.queryAll(By.css('.js-test-learn-about-investments-tile h3'))[1].nativeElement.innerHTML
      ).toEqual('CHOCOLATE');
    });
  });
});
