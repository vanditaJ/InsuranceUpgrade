import { DOCUMENT } from '@angular/common';
import { AfterViewInit, Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';
import { find, flatten, forEach, get, values } from 'lodash-es';
import { PageScrollService } from 'ngx-page-scroll-core';

import {
  CANCEL_FORM_BUTTON,
  COVER_LEVEL,
  GENERIC_ERROR_ALERT,
  OUTLINE_INFO_ALERT,
  RETAIL,
  REVIEW_FORM_BUTTON
} from '../../pano-insurance.constants';
import { findContentByKey } from '../../pano-insurance.helper';
import { InsurancePolicy, NewCoverType, PolicyType, SelectCoverType } from '../../pano-insurance.interface';
import { PanoInsuranceUtil } from '../../pano-insurance.util';
import { CHANGE_OR_DECREASE_SHOW_STATUS, SELECT_COVER_AMOUNTS } from '../pano-change-cover-insurance.constants';
import {
  ChangeCoverMode,
  CoverAmountOptions,
  CoverMode,
  CoverTypeSelected,
  InsuranceRate
} from '../pano-change-cover-insurance.interface';

import {
  CHANGE_COVER_AEM_KEY,
  COVER_AMOUNT_CHANGE_AS_GET_OLDER_LINK,
  CUSTOMISED_INSURANCE_AEM_KEY,
  CUSTOMISED_INSURANCE_CONFIG,
  DECREASE_COVER_AEM_KEY,
  EXCLUSIONS_AEM_KEY,
  EXCLUSIONS_CONFIG,
  PANO_HINT_INLINE_BUTTONS,
  PRE_EXISTING_CONDITIONS_AEM_KEY,
  PRE_EXISTING_CONDITIONS_CONFIG
} from './pano-change-cover-options.constants';
import { PanoContentDialogComponent } from './pano-content-dialog/pano-content-dialog.component';

@Component({
  selector: 'pano-change-cover-options',
  templateUrl: './pano-change-cover-options.component.html'
})
export class PanoChangeCoverOptionsComponent implements OnInit, AfterViewInit {
  @Input() account: Account;
  @Input() insurance: InsurancePolicy;
  @Input() mode: ChangeCoverMode;
  @Input() currentCoverType: CoverAmountOptions;
  @Input() selectCoverTypes: SelectCoverType[];
  @Input() newCoverType: NewCoverType;
  @Input() insuranceRates: InsuranceRate[];
  @Input() cmsContent: AemContent[];

  @Output() reviewComplete: EventEmitter<object> = new EventEmitter<object>();
  @Output() navigate: EventEmitter<void> = new EventEmitter<void>();
  @Output() coverLevel: EventEmitter<Array<'Single' | 'Double' | 'Triple'>> = new EventEmitter<
    Array<'Single' | 'Double' | 'Triple'>
  >();
  @Output() resetFocus: EventEmitter<void> = new EventEmitter<void>();

  selectCoverAmounts = SELECT_COVER_AMOUNTS;
  changeCoverSelection: FormGroup;
  selectedCoverLevel: CoverTypeSelected['coverLevels'];
  showDecreaseMsg: boolean = false;
  showChangeMsg: boolean = false;
  isChangeMode: boolean = false;
  exclusionsAemMessage: string;
  preExistingConditionsAemMessage: string;
  customisedInsuranceAemMessage: string;
  decreaseSelectionAemMessage: string;
  changeSelectionAemMessage: string;

  readonly cancelReviewFormButton: Button = CANCEL_FORM_BUTTON;
  readonly reviewFormButton: Button = REVIEW_FORM_BUTTON;
  readonly decreaseSelectionInfo: Alert = OUTLINE_INFO_ALERT;
  readonly changeSelectionInfo: Alert = OUTLINE_INFO_ALERT;
  readonly genericErrorAlert: Alert = GENERIC_ERROR_ALERT;
  readonly coverAmountChangeAsGetOlderLink: string = COVER_AMOUNT_CHANGE_AS_GET_OLDER_LINK;
  readonly notBeCoveredForCertainEventsButton: Button = PANO_HINT_INLINE_BUTTONS['notBeCoveredForCertainEvents'];
  readonly preExistingConditionsButton: Button = PANO_HINT_INLINE_BUTTONS['preExistingConditions'];
  readonly customisedCoverButton: Button = PANO_HINT_INLINE_BUTTONS['customisedCover'];

  constructor(
    private readonly fb: FormBuilder,
    private panoInsuranceUtil: PanoInsuranceUtil,
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: HTMLDocument,
    private readonly dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.pageScrollService.scroll({
      document: this.document,
      scrollTarget: '.top-scroll',
      duration: 200
    });

    this.changeCoverSelection = this.fb.group({
      coverType: ['', [Validators.required]],
      coverAmountType: ['', [Validators.required]]
    });

    this.setSelectedCoverTypes();
    this.getShowDecreaseMsg();
    this.getShowChangeMsg();
    this.checkCoverAmount();
    this.setAemMessages();

    if (this.newCoverType !== undefined) {
      this.changeCoverSelection.controls.coverType.setValue(this.newCoverType.coverType);
      this.changeCoverSelection.controls.coverAmountType.setValue(this.newCoverType.coverAmountType);
    }

    this.isChangeMode = this.mode === CoverMode.CHANGE;
  }

  ngAfterViewInit(): void {
    this.resetFocus.emit(); // move focus to parent heading
  }

  checkCoverAmount(): void {
    this.changeCoverSelection.controls['coverType'].valueChanges.subscribe(type => {
      this.changeCoverSelection.controls.coverAmountType.setValue('');
      const coverType: CoverTypeSelected = find(
        this.currentCoverType.coverTypeSelected,
        selected => selected.coverType === type.policyType
      );
      if (coverType) {
        this.selectedCoverLevel = coverType.coverLevels;
      }
      const coverAmountTypes = flatten(values(get(coverType, 'coverLevels')));
      this.selectCoverAmounts = SELECT_COVER_AMOUNTS.filter(selectCoverAmount =>
        coverAmountTypes.includes(selectCoverAmount.coverAmountType)
      );
      this.selectCoverAmounts.forEach(amount => {
        const insuranceRate: InsuranceRate = find(
          this.insuranceRates,
          rate => rate.coverLevel === amount.coverAmountType && rate.policyType === coverType.coverType
        );
        amount.coverSubTypeId = insuranceRate.coverOptionId;
        amount.coverAmount = insuranceRate.coverAmount;
        amount.premium = insuranceRate.premium;
        amount.increase = insuranceRate.increase;
      });
    });
  }

  setAemMessages(): void {
    this.exclusionsAemMessage = findContentByKey(this.cmsContent, EXCLUSIONS_AEM_KEY);
    this.preExistingConditionsAemMessage = findContentByKey(this.cmsContent, PRE_EXISTING_CONDITIONS_AEM_KEY);
    this.customisedInsuranceAemMessage = findContentByKey(this.cmsContent, CUSTOMISED_INSURANCE_AEM_KEY);
    this.decreaseSelectionAemMessage = findContentByKey(this.cmsContent, DECREASE_COVER_AEM_KEY);
    this.changeSelectionAemMessage = findContentByKey(this.cmsContent, CHANGE_COVER_AEM_KEY);
  }

  setSelectedCoverTypes(): void {
    if (this.currentCoverType !== undefined && this.currentCoverType.coverTypeSelected !== undefined) {
      const coverTypes = [];
      forEach(this.currentCoverType.coverTypeSelected, selected => {
        coverTypes.push(selected.coverType);
      });
      this.selectCoverTypes = this.selectCoverTypes.filter(item => coverTypes.includes(item.policyType));
    }
  }

  getShowDecreaseMsg(): void {
    const showStatus = this.showDecreaseMsgStatus(this.insurance, this.account);
    if (showStatus && this.mode === CoverMode.DECREASE) {
      this.showDecreaseMsg = true;
    }
  }

  showDecreaseMsgStatus(policy: InsurancePolicy, account: Account): boolean {
    const customised = get(policy, 'customised');
    const status = CHANGE_OR_DECREASE_SHOW_STATUS.includes(get(policy, 'status'));
    const policyType = get(policy, 'policyType');
    const age = get(policy, 'ageNextBirthday');
    const customerType = get(policy, 'customerType');
    const coverLevel = get(policy, 'coverLevel');
    if (
      !customised &&
      status &&
      customerType === RETAIL &&
      age < 60 &&
      this.panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria(policy, account) > 90
    ) {
      if (
        (policyType === PolicyType.DEATH_AND_TPD && coverLevel !== COVER_LEVEL.Single) ||
        (policyType === PolicyType.DEATH && coverLevel === COVER_LEVEL.Triple)
      ) {
        return true;
      }
    }
    return false;
  }

  getShowChangeMsg(): void {
    const showStatus = this.showChangeMsgStatus(this.insurance, this.account);
    if (showStatus && this.mode === CoverMode.CHANGE) {
      this.showChangeMsg = true;
    }
  }

  showChangeMsgStatus(policy: InsurancePolicy, account: Account): boolean {
    const customised = get(policy, 'customised');
    const customerType = get(policy, 'customerType');
    const age = get(policy, 'ageNextBirthday');
    const status = CHANGE_OR_DECREASE_SHOW_STATUS.includes(get(policy, 'status'));
    const daysSinceAccountActivation = this.panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria(
      policy,
      account
    );
    if (!customised && customerType === RETAIL && age < 60 && status && daysSinceAccountActivation <= 90) {
      return true;
    }
    return false;
  }

  submitForm(): void {
    if (
      this.mode === CoverMode.CHANGE ||
      (this.mode === CoverMode.DECREASE &&
        this.panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria(this.insurance, this.account) > 90)
    ) {
      this.reviewComplete.emit(this.changeCoverSelection.value);
    }
  }

  cancel(): void {
    this.navigate.emit();
  }

  openExclusionsDialog(): void {
    this.dialog.open(PanoContentDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: false,
      ariaLabel: 'Open exclusions information dialog',
      data: {
        ...EXCLUSIONS_CONFIG,
        descriptionText: this.exclusionsAemMessage
      }
    });
  }

  openPreExistingConditionsDialog(): void {
    this.dialog.open(PanoContentDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: false,
      ariaLabel: 'Open pre-existing conditions information dialog',
      data: {
        ...PRE_EXISTING_CONDITIONS_CONFIG,
        descriptionText: this.preExistingConditionsAemMessage
      }
    });
  }

  openCustomisedInsuranceDialog(): void {
    this.dialog.open(PanoContentDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: false,
      ariaLabel: 'Open customised cover information dialog',
      data: {
        ...CUSTOMISED_INSURANCE_CONFIG,
        descriptionText: this.customisedInsuranceAemMessage
      }
    });
  }
}
