import { StaticData } from '../pano-insurance-list.interface';
import { PanoInsuranceListService } from '../pano-insurance-list.service';

export function panoInsuranceListStaticPoliciesResolver($transition$): Promise<StaticData[]> {
  const panoInsuranceListService = $transition$.injector().get(PanoInsuranceListService);
  return panoInsuranceListService.getStaticPolicyData().toPromise();
}
