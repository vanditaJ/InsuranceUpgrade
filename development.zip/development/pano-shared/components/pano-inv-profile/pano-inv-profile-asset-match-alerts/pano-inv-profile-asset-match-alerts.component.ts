import { DOCUMENT } from '@angular/common';
import { Component, Inject, Input, OnInit } from '@angular/core';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';
import { PageScrollService } from 'ngx-page-scroll-core';

import {
  ASSET_NOT_MATCH_ALERT,
  NOT_WITHIN_MARKET_ALERT,
  PAGE_SCROLL_DURATION,
  REMIND_PROFILE_REVIEW_ALERT,
  REQUIRE_PROFILE_REVIEW_UPDATE_ALERT_ID,
  SHARES_ETFS_ALERT,
  UPDATE_PROFILE_ALERT,
  UPDATE_PROFILE_ALERT_ID,
  UPDATE_PROFILE_BUTTON
} from './pano-inv-profile-asset-match-alerts.constants';

@Component({
  selector: 'pano-inv-profile-asset-match-alerts',
  templateUrl: './pano-inv-profile-asset-match-alerts.component.html'
})
export class PanoInvProfileAssetMatchAlertsComponent implements OnInit {
  @Input() showShareEtfsAlert: boolean;
  @Input() showAssetNotMatchAlert: boolean;
  @Input() showNotInTargetMarketAlert: boolean;
  @Input() showRequireProfileUpdateAlert: boolean;
  @Input() showRemindProfileReviewAlert: boolean;
  @Input() showUpdateProfileAlert: boolean;
  @Input() activeAssetType: string = 'this investment type';

  readonly assetNotMatchAlert: Alert = ASSET_NOT_MATCH_ALERT;
  readonly notWithinMarketAlert: Alert = NOT_WITHIN_MARKET_ALERT;
  readonly remindProfileReviewAlert: Alert = REMIND_PROFILE_REVIEW_ALERT;
  readonly shareEtfsAlert: Alert = SHARES_ETFS_ALERT;
  readonly updateProfileAlert: Alert = UPDATE_PROFILE_ALERT;
  readonly updateProfileButton: Button = UPDATE_PROFILE_BUTTON;
  updateProfileMessage: string;

  constructor(
    private copyMatrixPipe: CopyMatrixPipe,
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: HTMLDocument
  ) {}

  ngOnInit(): void {
    if (this.showUpdateProfileAlert) {
      this.updateProfileMessage = this.copyMatrixPipe.transform(UPDATE_PROFILE_ALERT_ID, this.activeAssetType);
    }

    if (this.showRequireProfileUpdateAlert) {
      this.updateProfileMessage = this.copyMatrixPipe.transform(REQUIRE_PROFILE_REVIEW_UPDATE_ALERT_ID);
    }
  }

  updateProfile(): void {
    this.pageScrollService.scroll({
      document: this.document,
      duration: PAGE_SCROLL_DURATION,
      scrollTarget: '.js-investment-profile-title',
      scrollViews: [this.document.querySelector('.layout-scroll')]
    });
  }
}
