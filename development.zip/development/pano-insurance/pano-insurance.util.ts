import { Injectable } from '@angular/core';
import { Account } from '@investor/account/pano-shared/interfaces';
import { isNull } from 'lodash-es';
import * as moment from 'moment-timezone';

import { Insurances } from './pano-insurance-policies/pano-insurance-policies.interface';
import { PRODUCT } from './pano-insurance.constants';
import { InsurancePolicy, PolicyStatus, PolicyType } from './pano-insurance.interface';

@Injectable()
export class PanoInsuranceUtil {
  getDate(dateString: string): moment {
    const date = dateString === 'now' ? moment() : moment(dateString);
    return date.tz('Australia/Sydney').startOf('day');
  }

  getDaysSince(date: string): number {
    const now = this.getDate('now');
    return now.diff(this.getDate(date), 'days');
  }

  getAccountActivationDaysFor90DaysCriteria(policy: InsurancePolicy, account: Account): number {
    const accountActivationDate = this.getAccountActivationDateFor90DaysCriteria(policy, account);

    return this.getDaysSince(accountActivationDate);
  }

  getAccountActivationDaysFor60DaysCriteria(policy: InsurancePolicy, account: Account): number {
    const accountActivationDate = this.getAccountActivationDateFor60DaysCriteria(policy, account);
    return accountActivationDate ? this.getDaysSince(accountActivationDate) : 0;
  }

  private getAccountActivationDateFor60DaysCriteria(policy: InsurancePolicy, account: Account): string {
    let accountActivationDate: string = null;
    const pmifDetail = policy.pmifDetails;
    if (pmifDetail) {
      const automaticCoverDate = this.getAutomaticCoverDate(account, pmifDetail.lowBalanceThresholdDate);
      if (automaticCoverDate) {
        if (pmifDetail.optInDate) {
          accountActivationDate =
            this.getDate(automaticCoverDate) < this.getDate(pmifDetail.optInDate)
              ? automaticCoverDate
              : pmifDetail.optInDate;
        } else {
          accountActivationDate = automaticCoverDate;
        }
      } else {
        accountActivationDate = null;
      }
    }
    return accountActivationDate;
  }

  private getAccountActivationDateFor90DaysCriteria(policy: InsurancePolicy, account: Account): string {
    let accountActivationDate: string = null;
    const pmifDetail = policy.pmifDetails;
    if (pmifDetail) {
      const automaticCoverDate = this.getAutomaticCoverDate(account, pmifDetail.lowBalanceThresholdDate);
      const firstMoneyReceivedDate = account.firstMoneyReceivedDate;

      if (pmifDetail.optInDate && firstMoneyReceivedDate) {
        accountActivationDate =
          this.getDate(firstMoneyReceivedDate) > this.getDate(pmifDetail.optInDate)
            ? firstMoneyReceivedDate
            : pmifDetail.optInDate;
      }

      if (!accountActivationDate || this.getDate(automaticCoverDate) < this.getDate(accountActivationDate)) {
        accountActivationDate = automaticCoverDate || null;
      }
    }

    return accountActivationDate;
  }

  getAutomaticCoverDate(account: Account, lowBalanceThresholdDate: string): string {
    if (lowBalanceThresholdDate && account.owners[0].age >= 25) {
      const dateTurned25 = moment(account.owners[0].dateOfBirth).add(25, 'years');
      return dateTurned25.isAfter(this.getDate(lowBalanceThresholdDate))
        ? dateTurned25.format('YYYY-MM-DD')
        : lowBalanceThresholdDate;
    }
  }

  isBTSFLMember(account: Account): boolean {
    return account.productDescription === PRODUCT['BT_SUPER_FOR_LIFE'];
  }

  isBTSuperMember(account: Account): boolean {
    return account.productDescription === PRODUCT['BT_SUPER'];
  }

  getDeathAssociatedTPDPolicies(policies: InsurancePolicy[], insurance: Insurances): InsurancePolicy[] {
    return policies?.filter(
      (policy: InsurancePolicy) =>
        policy.policyType === PolicyType.TPD &&
        insurance.associatedTpd?.includes(policy.coverSubTypeId) &&
        !(policy.status === PolicyStatus.INACTIVE) &&
        !(insurance.status === PolicyStatus.INACTIVE)
    );
  }

  isPolicyAvailableForInsuranceTable(policy: InsurancePolicy): boolean {
    return (
      (policy.status === PolicyStatus.INACTIVE && this.isEndOfTheMonth(policy.endDate)) ||
      (policy.status === PolicyStatus.ACTIVE &&
        isNull(policy.endDate) &&
        this.getDaysSince(policy.commencementDate) >= 0) ||
      policy.status === PolicyStatus.PENDING ||
      policy.status === PolicyStatus.NOT_ACTIVE ||
      policy.status === PolicyStatus.REQUESTED
    );
  }

  isEndOfTheMonth(date: string): boolean {
    return (
      moment(date)
        .tz('Australia/Sydney')
        .endOf('month')
        .format('YYYY-MM-DD') ===
      moment(date)
        .tz('Australia/Sydney')
        .format('YYYY-MM-DD')
    );
  }
}
