import { Injectable } from '@angular/core';
import { Account } from '@investor/account/pano-shared/interfaces';
import { forEach, get, groupBy } from 'lodash-es';
import * as moment from 'moment-timezone';

import {
  ChangeCoverMode,
  CoverAmountOptions,
  CoverMode,
  CoverTypeSelected,
  InsuranceRate
} from './pano-change-cover-insurance.interface';

@Injectable()
export class PanoChangeCoverInsuranceCommonUtil {
  getCoverAmountOptions(
    mode: ChangeCoverMode,
    currentPolicyType: string,
    currentCoverLevel: string,
    insuranceRates: InsuranceRate[]
  ): CoverAmountOptions {
    const coverTypes =
      mode === CoverMode.DECREASE
        ? groupBy(
            insuranceRates.filter(rate => !rate.increase),
            'policyType'
          )
        : groupBy(insuranceRates, 'policyType');

    const coverAmountOptions: CoverAmountOptions = {
      policyType: currentPolicyType,
      coverLevel: currentCoverLevel,
      coverTypeSelected: []
    };

    if (coverTypes.DEATH) {
      const death = this.getCoverTypes(coverTypes.DEATH);
      coverAmountOptions.coverTypeSelected.push(death);
    }

    if (coverTypes.DEATH_AND_TPD) {
      const deathTpd = this.getCoverTypes(coverTypes.DEATH_AND_TPD);
      coverAmountOptions.coverTypeSelected.push(deathTpd);
    }

    return coverAmountOptions;
  }

  getCoverTypes(coverTypes: InsuranceRate[]): CoverTypeSelected {
    let coverType;
    const coverLevels = [];

    forEach(coverTypes, cover => {
      coverType = cover.policyType;
      coverLevels.push(cover.coverLevel);
    });

    return {
      coverType,
      coverLevels
    };
  }

  getAccountActivationDays(account: Account): number {
    const firstMoneyReceivedDate = get(account, 'firstMoneyReceivedDate');
    const firstMoneyReceived = moment(firstMoneyReceivedDate);
    const now = moment().tz('Australia/Sydney');
    return now.tz('Australia/Sydney').diff(firstMoneyReceived, 'days');
  }
}
