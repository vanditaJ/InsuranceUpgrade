import { Injectable } from '@angular/core';
import { get } from 'lodash-es';

import { CUSTOMER_TYPE_BT_SFL } from '../pano-insurance.constants';
import { InsurancePolicy, PolicyStatus } from '../pano-insurance.interface';
import { PanoInsuranceUtil } from '../pano-insurance.util';

import { CUSTOMER_TYPE_PCS, PMIF_DETAILS, PYS_DETAILS } from './pano-insurance-policies.constants';

@Injectable()
export class PanoInsurancePoliciesUtil extends PanoInsuranceUtil {
  pysAndPMIFOptInRequired(policies: InsurancePolicy[]): boolean {
    return this.pysOptInRequiredForPolicies(policies) && this.pmifOptInRequiredForPolicies(policies);
  }

  pysOptInRequiredForPolicies(policies: InsurancePolicy[]): boolean {
    let pysPolicies: InsurancePolicy[] = [];
    if (policies.length > 0) {
      pysPolicies = policies.filter(policy => this.pysOptInRequired(policy));
    }
    return pysPolicies.length > 0;
  }

  pmifOptInRequiredForPolicies(policies: InsurancePolicy[]): boolean {
    let pmifPolicies: InsurancePolicy[] = [];
    if (policies.length > 0) {
      pmifPolicies = policies.filter(policy => this.pmifOptInRequired(policy));
    }
    return pmifPolicies.length > 0;
  }

  pmifOptInRequired(policy: InsurancePolicy): boolean {
    return policy.status === PolicyStatus.NOT_ACTIVE && this.optInRequired(policy, PMIF_DETAILS);
  }

  pysOptInRequired(policy: InsurancePolicy): boolean {
    return (
      (policy.status === PolicyStatus.NOT_ACTIVE || this.checkActive(policy)) && this.optInRequired(policy, PYS_DETAILS)
    );
  }

  optInRequired(policy: InsurancePolicy, optInType: string): boolean {
    let optInDate: string = null;
    const riskCommencementDate = get(policy, 'riskCommencementDate');
    if (optInType === PYS_DETAILS) {
      optInDate = get(policy, 'pysDetails.optInDate');
    } else if (optInType === PMIF_DETAILS) {
      optInDate = get(policy, 'pmifDetails.optInDate');
    }

    return (
      !this.automaticCoverMessageRequired(policy) &&
      (!optInDate || (riskCommencementDate && this.getDate(optInDate) < this.getDate(riskCommencementDate)))
    );
  }

  automaticCoverMessageRequired(policy: InsurancePolicy): boolean {
    return (
      policy.customerType === CUSTOMER_TYPE_BT_SFL &&
      policy.status === PolicyStatus.NOT_ACTIVE &&
      this.getDate('now').diff(this.getDate(policy.riskCommencementDate), 'days') > 34 // business decision 34 days to align with the welcome pack
    );
  }

  checkActive(policy: InsurancePolicy): boolean {
    return (
      (policy.status === PolicyStatus.ACTIVE && this.getDate(policy.commencementDate) <= this.getDate('now')) ||
      policy.status === PolicyStatus.INACTIVE
    );
  }

  getSFLPolicyWithRiskCommencementDateGreaterThan30(policies: InsurancePolicy[]): boolean {
    const standardCoverPolicies: InsurancePolicy[] = policies.filter(
      policy => policy.customerType === CUSTOMER_TYPE_BT_SFL && policy.status === PolicyStatus.NOT_ACTIVE
    );
    return !!standardCoverPolicies.find(
      policy => this.getDate('now').diff(this.getDate(policy.riskCommencementDate), 'days') > 34 // business decision 34 days to align with the welcome pack
    );
  }

  isPolicySuitableForNoOccupationCodeAlert(policy: InsurancePolicy): boolean {
    return (
      policy.customerType === CUSTOMER_TYPE_PCS &&
      !policy.external &&
      policy.personBenefitDetails[0].benefits[0].benefits[0].occupationClass === 'N/A'
    );
  }

  checkPmifPolicy(policies: InsurancePolicy[], pmifPermission: boolean): InsurancePolicy[] {
    if (!pmifPermission) {
      return policies.filter(
        policy => policy.status !== PolicyStatus.NOT_ACTIVE && policy.status !== PolicyStatus.REQUESTED
      );
    }
    return policies;
  }
}
