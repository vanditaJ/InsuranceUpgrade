import { HttpHeaders } from '@angular/common/http';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { Loading } from '@bt/components/loading';
import { Optionals } from '@bt/services/data';

export const SUBMIT_NOTIFICATION_URL = '../panorama-inv-ui/api/v1/correspondence/super';

export const SUBMIT_NOTIFICATION_BUTTON: Button = {
  type: 'solid',
  colourModifier: 'primary',
  action: 'submit',
  label: 'Submit',
  size: 'large'
};

export const CANCEL_NOTIFICATION_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'primary',
  action: 'button',
  label: 'Cancel',
  size: 'large'
};

export const BACK_OUT_NOTIFICATION_BUTTON: Button = {
  type: 'solid',
  action: 'button',
  label: 'Back to Employer contributions',
  size: 'large'
};

export const SUBMITTED_FOR_ME_ALERT: Alert = {
  type: 'success',
  messages: 'Superannuation contributions details successfully submitted'
};

export const SUBMITTED_MYSELF_ALERT: Alert = {
  type: 'success',
  messages: 'Your superannuation contribution form has been sent'
};

export const SUBMITTED_NEXT_STEPS_ICON: Icon = {
  name: 'icon-envelope',
  size: 'medium'
};

export const SUBMIT_ERROR_ALERT: Alert = {
  type: 'error',
  messages: 'Something unexpected has happened. Please try again later.',
  outline: true,
  showCodes: false
};

export const SUBMIT_ANOTHER_FORM_BUTTON: Button = {
  colourModifier: 'primary',
  type: 'flat',
  label: 'Submit another Employer contributions form',
  size: 'small',
  action: 'button',
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  iconPosition: 'left'
};

export const SUBMIT_SPINNER: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const SETUP_TYPE_ON_MY_BEHALF: string = 'O';

export const SETUP_TYPE_SELF: string = 'S';

export const EMAIL_OPTION_ACCOUNT_DETAILS: string = 'A';

export const EMAIL_OPTION_ACCOUNT_DETAILS_PDF: string = 'P';

export const NOTIFICATION_TYPE_DO_IT_FOR_ME: string = 'SGDoItForMe';

export const NOTIFICATION_TYPE_NOTIFY_ME: string = 'SGNotifyMe';

export const NOTIFICATION_TYPE_PDF_NOTIFY_ME: string = 'SGPDFNotifyMe';

export const SUBMIT_NOTIFICATION_OPTIONALS: Optionals = {
  httpOptions: {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }
};
