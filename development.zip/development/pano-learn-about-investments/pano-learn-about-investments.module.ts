import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatListModule } from '@angular/material/list';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { IconModule } from '@bt/components/icon';
import { LinkModule } from '@bt/components/link';
import { LoadingModule } from '@bt/components/loading';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataModule } from '@bt/services/data';
import { panoAccountResolver } from '@investor/account/pano-shared/resolvers';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';
import { NgxMaskModule } from 'ngx-mask';

import { PanoInvestmentFeesComponent } from './pano-investment-fees/pano-investment-fees.component';
import { PanoInvestmentFeesService } from './pano-investment-fees/pano-investment-fees.service';
import { PanoLearnAboutInvestmentsTilesComponent } from './pano-learn-about-investments-tiles/pano-learn-about-investments-tiles.component';
import { PanoLearnAboutInvestmentsTilesService } from './pano-learn-about-investments-tiles/pano-learn-about-investments-tiles.service';
import { PanoLearnAboutInvestmentsComponent } from './pano-learn-about-investments.component';
import { PanoLearnAboutInvestmentsService } from './pano-learn-about-investments.service';

@NgModule({
  declarations: [
    PanoLearnAboutInvestmentsComponent,
    PanoInvestmentFeesComponent,
    PanoLearnAboutInvestmentsTilesComponent
  ],
  providers: [PanoInvestmentFeesService, PanoLearnAboutInvestmentsService, PanoLearnAboutInvestmentsTilesService],
  entryComponents: [],
  imports: [
    AlertModule,
    ButtonModule,
    CommonModule,
    CopyMatrixPipeModule,
    DataModule,
    IconModule,
    LayoutModule,
    LinkModule,
    LoadingModule,
    MatExpansionModule,
    MatListModule,
    HttpClientModule,
    NgxMaskModule.forRoot({}),
    ReactiveFormsModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.learnAboutInvestments',
          url: '/learn-about-investments',
          component: PanoLearnAboutInvestmentsComponent,
          data: {
            requiredPermissions: {
              rule: 'corporatesuper.view',
              targetId: 'a'
            },
            title: 'Learn about investments'
          },
          resolve: {
            account: ['$transition$', panoAccountResolver]
          }
        },
        {
          name: 'app.investor.account.investmentFees',
          url: '/learn-about-investments/investment-fees',
          component: PanoInvestmentFeesComponent,
          data: {
            requiredPermissions: {
              rule: 'corporatesuper.view',
              targetId: 'a'
            },
            title: 'Investment fees'
          },
          resolve: {
            account: ['$transition$', panoAccountResolver]
          }
        }
      ]
    })
  ]
})
export class PanoLearnAboutInvestmentsModule {}
