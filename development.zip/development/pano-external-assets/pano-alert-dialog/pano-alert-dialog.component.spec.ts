import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

import { MAX_ASSET_ALERT_BUTTON } from '../pano-external-assets-constants/pano-external-assets.constants';

import { PanoAlertDialogComponent } from './pano-alert-dialog.component';

describe('PanoAlertDialogComponent', () => {
  let component: PanoAlertDialogComponent;
  let fixture: ComponentFixture<PanoAlertDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoAlertDialogComponent],
        imports: [MatDialogModule],
        providers: [
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          {
            provide: MAT_DIALOG_DATA,
            useValue: {
              headerText: 'Header text',
              descriptionText: 'description text',
              alertButton: MAX_ASSET_ALERT_BUTTON
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [PanoAlertDialogComponent]
        }
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoAlertDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('closeDialog()', () => {
      it('should call dialog close method', () => {
        component.closeDialog();
        expect((component as any).dialogRef.close).toHaveBeenCalled();
      });
    });
  });

  describe('view', () => {
    it('should have correct header', () => {
      expect(fixture.debugElement.query(By.css('.js-test-pano-alert-header')).nativeElement.innerHTML.trim()).toBe(
        'Header text'
      );
    });

    it('should have correct sub heading', () => {
      expect(fixture.debugElement.query(By.css('.js-test-pano-alert-description')).nativeElement.innerHTML.trim()).toBe(
        'description text'
      );
    });

    describe('bt-buttons', () => {
      it('should have correct properties', () => {
        expect(fixture.debugElement.query(By.css('.js-test-pano-alert-button-confirm')).properties.config).toEqual(
          MAX_ASSET_ALERT_BUTTON
        );
      });

      it('should call correct method when cancel button clicked', () => {
        spyOn(component, 'closeDialog');
        fixture.debugElement
          .query(By.css('.js-test-pano-alert-button-confirm'))
          .nativeElement.dispatchEvent(new Event('btClick', null));

        expect(component.closeDialog).toHaveBeenCalled();
      });
    });
  });
});
