import { Button } from '@bt/components/button';

export const DIALOG_CLOSE_BUTTON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  size: 'medium',
  colourModifier: 'basic',
  a11yProps: {
    ariaLabel: 'Close dialog'
  }
};

export const SUBMIT_BUTTON: Button = {
  type: 'solid',
  action: 'submit',
  label: 'Submit',
  size: 'large',
  colourModifier: 'primary',
  disableInEmulationMode: true,
  a11yProps: {
    ariaLabel: 'Submit'
  }
};

export const CANCEL_BUTTON: Button = {
  action: 'button',
  label: 'Cancel',
  size: 'large',
  colourModifier: 'primary',
  type: 'outline',
  a11yProps: {
    ariaLabel: 'Cancel and close dialog'
  }
};
