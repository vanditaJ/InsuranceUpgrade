import { LIQUIDITY_NEED_SLIDER, RISK_SLIDER } from './pano-inv-profile-setup.constants';

const riskSlider = RISK_SLIDER;
const liquidityNeedsSlider = LIQUIDITY_NEED_SLIDER;
describe('RISK_SLIDER', () => {
  it('should setup minValue as 0', () => {
    expect(riskSlider.minValue).toBe(0);
  });

  it('should setup maxValue as 0', () => {
    expect(riskSlider.maxValue).toBe(0);
  });

  it('should setup floor as 0', () => {
    expect(riskSlider.options.floor).toBe(0);
  });

  it('should setup ceil as 3', () => {
    expect(riskSlider.options.ceil).toBe(3);
  });

  it('should setup showTicksValues as true', () => {
    expect(riskSlider.options.showTicksValues).toBeTrue();
  });

  describe('translate()', () => {
    it('should transalte 0 to Low', () => {
      const expectedReturn = riskSlider.options.translate(0, 0);
      expect(expectedReturn).toBe('Low');
    });

    it('should transalte 1 to Medium', () => {
      const expectedReturn = riskSlider.options.translate(1, 0);
      expect(expectedReturn).toBe('Medium');
    });

    it('should transalte 2 to High', () => {
      const expectedReturn = riskSlider.options.translate(2, 0);
      expect(expectedReturn).toBe('High');
    });

    it('should transalte 3 to Very High', () => {
      const expectedReturn = riskSlider.options.translate(3, 0);
      expect(expectedReturn).toBe('Very High');
    });

    it('should transalte 4 to be empty', () => {
      const expectedReturn = riskSlider.options.translate(4, 0);
      expect(expectedReturn).toBe('');
    });
  });
});

describe('LIQUIDITY_NEED_SLIDER', () => {
  it('should setup minValue as 0', () => {
    expect(liquidityNeedsSlider.minValue).toBe(0);
  });

  it('should setup maxValue as 0', () => {
    expect(liquidityNeedsSlider.maxValue).toBe(0);
  });

  it('should setup floor as 0', () => {
    expect(liquidityNeedsSlider.options.floor).toBe(0);
  });

  it('should setup ceil as 4', () => {
    expect(liquidityNeedsSlider.options.ceil).toBe(4);
  });

  it('should setup showTicksValues as true', () => {
    expect(liquidityNeedsSlider.options.showTicksValues).toBeTrue();
  });

  describe('customValueToPosition()', () => {
    it('should return 0 if val is 0', () => {
      expect(liquidityNeedsSlider.options.customValueToPosition(0, 0, 0)).toBe(0);
    });

    it('should return 0.2 if val is 1', () => {
      expect(liquidityNeedsSlider.options.customValueToPosition(1, 0, 0)).toBe(0.2);
    });
    it('should return 0.4 if val is 2', () => {
      expect(liquidityNeedsSlider.options.customValueToPosition(2, 0, 0)).toBe(0.4);
    });
    it('should return 0.6 if val is 3', () => {
      expect(liquidityNeedsSlider.options.customValueToPosition(3, 0, 0)).toBe(0.6);
    });
    it('should return 1 if val is 4', () => {
      expect(liquidityNeedsSlider.options.customValueToPosition(4, 0, 0)).toBe(1);
    });
  });

  describe('customPositionToValue()', () => {
    it('should return 0 if percent is less 0.15', () => {
      expect(liquidityNeedsSlider.options.customPositionToValue(0, 0, 0)).toBe(0);
    });

    it('should return 1 if percent is >= 0.15 and < 0.25', () => {
      expect(liquidityNeedsSlider.options.customPositionToValue(0.16, 0, 0)).toBe(1);
    });
    it('should return 2 if percent is >=0.25 and <0.45', () => {
      expect(liquidityNeedsSlider.options.customPositionToValue(0.33, 0, 0)).toBe(2);
    });
    it('should return 3 if percent is >=0.45 and < 0.65', () => {
      expect(liquidityNeedsSlider.options.customPositionToValue(0.53, 0, 0)).toBe(3);
    });
    it('should return 4 if percent is >= 0.65 and < 1.5', () => {
      expect(liquidityNeedsSlider.options.customPositionToValue(1.2, 0, 0)).toBe(4);
    });
  });

  describe('translate()', () => {
    it('should transalte 0 to Daily', () => {
      const expectedReturn = liquidityNeedsSlider.options.translate(0, 0);
      expect(expectedReturn).toBe('Daily');
    });

    it('should transalte 1 to Weekly', () => {
      const expectedReturn = liquidityNeedsSlider.options.translate(1, 0);
      expect(expectedReturn).toBe('Weekly');
    });

    it('should transalte 2 to Monthly', () => {
      const expectedReturn = liquidityNeedsSlider.options.translate(2, 0);
      expect(expectedReturn).toBe('Monthly');
    });

    it('should transalte 3 to Quarterly', () => {
      const expectedReturn = liquidityNeedsSlider.options.translate(3, 0);
      expect(expectedReturn).toBe('Quarterly');
    });

    it('should transalte 4 to Annually or longer', () => {
      const expectedReturn = liquidityNeedsSlider.options.translate(4, 0);
      expect(expectedReturn).toBe('Annually or longer');
    });
  });
});
