import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatAccordion } from '@angular/material/expansion';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Icon } from '@bt/components/icon';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';
import { cloneDeep } from 'lodash-es';
import * as moment from 'moment-timezone';
import { finalize } from 'rxjs/operators';

import { PanoInvestmentProfileLoadingComponent } from './pano-inv-profile-loading/pano-inv-profile-loading.component';
import {
  ACCORDION_HEADER_ICON,
  ALL_INVESTMENT_TYPES_ICON,
  DATE_TIME_FORMAT,
  EDIT_INVESTMENT_PROFILE_BUTTON,
  INVESTMENT_PROFILE_TITLE,
  SAVE_PROFILE_FAILED_ALERT,
  SAVE_PROFILE_SUCCESS_ALERT,
  SET_UP_PROFILE_ALERT,
  SHARES_AND_ETFS_ICON,
  TIME_ZONE
} from './pano-inv-profile.constants';
import { InvestmentProfile, InvestmentType } from './pano-inv-profile.interface';
import { PanoInvestmentProfileService } from './pano-inv-profile.service';

@Component({
  selector: 'pano-inv-profile',
  templateUrl: './pano-inv-profile.component.html'
})
export class PanoInvestmentProfileComponent implements OnChanges {
  @Input() profile: InvestmentProfile;
  @Input() isEditable: boolean = true;
  @Output() profileChange: EventEmitter<InvestmentProfile> = new EventEmitter();

  @ViewChild(MatAccordion) invProfileAccordion: MatAccordion;

  readonly accordionHeaderIcon: Icon = ACCORDION_HEADER_ICON;
  readonly sharedAndEtfsIcon: Icon = SHARES_AND_ETFS_ICON;
  readonly allInvestmentTypesIcon: Icon = ALL_INVESTMENT_TYPES_ICON;

  readonly investmentProfileTitle: string = INVESTMENT_PROFILE_TITLE;

  readonly editInvestmentProfileButton: Button = EDIT_INVESTMENT_PROFILE_BUTTON;

  readonly setUpProfileAlert: Alert = SET_UP_PROFILE_ALERT;
  readonly saveProfileSuccessAlert: Alert = SAVE_PROFILE_SUCCESS_ALERT;
  readonly saveProfileFailedAlert: Alert = SAVE_PROFILE_FAILED_ALERT;
  readonly expansionIcon: Icon = ACCORDION_HEADER_ICON;

  isFirstTimeSettingProfile: boolean;
  isSaveProfileFailed: boolean;

  isEditingProfile: boolean = false;

  selectedInvestmentType: string;
  lastUpdatedAtTime: string;

  constructor(
    private copyMatrixPipe: CopyMatrixPipe,
    private dialog: MatDialog,
    private profileService: PanoInvestmentProfileService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes?.profile?.currentValue) {
      this.selectedInvestmentType = InvestmentType[changes?.profile?.currentValue?.investmentType];
      this.lastUpdatedAtTime = moment(changes?.profile?.currentValue?.lastUpdatedAt)
        .tz(TIME_ZONE)
        .format(DATE_TIME_FORMAT.DDMMMYYYYHMMAZ);
    } else {
      this.isFirstTimeSettingProfile = true;
    }
  }

  saveInvestmentProfile(profile: InvestmentProfile): void {
    this.isSaveProfileFailed = false;
    this.showSavingProfileProgress();

    this.profileService
      .setInvestmentProfile(profile.accountId, profile)
      .pipe(finalize(() => this.dialog.closeAll()))
      .subscribe(
        (investmentProfile: InvestmentProfile) => {
          this.profile = cloneDeep(investmentProfile);
          this.selectedInvestmentType = InvestmentType[investmentProfile.investmentType];
          this.lastUpdatedAtTime = moment(investmentProfile.lastUpdatedAt)
            .tz(TIME_ZONE)
            .format(DATE_TIME_FORMAT.DDMMMYYYYHMMAZ);

          this.setupSaveProfileSuccessMessage();

          this.isEditingProfile = false;
          this.isFirstTimeSettingProfile = false;
          this.profileChange.emit(this.profile);
          this.invProfileAccordion.closeAll();
        },
        () => {
          this.isSaveProfileFailed = true;
        }
      );
  }

  private setupSaveProfileSuccessMessage(): void {
    this.saveProfileSuccessAlert.messages = this.copyMatrixPipe.transform(
      this.saveProfileSuccessAlert.messages as string,
      this.lastUpdatedAtTime
    );

    this.saveProfileSuccessAlert.visibilitySubject.next();
  }

  private showSavingProfileProgress(): void {
    this.dialog.open(PanoInvestmentProfileLoadingComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: true,
      disableClose: true
    });
  }
}
