import { Icon } from '@bt/components/icon';
import { Loading } from '@bt/components/loading';
import { Optionals } from '@bt/services/data';

export const AEM_TEXT_URL: string =
  '/content/secure/panorama/_services/learn-about-investments/text-content/_jcr_content.getAggr.getContentPage.json';

export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0344' };

export const DEFAULT_PAGE_LOADING: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const NEW_WINDOW_ICON: Icon = {
  name: 'icon-external-link',
  size: 'x-small',
  type: 'info'
};
