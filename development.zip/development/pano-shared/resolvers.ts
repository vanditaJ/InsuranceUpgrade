import { Entitlements, EntitlementsService } from '@bt/services/entitlements';
import { Transition } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { Account } from './interfaces';

export function panoAccountResolver($transition$): Promise<Account> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const accountId = accountService.getAccountId();

  return accountService.getAccount(accountId).catch(() =>
    $transition$
      .injector()
      .get('$state')
      .go('app.investor.account.systemError', { accountId })
  );
}

export function panoEntitlementsResolver(transition: Transition, moduleName: string): Promise<Entitlements> {
  const accountService = transition.injector().get(PanoUpgradeAccountService);
  const accountId = accountService.getAccountId();

  return (transition.injector().get(EntitlementsService) as EntitlementsService)
    .fetchEntitlements(accountId, moduleName)
    .toPromise()
    .catch(() =>
      transition
        .injector()
        .get('$state')
        .go('app.investor.account.systemError', { accountId })
    );
}
