import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { Loading } from '@bt/components/loading';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoUpgradePermissionService } from '@upgrade/upgrade.services';
import { head, isEmpty } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of, Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';

import {
  BACK_OUT_NOTIFICATION_BUTTON,
  CANCEL_NOTIFICATION_BUTTON,
  EMAIL_OPTION_ACCOUNT_DETAILS,
  EMAIL_OPTION_ACCOUNT_DETAILS_PDF,
  NOTIFICATION_TYPE_DO_IT_FOR_ME,
  NOTIFICATION_TYPE_NOTIFY_ME,
  NOTIFICATION_TYPE_PDF_NOTIFY_ME,
  SETUP_TYPE_ON_MY_BEHALF,
  SETUP_TYPE_SELF,
  SUBMITTED_FOR_ME_ALERT,
  SUBMITTED_MYSELF_ALERT,
  SUBMITTED_NEXT_STEPS_ICON,
  SUBMIT_ANOTHER_FORM_BUTTON,
  SUBMIT_ERROR_ALERT,
  SUBMIT_NOTIFICATION_BUTTON,
  SUBMIT_SPINNER
} from './pano-employer-contributions-details.constants';
import { Account, NotificationResponse, Owner } from './pano-employer-contributions-details.interfaces';
import { PanoEmployerContributionsDetailsService } from './pano-employer-contributions-details.service';

@Component({
  selector: 'pano-employer-contributions-details',
  templateUrl: './pano-employer-contributions-details.component.html'
})
export class PanoEmployerContributionsDetailsComponent implements OnInit, OnDestroy {
  @Input()
  account: Account;

  formGroup: FormGroup;
  originalEmail: string;
  receiptId: string;
  submitted: boolean = false;
  submitting: boolean = false;
  submitError: boolean = false;
  submittedAlertConfig: Alert;
  disclaimer: string;
  productDisclaimer: string;
  hasSubmitPermission: boolean = true;

  readonly backOutNotificationButton: Button = BACK_OUT_NOTIFICATION_BUTTON;
  readonly submitNotificationButton: Button = SUBMIT_NOTIFICATION_BUTTON;
  readonly cancelNotificationButton: Button = CANCEL_NOTIFICATION_BUTTON;
  readonly submitAnotherFormButton: Button = SUBMIT_ANOTHER_FORM_BUTTON;
  readonly submittedNextStepsIcon: Icon = SUBMITTED_NEXT_STEPS_ICON;
  readonly setupTypeOnMyBehalf: string = SETUP_TYPE_ON_MY_BEHALF;
  readonly setupTypeSelf: string = SETUP_TYPE_SELF;
  readonly emailOptionAccountDetails: string = EMAIL_OPTION_ACCOUNT_DETAILS;
  readonly emailOptionAccountDetailsPdf: string = EMAIL_OPTION_ACCOUNT_DETAILS_PDF;
  readonly submitSpinner: Loading = SUBMIT_SPINNER;
  readonly submitErrorAlert: Alert = SUBMIT_ERROR_ALERT;

  private submitNotificationSubscription: Subscription = of(null).subscribe();

  constructor(
    private formBuilder: FormBuilder,
    private permissionService: PanoUpgradePermissionService,
    private service: PanoEmployerContributionsDetailsService,
    private copyMatrixPipe: CopyMatrixPipe,
    private disclaimerService: PanoDisclaimersService
  ) {}

  ngOnInit() {
    this.hasSubmitPermission = !this.permissionService.hasPermission('emulating', 'base');

    if (!isEmpty(this.account.owners)) {
      const email = head(head(this.account.owners).emails);

      if (email) {
        this.originalEmail = email.email;
      }
    }

    this.formGroup = this.formBuilder.group({
      setupType: [this.setupTypeSelf],
      employerContactName: ['', Validators.maxLength(50)],
      employerEmailAddress: ['', [Validators.required, Validators.email]],
      emailOption: ['', Validators.required],
      emailAddress: [this.originalEmail, [Validators.required, Validators.email]]
    });

    this.disclaimer = this.copyMatrixPipe
      .transform('DS-IP-0327')
      .replace('{1}', moment(new Date()).format('D MMM YYYY'));

    this.productDisclaimer = this.disclaimerService.evaluateDisclaimer(this.account);
  }

  ngOnDestroy() {
    this.submitNotificationSubscription.unsubscribe();
  }

  submitNotification() {
    if (this.hasInvalidInput()) {
      this.formGroup.controls.emailAddress.markAsTouched({ onlySelf: true });

      if (this.formGroup.controls.setupType.value === SETUP_TYPE_SELF) {
        this.formGroup.controls.emailOption.markAsTouched({ onlySelf: true });
      } else {
        this.formGroup.controls.employerContactName.markAsTouched({ onlySelf: true });
        this.formGroup.controls.employerEmailAddress.markAsTouched({ onlySelf: true });
      }

      return;
    }

    let notificationType: string;
    let employerContactName = '';
    let employerEmailAddress = '';

    if (this.formGroup.controls.setupType.value === SETUP_TYPE_SELF) {
      notificationType =
        this.formGroup.controls.emailOption.value === EMAIL_OPTION_ACCOUNT_DETAILS
          ? NOTIFICATION_TYPE_NOTIFY_ME
          : NOTIFICATION_TYPE_PDF_NOTIFY_ME;
      this.submittedAlertConfig = SUBMITTED_MYSELF_ALERT;
    } else {
      notificationType = NOTIFICATION_TYPE_DO_IT_FOR_ME;
      this.submittedAlertConfig = SUBMITTED_FOR_ME_ALERT;
      employerContactName = this.formGroup.controls.employerContactName.value;
      employerEmailAddress = this.formGroup.controls.employerEmailAddress.value;
    }

    this.submitError = false;
    this.submitting = true;

    // There is only one owner for BT Super
    const owner: Owner = head(this.account.owners);

    this.submitNotificationSubscription = this.service
      .submitNotification(
        notificationType,
        owner.firstName,
        owner.lastName,
        owner.dateOfBirth,
        employerContactName,
        employerEmailAddress,
        this.formGroup.controls.emailAddress.value
      )
      .pipe(
        finalize(() => {
          this.submitting = false;
        })
      )
      .subscribe(
        (response: NotificationResponse) => {
          this.receiptId = response.receiptId;
          this.submitted = true;
        },
        () => (this.submitError = true)
      );
  }

  reset() {
    this.submitted = false;
    this.submitting = false;
    this.submitError = false;
    this.formGroup.reset();
    this.formGroup.controls.setupType.setValue(this.setupTypeSelf);
    this.formGroup.controls.emailOption.setValue('');
    this.formGroup.controls.emailAddress.setValue(this.originalEmail);
  }

  hasInvalidInput() {
    if (this.formGroup.controls.setupType.value === SETUP_TYPE_SELF) {
      return this.formGroup.controls.emailAddress.invalid || this.formGroup.controls.emailOption.invalid;
    }

    return (
      this.formGroup.controls.emailAddress.invalid ||
      this.formGroup.controls.employerContactName.invalid ||
      this.formGroup.controls.employerEmailAddress.invalid
    );
  }
}
