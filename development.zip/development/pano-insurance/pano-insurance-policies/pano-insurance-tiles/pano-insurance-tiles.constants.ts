import { InsuranceTile } from './pano-insurance-tiles.interface';

export const INSURANCE_TILES: InsuranceTile[] = [
  {
    icon: {
      name: 'icon-death',
      type: 'brand-primary',
      size: 'large'
    },
    heading: 'Death cover',
    description:
      'Pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.'
  },
  {
    icon: {
      name: 'icon-income-protection',
      type: 'brand-primary',
      size: 'large'
    },
    heading: 'Total Permanent Disability/Disablement (TPD)',
    description: 'Provides cover if you become totally and permanently disabled and are no longer able to work.'
  },
  {
    icon: {
      name: 'icon-tpd',
      type: 'brand-primary',
      size: 'large'
    },
    heading: 'Salary Continuance Insurance (SCI)',
    description:
      'Provides a regular payment if you can’t work due to illness or injury. You can also choose to insure a percentage of your superannuation contributions.'
  }
];
