import { Component, Input } from '@angular/core';
import { Alert } from '@bt/components/alert';

import { ACCOUNTING_SOFTWARE_CONNECTED_ALERT } from '../pano-external-assets.constants';
import { SoftwareData } from '../pano-external-assets.interfaces';

@Component({
  selector: 'pano-external-assets-connected',
  templateUrl: './pano-external-assets-connected.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoExternalAssetsConnectedComponent {
  @Input()
  softwareData: SoftwareData;

  infoAlert: Alert = ACCOUNTING_SOFTWARE_CONNECTED_ALERT;
}
