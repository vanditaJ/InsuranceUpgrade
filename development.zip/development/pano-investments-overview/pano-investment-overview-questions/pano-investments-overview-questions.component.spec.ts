import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DataService } from '@bt/services/data';
import { LayoutModule } from '@panorama/components/layout';
import { of } from 'rxjs';

import { PanoInvestmentsOverviewQuestionsComponent } from './pano-investments-overview-questions.component';
import {
  FAQ_CONTENT,
  MOCK_AEM_CONTENT,
  MOCK_APIR_CODE
} from './pano-investments-overview-questions.component.spec.constants';
import {
  AEM_URL_SUFFIX,
  GENERIC_OPTIONS,
  INVESTMENT_OVERVIEW_FAQ_AEM_URL
} from './pano-investments-overview-questions.constants';
import { PanoInvestmentsOverviewQuestionsService } from './pano-investments-overview-questions.service';

describe('PanoInvestmentsOverviewQuestions', () => {
  let component: PanoInvestmentsOverviewQuestionsComponent;
  let fixture: ComponentFixture<PanoInvestmentsOverviewQuestionsComponent>;
  let service: PanoInvestmentsOverviewQuestionsService;

  const dataService = {
    retrieve: jasmine.createSpy().and.returnValue(of(MOCK_AEM_CONTENT))
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInvestmentsOverviewQuestionsComponent],
        imports: [LayoutModule],
        providers: [
          {
            provide: DataService,
            useValue: dataService
          },
          PanoInvestmentsOverviewQuestionsService
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentsOverviewQuestionsComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(PanoInvestmentsOverviewQuestionsService);
  });

  function initWithApirCode(apirCode: string) {
    spyOn(service, 'getAemContent').and.returnValue(of(MOCK_AEM_CONTENT));
    component.apirCode = apirCode;
    component.ngOnInit();
    fixture.detectChanges();
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Service', () => {
    it('should load the text from aem', () => {
      service.getAemContent(MOCK_APIR_CODE);
      expect(dataService.retrieve).toHaveBeenCalledWith(
        `${INVESTMENT_OVERVIEW_FAQ_AEM_URL}/${MOCK_APIR_CODE}/${AEM_URL_SUFFIX}`,
        GENERIC_OPTIONS
      );
    });
  });

  describe('Component', () => {
    it('should populate faq content', () => {
      initWithApirCode(MOCK_APIR_CODE);

      expect(component.faqContent).toEqual(FAQ_CONTENT);
    });
  });

  describe('View', () => {
    it('should have accordions with the correct header and description', () => {
      initWithApirCode(MOCK_APIR_CODE);

      expect(fixture.debugElement.query(By.css('.ts-test-accordion-header-0')).nativeElement.innerText).toContain(
        FAQ_CONTENT[0].header
      );
      expect(fixture.debugElement.query(By.css('.ts-test-accordion-body-0')).nativeElement.innerText).toContain(
        FAQ_CONTENT[0].description
      );

      expect(fixture.debugElement.query(By.css('.ts-test-accordion-header-1')).nativeElement.innerText).toContain(
        FAQ_CONTENT[1].header
      );
      expect(fixture.debugElement.query(By.css('.ts-test-accordion-body-1')).nativeElement.innerText).toContain(
        FAQ_CONTENT[1].description
      );
    });
  });
});
