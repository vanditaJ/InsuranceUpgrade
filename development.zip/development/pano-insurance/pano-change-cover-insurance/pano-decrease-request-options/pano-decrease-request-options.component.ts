import { DOCUMENT } from '@angular/common';
import { AfterViewInit, Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Button } from '@bt/components/button';
import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';
import { each, range } from 'lodash-es';
import { PageScrollService } from 'ngx-page-scroll-core';

import { CANCEL_FORM_BUTTON, REVIEW_FORM_BUTTON } from '../../pano-insurance.constants';
import { findContentByKey } from '../../pano-insurance.helper';
import { InsuranceOption, InsurancePolicy, NewCoverType, PolicyType } from '../../pano-insurance.interface';
import { ChangeCoverMode } from '../pano-change-cover-insurance.interface';

import {
  SCI_AEM_KEY,
  SCI_HINT_AEM_KEY,
  SUM_INSURED_AEM_KEY,
  UNITS_OF_COVER_AEM_KEY
} from './pano-decrease-request-options.constants';

@Component({
  selector: 'pano-decrease-request-options',
  templateUrl: './pano-decrease-request-options.component.html',
  styleUrls: ['./pano-decrease-request-options.component.scss']
})
export class PanoDecreaseRequestOptionsComponent implements OnInit, AfterViewInit {
  @Input() account: Account;
  @Input() insurance: InsurancePolicy;
  @Input() mode: ChangeCoverMode;
  @Input() cmsContent: AemContent[];
  @Input() newCoverType: NewCoverType;
  @Input() insuranceOptions: InsuranceOption[];

  @Output() reviewComplete: EventEmitter<object> = new EventEmitter<object>();
  @Output() navigate: EventEmitter<void> = new EventEmitter<void>();
  @Output() resetFocus: EventEmitter<void> = new EventEmitter<void>();

  decreaseRequestSelection: FormGroup;
  decreaseRequestAemMessage: string;
  unitsOfCoversRange: Array<number>;
  calculatedCoverAmount: number = 0;
  waitingPeriodOptions: string[] = [];
  benefitPeriodOptions: string[] = [];
  hasError: boolean = false;
  sciHintAemMessage: string;

  readonly cancelReviewFormButton: Button = CANCEL_FORM_BUTTON;
  readonly reviewFormButton: Button = REVIEW_FORM_BUTTON;

  constructor(
    private readonly fb: FormBuilder,
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: HTMLDocument
  ) {
    this.decreaseRequestSelection = this.fb.group({
      requestWaitingPeriod: [''],
      requestBenefitPeriod: [''],
      requestCoverAmount: [''],
      requestUnitsCover: ['']
    });
  }

  ngOnInit(): void {
    this.pageScrollService.scroll({
      document: this.document,
      scrollTarget: '.top-scroll',
      duration: 200
    });

    if (this.insurance.policyType === PolicyType.INCOME_PROTECTION) {
      if (!this.insuranceOptions) {
        this.hasError = true;
      } else {
        this.setWaitingPeriodOptions();
        this.validateDecreaseRequestForSCI();
      }
    } else if (this.insurance.unitsOfCover) {
      this.unitsOfCoversRange = range(1, this.insurance.unitsOfCover);
      this.validateRequestUnitsCover();
    } else {
      this.validateRequestCoverAmount();
    }

    if (this.newCoverType !== undefined) {
      if (this.insurance.unitsOfCover) {
        this.decreaseRequestSelection.controls.requestUnitsCover.setValue(this.newCoverType.requestUnitsCover);
        this.calculatedCoverAmount = this.newCoverType.requestCoverAmount;
      } else {
        this.decreaseRequestSelection.controls.requestCoverAmount.setValue(this.newCoverType.requestCoverAmount);
        if (this.insurance.policyType === PolicyType.INCOME_PROTECTION) {
          this.updateBenefitPeriodOptions(this.newCoverType.requestWaitingPeriod);
          this.decreaseRequestSelection.controls.requestWaitingPeriod.setValue(this.newCoverType.requestWaitingPeriod);
          this.decreaseRequestSelection.controls.requestBenefitPeriod.setValue(this.newCoverType.requestBenefitPeriod);
        }
      }
    }

    this.setAemMessages();
  }

  validateRequestUnitsCover(): void {
    this.decreaseRequestSelection = this.fb.group({
      requestUnitsCover: ['', [Validators.required]]
    });
  }

  validateRequestCoverAmount(): void {
    this.decreaseRequestSelection = this.fb.group({
      requestCoverAmount: [
        '',
        [
          Validators.required,
          Validators.min(1000),
          Validators.max(this.insurance.sumInsured - 0.01),
          Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
        ]
      ]
    });
  }

  validateDecreaseRequestForSCI(): void {
    this.decreaseRequestSelection = this.fb.group({
      requestWaitingPeriod: ['', [Validators.required]],
      requestBenefitPeriod: ['', [Validators.required]],
      requestCoverAmount: [
        '',
        [
          Validators.required,
          Validators.min(1000),
          Validators.max(this.insurance.sumInsured),
          Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
        ]
      ]
    });
  }

  ngAfterViewInit(): void {
    this.resetFocus.emit(); // move focus to parent heading
  }

  setCalculatedCoverAmount(value: any): void {
    this.calculatedCoverAmount = (this.insurance.sumInsured / this.insurance.unitsOfCover) * value;
  }

  setWaitingPeriodOptions(): void {
    this.insuranceOptions.forEach(option => {
      this.waitingPeriodOptions = [...this.waitingPeriodOptions, option.waitingPeriod];
    });
  }

  updateBenefitPeriodOptions(waitingPeriod: string): void {
    this.insuranceOptions.forEach(option => {
      if (option.waitingPeriod === waitingPeriod) {
        this.benefitPeriodOptions = option.benefitPeriods;
      }
    });
  }

  setAemMessages(): void {
    if (this.insurance.policyType === PolicyType.INCOME_PROTECTION) {
      this.decreaseRequestAemMessage = findContentByKey(this.cmsContent, SCI_AEM_KEY);
      this.sciHintAemMessage = findContentByKey(this.cmsContent, SCI_HINT_AEM_KEY);
    } else if (this.insurance.unitsOfCover) {
      this.decreaseRequestAemMessage = findContentByKey(this.cmsContent, UNITS_OF_COVER_AEM_KEY);
    } else {
      this.decreaseRequestAemMessage = findContentByKey(this.cmsContent, SUM_INSURED_AEM_KEY);
    }
  }

  validateAndSubmitForm(): void {
    each(this.decreaseRequestSelection.controls, (control: AbstractControl) => control.markAsTouched());

    if (this.decreaseRequestSelection.valid) {
      this.submitForm();
    }
  }

  submitForm(): void {
    if (this.insurance.unitsOfCover) {
      this.decreaseRequestSelection.setControl('requestCoverAmount', new FormControl(this.calculatedCoverAmount));
    }
    this.reviewComplete.emit(this.decreaseRequestSelection.value);
  }

  cancel(): void {
    this.navigate.emit();
  }
}
