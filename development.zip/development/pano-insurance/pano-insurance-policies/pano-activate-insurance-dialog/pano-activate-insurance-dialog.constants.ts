import { Button } from '@bt/components/button';

export const SUBMIT_BUTTON: Button = {
  action: 'submit',
  disableInEmulationMode: true,
  label: 'Activate',
  size: 'large',
  type: 'solid',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Activate'
  }
};

export const CANCEL_BUTTON: Button = {
  action: 'button',
  label: 'Cancel',
  size: 'large',
  type: 'outline',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Cancel and close dialog'
  }
};

export const CLOSE_ICON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  size: 'medium',
  colourModifier: 'basic',
  a11yProps: {
    ariaLabel: 'Close dialog'
  }
};
