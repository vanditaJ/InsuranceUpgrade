import { HttpHeaders } from '@angular/common/http';
import { Alert } from '@bt/components/alert';
import { Loading } from '@bt/components/loading';
import { Optionals } from '@bt/services/data';

export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0315' };

export const GENERIC_CACHE_OPTIONS: Optionals = {
  errorCode: 'Err.IP-0315',
  cacheOptions: {
    cacheInterval: 20,
    refreshCache: false
  }
};

export const GET_INVESTOR_ASSET_TYPES_OPTIONS: Optionals = {
  ...GENERIC_CACHE_OPTIONS,
  errorCode: 'Err.IP-0344'
};

export const GENERIC_SAVE_OPTIONS: Optionals = {
  httpOptions: {
    headers: new HttpHeaders({ 'Content-Type': 'application/json', Accept: 'application/json' })
  },
  errorCode: 'Err.IP-0344'
};

export enum SOFTWARE_STATUS {
  MANUAL = 'manual',
  RECEIVED = 'received',
  AWAITING = 'awaiting',
  REQUESTED = 'requested',
  STOP = 'stop'
}

export enum SOFTWARE_NAME {
  CLASS_SUPER = 'Class Super',
  BGL_SF360 = 'BGL SF360'
}

export enum SCREEN_TYPE {
  MANUAL = 'manual',
  CONNECTED = 'connected',
  PENDING = 'pending'
}

export const ACCOUNTING_SOFTWARE_CONNECTED_ALERT: Alert = {
  type: 'info',
  outline: true
};

export const ACCOUNTING_SOFTWARE_CONNECTION_PENDING_ALERT: Alert = {
  type: 'warning',
  outline: true
};

export const SMSF_SERVICES_ALERT: Alert = {
  type: 'info',
  outline: true
};

export const GENERIC_ALERT: Alert = {
  type: 'error',
  messages: '',
  outline: true,
  showCodes: false
};

export const INITIAL_PAGE_LOADING: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const SMSF_SERVICE_MODULE_NAME: string = 'app.investor.account.smsfServices';
export const SYSTEM_ERROR_MODULE_NAME: string = 'app.investor.account.systemError';
export const SMSF_ACCOUNTING_SOFTWARE_READ_ENTITLEMENT: string = 'accountingSoftware.connect.read';

export const MODULE_NAME: string = 'external-assets';
