export interface Content {
  description: string;
  headerText: string;
}

export interface ContentItem {
  id: string;
  data: Content;
}

export interface CmsContent {
  details: ContentItem[];
}

export interface PersonalRateOfReturn {
  apirCode: string;
  investmentOptionName: string;
  startDate: string;
  endDate: string;
  rateOfReturn: number;
}

export interface Investment {
  allocationPercentage: number;
  apirCode: string;
  fundName: string;
  balance: number;
}

export interface Investments {
  investments: Investment[];
}
export interface InvestmentAllocation {
  name: string;
  allocation: string;
}
