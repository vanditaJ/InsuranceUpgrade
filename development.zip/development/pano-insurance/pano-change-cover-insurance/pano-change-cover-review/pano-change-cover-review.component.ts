import { DOCUMENT } from '@angular/common';
import { AfterViewInit, Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { PageScrollService } from 'ngx-page-scroll-core';
import { finalize } from 'rxjs/operators';

import { PanoInsuranceSharedLinkService } from '../../pano-insurance-shared-link/pano-insurance-shared-link.service';
import { LinkType } from '../../pano-insurance-shared-link/pano-insurance-shared-link.service.constants';
import { CANCEL_FORM_BUTTON, CHANGE_FORM_BUTTON, SUBMIT_FORM_BUTTON } from '../../pano-insurance.constants';
import { findContentByKey } from '../../pano-insurance.helper';
import {
  InsurancePolicy,
  NewCoverType,
  PolicyStatus,
  PolicyType,
  SelectCoverType
} from '../../pano-insurance.interface';
import { PanoInsuranceService } from '../../pano-insurance.service';
import { PanoInsuranceUtil } from '../../pano-insurance.util';
import {
  ChangeCoverMode,
  CoverAmountOptions,
  CoverMode,
  CoverState,
  CoverTypeSelected
} from '../pano-change-cover-insurance.interface';
import {
  PRE_EXISTING_CONDITIONS_AEM_KEY,
  PRE_EXISTING_CONDITIONS_CONFIG
} from '../pano-change-cover-options/pano-change-cover-options.constants';
import { PanoContentDialogComponent } from '../pano-change-cover-options/pano-content-dialog/pano-content-dialog.component';

import {
  CHANGE_INCREASE_ACTIVE_COVER_INFO_AEM_KEY,
  CHANGE_INCREASE_ACTIVE_COVER_TERMS_AEM_KEY,
  CHANGE_PENDING_COVER_INFO_AEM_KEY,
  CHANGE_PENDING_COVER_TERMS_AEM_KEY,
  CHANGE_REDUCE_ACTIVE_COVER_INFO_AEM_KEY,
  CHANGE_REDUCE_ACTIVE_COVER_TERMS_AEM_KEY,
  DECREASE_COVER_INFO_AEM_KEY,
  DECREASE_COVER_TERMS_AEM_KEY,
  DECREASE_REQUEST_COVER_TERMS_AEM_KEY,
  DECREASE_REQUEST_SCI_AEM_KEY,
  DECREASE_REQUEST_SUM_INSURED_AEM_KEY,
  DECREASE_REQUEST_UNITS_AEM_KEY,
  DECREASE_REVIEW_MSG_DEATH,
  DECREASE_REVIEW_MSG_DEATH_AND_TPD,
  PRE_EXISTING_CONDITIONS_BUTTON,
  REVIEW_CANCEL_MSG,
  SUBMIT_ERROR_ALERT
} from './pano-change-cover-review.constants';

@Component({
  selector: 'pano-change-cover-review',
  templateUrl: './pano-change-cover-review.component.html',
  styleUrls: ['./pano-change-cover-review.component.scss']
})
export class PanoChangeCoverReviewComponent implements OnInit, AfterViewInit {
  @Input() account: Account;
  @Input() insurance: InsurancePolicy;
  @Input() mode: ChangeCoverMode;
  @Input() currentCoverType: CoverAmountOptions;
  @Input() newCoverType: NewCoverType;
  @Input() selectedCoverLevel: CoverTypeSelected['coverLevels'];
  @Input() hideChangeButton: boolean;
  @Input() cmsContent: AemContent[];

  @Output() updateState: EventEmitter<string> = new EventEmitter<string>();
  @Output() resetFocus: EventEmitter<void> = new EventEmitter<void>();

  submitting: boolean = false;
  submitError: boolean = false;
  showReviewCancelMsg: boolean = false;
  showDecreaseReviewMsgDeath: boolean = false;
  showDecreaseReviewMsgDeathAndTpd: boolean = false;
  infoAemMessage: string;
  termsAemMessage: string;
  preExistingConditionsAemMessage: string;
  isIncrease: boolean = false;
  productDisclosureStatementLink: string;

  readonly coverMode = CoverMode;
  readonly changeFormButton: Button = CHANGE_FORM_BUTTON;
  readonly submitButton: Button = SUBMIT_FORM_BUTTON;
  readonly cancelFormButton: Button = CANCEL_FORM_BUTTON;
  readonly submitErrorAlert: Alert = SUBMIT_ERROR_ALERT;
  readonly decreaseReviewMsgDeath: Alert = DECREASE_REVIEW_MSG_DEATH;
  readonly decreaseReviewMsgDeathAndTpd: Alert = DECREASE_REVIEW_MSG_DEATH_AND_TPD;
  readonly reviewCancelMsg: Alert = REVIEW_CANCEL_MSG;
  readonly preExistingConditionsButton: Button = PRE_EXISTING_CONDITIONS_BUTTON;

  checkTermsAndCondition: FormGroup;

  constructor(
    private fb: FormBuilder,
    public policies: PanoInsuranceService,
    private accountService: PanoUpgradeAccountService,
    private pageScrollService: PageScrollService,
    private panoInsuranceUtil: PanoInsuranceUtil,
    private linkService: PanoInsuranceSharedLinkService,
    @Inject(DOCUMENT) private document: HTMLDocument,
    private readonly dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.pageScrollService.scroll({
      document: this.document,
      scrollTarget: '.top-scroll',
      duration: 200
    });

    this.isIncrease = get(this.newCoverType, 'coverAmountType.increase', false);

    if (this.mode === CoverMode.DECREASE_REQUEST) {
      this.checkTermsAndConditionDecreaseRequestCover();
      this.setDecreaseRequestCoverType();
    } else {
      this.checkTermsAndConditionChangeCover();
      this.showReviewMsg();
    }
    this.setAemMessages();
    this.setPDSLink();
  }

  ngAfterViewInit(): void {
    this.resetFocus.emit(); // move focus to parent heading
  }

  checkTermsAndConditionChangeCover(): void {
    this.checkTermsAndCondition = this.fb.group({
      preExisting: ['', [Validators.requiredTrue]],
      acknowledge: ['', [Validators.requiredTrue]]
    });
  }

  checkTermsAndConditionDecreaseRequestCover(): void {
    this.checkTermsAndCondition = this.fb.group({
      acknowledge: ['', [Validators.requiredTrue]]
    });
  }

  showReviewMsg(): void {
    if (
      this.mode === CoverMode.DECREASE &&
      this.currentCoverType.coverTypeSelected.length === 1 &&
      this.currentCoverType.coverTypeSelected[0].coverLevels.length === 1 &&
      this.panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria(this.insurance, this.account) > 90
    ) {
      if (this.currentCoverType.policyType === PolicyType.DEATH) {
        this.showDecreaseReviewMsgDeath = true;
      } else if (this.currentCoverType.policyType === PolicyType.DEATH_AND_TPD) {
        this.showDecreaseReviewMsgDeathAndTpd = true;
      }
    }
    if (
      this.currentCoverType &&
      this.currentCoverType.policyType === PolicyType.DEATH_AND_TPD &&
      this.newCoverType.coverType.policyType === PolicyType.DEATH
    ) {
      this.showReviewCancelMsg = true;
    }
  }

  setAemMessages(): void {
    this.preExistingConditionsAemMessage = findContentByKey(this.cmsContent, PRE_EXISTING_CONDITIONS_AEM_KEY);

    if (this.mode === CoverMode.DECREASE) {
      this.infoAemMessage = findContentByKey(this.cmsContent, DECREASE_COVER_INFO_AEM_KEY);
      this.termsAemMessage = findContentByKey(this.cmsContent, DECREASE_COVER_TERMS_AEM_KEY);
    } else if (this.mode === CoverMode.DECREASE_REQUEST) {
      if (this.insurance.policyType === PolicyType.INCOME_PROTECTION) {
        this.infoAemMessage = findContentByKey(this.cmsContent, DECREASE_REQUEST_SCI_AEM_KEY);
      } else if (this.insurance.unitsOfCover) {
        this.infoAemMessage = findContentByKey(this.cmsContent, DECREASE_REQUEST_UNITS_AEM_KEY);
      } else {
        this.infoAemMessage = findContentByKey(this.cmsContent, DECREASE_REQUEST_SUM_INSURED_AEM_KEY);
      }
      this.termsAemMessage = findContentByKey(this.cmsContent, DECREASE_REQUEST_COVER_TERMS_AEM_KEY);
    } else {
      if (this.insurance.status === PolicyStatus.ACTIVE) {
        if (this.isIncrease) {
          this.infoAemMessage = findContentByKey(this.cmsContent, CHANGE_INCREASE_ACTIVE_COVER_INFO_AEM_KEY);
          this.termsAemMessage = findContentByKey(this.cmsContent, CHANGE_INCREASE_ACTIVE_COVER_TERMS_AEM_KEY);
        } else {
          this.infoAemMessage = findContentByKey(this.cmsContent, CHANGE_REDUCE_ACTIVE_COVER_INFO_AEM_KEY);
          this.termsAemMessage = findContentByKey(this.cmsContent, CHANGE_REDUCE_ACTIVE_COVER_TERMS_AEM_KEY);
        }
      } else {
        this.infoAemMessage = findContentByKey(this.cmsContent, CHANGE_PENDING_COVER_INFO_AEM_KEY);
        this.termsAemMessage = findContentByKey(this.cmsContent, CHANGE_PENDING_COVER_TERMS_AEM_KEY);
      }
    }
  }

  setPDSLink(): void {
    this.productDisclosureStatementLink = this.linkService.getUrl(
      LinkType.PRODUCT_DISCLOSURE_STATEMENT,
      this.insurance,
      this.account
    );
  }

  setDecreaseRequestCoverType(): void {
    const newSelectCoverType: SelectCoverType = {
      policyName: this.insurance.policyName,
      policyType: this.insurance.policyType
    };

    const newSelectedCoverAmount = {
      coverSubTypeId: this.insurance.coverSubTypeId,
      coverAmount: this.newCoverType.requestCoverAmount
    };

    this.newCoverType.coverType = newSelectCoverType;
    this.newCoverType.coverAmountType = newSelectedCoverAmount;
  }

  navigateToOptionsScreen(): void {
    this.updateState.emit(CoverState.OPTIONS);
  }

  submitForm(): void {
    if (this.checkTermsAndCondition.valid) {
      this.submitError = false;
      this.submitting = true;
      this.checkTermsAndCondition.disable();

      if (this.mode === CoverMode.DECREASE_REQUEST) {
        this.submitChangeRequest(); // request earthrise
      } else {
        this.submitInsurance(); // submit to composer
      }
    }
  }

  submitInsurance(): void {
    const params = {
      policyNumber: get(this.insurance, 'policyNumber'),
      ageNextBirthday: get(this.insurance, 'ageNextBirthday'),
      status: get(this.insurance, 'status'),
      coverSubTypeId: get(this.newCoverType, 'coverAmountType.coverSubTypeId'),
      coverAmount: get(this.newCoverType, 'coverAmountType.coverAmount'),
      currentStartDate: moment(this.insurance.commencementDate)
        .tz('Australia/Sydney')
        .format('YYYY-MM-DD'),
      increase: this.isIncrease
    };

    this.policies
      .submitInsurance(this.accountService.getAccountId(), params)
      .pipe(
        finalize(() => {
          this.submitting = false;
          this.checkTermsAndCondition.enable();
        })
      )
      .subscribe(
        () => {
          this.updateState.emit(CoverState.CONFIRMATION);
        },
        () => {
          this.submitError = true;
          this.pageTopScroll();
        }
      );
  }

  submitChangeRequest(): void {
    const params = {} as any;
    params.policyNumber = get(this.insurance, 'policyNumber');
    params.coverSubTypeId = get(this.newCoverType, 'coverAmountType.coverSubTypeId');

    if (this.insurance.policyType === PolicyType.INCOME_PROTECTION) {
      params.waitingPeriod = this.newCoverType.requestWaitingPeriod;
      params.benefitPeriod = this.newCoverType.requestBenefitPeriod;
      params.coverAmount = this.newCoverType.coverAmountType.coverAmount;
    } else if (this.insurance.unitsOfCover) {
      params.units = get(this.newCoverType, 'requestUnitsCover');
    } else {
      params.coverAmount = get(this.newCoverType, 'coverAmountType.coverAmount');
    }

    this.policies
      .submitChangeRequest(this.accountService.getAccountId(), params)
      .pipe(
        finalize(() => {
          this.submitting = false;
          this.checkTermsAndCondition.enable();
        })
      )
      .subscribe(
        () => {
          this.updateState.emit(CoverState.CONFIRMATION);
        },
        () => {
          this.submitError = true;
          this.pageTopScroll();
        }
      );
  }

  pageTopScroll(): void {
    this.pageScrollService.scroll({
      document: this.document,
      scrollTarget: '.top-scroll',
      scrollViews: [this.document.querySelector('.layout-scroll')],
      duration: 200
    });
  }

  openPreExistingConditionsDialog(): void {
    this.dialog.open(PanoContentDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: false,
      ariaLabel: 'Open pre-existing conditions information dialog',
      data: {
        ...PRE_EXISTING_CONDITIONS_CONFIG,
        descriptionText: this.preExistingConditionsAemMessage
      }
    });
  }
}
