import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { of } from 'rxjs';

import {
  MOCK_FULLY_ALLOCATED_LIFESTAGE,
  MOCK_NO_BALANCE_LIFESTAGE,
  MOCK_NO_LIFESTAGE,
  MOCK_PARTIALLY_ALLOCATED_LIFESTAGE
} from './pano-investments-overview.constants.spec';
import { panoLifestageInvestmentResolver } from './pano-investments-overview.resolver';
import { PanoInvestmentsOverviewService } from './pano-investments-overview.service';

describe('panoInsurancePolicyResolver', () => {
  let accountServiceSpyObj: jasmine.SpyObj<PanoUpgradeAccountService>;
  let panoInvestmentsOverviewServiceSpyObj: jasmine.SpyObj<PanoInvestmentsOverviewService>;
  let transition;
  const getObj: any = { get: () => {} };

  beforeEach(() => {
    accountServiceSpyObj = jasmine.createSpyObj('PanoUpgradeAccountService', ['getAccountId']);
    panoInvestmentsOverviewServiceSpyObj = jasmine.createSpyObj('PanoInvestmentsOverviewService', [
      'getCurrentInvestments'
    ]);
    transition = {
      injector: () => getObj
    };
  });

  it('call panoLifestageInvestmentResolver method and return fully allocated lifestage fund', async () => {
    const accountId = '123';
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');
    getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
    getSpy.withArgs(PanoInvestmentsOverviewService).and.returnValue(panoInvestmentsOverviewServiceSpyObj);

    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoInvestmentsOverviewServiceSpyObj.getCurrentInvestments.and.returnValues(of(MOCK_FULLY_ALLOCATED_LIFESTAGE));

    const promise = panoLifestageInvestmentResolver(transition);
    const investment = await promise;

    expect(investment).toEqual(MOCK_FULLY_ALLOCATED_LIFESTAGE.investments[0]);
  });

  it('call panoLifestageInvestmentResolver method and return exception for not fully allocated lifestage fund', async () => {
    const accountId = '123';
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');

    getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
    getSpy.withArgs(PanoInvestmentsOverviewService).and.returnValue(panoInvestmentsOverviewServiceSpyObj);

    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoInvestmentsOverviewServiceSpyObj.getCurrentInvestments.and.returnValues(of(MOCK_PARTIALLY_ALLOCATED_LIFESTAGE));

    try {
      await panoLifestageInvestmentResolver(transition);
    } catch (error) {
      expect(error).toEqual({ msg: 'Fully allocated lifestage fund not found!' });
    }
  });

  it('call panoLifestageInvestmentResolver method and return exception if no balance for allocated lifestage fund', async () => {
    const accountId = '123';
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');

    getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
    getSpy.withArgs(PanoInvestmentsOverviewService).and.returnValue(panoInvestmentsOverviewServiceSpyObj);

    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoInvestmentsOverviewServiceSpyObj.getCurrentInvestments.and.returnValues(of(MOCK_NO_BALANCE_LIFESTAGE));

    try {
      await panoLifestageInvestmentResolver(transition);
    } catch (error) {
      expect(error).toEqual({ msg: 'Fully allocated lifestage fund not found!' });
    }
  });

  it('call panoLifestageInvestmentResolver method and return exception if no lifestage fund found', async () => {
    const accountId = '123';
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');

    getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
    getSpy.withArgs(PanoInvestmentsOverviewService).and.returnValue(panoInvestmentsOverviewServiceSpyObj);

    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoInvestmentsOverviewServiceSpyObj.getCurrentInvestments.and.returnValues(of(MOCK_NO_LIFESTAGE));

    try {
      await panoLifestageInvestmentResolver(transition);
    } catch (error) {
      expect(error).toEqual({ msg: 'Fully allocated lifestage fund not found!' });
    }
  });
});
