import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Button } from '@bt/components/button';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { cloneDeep } from 'lodash-es';

import { INVESTMENT_TYPES } from '../pano-inv-profile.constants';
import {
  InvestmentObjective,
  InvestmentProfile,
  InvestmentTimeframe,
  RedemptionFrequency,
  ReturnObjective
} from '../pano-inv-profile.interface';

import { PanoInvestmentPreferencesComponent } from './pano-inv-pref/pano-inv-pref.component';
import { CheckboxField } from './pano-inv-pref/pano-inv-pref.interface';
import {
  INVESTMENT_OBJECTIVES,
  INVESTMENT_TIMEFRAMES,
  LIQUIDITY_NEED_SLIDER,
  RESET_INVESTMENT_PROFILE_BUTTON,
  RISK_SLIDER,
  SAVE_INVESTMENT_PROFILE_BUTTON,
  SET_UP_INVESTMENT_PROFILE_BUTTON,
  SET_UP_INVESTMENT_PROFILE_CONFIRMATION,
  SET_UP_INVESTMENT_PROFILE_DESCRIPTION,
  SET_UP_INVESTMENT_PROFILE_TITLE
} from './pano-inv-profile-setup.constants';
import { RangeSliderModel } from './pano-inv-profile-setup.interface';
import { PanoInvestmentTypesComponent } from './pano-inv-types/pano-inv-types.component';

@Component({
  selector: 'pano-inv-profile-setup',
  templateUrl: './pano-inv-profile-setup.component.html'
})
export class PanoInvestmentProfileSetupComponent implements OnInit {
  @Input() profile: InvestmentProfile;
  @Output() saveProfile: EventEmitter<InvestmentProfile> = new EventEmitter();

  @ViewChild(PanoInvestmentTypesComponent) investmentTypesComponent: PanoInvestmentTypesComponent;
  @ViewChild(PanoInvestmentPreferencesComponent) investmentPreferencesComponent: PanoInvestmentPreferencesComponent;

  accountId: string;
  existingProfile: InvestmentProfile;

  investmentObjectives: CheckboxField[];
  investmentTimeframes: CheckboxField[];

  riskReturnObjectives: RangeSliderModel;
  redemptionFrequencies: RangeSliderModel;

  transformedInvestmentObjectives: CheckboxField[];
  transformedInvestmentTimeframes: CheckboxField[];

  transformedReturnObjectives: RangeSliderModel;
  transformedRedemptionFrequencies: RangeSliderModel;

  readonly setUpInvestmentProfileTitle: string = SET_UP_INVESTMENT_PROFILE_TITLE;
  readonly setUpInvestmentProfileDescription: string = SET_UP_INVESTMENT_PROFILE_DESCRIPTION;
  readonly setUpInvestmentProfileConfirmation: string = SET_UP_INVESTMENT_PROFILE_CONFIRMATION;

  readonly setUpInvestmentProfileButton: Button = SET_UP_INVESTMENT_PROFILE_BUTTON;
  readonly saveInvestmentProfileButton: Button = SAVE_INVESTMENT_PROFILE_BUTTON;
  readonly resetInvestmentProfileButton: Button = RESET_INVESTMENT_PROFILE_BUTTON;
  readonly allInvestmentTypes: string = INVESTMENT_TYPES.ALL_INVESTMENT_TYPES;

  constructor(private accountService: PanoUpgradeAccountService) {
    this.accountId = this.accountService.getAccountId();
  }

  ngOnInit(): void {
    this.existingProfile = cloneDeep(this.profile);

    this.resetProfilePreferences(true);

    if (this.existingProfile) {
      // if existing profile, then transform data to render checkbox and slider
      this.transformInvestmentPreferencesFromTextValue(this.existingProfile);
    }
    this.saveTransformedProfilePreferences();
  }

  initInvestmentProfile(): void {
    this.profile = {
      accountId: this.accountId,
      investmentType: ''
    };
  }

  resetInvestmentProfile(): void {
    this.resetProfilePreferences();

    if (this.investmentPreferencesComponent) {
      this.investmentPreferencesComponent.noInvestmentObjectivesChecked = false;
      this.investmentPreferencesComponent.noInvestmentTimeframesChecked = false;
    }
  }

  saveInvestmentProfile(): void {
    this.investmentTypesComponent.form.controls.investmentType.markAsTouched();

    if (this.investmentPreferencesComponent) {
      this.investmentPreferencesComponent.updateInvestmentObjectivesState();
      this.investmentPreferencesComponent.updateInvestmentTimeframesState();
    }

    if (
      INVESTMENT_TYPES.SHARES_AND_ETFS === this.profile.investmentType ||
      INVESTMENT_TYPES.ALL_INVESTMENT_TYPES === this.profile.investmentType
    ) {
      let newProfile: InvestmentProfile = {
        accountId: this.accountId,
        profileId: this.profile.profileId,
        investmentType: this.profile.investmentType
      };

      if (INVESTMENT_TYPES.ALL_INVESTMENT_TYPES === this.profile.investmentType) {
        newProfile = this.transformInvestmentPreferencesToTextValue(newProfile);
        if (!newProfile.investmentObjectives.length || !newProfile.investmentTimeframes.length) {
          return;
        }
      }

      this.saveProfile.emit(newProfile);
    }
  }

  private resetProfilePreferences(isInit?: boolean): void {
    if (isInit) {
      this.investmentObjectives = cloneDeep(INVESTMENT_OBJECTIVES);
      this.investmentTimeframes = cloneDeep(INVESTMENT_TIMEFRAMES);
      this.riskReturnObjectives = cloneDeep(RISK_SLIDER);
      this.redemptionFrequencies = cloneDeep(LIQUIDITY_NEED_SLIDER);
    } else {
      this.investmentObjectives = cloneDeep(this.transformedInvestmentObjectives);
      this.investmentTimeframes = cloneDeep(this.transformedInvestmentTimeframes);
      this.riskReturnObjectives = cloneDeep(this.transformedReturnObjectives);
      this.redemptionFrequencies = cloneDeep(this.transformedRedemptionFrequencies);
    }
  }

  private saveTransformedProfilePreferences(): void {
    this.transformedInvestmentObjectives = cloneDeep(this.investmentObjectives);
    this.transformedInvestmentTimeframes = cloneDeep(this.investmentTimeframes);
    this.transformedReturnObjectives = cloneDeep(this.riskReturnObjectives);
    this.transformedRedemptionFrequencies = cloneDeep(this.redemptionFrequencies);
  }

  private transformInvestmentPreferencesFromTextValue(profile: InvestmentProfile): void {
    profile.investmentObjectives.forEach(
      profileInvestmentObjective =>
        (this.investmentObjectives.find(
          investmentObjective => investmentObjective.name === profileInvestmentObjective
        ).value = true)
    ); // transform text value to corresponding field boolean value

    profile.investmentTimeframes.forEach(
      profileInvestmentTimeframe =>
        (this.investmentTimeframes.find(
          investmentTimeframe => investmentTimeframe.name === profileInvestmentTimeframe
        ).value = true)
    ); // transform text value to corresponding field boolean value

    // transform ranges' current value and highValue into number from text
    this.riskReturnObjectives.minValue = Object.values(ReturnObjective).findIndex(
      returnObjective => returnObjective === profile.riskReturnObjectives[0]
    );

    if (1 === profile.riskReturnObjectives.length) {
      this.riskReturnObjectives.maxValue = this.riskReturnObjectives.minValue;
    } else {
      this.riskReturnObjectives.maxValue = Object.values(ReturnObjective).findIndex(
        returnObjective => returnObjective === profile.riskReturnObjectives[1]
      );
    }

    this.redemptionFrequencies.minValue = Object.values(RedemptionFrequency).findIndex(
      redemptionFrequency => redemptionFrequency === profile.redemptionFrequencies[0]
    );

    if (1 === profile.redemptionFrequencies.length) {
      this.redemptionFrequencies.maxValue = this.redemptionFrequencies.minValue;
    } else {
      this.redemptionFrequencies.maxValue = Object.values(RedemptionFrequency).findIndex(
        redemptionFrequency => redemptionFrequency === profile.redemptionFrequencies[1]
      );
    }
  }

  private transformInvestmentPreferencesToTextValue(profile: InvestmentProfile): InvestmentProfile {
    // transform boolean and numeric value to text value
    profile.investmentObjectives = [];
    this.investmentObjectives.forEach(objective => {
      if (objective.value) {
        profile.investmentObjectives.push(InvestmentObjective[objective.name]);
      }
    });

    profile.investmentTimeframes = [];
    this.investmentTimeframes.forEach(timeframe => {
      if (timeframe.value) {
        profile.investmentTimeframes.push(InvestmentTimeframe[timeframe.name]);
      }
    });

    profile.riskReturnObjectives = [];
    profile.riskReturnObjectives.push(Object.values(ReturnObjective)[this.riskReturnObjectives.minValue]);
    if (this.riskReturnObjectives.minValue !== this.riskReturnObjectives.maxValue) {
      profile.riskReturnObjectives.push(Object.values(ReturnObjective)[this.riskReturnObjectives.maxValue]);
    }

    profile.redemptionFrequencies = [];
    profile.redemptionFrequencies.push(Object.values(RedemptionFrequency)[this.redemptionFrequencies.minValue]);
    if (this.redemptionFrequencies.minValue !== this.redemptionFrequencies.maxValue) {
      profile.redemptionFrequencies.push(Object.values(RedemptionFrequency)[this.redemptionFrequencies.maxValue]);
    }

    return profile;
  }
}
