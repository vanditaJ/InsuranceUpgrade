import { Policy, PolicyStatus, PolicyType, RelatedAccounts, StaticData } from "./pano-insurance-list.interface";
export const MOCK_RELATED_POLICIES: RelatedAccounts ={
  policyType: 'INCOME_LINKING_PLUS',
  policyName: 'Income Linking Plus',
  policyNumber: 'CF748845',

}
export const MOCK_STATIC_POLICIES : StaticData ={
  id: 'IN_SUSPENSE',
  code: 'IN_SUSPENSE',
  label: 'In suspense',
}
export const MOCK_POLICIES: Policy = {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2080-02-03T00:00:00.000+10:00',
    endDate: '2021-03-03T00:00:00.000+10:00',
    external: true,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: true,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 65,
    customerType: 'Retail',
    personBenefitDetails: [
      {
        benefits: [
          {
            waitingPeriod: '90',
            benefitPeriodFactor: 'Years',
            benefitPeriodTerm: '2',
            benefits: [
              {
                frequency: 'MONTHLY',
                occupationClass: 'N/A'
              }
            ]
          }
        ]
      }
    ]
  };
  