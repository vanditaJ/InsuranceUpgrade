import { EventEmitter } from '@angular/core';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { FormArray, FormControl, Validators } from '@angular/forms';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';
import { cloneDeep } from 'lodash-es';
import { of, Subscription } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from './pano-external-assets-common.util';
import { TEST_CASH_ASSETS_FORM_ARRAY } from './pano-external-assets-constants/pano-external-assets-constants.spec.data';
import {
  ASSET_TYPES,
  MANAGED_FUND_ASSET_QUANTITY_REGEX,
  OTHER_ASSET_QUANTITY_REGEX
} from './pano-external-assets-constants/pano-external-assets.constants';
import { AssetTypeTotalDetails, ExternalAssetDeleteDetails } from './pano-external-assets.interfaces';

describe('PanoExternalAssetsCommonUtil ', () => {
  let panoExternalAssetsCommonUtil: PanoExternalAssetsCommonUtil;
  let copyMatrixPipe: CopyMatrixPipe;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        providers: [CopyMatrixPipe, PanoExternalAssetsCommonUtil]
      });
    })
  );

  beforeEach(() => {
    panoExternalAssetsCommonUtil = TestBed.inject(PanoExternalAssetsCommonUtil);
    copyMatrixPipe = TestBed.inject(CopyMatrixPipe);
  });

  describe('calculateAssetTypeTotalMarketValue', () => {
    it('should calculate assetTotalMarketValueUpdate and emit the EventEmitter passed', () => {
      const mockAssetFormArray = TEST_CASH_ASSETS_FORM_ARRAY as FormArray;
      const assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails> = new EventEmitter();
      spyOn(assetTotalMarketValueUpdate, 'emit');

      const expectedValue = panoExternalAssetsCommonUtil.calculateAssetTypeTotalMarketValue(
        mockAssetFormArray,
        ASSET_TYPES.cash.code,
        assetTotalMarketValueUpdate
      );

      expect(expectedValue).toBe(300);
      expect(assetTotalMarketValueUpdate.emit).toHaveBeenCalledWith({
        assetTypeTotalMarketValue: expectedValue,
        assetTypeCode: ASSET_TYPES.cash.code
      });
    });

    it('should return totalMarketValue as 0 and emit the EventEmitter passed, when formArray is undefined', () => {
      const mockAssetFormArray: FormArray = undefined;
      const assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails> = new EventEmitter();
      spyOn(assetTotalMarketValueUpdate, 'emit');

      const expectedValue = panoExternalAssetsCommonUtil.calculateAssetTypeTotalMarketValue(
        mockAssetFormArray,
        ASSET_TYPES.cash.code,
        assetTotalMarketValueUpdate
      );

      expect(expectedValue).toBe(0);
      expect(assetTotalMarketValueUpdate.emit).toHaveBeenCalledWith({
        assetTypeTotalMarketValue: expectedValue,
        assetTypeCode: ASSET_TYPES.cash.code
      });
    });
  });

  describe('deleteAsset', () => {
    it('should emit assetDeleteToDetails', () => {
      const assetDeleteToDetails = {
        index: 1,
        assetTypeCode: ASSET_TYPES.cash.code,
        positionId: '345345',
        isNewAsset: false
      };
      const assetToDeleteEmitter: EventEmitter<ExternalAssetDeleteDetails> = new EventEmitter();
      spyOn(assetToDeleteEmitter, 'emit');

      panoExternalAssetsCommonUtil.deleteAsset(assetDeleteToDetails, assetToDeleteEmitter);
      expect(assetToDeleteEmitter.emit).toHaveBeenCalledWith(assetDeleteToDetails);
    });
  });

  describe('unregisterAssetEditControlsValueChanges', () => {
    it('should unsubscribe all subscriptions and return empty array back', () => {
      const mockSubscription1: Subscription = of(null).subscribe();
      const mockSubscription2: Subscription = of(null).subscribe();
      const controlsValueChangesSubscriptions = [mockSubscription1, mockSubscription2];
      spyOn(mockSubscription1, 'unsubscribe');
      spyOn(mockSubscription2, 'unsubscribe');
      const expectedResult = panoExternalAssetsCommonUtil.unregisterAssetEditControlsValueChanges(
        controlsValueChangesSubscriptions
      );

      expect(mockSubscription1.unsubscribe).toHaveBeenCalled();
      expect(mockSubscription2.unsubscribe).toHaveBeenCalled();
      expect(expectedResult).toEqual([]);
    });
  });

  describe('registerAssetEditMarketValueControlsValueChanges', () => {
    it('should register value change subscription ', () => {
      const mockAssetFormArray = cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray;
      const mockComponent = {
        mockFunction: jasmine.createSpy()
      };

      const expectedResult = panoExternalAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges(
        mockAssetFormArray,
        mockComponent.mockFunction
      );
      expect(expectedResult.length).toBe(1);
    });

    it('should call the callbackfunction when value get changed, when its valid ', () => {
      const mockAssetFormArray = cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray;
      const mockComponent = {
        mockFunction: jasmine.createSpy()
      };

      panoExternalAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges(
        mockAssetFormArray,
        mockComponent.mockFunction
      );

      mockAssetFormArray.controls[0].get('marketValue').setValue(10);
      expect(mockComponent.mockFunction).toHaveBeenCalled();
    });

    it('should not call the callbackfunction when value get changed, when its invalid ', () => {
      const mockAssetFormArray = cloneDeep(TEST_CASH_ASSETS_FORM_ARRAY) as FormArray;
      const mockComponent = {
        mockFunction: jasmine.createSpy()
      };

      panoExternalAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges(
        mockAssetFormArray,
        mockComponent.mockFunction
      );

      mockAssetFormArray.controls[0].get('marketValue').setValue('test');
      expect(mockComponent.mockFunction).not.toHaveBeenCalled();
    });
  });

  describe('getErrorMessagesForQuantity', () => {
    beforeEach(() => {
      spyOn(copyMatrixPipe, 'transform');
    });

    it('when valid value is given should return empty string as error message', () => {
      const quantityControl: FormControl = new FormControl('123213', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();
      expect(panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl)).toBe('');
    });

    it('when no value is given should return Quantity is required as error message', () => {
      const quantityControl: FormControl = new FormControl('', [
        Validators.required,
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-0398');
    });

    it('when zero value is given should return Quantity must be greater than 0. string value', () => {
      const quantityControl: FormControl = new FormControl('0', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-0382');
    });

    it('when negative value is given should return Quantity must be a positive whole number. string value', () => {
      const quantityControl: FormControl = new FormControl('-1', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-0382');
    });

    it('when value is greater than zero and less than min should return Quantity must be a positive whole number', () => {
      const quantityControl: FormControl = new FormControl('0.2', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-0381');
    });

    it('when decimal value is given more than the expected should return proper error message, special case for managed fund', () => {
      const quantityControl: FormControl = new FormControl('1.12345', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(MANAGED_FUND_ASSET_QUANTITY_REGEX)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-1210');
    });

    it('when decimal value is given more than the expected should return proper error message, special case for other assets', () => {
      const quantityControl: FormControl = new FormControl('1.1234', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(OTHER_ASSET_QUANTITY_REGEX)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-0384');
    });

    it('when decimal value is given should return Quantity must be a positive whole number. string value', () => {
      const quantityControl: FormControl = new FormControl('1.2', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-0381');
    });

    it('when alphabetical or special character value is given should return Enter a valid quantity string value', () => {
      const quantityControl: FormControl = new FormControl('+-1232asf13', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-0387');
    });

    it('when maximum character value is given should return Maximum allowed is 15 characters. string value', () => {
      const quantityControl: FormControl = new FormControl('1232132131232131231231231', [
        Validators.min(1),
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*$/)
      ]);
      quantityControl.markAsTouched();

      panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-1240');
    });
  });
});
