import { PolicyStatus, PolicyType } from '../pano-insurance.interface';

import { SelectCoverAmount, SelectCoverType } from './pano-change-cover-insurance.interface';

export const SELECT_COVER_TYPES: SelectCoverType[] = [
  {
    policyName: 'Death and Total & Permanent Disability/Disablement (TPD)',
    policyType: PolicyType.DEATH_AND_TPD,
    description: null
  },
  {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH,
    description: null
  },
  {
    policyName: 'Total Permanent Disability/Disablement (TPD)',
    policyType: PolicyType.TPD,
    description: null
  },
  {
    policyName: 'Salary Continuance Insurance (SCI)',
    policyType: PolicyType.INCOME_PROTECTION,
    description: null
  }
];

export const SELECT_COVER_AMOUNTS: SelectCoverAmount[] = [
  {
    coverSubTypeId: null,
    coverAmountName: 'Single cover',
    coverAmountType: 'Single',
    coverAmount: null,
    premium: null,
    increase: null
  },
  {
    coverSubTypeId: null,
    coverAmountName: 'Double cover',
    coverAmountType: 'Double',
    coverAmount: null,
    premium: null,
    increase: null
  },
  {
    coverSubTypeId: null,
    coverAmountName: 'Triple cover',
    coverAmountType: 'Triple',
    coverAmount: null,
    premium: null,
    increase: null
  }
];

export const CHANGE_OR_DECREASE_SHOW_STATUS = [PolicyStatus.ACTIVE, PolicyStatus.PENDING];

export const CHANGE_COVER_POLICY_TYPES = [PolicyType.DEATH, PolicyType.DEATH_AND_TPD];

export const CHANGE_DEATH_AND_TPD_INFO_AEM_KEY = 'change_cover_death_tpd_info';

export const CHANGE_DEATH_INFO_AEM_KEY = 'change_cover_death_info';

export const DECREASE_DEATH_AND_TPD_INFO_AEM_KEY = 'decrease_cover_death_tpd_info';

export const DECREASE_DEATH_INFO_AEM_KEY = 'decrease_cover_death_info';
