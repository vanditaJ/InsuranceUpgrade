import { Component, NO_ERRORS_SCHEMA, SimpleChange } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormArray, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import { cloneDeep, each } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of, Subscription } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import { TEST_TD_ASSETS_FORM_ARRAY } from '../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { ASSET_TYPES, PANO_DATE_FORMATS } from '../pano-external-assets-constants/pano-external-assets.constants';

import { PanoExternalAssetsTermDepositComponent } from './pano-external-assets-term-deposit.component';

@Component({
  template: `
    <pano-external-assets-term-deposit
      [tdFormArray]="tdFormArray"
      [assetCount]="assetCount"
      (assetDelete)="testAssetDelete($event)"
      (assetTotalMarketValueUpdate)="testAssetTotalMarketValue($event)"
    >
    </pano-external-assets-term-deposit>
  `
})
class TestHostComponent {
  assetDetails = null;
  assetMarketValue = null;
  tdFormArray: FormArray = TEST_TD_ASSETS_FORM_ARRAY as FormArray;
  assetCount: number = TEST_TD_ASSETS_FORM_ARRAY['controls'].length;

  testAssetDelete(assetDetails): void {
    this.assetDetails = assetDetails;
  }
  testAssetTotalMarketValue(assetMarketValue): void {
    this.assetMarketValue = assetMarketValue;
  }
}

describe('PanoExternalAssetsTermDepositComponent', () => {
  let component: PanoExternalAssetsTermDepositComponent;
  let fixture: ComponentFixture<PanoExternalAssetsTermDepositComponent>;
  let panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoExternalAssetsTermDepositComponent, TestHostComponent],
        providers: [
          PanoExternalAssetsCommonUtil,
          { provide: MAT_DATE_FORMATS, useValue: PANO_DATE_FORMATS },
          { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] }
        ],
        imports: [
          MatDatepickerModule,
          MatInputModule,
          MatMomentDateModule,
          NoopAnimationsModule,
          ReactiveFormsModule,
          DataModule,
          PipesTestingModule
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoExternalAssetsTermDepositComponent);
    panoExtAssetsCommonUtil = TestBed.inject(PanoExternalAssetsCommonUtil);
    component = fixture.componentInstance;
  });

  describe('component', () => {
    beforeEach(() => {
      component.tdFormArray = cloneDeep(TEST_TD_ASSETS_FORM_ARRAY) as FormArray;
    });

    it('should accept the inputs and transmit the outputs correctly', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const hostComponent: TestHostComponent = hostFixture.componentInstance;
      hostFixture.detectChanges();

      const mockFormArray = TEST_TD_ASSETS_FORM_ARRAY as FormArray;
      const cmp = hostFixture.debugElement.query(By.directive(PanoExternalAssetsTermDepositComponent))
        .componentInstance;
      expect(cmp.tdFormArray).toEqual(mockFormArray);
      expect(cmp.assetCount).toBe(mockFormArray['controls'].length);

      const assetToDelete = {
        index: 0,
        assetTypeCode: ASSET_TYPES.td.code,
        positionId: mockFormArray['controls'][0].get('positionId').value,
        isNewAsset: mockFormArray['controls'][0].get('isNewAsset').value
      };
      const assetTotalMarketValueUpdate = {
        assetTypeTotalMarketValue: 12,
        assetTypeCode: ASSET_TYPES.td.code
      };

      spyOn(hostComponent, 'testAssetDelete');
      cmp.assetDelete.emit(assetToDelete);
      expect(hostComponent.testAssetDelete).toHaveBeenCalledWith(assetToDelete);

      spyOn(hostComponent, 'testAssetTotalMarketValue');
      cmp.assetTotalMarketValueUpdate.emit(assetTotalMarketValueUpdate);
      expect(hostComponent.testAssetTotalMarketValue).toHaveBeenCalledWith(assetTotalMarketValueUpdate);
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('ngOnDestroy()', () => {
      it('should unsubscribe all subscriptions', () => {
        spyOn(component, 'calculateTotal');
        spyOn(component, 'unregisterControlsValueChanges');

        component.ngOnDestroy();

        expect(component.calculateTotal).toHaveBeenCalled();
        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
      });
    });

    describe('on changes', () => {
      beforeEach(() => {
        spyOn(component, 'unregisterControlsValueChanges');
        spyOn(component, 'registerControlsValueChanges');
        spyOn(component, 'calculateTotal');
      });
      it('should call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when assetCount get changed, that is add, delete an asset', () => {
        component.ngOnChanges({ assetCount: new SimpleChange(0, 1, true) });

        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
        expect(component.registerControlsValueChanges).toHaveBeenCalled();
        expect(component.calculateTotal).toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when assetCount is not changed', () => {
        component.ngOnChanges({ assetCount: new SimpleChange(1, 1, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });

      it('should call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when FormArray get changed, that is on componet init or save api gives new data', () => {
        component.ngOnChanges({ tdFormArray: new SimpleChange([], cloneDeep(TEST_TD_ASSETS_FORM_ARRAY), true) });

        expect(component.unregisterControlsValueChanges).toHaveBeenCalled();
        expect(component.registerControlsValueChanges).toHaveBeenCalled();
        expect(component.calculateTotal).toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when FormArray is not changed', () => {
        const mockFormArray = [];
        component.ngOnChanges({ tdFormArray: new SimpleChange(mockFormArray, mockFormArray, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });

      it('should not call unregisterControlsValueChanges, registerControlsValueChanges, calculateTotal when any other input get changed', () => {
        component.ngOnChanges({ someother: new SimpleChange(1, 2, true) });

        expect(component.unregisterControlsValueChanges).not.toHaveBeenCalled();
        expect(component.registerControlsValueChanges).not.toHaveBeenCalled();
        expect(component.calculateTotal).not.toHaveBeenCalled();
      });
    });

    describe('registerControlsValueChanges', () => {
      it('should registerAssetEditMarketValueControlsValueChanges of PanoExternalAssetsCommonUtil to add marketValue valueChanges subscriptions to controlsValueChangesSubscriptions, also add maturityDate value changes subscriptions to maturityDateControlsValueChangesSubscriptions', () => {
        spyOn(panoExtAssetsCommonUtil, 'registerAssetEditMarketValueControlsValueChanges').and.returnValue([
          of(null).subscribe()
        ]);
        expect((component as any).controlsValueChangesSubscriptions.length).toBe(0);
        expect((component as any).maturityDateControlsValueChangesSubscriptions.length).toBe(0);

        component.registerControlsValueChanges();

        expect((component as any).controlsValueChangesSubscriptions.length).toBe(1);
        expect(panoExtAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges).toHaveBeenCalledWith(
          component.tdFormArray as FormArray,
          jasmine.any(Function)
        );
        expect((component as any).maturityDateControlsValueChangesSubscriptions.length).toBe(1);
      });

      it('should not add maturityDate value changes subscriptions to maturityDateControlsValueChangesSubscriptions when its a newAsset', () => {
        const mockFormArray = cloneDeep(TEST_TD_ASSETS_FORM_ARRAY) as FormArray;
        mockFormArray['controls'][0].get('isNewAsset').setValue(true);
        component.tdFormArray = mockFormArray;
        expect((component as any).maturityDateControlsValueChangesSubscriptions.length).toBe(0);

        component.registerControlsValueChanges();

        expect((component as any).maturityDateControlsValueChangesSubscriptions.length).toBe(0);
      });

      it('should set isMaturityDateChanged to true when maturityDate get changed ', () => {
        expect(component.tdFormArray['controls'][0].get('isMaturityDateChanged').value).toBe(false);

        component.registerControlsValueChanges();

        component.tdFormArray.controls[0].get('maturityDate').setValue(
          moment()
            .subtract(4, 'day')
            .tz('Australia/Sydney')
        );

        expect(component.tdFormArray['controls'][0].get('isMaturityDateChanged').value).toBe(true);
      });
    });

    describe('unregisterControlsValueChanges', () => {
      it('should call unregisterAssetEditControlsValueChanges of PanoExternalAssetsCommonUtil to unsubscribe all valuechange subcribtion of controlsValueChangesSubscriptions and also unsubscribe all maturityDate subscribtion of maturityDateControlsValueChangesSubscriptions', () => {
        const mockSubscription1: Subscription = of(null).subscribe();
        (component as any).maturityDateControlsValueChangesSubscriptions = [mockSubscription1];
        spyOn(mockSubscription1, 'unsubscribe');

        spyOn(panoExtAssetsCommonUtil, 'unregisterAssetEditControlsValueChanges').and.returnValue([]);

        component.unregisterControlsValueChanges();

        expect(panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges).toHaveBeenCalledWith(
          (component as any).controlsValueChangesSubscriptions
        );
        expect((component as any).controlsValueChangesSubscriptions.length).toBe(0);
        expect(mockSubscription1.unsubscribe).toHaveBeenCalled();
        expect((component as any).maturityDateControlsValueChangesSubscriptions.length).toBe(0);
      });
    });

    describe('deleteTermDeposit', () => {
      it('should call deleteAsset', () => {
        spyOn(panoExtAssetsCommonUtil, 'deleteAsset');
        expect(component.tdFormArray.length).toBe(1);

        const deletedFormGroup = TEST_TD_ASSETS_FORM_ARRAY.controls[0] as FormGroup;

        component.deleteTermDeposit(
          0,
          deletedFormGroup.get('positionId').value,
          deletedFormGroup.get('isNewAsset').value
        );

        expect(panoExtAssetsCommonUtil.deleteAsset).toHaveBeenCalledWith(
          {
            index: 0,
            assetTypeCode: ASSET_TYPES.td.code,
            positionId: deletedFormGroup.get('positionId').value,
            isNewAsset: deletedFormGroup.get('isNewAsset').value
          },
          component.assetDelete
        );
      });
    });

    describe('calculateTotal', () => {
      it('should call calculateAssetTypeTotalMarketValue of PanoExternalAssetsCommonUtil', () => {
        spyOn(panoExtAssetsCommonUtil, 'calculateAssetTypeTotalMarketValue').and.returnValue(300);

        component.calculateTotal();

        expect(panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue).toHaveBeenCalledWith(
          component.tdFormArray,
          ASSET_TYPES.td.code,
          component.assetTotalMarketValueUpdate
        );
        expect(component.totalMarketValue).toBe(300);
      });
    });
  });

  describe('view', () => {
    it('should hide the section element when no controls are there', () => {
      expect(fixture.debugElement.query(By.css('section'))).toBeFalsy();
    });

    it('should hide the section element when FormArray is empty', () => {
      component.tdFormArray = new FormArray([]);
      expect(fixture.debugElement.query(By.css('section'))).toBeFalsy();
    });

    describe('btToggleClassByBreakpoint', () => {
      beforeEach(() => {
        const mockFormArray = cloneDeep(TEST_TD_ASSETS_FORM_ARRAY);
        component.tdFormArray = mockFormArray as FormArray;
        fixture.detectChanges();
      });

      it('it should have btToggleClassByBreakpoint directive on "Source" header column', () => {
        const sourceColEl = fixture.debugElement.query(By.css('th:nth-child(2'));
        expect(sourceColEl.properties.btToggleClassByBreakpoint).toEqual({
          breakpoints: ['md'],
          classNames: ['sr-only']
        });
      });

      it('it should have btToggleClassByBreakpoint directive on "Source" cell', () => {
        const sourceColEls = fixture.debugElement.queryAll(By.css('tbody tr td:nth-child(2)'));
        each(sourceColEls, el =>
          expect(el.properties.btToggleClassByBreakpoint).toEqual({ breakpoints: ['md'], classNames: ['sr-only'] })
        );
      });
    });

    describe('when controls are available', () => {
      beforeEach(() => {
        component.tdFormArray = TEST_TD_ASSETS_FORM_ARRAY as FormArray;
        fixture.detectChanges();
      });

      it('should show the section, header and table when controls are available', () => {
        expect(fixture.debugElement.query(By.css('section'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-td-header'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-td-table'))).toBeTruthy();
      });

      it('should show the header label and table headings and total market value label when assets are available', () => {
        expect(fixture.debugElement.query(By.css('.js-test-extassets-td-header')).nativeElement.innerHTML).toBe(
          'Term deposits'
        );
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-table-header-investment')).nativeElement.innerHTML
        ).toBe('Asset');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-table-header-source')).nativeElement.innerHTML
        ).toBe('Source');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-table-header-valuation-date')).nativeElement
            .innerHTML
        ).toBe('Valuation date');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-table-header-maturity-date')).nativeElement.innerHTML
        ).toBe('Maturity date');
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-table-header-balance')).nativeElement.innerHTML
        ).toBe('Balance');
        expect(fixture.debugElement.query(By.css('.js-test-extassets-td-total-label')).nativeElement.innerHTML).toBe(
          'Total term deposits'
        );
      });

      it('should hide all Errors by default', () => {
        expect(fixture.debugElement.queryAll(By.css('mat-error')).length).toBe(0);
      });

      it('should show the data', () => {
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-table-row-cell-asset-name-0')).nativeElement
            .innerHTML
        ).toBe(TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('positionName').value);
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-table-row-cell-source-0')).nativeElement.innerHTML
        ).toBe(TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('source').value);
        expect(
          moment(
            fixture.debugElement.query(By.css('.js-test-extassets-td-form-input-value-date-0')).nativeElement.value,
            'DD MMM YYYY'
          ).format('DD MMM YYYY')
        ).toBe(
          moment(TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value, 'DD MMM YYYY').format('DD MMM YYYY')
        );
        expect(
          moment(
            fixture.debugElement.query(By.css('.js-test-extassets-td-form-input-maturity-date-0')).nativeElement.value,
            'DD MMM YYYY'
          ).format('DD MMM YYYY')
        ).toBe(
          moment(TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('maturityDate').value, 'DD MMM YYYY').format('DD MMM YYYY')
        );
        expect(
          fixture.debugElement.query(By.css('.js-test-extassets-td-form-input-market-value-0')).nativeElement.value
        ).toBe(TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value);
        expect(fixture.debugElement.query(By.css('.js-test-extassets-td-table-row-cell-delete-0'))).toBeTruthy();
      });

      it('should show the total td', () => {
        component.totalMarketValue = 300;
        fixture.detectChanges();
        expect(fixture.debugElement.query(By.css('.js-test-extassets-td-total')).nativeElement.innerHTML).toBe(
          '$300.00'
        );
      });

      describe('delete button', () => {
        it('should show with the correct config and event handlers attached', () => {
          const button = fixture.debugElement.query(By.css('.js-test-extassets-td-table-row-cell-delete-0'));
          const deletedFormGroup = TEST_TD_ASSETS_FORM_ARRAY.controls[0] as FormGroup;

          expect(button.nativeElement).toBeTruthy();
          expect(button.properties.config).toEqual(component.deleteButton);

          spyOn(component, 'deleteTermDeposit');
          button.nativeElement.dispatchEvent(new Event('click'));
          expect(component.deleteTermDeposit).toHaveBeenCalledWith(
            0,
            deletedFormGroup.get('positionId').value,
            deletedFormGroup.get('isNewAsset').value
          );
        });
      });
    });

    describe('validate form control', () => {
      beforeEach(() => {
        const mockFormArray = cloneDeep(TEST_TD_ASSETS_FORM_ARRAY);
        component.tdFormArray = mockFormArray as FormArray;
        component.tdFormArray.markAllAsTouched();
        fixture.detectChanges();
      });

      describe('validate marketValue', () => {
        it('should show error message when no value entered', () => {
          component.tdFormArray.controls[0].get('marketValue').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-td-form-market-value-required-error-0')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1235');
        });

        it('should not show error message when valid value entered', () => {
          component.tdFormArray.controls[0].get('marketValue').setValue(12);
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-td-form-market-value-required-error-0'))
          ).toBeFalsy();
        });

        it('should show error message when invalid number is entered', () => {
          component.tdFormArray.controls[0].get('marketValue').setValue('0.');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-market-value-min-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1233');
        });

        it('should show error message when maximum length number is entered', () => {
          component.tdFormArray.controls[0].get('marketValue').setValue('12345353453445345435');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-market-value-max-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1227');
        });

        it('should show error message when invalid number is entered', () => {
          component.tdFormArray.controls[0].get('marketValue').setValue('12.3.5');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-market-value-pattern-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1236');
        });
      });

      describe('validate valuationDate', () => {
        it('should show error message when no value is entered', () => {
          component.tdFormArray.controls[0].get('valuationDate').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-value-date-required-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
        });

        it('should not show error message when valid value is entered', () => {
          component.tdFormArray.controls[0].get('valuationDate').setValue(moment().tz('Australia/Sydney'));
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-td-form-value-date-required-error-0'))
          ).toBeFalsy();
        });

        it('should show error message when future date is entered', () => {
          component.tdFormArray.controls[0].get('valuationDate').setValue(
            moment()
              .add(4, 'day')
              .tz('Australia/Sydney')
          );
          component.tdFormArray.controls[0].get('valuationDate').markAsTouched();
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-value-date-max-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0386');
        });
      });

      describe('validate maturityDate', () => {
        it('should show error message when no value is entered', () => {
          component.tdFormArray.controls[0].get('maturityDate').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-td-form-maturity-date-required-error-0')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
        });

        it('should not show error message when valid value is entered', () => {
          component.tdFormArray.controls[0].get('maturityDate').setValue(moment().tz('Australia/Sydney'));
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-td-form-maturity-date-required-error-0'))
          ).toBeFalsy();
        });

        it('should show error message td reached maturity when past date is already set with isNewAsset is false and isMaturityDateChanged is false', () => {
          component.tdFormArray.controls[0].get('maturityDate').setValue(
            moment()
              .subtract(4, 'day')
              .tz('Australia/Sydney')
          );
          component.tdFormArray.controls[0].get('maturityDate').markAsTouched();
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-maturity-date-min-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1211');
        });

        it('should show error message select current or future date when past date is entered with isNewAsset is false and isMaturityDateChanged is true', () => {
          component.tdFormArray.controls[0].get('maturityDate').setValue(
            moment()
              .subtract(4, 'day')
              .tz('Australia/Sydney')
          );
          component.tdFormArray.controls[0].get('isMaturityDateChanged').setValue(true);
          component.tdFormArray.controls[0].get('maturityDate').markAsTouched();
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-maturity-date-min-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0281');
        });

        it('should show error message select current or future date when past date is entered with isNewAsset is true', () => {
          component.tdFormArray.controls[0].get('maturityDate').setValue(
            moment()
              .subtract(4, 'day')
              .tz('Australia/Sydney')
          );
          component.tdFormArray.controls[0].get('isNewAsset').setValue(true);
          component.tdFormArray.controls[0].get('maturityDate').markAsTouched();
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-td-form-maturity-date-min-error-0'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0281');
        });
      });
    });
  });
});
