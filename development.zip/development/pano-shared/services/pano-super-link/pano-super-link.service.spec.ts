import { TestBed } from '@angular/core/testing';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoUpgradePermissionService } from '@upgrade/upgrade.services';

import { PanoSuperLinkService } from './pano-super-link.service';
import { LinkType } from './pano-super-link.service.constants';

describe('PanoSuperLinkService', () => {
  let superLinkService: PanoSuperLinkService;
  let permissionService: PanoUpgradePermissionService;

  const TEST_ACCOUNT_ID: string = 'accountId';
  const TEST_ACCOUNT: Partial<Account> = {
    key: {
      accountId: TEST_ACCOUNT_ID
    },
    product: {
      productSubType: 'PERSONAL_SUPER'
    },
    pdsStatus: 'WGP_CURRENT',
    heritageCohort: 'LSEP'
  };

  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [],
      providers: [
        PanoSuperLinkService,
        { provide: PanoUpgradePermissionService, useValue: { hasPermission: jasmine.createSpy() } }
      ]
    });
  });

  beforeEach(() => {
    superLinkService = TestBed.inject(PanoSuperLinkService);
    permissionService = TestBed.inject(PanoUpgradePermissionService);
    permissionService.hasPermission
      .withArgs('feature.fees.view', 'base')
      .and.returnValue(false)
      .withArgs('feature.fees.view', TEST_ACCOUNT.key.accountId)
      .and.returnValue(false)
      .withArgs('account.fees.v1.view', 'base')
      .and.returnValue(false)
      .withArgs('account.fees.v1.view', TEST_ACCOUNT.key.accountId)
      .and.returnValue(false)
      .withArgs('feature.investmentFees.view', 'base')
      .and.returnValue(false)
      .withArgs('feature.investmentFees.view', TEST_ACCOUNT.key.accountId)
      .and.returnValue(true);
  });

  it('should be created', () => {
    expect(superLinkService).toBeTruthy();
  });

  describe('getUrl', () => {
    it('should return falsy when no url defined', () => {
      expect(superLinkService.getUrl(LinkType.SUPER_GUIDE, TEST_ACCOUNT_ID, TEST_ACCOUNT as Account)).toBeFalsy();
    });

    it('should return falsy when url defined but no matched permission', () => {
      expect(superLinkService.getUrl(LinkType.FEES, TEST_ACCOUNT_ID, TEST_ACCOUNT as Account)).toBeFalsy();
    });

    it('should return matched url', () => {
      expect(
        superLinkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, TEST_ACCOUNT_ID, TEST_ACCOUNT as Account)
      ).toEqual(
        'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-lsep.html#new_member_info'
      );
    });

    it('should return matched url when permission defined', () => {
      expect(superLinkService.getUrl(LinkType.INVESTMENT_FEES, TEST_ACCOUNT_ID, TEST_ACCOUNT as Account)).toEqual(
        '#/app/investor/account/accountId/learn-about-investments/investment-fees'
      );
    });

    it('should return first matched url in the url hierarchy based on the account data', () => {
      const account: Account = { ...TEST_ACCOUNT } as Account;
      expect(superLinkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, TEST_ACCOUNT_ID, account)).toEqual(
        'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-lsep.html#new_member_info'
      );

      account.heritageCohort = 'OPEN';
      expect(superLinkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, TEST_ACCOUNT_ID, account)).toEqual(
        'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates.html#new_member_info'
      );

      account.pdsStatus = 'EY';
      expect(superLinkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, TEST_ACCOUNT_ID, account)).toEqual(
        'https://www.bt.com.au/ey.html#new_member_info'
      );

      account.pdsStatus = 'DEFAULT';
      expect(superLinkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, TEST_ACCOUNT_ID, account)).toEqual(
        'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html#personal_super_pds'
      );
    });
  });

  describe('getLinks', () => {
    beforeEach(() => {
      TEST_ACCOUNT.pdsStatus = 'WGP_CURRENT';
      TEST_ACCOUNT.product.productSubType = 'PERSONAL_SUPER';
    });
    it('should process all link types', () => {
      spyOn(superLinkService, 'getLink');
      superLinkService.getLinks(
        [LinkType.ADDITIONAL_INFORMATION_BOOKLET, LinkType.FEES],
        TEST_ACCOUNT_ID,
        TEST_ACCOUNT as Account
      );
      expect(superLinkService.getLink).toHaveBeenCalledWith(
        LinkType.ADDITIONAL_INFORMATION_BOOKLET,
        TEST_ACCOUNT_ID,
        TEST_ACCOUNT as Account
      );
      expect(superLinkService.getLink).toHaveBeenCalledWith(LinkType.FEES, TEST_ACCOUNT_ID, TEST_ACCOUNT as Account);
    });

    it('should return link where url found', () => {
      const links = superLinkService.getLinks(
        [LinkType.ADDITIONAL_INFORMATION_BOOKLET],
        TEST_ACCOUNT_ID,
        TEST_ACCOUNT as Account
      );
      expect(links[0].label).toEqual('Additional information booklet - PDF');
    });

    it('should not return link where url found', () => {
      const links = superLinkService.getLinks([LinkType.FEES], TEST_ACCOUNT_ID, TEST_ACCOUNT as Account);
      expect(links).toEqual([]);
    });

    it('should return a link with the url defined', () => {
      const links = superLinkService.getLinks(
        [LinkType.PRODUCT_DISCLOSURE_STATEMENT],
        TEST_ACCOUNT_ID,
        TEST_ACCOUNT as Account
      );
      expect(links[0].link).toEqual(
        'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-lsep.html#new_member_info'
      );
      expect(links[0].label).toEqual('Product disclosure statement (PDS)');
    });

    it('should not return link when account is WGP and WGP urls are empty', () => {
      const links = superLinkService.getLinks([LinkType.SUPER_GUIDE], TEST_ACCOUNT_ID, TEST_ACCOUNT as Account);
      expect(links).toEqual([]);
    });

    it('should return link when account is not WGP and url found', () => {
      TEST_ACCOUNT.pdsStatus = 'DEFAULT';
      TEST_ACCOUNT.product.productSubType = 'CORPORATE_SUPER';
      const links = superLinkService.getLinks([LinkType.SUPER_GUIDE], TEST_ACCOUNT_ID, TEST_ACCOUNT as Account);
      expect(links[0]).toBeTruthy();
    });
  });
});
