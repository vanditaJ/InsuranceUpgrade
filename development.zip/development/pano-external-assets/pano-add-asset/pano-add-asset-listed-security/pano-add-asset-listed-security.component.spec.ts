import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesTestingModule } from '@bt/pipes/testing';
import { TextHighlightPipeModule } from '@bt/pipes/text-highlight';
import { DataModule } from '@bt/services/data';
import * as moment from 'moment-timezone';
import { of, throwError } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from '../../pano-external-assets-common.util';
import {
  ASSET_PRICE_VALUATION_DETAILS,
  CHARCTER_LENGTH_TEN,
  PANORAMA_ASSET_DETAILS,
  TEST_ADD_EXTERNAL_FORM,
  TEST_ADD_MF_EXTERNAL_FORM,
  TEST_ASSET_TYPES
} from '../../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { AssetClasses } from '../../pano-external-assets.interfaces';
import { PanoExternalAssetsService } from '../../pano-external-assets.service';
import { PanoAddAssetFormCreator } from '../pano-add-asset-form-creator';

import { PanoAddAssetListedSecurityComponent } from './pano-add-asset-listed-security.component';

@Component({
  template: `
    <pano-add-asset-listed-security
      [addAssetForm]="addAssetForm"
      [assetClasses]="assetClasses"
      (showButtons)="showOrHideButtons($event)"
    >
    </pano-add-asset-listed-security>
  `
})
class TestHostComponent {
  showButton = false;
  addAssetForm: FormGroup = TEST_ADD_MF_EXTERNAL_FORM as FormGroup;
  assetClasses: AssetClasses[] = TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'ls').assetClasses;
  showOrHideButtons(showButton): void {
    this.showButton = showButton;
  }
}

describe('PanoAddAssetListedSecurityComponent', () => {
  let externalAssetsAddFormCreator: PanoAddAssetFormCreator;
  let component: PanoAddAssetListedSecurityComponent;
  let fixture: ComponentFixture<PanoAddAssetListedSecurityComponent>;
  let hostFixture: ComponentFixture<TestHostComponent>;

  let service: PanoExternalAssetsService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoAddAssetListedSecurityComponent, TestHostComponent],
        providers: [
          Location,
          { provide: LocationStrategy, useClass: PathLocationStrategy },
          PanoAddAssetFormCreator,
          PanoExternalAssetsService,
          PanoExternalAssetsCommonUtil
        ],
        imports: [
          DataModule,
          HttpClientTestingModule,
          MatAutocompleteModule,
          MatDatepickerModule,
          MatInputModule,
          MatMomentDateModule,
          MatSelectModule,
          NoopAnimationsModule,
          ReactiveFormsModule,
          TextHighlightPipeModule,
          PipesTestingModule
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoAddAssetListedSecurityComponent);
    externalAssetsAddFormCreator = TestBed.inject(PanoAddAssetFormCreator);
    component = fixture.componentInstance;
    component.addAssetForm = TEST_ADD_EXTERNAL_FORM as FormGroup;
    hostFixture = TestBed.createComponent(TestHostComponent);
    service = fixture.debugElement.injector.get(PanoExternalAssetsService);
    component.assetsLoading = false;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('ngOnDestroy', () => {
      it('should call unsubscribe on subscription', () => {
        spyOn((component as any).assetsSubscription, 'unsubscribe');
        spyOn((component as any).assetDetailsSubscription, 'unsubscribe');
        spyOn((component as any).latestPriceSubscription, 'unsubscribe');
        spyOn((component as any).quantitySubscription, 'unsubscribe');
        spyOn((component as any).assetCodeSubscription, 'unsubscribe');
        component.ngOnDestroy();

        expect((component as any).assetsSubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).assetDetailsSubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).latestPriceSubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).quantitySubscription.unsubscribe).toHaveBeenCalled();
        expect((component as any).assetCodeSubscription.unsubscribe).toHaveBeenCalled();
      });
    });

    describe('ngOnInit', () => {
      it('should emit false to showButtons output', () => {
        spyOn(component.showButtons, 'emit');

        component.ngOnInit();

        expect(component.showButtons.emit).toHaveBeenCalledWith(false);
      });

      it('should set assetDetails FormGroup with control to the addAssetForm', () => {
        const assetDetailsFormGroup = TEST_ADD_MF_EXTERNAL_FORM as FormGroup;

        spyOn(externalAssetsAddFormCreator, 'createAddAssetForm').and.returnValue(assetDetailsFormGroup);

        component.ngOnInit();

        expect(externalAssetsAddFormCreator.createAddAssetForm).toHaveBeenCalled();
        expect(component.addAssetForm.get('assetDetails')).toBeTruthy();
      });

      describe('when getPanoramaAssetDetails from externalAssetService returns a response', () => {
        beforeEach(() => {
          spyOn(component.showButtons, 'emit');
          spyOn(service, 'getPanoramaAssetDetails').and.returnValue(of(PANORAMA_ASSET_DETAILS));
          component.ngOnInit();
        });

        it('should set value of assets property', () => {
          expect(service.getPanoramaAssetDetails).toHaveBeenCalledWith('ls');
          expect(component.assets).toEqual(PANORAMA_ASSET_DETAILS);
        });

        it('should emit true to showButtons output and set assetsLoading to false', () => {
          expect(component.assetsLoading).toEqual(false);
          expect(component.showButtons.emit).toHaveBeenCalledWith(true);
        });
      });

      describe('when value changes in panoramaAssetDetails control', () => {
        let input;

        beforeEach(() => {
          input = fixture.nativeElement.querySelector('.js-test-extassets-add-ls-form-input-panorama-asset-details');
        });

        describe('when user has entered more than 2 characters and filterAssets returns with assets', () => {
          it(
            'should call filterAssets and set filteredAssets',
            waitForAsync(() => {
              spyOn(component, 'filterAssets').and.returnValue(PANORAMA_ASSET_DETAILS);
              component.ngOnInit();
              input.value = 'test';

              input.dispatchEvent(new Event('input'));
              fixture.whenStable().then(() => {
                fixture.detectChanges();
                expect(component.filterAssets).toHaveBeenCalledWith('test');
                expect(component.filteredAssets).toEqual(PANORAMA_ASSET_DETAILS);
              });
            })
          );
        });

        describe('when user has entered more than 2 characters and filterAssets returns with no assets', () => {
          it(
            'should call filterAssets and set filteredAssets',
            waitForAsync(() => {
              spyOn(component, 'filterAssets').and.returnValue([]);
              component.ngOnInit();
              input.value = 'test';

              input.dispatchEvent(new Event('input'));
              fixture.whenStable().then(() => {
                fixture.detectChanges();
                expect(component.filterAssets).toHaveBeenCalledWith('test');
                expect(component.filteredAssets).toEqual(null);
              });
            })
          );
        });

        describe('when user has entered one character', () => {
          it(
            'should not call filterAssets function and set properties correctly',
            waitForAsync(() => {
              spyOn(component, 'filterAssets');
              component.ngOnInit();
              input.value = 't';

              input.dispatchEvent(new Event('input'));
              fixture.whenStable().then(() => {
                fixture.detectChanges();
                expect(component.filterAssets).not.toHaveBeenCalled();
                expect(component.assetSelected).toEqual(false);
                expect(component.filteredAssets).toBeFalsy();
              });
            })
          );
        });

        describe('when user has cleared input', () => {
          it(
            'should not call filterAssets function and set properties correctly',
            waitForAsync(() => {
              spyOn(component, 'filterAssets');
              component.ngOnInit();
              input.value = '';

              input.dispatchEvent(new Event('input'));
              fixture.whenStable().then(() => {
                fixture.detectChanges();
                expect(component.filterAssets).not.toHaveBeenCalled();
                expect(component.assetSelected).toEqual(false);
                expect(component.filteredAssets).toBeFalsy();
              });
            })
          );
        });
      });

      describe('when value changes in quantity control', () => {
        it('should call calculateTotalMarketValue function if not manual mode', () => {
          spyOn(component, 'calculateTotalMarketValue');
          component.assetDetails.get('quantity').setValue(1);

          expect(component.calculateTotalMarketValue).toHaveBeenCalled();
        });

        it('should not call calculateTotalMarketValue function if manual mode', () => {
          spyOn(component, 'calculateTotalMarketValue');
          component.manualMode = true;
          component.assetDetails.get('quantity').setValue(1);

          expect(component.calculateTotalMarketValue).not.toHaveBeenCalled();
        });
      });

      describe('when value changes in asset code and manualMode is true', () => {
        beforeEach(() => {
          spyOn(service, 'getPanoramaAssetDetails').and.returnValue(of(PANORAMA_ASSET_DETAILS));
          component.manualMode = true;
          component.ngOnInit();
        });

        it('should set assetCodeFound error to true if an asset code found', () => {
          const setErrorsSpy: jasmine.Spy = spyOn(component.assetDetails.controls['positionCode'], 'setErrors');
          component.assetDetails.get('positionCode').setValue('MGE0006AU');

          expect(component.assetCodeFound).toEqual(true);
          expect(setErrorsSpy).toHaveBeenCalled();
        });

        it('should set assetCodeFound boolean to false if no asset code found', () => {
          component.assetDetails.get('positionCode').setValue(null);

          expect(component.assetCodeFound).toEqual(false);
        });
      });
    });
  });

  describe('displayAsset', () => {
    it('should return empty string for undefined asset', () => {
      expect(component.displayAsset(undefined)).toEqual('');
    });

    it('should return formatted asset', () => {
      const assetObj = PANORAMA_ASSET_DETAILS[0];
      const dispayAssetResult: string = component.displayAsset(assetObj);

      expect(dispayAssetResult).toEqual('MGE0006AU • Magellan Infrastructure Fund (Unhedged)');
    });
  });

  describe('selectAsset', () => {
    beforeEach(() => {
      spyOn(externalAssetsAddFormCreator, 'reAssignValidatorsForMarketValueAndValuationDate');
      spyOn(externalAssetsAddFormCreator, 'reAssignValidatorsForPanoramaAssetDetails');
    });
    describe('when the user has selected an asset', () => {
      const selectedAsset = PANORAMA_ASSET_DETAILS[0];

      it('should set the correct control values and also call reAssignValidatorsForMarketValueAndValuationDate', () => {
        spyOn(component, 'selectAsset').and.callThrough();
        spyOn(service, 'getAssetLatestPrice').and.returnValue(of());
        spyOn(component.assetDetails.controls['isPanoramaAsset'], 'setValue');
        spyOn(component.assetDetails.controls['assetId'], 'setValue');
        spyOn(component.assetDetails.controls['positionName'], 'setValue');
        spyOn(component.assetDetails.controls['positionCode'], 'setValue');
        spyOn(component.assetDetails.controls['assetClassCode'], 'setValue');

        component.selectAsset(selectedAsset);

        expect(component.assetSelected).toEqual(true);
        expect(component.filteredAssets).toEqual(null);
        expect(externalAssetsAddFormCreator.reAssignValidatorsForMarketValueAndValuationDate).toHaveBeenCalledWith(
          component.assetDetails,
          false
        );
        expect(component.assetDetails.controls['isPanoramaAsset'].setValue).toHaveBeenCalledWith(true);
        expect(component.assetDetails.controls['assetId'].setValue).toHaveBeenCalledWith(selectedAsset.assetId);
        expect(component.assetDetails.controls['positionName'].setValue).toHaveBeenCalledWith(selectedAsset.assetName);
        expect(component.assetDetails.controls['positionCode'].setValue).toHaveBeenCalledWith(selectedAsset.assetCode);
        expect(component.assetDetails.controls['assetClassCode'].setValue).toHaveBeenCalledWith(
          selectedAsset.assetClassId
        );
        expect(service.getAssetLatestPrice).toHaveBeenCalledWith(selectedAsset.assetId);
        expect(externalAssetsAddFormCreator.reAssignValidatorsForPanoramaAssetDetails).not.toHaveBeenCalled();
      });

      describe('when getAssetLatestPrice from externalAssetService returns a reponse', () => {
        it('should set the correct property and control values', () => {
          spyOn(component, 'selectAsset').and.callThrough();
          spyOn(service, 'getAssetLatestPrice').and.returnValue(of(ASSET_PRICE_VALUATION_DETAILS));
          spyOn(component.assetDetails.controls['valuationDate'], 'setValue');
          spyOn(component, 'calculateTotalMarketValue');

          component.selectAsset(selectedAsset);

          expect(component.assetSelected).toEqual(true);
          expect(component.latestPrice).toEqual(ASSET_PRICE_VALUATION_DETAILS);
          expect(component.assetDetails.controls['valuationDate'].setValue).toHaveBeenCalledWith(
            ASSET_PRICE_VALUATION_DETAILS.valuationDate
          );
          expect(component.calculateTotalMarketValue).toHaveBeenCalled();
        });
      });

      describe('when getAssetLatestPrice from externalAsset service returns with error', () => {
        it('should set marketValue and valuationDate to empty string', () => {
          spyOn(component, 'selectAsset').and.callThrough();
          spyOn(service, 'getAssetLatestPrice').and.returnValue(throwError({ status: 'error' }));
          spyOn(component.assetDetails.controls['marketValue'], 'setValue');
          spyOn(component.assetDetails.controls['valuationDate'], 'setValue');
          spyOn(component, 'calculateTotalMarketValue');

          component.selectAsset(selectedAsset);

          expect(component.latestPrice).toEqual(null);
          expect(component.assetDetails.controls['marketValue'].setValue).toHaveBeenCalledWith('');
          expect(component.assetDetails.controls['valuationDate'].setValue).toHaveBeenCalledWith('');
        });
      });
    });

    describe('when user has selected manual entry', () => {
      it('should reset control values', () => {
        spyOn(component, 'selectAsset').and.callThrough();
        spyOn(component.assetDetails.controls['isPanoramaAsset'], 'setValue');
        spyOn(component.assetDetails, 'reset');
        spyOn(component.assetDetails, 'markAsUntouched');
        spyOn(component.assetDetails.controls['valuationDate'], 'setValue');

        component.selectAsset(null);

        expect(externalAssetsAddFormCreator.reAssignValidatorsForPanoramaAssetDetails).toHaveBeenCalledWith(
          component.assetDetails,
          false
        );
        expect(externalAssetsAddFormCreator.reAssignValidatorsForMarketValueAndValuationDate).toHaveBeenCalledWith(
          component.assetDetails,
          true
        );
        expect(component.assetDetails.reset).toHaveBeenCalled();
        expect(component.assetDetails.markAsUntouched).toHaveBeenCalled();
        expect(component.assetDetails.controls['isPanoramaAsset'].setValue).toHaveBeenCalledWith(false);
        expect(component.assetDetails.controls['valuationDate'].setValue).toHaveBeenCalledWith(component.today);
      });
    });
  });

  describe('filterAssets', () => {
    beforeEach(() => {
      component.assets = PANORAMA_ASSET_DETAILS;
    });

    it('should filter by assetName', () => {
      const expectedResult = component.filterAssets('MAG');
      expect(expectedResult.length).toBe(1);
      expect(expectedResult[0].assetName).toBe(PANORAMA_ASSET_DETAILS[0].assetName);
    });

    it('should filter by assetCode', () => {
      const expectedResult = component.filterAssets('CRM0008AU');
      expect(expectedResult.length).toBe(1);
      expect(expectedResult[0].assetCode).toBe(PANORAMA_ASSET_DETAILS[1].assetCode);
    });

    it('should filter by both assetName and assetCode', () => {
      const expectedResult = component.filterAssets('MGE0006AU • Magellan Infrastructure Fund (Unhe ');
      expect(expectedResult.length).toBe(1);
      expect(expectedResult[0].assetName).toBe(PANORAMA_ASSET_DETAILS[0].assetName);
    });

    it('should skip asset from filtered when assetCode is null', () => {
      component.assets = [
        {
          assetId: '163196',
          assetName: 'Magellan Infrastructure Fund (Unhedged)',
          assetCode: null,
          assetClass: null,
          assetClassId: null
        }
      ];
      const expectedResult = component.filterAssets('MAG');
      expect(expectedResult.length).toBe(0);
    });

    it('should skip asset from filtered when assetName is null', () => {
      component.assets = [
        {
          assetId: '163196',
          assetName: null,
          assetCode: null,
          assetClass: null,
          assetClassId: null
        }
      ];
      const expectedResult = component.filterAssets('MAG');
      expect(expectedResult.length).toBe(0);
    });
  });

  describe('calculateTotalMarketValue', () => {
    it('should set totalMarket value to calculated value when quantity is valid and asset is selected and latestPrice is valid', () => {
      spyOn(component.assetDetails.controls['marketValue'], 'setValue');
      component.assetDetails.controls['quantity'].setValue(2);
      component.latestPrice = { lastPrice: 10, valuationDate: '' };
      component.assetSelected = true;

      component.calculateTotalMarketValue();

      expect(component.assetDetails.controls['marketValue'].setValue).toHaveBeenCalledWith('20.00');
    });

    it('should set totalMarket value to null when quantity is invalid or asset is not selected or latest price is null', () => {
      spyOn(component.assetDetails.controls['marketValue'], 'setValue');
      component.assetSelected = false;

      component.calculateTotalMarketValue();

      expect(component.assetDetails.controls['marketValue'].setValue).toHaveBeenCalledWith(null);
    });
  });

  describe('formatDateForDispay', () => {
    it('should return formated date', () => {
      const date = '2019-12-10T00:00:00.000+10:00';
      expect(component.formatDateForDisplay(date)).toEqual(
        moment(date)
          .tz('Australia/Sydney')
          .format('DD MMM YYYY')
      );
    });
  });

  describe('turnManualModeOff', () => {
    it('should set manual mode to false and call reAssignValidatorsForPanoramaAssetDetails', () => {
      spyOn(externalAssetsAddFormCreator, 'reAssignValidatorsForPanoramaAssetDetails');
      spyOn(component.assetDetails, 'reset');
      spyOn(component.assetDetails, 'markAsUntouched');

      component.manualMode = true;
      component.turnManualModeOff();
      fixture.detectChanges();

      expect(component.manualMode).toEqual(false);
      expect(component.assetDetails.reset).toHaveBeenCalled();
      expect(component.assetDetails.markAsUntouched).toHaveBeenCalled();
      expect(externalAssetsAddFormCreator.reAssignValidatorsForPanoramaAssetDetails).toHaveBeenCalledWith(
        component.assetDetails,
        true
      );
    });
  });

  describe('view', () => {
    it('should accept the inputs and transmit outputs correctly', () => {
      hostFixture = TestBed.createComponent(TestHostComponent);
      const hostComponent = hostFixture.componentInstance;
      hostFixture.detectChanges();
      const cmp = hostFixture.debugElement.query(By.directive(PanoAddAssetListedSecurityComponent)).componentInstance;

      expect(cmp.addAssetForm).toEqual(TEST_ADD_MF_EXTERNAL_FORM);
      expect(cmp.assetClasses).toEqual(TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'ls').assetClasses);

      spyOn(hostComponent, 'showOrHideButtons');
      cmp.showButtons.emit(true);
      expect(hostComponent.showOrHideButtons).toHaveBeenCalledWith(true);
    });

    describe('when assets are loading', () => {
      beforeEach(() => {
        component.assetsLoading = true;
        fixture.detectChanges();
      });

      it('should display loading spinner', () => {
        const loadingSpinner = fixture.debugElement.query(By.css('bt-loading.js-loading-spinner'));
        expect(loadingSpinner).toBeTruthy();
      });

      it('should not show form group', () => {
        const formGroup = fixture.debugElement.query(By.css('.form-field-group'));
        expect(formGroup).toBeFalsy();
      });
    });

    describe('when assets are loaded', () => {
      beforeEach(() => {
        component.assetsLoading = false;
        fixture.detectChanges();
      });

      it('should not display loading spinner', () => {
        const loadingSpinner = fixture.debugElement.query(By.css('bt-loading.js-loading-spinner'));
        expect(loadingSpinner).toBeFalsy();
      });

      describe('when manual mode is false (default)', () => {
        it('should show these controls', () => {
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-panorama-asset-details'))
          ).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-quantity'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-source'))).toBeTruthy();
        });

        it('should have btClearInput on appropriate inputs', () => {
          expect(
            fixture.debugElement
              .query(By.css('.js-test-extassets-add-ls-form-input-panorama-asset-details'))
              .nativeElement.getAttribute('btClearInput')
          ).toBeDefined();
          expect(
            fixture.debugElement
              .query(By.css('.js-test-extassets-add-ls-form-input-source'))
              .nativeElement.getAttribute('btClearInput')
          ).toBeDefined();
        });
      });

      describe('when manual mode is true', () => {
        beforeEach(() => {
          component.manualMode = true;
          fixture.detectChanges();
        });

        it('should show the controls', () => {
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-position-name'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-asset-code'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-quantity'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-market-value'))).toBeTruthy();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-value-date-datepicker-toggle'))
          ).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-select'))).toBeTruthy();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-input-source'))).toBeTruthy();
        });

        it('should have btClearInput on appropriate inputs', () => {
          expect(
            fixture.debugElement
              .query(By.css('.js-test-extassets-add-ls-form-input-position-name'))
              .nativeElement.getAttribute('btClearInput')
          ).toBeDefined();
          expect(
            fixture.debugElement
              .query(By.css('.js-test-extassets-add-ls-form-input-source'))
              .nativeElement.getAttribute('btClearInput')
          ).toBeDefined();
        });
      });

      it('should hide all Errors by default', () => {
        expect(fixture.debugElement.queryAll(By.css('mat-error')).length).toBe(0);
      });

      describe('validate form control', () => {
        let assetDetailsFormGroup: FormGroup;
        beforeEach(() => {
          component.ngOnInit();
          fixture.detectChanges();
          assetDetailsFormGroup = component.addAssetForm.get('assetDetails') as FormGroup;
          assetDetailsFormGroup.markAllAsTouched();
        });

        describe('validate panoramaAssetDetails', () => {
          it('should show error message ', () => {
            assetDetailsFormGroup.get('panoramaAssetDetails').setValue('');
            fixture.detectChanges();
            const element = fixture.debugElement.query(
              By.css('.js-test-extassets-add-ls-form-panorama-asset-details-invalid-error')
            );
            expect(element).toBeTruthy();
            expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1225');
          });

          it('should show error message when an asset has not been selected', () => {
            assetDetailsFormGroup.get('panoramaAssetDetails').setValue({ status: 'error' });
            fixture.detectChanges();
            const element = fixture.debugElement.query(
              By.css('.js-test-extassets-add-ls-form-panorama-asset-details-assetSelected-error')
            );
            expect(element).toBeTruthy();
            expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1225');
          });

          it('should not show error message ', () => {
            assetDetailsFormGroup.get('panoramaAssetDetails').setValue({ assetCode: 'test', assetName: 'test' });
            fixture.detectChanges();
            expect(
              fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-panorama-asset-details-assetSelected-error')
              )
            ).toBeNull();
          });
        });

        describe('validate quantity', () => {
          it('should show error message when invalid value entered and getErrorMessagesForQuantity method should have been called', () => {
            spyOn(component, 'getErrorMessagesForQuantity').and.returnValue('Enter a valid quantity.');
            assetDetailsFormGroup.get('quantity').setValue('hdgddhdhd');
            component.assetDetails.get('quantity').markAsTouched();
            fixture.detectChanges();
            const element = fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-quantity-error'));
            expect(component.getErrorMessagesForQuantity).toHaveBeenCalled();
            expect(element).toBeTruthy();
            expect(element.nativeElement.innerHTML.trim()).toBe('Enter a valid quantity.');
          });
        });

        describe('validate manual mode controls', () => {
          beforeEach(() => {
            component.manualMode = true;
            fixture.detectChanges();
          });

          describe('validate positionName', () => {
            it('should show error message when no value entered', () => {
              assetDetailsFormGroup.get('positionName').setValue('');
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-position-name-invalid-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0394');
            });

            it('should show error message when exceeds max length', () => {
              const positionNameTextMoreThanMax = CHARCTER_LENGTH_TEN.repeat(21);
              assetDetailsFormGroup.get('positionName').setValue(positionNameTextMoreThanMax);
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-position-name-invalid-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0394');
            });

            it('should not show error message when valid value entered', () => {
              assetDetailsFormGroup.get('positionName').setValue('asset name');
              fixture.detectChanges();
              expect(
                fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-position-name-invalid-error'))
              ).toBeNull();
            });
          });

          describe('validate asset code', () => {
            it('should show error message when exceeds maximum charcter length', () => {
              assetDetailsFormGroup.get('positionCode').setValue('');
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-asset-code-invalid-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0395');
            });

            it('should show error message when non alphanumeric charcter', () => {
              assetDetailsFormGroup.get('positionCode').setValue('+/asdg1');
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-asset-code-pattern-alphanumeric-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0397');
            });

            it('should show error message when asset code found', () => {
              component.assetCodeFound = true;
              component.assetDetails.controls['positionCode'].setErrors({ assetCodeFound: true });
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-asset-code-assetCodeFound-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1200');
            });

            it('should not show error message when valid value entered', () => {
              assetDetailsFormGroup.get('positionCode').setValue('AAA9999AA');
              fixture.detectChanges();
              expect(
                fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-asset-code-invalid-error'))
              ).toBeNull();
            });
          });

          describe('validate marketValue', () => {
            it('should show error message when no value entered', () => {
              assetDetailsFormGroup.get('marketValue').setValue(null);
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-market-value-required-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1235');
            });

            it('should not show error message when valid value entered', () => {
              assetDetailsFormGroup.get('marketValue').setValue(12);
              fixture.detectChanges();
              expect(
                fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-market-value-required-error'))
              ).toBeNull();
            });

            it('should show error message when invalid number is entered', () => {
              assetDetailsFormGroup.get('marketValue').setValue('12.3.5');
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-market-value-pattern-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1236');
            });

            it('should show error message when minimum number is entered', () => {
              assetDetailsFormGroup.get('marketValue').setValue('0.');
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-market-value-min-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1233');
            });

            it('should show error message maximum number is entered', () => {
              assetDetailsFormGroup.get('marketValue').setValue('999999999999');
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-market-value-max-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1227');
            });
          });

          describe('validate valuationDate', () => {
            it('should show error message when no value entered', () => {
              assetDetailsFormGroup.get('valuationDate').setValue(null);
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-value-date-required-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
            });

            it('should not show error message when valid value entered', () => {
              assetDetailsFormGroup.get('valuationDate').setValue(moment().tz('Australia/Sydney'));
              fixture.detectChanges();
              expect(
                fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-value-date-required-error'))
              ).toBeNull();
            });

            it('should show error message when future date is entered', () => {
              assetDetailsFormGroup.get('valuationDate').setValue(
                moment()
                  .add(4, 'day')
                  .tz('Australia/Sydney')
              );
              fixture.detectChanges();
              const element = fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-value-date-max-error'));
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0386');
            });
          });

          describe('validate asset class', () => {
            it('should show error message when no value entered', () => {
              assetDetailsFormGroup.get('assetClassCode').setValue(null);
              fixture.detectChanges();
              const element = fixture.debugElement.query(
                By.css('.js-test-extassets-add-ls-form-asset-class-invalid-error')
              );
              expect(element).toBeTruthy();
              expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0388');
            });

            it('should not show error message when valid value entered', () => {
              assetDetailsFormGroup.get('assetClassCode').setValue('cash');
              fixture.detectChanges();
              expect(
                fixture.debugElement.query(By.css('.js-test-extassets-add-ls-form-asset-class-invalid-error'))
              ).toBeNull();
            });
          });
        });
      });
    });
  });
});
