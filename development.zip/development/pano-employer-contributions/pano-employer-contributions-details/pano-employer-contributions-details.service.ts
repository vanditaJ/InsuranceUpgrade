import { Injectable, Injector, Type } from '@angular/core';
import { BtError, DataService } from '@bt/services/data';
import { PanoUpgradeAccountService, PanoUpgradeUserService } from '@upgrade/upgrade.services';
import { Observable } from 'rxjs';

import {
  SUBMIT_NOTIFICATION_OPTIONALS,
  SUBMIT_NOTIFICATION_URL
} from './pano-employer-contributions-details.constants';
import { NotificationResponse } from './pano-employer-contributions-details.interfaces';

@Injectable()
export class PanoEmployerContributionsDetailsService {
  constructor(private dataService: DataService<NotificationResponse | BtError>, private injector: Injector) {}

  submitNotification(
    notificationType: string,
    firstName: string,
    lastName: string,
    dateOfBirth: string,
    employerContactName: string,
    employerEmailAddress: string,
    emailAddress: string
  ): Observable<NotificationResponse | BtError> {
    const accountService = this.injector.get<PanoUpgradeAccountService>(
      PanoUpgradeAccountService as Type<PanoUpgradeAccountService>
    );
    const userService = this.injector.get<PanoUpgradeUserService>(
      PanoUpgradeUserService as Type<PanoUpgradeUserService>
    );

    const notificationRequest = {
      clientId: userService.getProfile().clientId,
      notificationType,
      firstName,
      lastName,
      dateOfBirth,
      employerContactName,
      employerEmailAddress,
      emailAddress
    };

    return this.dataService.update(
      `${SUBMIT_NOTIFICATION_URL}/${accountService.getAccountId()}`,
      notificationRequest,
      SUBMIT_NOTIFICATION_OPTIONALS
    );
  }
}
