import { Component, OnInit } from '@angular/core';
import { ErrorType } from '@bt/components/error';
import { UserProfile } from '@investor/account/pano-shared/interfaces';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeUserService } from '@upgrade/upgrade.services';
import { PanoUpgradePermissionService } from '@upgrade/upgrade.services';

import { INVESTOR_ERROR_STATE } from './pano-personal-details.constants';
import { PersonalDetailsPermissions } from './pano-personal-details.interfaces';

@Component({
  selector: 'pano-personal-details',
  templateUrl: './pano-personal-details.component.html'
})
export class PanoPersonalDetailsComponent implements OnInit {
  userProfile: UserProfile;
  personalDetailsPermissions: PersonalDetailsPermissions;

  constructor(
    private route: UIRouter,
    private userService: PanoUpgradeUserService,
    private permissionService: PanoUpgradePermissionService
  ) {}

  ngOnInit(): void {
    this.userProfile = this.userService.getProfile();
    this.personalDetailsPermissions = {
      hasWestpacLive: this.permissionService.hasPermission('user.detail.investor.wplusermessage.view', 'base'),
      emulating: this.permissionService.hasPermission('emulating', 'base'),
      addessUpdate: this.permissionService.hasPermission('feature.investor.personalDetails.address.update', 'base'),
      primaryEmailUpdate: this.permissionService.hasPermission(
        'feature.investor.personalDetails.primary.email.update',
        'base'
      ),
      additionalContactUpdate: this.permissionService.hasPermission(
        'feature.investor.personalDetails.additional.contact.update',
        'base'
      ),
      additionalContactDetailsView: this.permissionService.hasPermission(
        'feature.investor.personalDetails.additional.contact.view',
        'base'
      ),
      userNameUpdate: this.permissionService.hasPermission('feature.investor.personalDetails.username.update', 'base'),
      passwordUpdate: this.permissionService.hasPermission('feature.investor.personalDetails.password.update', 'base')
    };
  }

  handleError(error: boolean): void {
    if (error) {
      this.route.stateService.go(INVESTOR_ERROR_STATE, { type: ErrorType.generic });
    }
  }
}
