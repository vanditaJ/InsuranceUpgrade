import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { cloneDeep } from 'lodash-es';

import { RangeSliderModel } from '../pano-inv-profile-setup.interface';

import { PanoInvestmentPreferencesComponent } from './pano-inv-pref.component';
import {
  MOCK_INVESTMENT_OBJECTIVES,
  MOCK_INVESTMENT_TIMEFRAMES,
  MOCK_REDEMPTION_FREQUENCIES,
  MOCK_RETURN_OBJECTIVES
} from './pano-inv-pref.component.data.spec';
import { CheckboxField } from './pano-inv-pref.interface';

@Component({
  template: `
    <pano-inv-pref
      [(investmentObjectives)]="investmentObjectives"
      (investmentObjectivesChange)="investmentObjectivesChange($event)"
      [(investmentTimeframes)]="investmentTimeframes"
      (investmentTimeframesChange)="investmentTimeframesChange($event)"
      [(riskReturnObjectives)]="riskReturnObjectives"
      (riskReturnObjectivesChange)="riskReturnObjectivesChange($event)"
      [(redemptionFrequencies)]="redemptionFrequencies"
      (redemptionFrequenciesChange)="redemptionFrequenciesChange($event)"
    >
    </pano-inv-pref>
  `
})
class TestHostComponent {
  investmentObjectives: CheckboxField[] = MOCK_INVESTMENT_OBJECTIVES;
  investmentTimeframes: CheckboxField[] = MOCK_INVESTMENT_TIMEFRAMES;
  riskReturnObjectives: RangeSliderModel = MOCK_RETURN_OBJECTIVES;
  redemptionFrequencies: RangeSliderModel = MOCK_REDEMPTION_FREQUENCIES;

  investmentObjectivesChange(): void {}
  investmentTimeframesChange(): void {}
  riskReturnObjectivesChange(): void {}
  redemptionFrequenciesChange(): void {}
}

describe('PanoInvestmentPreferencesComponent', () => {
  let component: PanoInvestmentPreferencesComponent;
  let fixture: ComponentFixture<PanoInvestmentPreferencesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [PanoInvestmentPreferencesComponent, TestHostComponent],
      imports: [NoopAnimationsModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentPreferencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct input and output mapping with its host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);

      const hostComponent = hostFixture.componentInstance;
      const currentComp: PanoInvestmentPreferencesComponent = hostFixture.debugElement.query(
        By.directive(PanoInvestmentPreferencesComponent)
      ).componentInstance;

      spyOn(hostComponent, 'investmentObjectivesChange');
      spyOn(hostComponent, 'investmentTimeframesChange');
      spyOn(hostComponent, 'riskReturnObjectivesChange');
      spyOn(hostComponent, 'redemptionFrequenciesChange');

      hostFixture.detectChanges();
      currentComp.investmentObjectivesChange.emit(MOCK_INVESTMENT_OBJECTIVES);
      currentComp.investmentTimeframesChange.emit(MOCK_INVESTMENT_TIMEFRAMES);
      currentComp.riskReturnObjectivesChange.emit(MOCK_RETURN_OBJECTIVES);
      currentComp.redemptionFrequenciesChange.emit(MOCK_REDEMPTION_FREQUENCIES);

      expect(currentComp.investmentObjectives).toEqual(hostComponent.investmentObjectives);
      expect(currentComp.investmentTimeframes).toEqual(hostComponent.investmentTimeframes);
      expect(currentComp.riskReturnObjectives).toEqual(hostComponent.riskReturnObjectives);
      expect(currentComp.redemptionFrequencies).toEqual(hostComponent.redemptionFrequencies);
      expect(hostComponent.investmentObjectivesChange).toHaveBeenCalled();
      expect(hostComponent.investmentTimeframesChange).toHaveBeenCalled();
      expect(hostComponent.riskReturnObjectivesChange).toHaveBeenCalled();
      expect(hostComponent.redemptionFrequenciesChange).toHaveBeenCalled();
    });

    describe('updateInvestmentObjectivesState', () => {
      it('should call investmentObjectivesChange.emit', () => {
        spyOn(component.investmentObjectivesChange, 'emit').and.stub();
        component.investmentObjectives = cloneDeep(MOCK_INVESTMENT_OBJECTIVES);

        component.updateInvestmentObjectivesState();

        expect(component.investmentObjectivesChange.emit).toHaveBeenCalled();
      });

      it('should setup noInvestmentObjectivesChecked as true if NO value of investmentObjectives is true', () => {
        spyOn(component.investmentObjectivesChange, 'emit').and.stub();
        component.investmentObjectives = cloneDeep(MOCK_INVESTMENT_OBJECTIVES);

        component.updateInvestmentObjectivesState();

        expect(component.noInvestmentObjectivesChecked).toBeTrue();
      });

      it('should setup noInvestmentObjectivesChecked as false if value of investmentObjectives has true', () => {
        spyOn(component.investmentObjectivesChange, 'emit').and.stub();
        component.investmentObjectives = cloneDeep(MOCK_INVESTMENT_OBJECTIVES);
        component.investmentObjectives[0].value = true;

        component.updateInvestmentObjectivesState();

        expect(component.noInvestmentObjectivesChecked).toBeFalse();
      });
    });

    describe('updateInvestmentTimeframesState', () => {
      it('should call investmentTimeframesChange.emit', () => {
        spyOn(component.investmentTimeframesChange, 'emit').and.stub();
        component.investmentTimeframes = cloneDeep(MOCK_INVESTMENT_OBJECTIVES);

        component.updateInvestmentTimeframesState();

        expect(component.investmentTimeframesChange.emit).toHaveBeenCalled();
      });

      it('should setup noInvestmentTimeframesChecked as true if NO value of investmentTimeframes is true', () => {
        spyOn(component.investmentTimeframesChange, 'emit').and.stub();
        component.investmentTimeframes = cloneDeep(MOCK_INVESTMENT_OBJECTIVES);

        component.updateInvestmentTimeframesState();

        expect(component.noInvestmentTimeframesChecked).toBeTrue();
      });

      it('should setup noInvestmentTimeframesChecked as false if value of investmentTimeframes has true', () => {
        spyOn(component.investmentTimeframesChange, 'emit').and.stub();
        component.investmentTimeframes = cloneDeep(MOCK_INVESTMENT_TIMEFRAMES);
        component.investmentTimeframes[0].value = true;

        component.updateInvestmentTimeframesState();

        expect(component.noInvestmentTimeframesChecked).toBeFalse();
      });
    });
  });

  describe('View', () => {
    beforeEach(() => {
      component.investmentObjectives = cloneDeep(MOCK_INVESTMENT_OBJECTIVES);
      component.investmentTimeframes = cloneDeep(MOCK_INVESTMENT_TIMEFRAMES);
      component.riskReturnObjectives = cloneDeep(MOCK_RETURN_OBJECTIVES);
      component.redemptionFrequencies = cloneDeep(MOCK_REDEMPTION_FREQUENCIES);

      fixture.detectChanges();
    });

    it('should show investment preference title and description', () => {
      const title = fixture.debugElement.query(By.css('.js-test-investment-preference-title'));
      expect(title.nativeElement.textContent.trim()).toBe(component.investPreferenceTitle);

      const description = fixture.debugElement.query(By.css('.js-test-investment-preference-description'));
      expect(description.nativeElement.textContent.trim()).toBe(component.investPreferenceDescription);
    });

    describe('investment objectives', () => {
      it('should render right header', () => {
        const header = fixture.debugElement.query(By.css('.js-test-investment-objectives pano-pref-header'));
        expect(header.properties['headerConfig']).toEqual(component.investmentObjectivesHeader);
      });

      it('should render investment objectives checkboxes', () => {
        const chekboxes = fixture.debugElement.query(By.css('.js-test-investment-objectives pano-pref-checkboxes'));
        expect(chekboxes.properties['checkBoxFields']).toEqual(component.investmentObjectives);
      });

      it('should call updateInvestmentObjectivesState()', () => {
        spyOn(component, 'updateInvestmentObjectivesState').and.stub();

        const chekboxes = fixture.debugElement.query(By.css('.js-test-investment-objectives pano-pref-checkboxes'));
        chekboxes.triggerEventHandler('checkBoxFieldsChange', [{ name: 'test', descripton: 'now', value: false }]);
        fixture.detectChanges();

        expect(component.updateInvestmentObjectivesState).toHaveBeenCalled();
      });

      describe('noInvestmentObjectivesCheckedAlert', () => {
        it('should show noInvestmentObjectivesCheckedAlert when noInvestmentObjectivesChecked is true', () => {
          component.noInvestmentObjectivesChecked = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-no-investment-objectives-alert'));
          expect(alert).toBeTruthy();
          expect(alert.properties.config).toEqual(component.noInvestmentObjectivesCheckedAlert);
        });

        it('should NOT show noInvestmentObjectivesCheckedAlert when noInvestmentObjectivesChecked is false', () => {
          component.noInvestmentObjectivesChecked = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-no-investment-objectives-alert'));
          expect(alert).toBeFalsy();
        });
      });

      describe('noInvestmentObjectivesCheckedAlert placeholder', () => {
        it('should show noInvestmentObjectivesCheckedAlert placeholder when noInvestmentObjectivesChecked is false and noInvestmentTimeframesChecked is true', () => {
          component.noInvestmentObjectivesChecked = false;
          component.noInvestmentTimeframesChecked = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-no-investment-objectives-alert-placeholder'));
          expect(alert).toBeTruthy();
        });

        it('should NOT show noInvestmentObjectivesCheckedAlert placeholder when noInvestmentObjectivesChecked is true and noInvestmentTimeframesChecked is true', () => {
          component.noInvestmentObjectivesChecked = true;
          component.noInvestmentTimeframesChecked = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-no-investment-objectives-alert-placeholder'));
          expect(alert).toBeFalsy();
        });

        it('should NOT show noInvestmentObjectivesCheckedAlert placeholder when noInvestmentObjectivesChecked is true and noInvestmentTimeframesChecked is false', () => {
          component.noInvestmentObjectivesChecked = true;
          component.noInvestmentTimeframesChecked = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-no-investment-objectives-alert-placeholder'));
          expect(alert).toBeFalsy();
        });

        it('should NOT show noInvestmentObjectivesCheckedAlert placeholder when noInvestmentObjectivesChecked is false and noInvestmentTimeframesChecked is false', () => {
          component.noInvestmentObjectivesChecked = false;
          component.noInvestmentTimeframesChecked = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-no-investment-objectives-alert-placeholder'));
          expect(alert).toBeFalsy();
        });
      });
    });

    describe('investment timeframes', () => {
      it('should render right header', () => {
        const header = fixture.debugElement.query(By.css('.js-test-investment-timeframe pano-pref-header'));
        expect(header.properties['headerConfig']).toEqual(component.investmentTimeframeHeader);
      });

      it('should render investment timeframe checkboxes', () => {
        const chekboxes = fixture.debugElement.query(By.css('.js-test-investment-timeframe pano-pref-checkboxes'));
        expect(chekboxes.properties['checkBoxFields']).toEqual(component.investmentTimeframes);
      });

      it('should call updateInvestmentTimeframesState()', () => {
        spyOn(component, 'updateInvestmentTimeframesState');

        const chekboxes = fixture.debugElement.query(By.css('.js-test-investment-timeframe pano-pref-checkboxes'));
        chekboxes.triggerEventHandler('checkBoxFieldsChange', [{ name: 'test', descripton: 'now', value: false }]);
        fixture.detectChanges();

        expect(component.updateInvestmentTimeframesState).toHaveBeenCalled();
      });

      describe('noInvestmentTimeframesCheckedAlert', () => {
        it('should show noInvestmentTimeframesCheckedAlert when noInvestmentTimeframesChecked is true', () => {
          component.noInvestmentTimeframesChecked = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-investment-timeframes-alert'));
          expect(alert).toBeTruthy();
          expect(alert.properties.config).toEqual(component.noInvestmentTimeframesCheckedAlert);
        });

        it('should NOT show noInvestmentTimeframesCheckedAlert when noInvestmentTimeframesChecked is false', () => {
          component.noInvestmentObjectivesChecked = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-investment-timeframes-alert'));
          expect(alert).toBeFalsy();
        });
      });

      describe('noInvestmentTimeframesCheckedAlert placeholder', () => {
        it('should show noInvestmentTimeframesCheckedAlert placeholder when noInvestmentObjectivesChecked is true and noInvestmentTimeframesChecked is false', () => {
          component.noInvestmentObjectivesChecked = true;
          component.noInvestmentTimeframesChecked = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-investment-timeframes-alert-placeholder'));
          expect(alert).toBeTruthy();
        });

        it('should NOT show noInvestmentTimeframesCheckedAlert placeholder when noInvestmentObjectivesChecked is false and noInvestmentTimeframesChecked is false', () => {
          component.noInvestmentObjectivesChecked = false;
          component.noInvestmentTimeframesChecked = false;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-investment-timeframes-alert-placeholder'));
          expect(alert).toBeFalsy();
        });

        it('should NOT show noInvestmentTimeframesCheckedAlert placeholder when noInvestmentObjectivesChecked is true and noInvestmentTimeframesChecked is true', () => {
          component.noInvestmentObjectivesChecked = true;
          component.noInvestmentTimeframesChecked = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-investment-timeframes-alert-placeholder'));
          expect(alert).toBeFalsy();
        });

        it('should NOT show noInvestmentTimeframesCheckedAlert placeholder when noInvestmentObjectivesChecked is false and noInvestmentTimeframesChecked is true', () => {
          component.noInvestmentObjectivesChecked = false;
          component.noInvestmentTimeframesChecked = true;
          fixture.detectChanges();

          const alert = fixture.debugElement.query(By.css('.js-test-investment-timeframes-alert-placeholder'));
          expect(alert).toBeFalsy();
        });
      });
    });

    describe('investment appetite for risk', () => {
      it('should render right header', () => {
        const header = fixture.debugElement.query(By.css('.js-test-investment-appetite-for-risk pano-pref-header'));
        expect(header.properties['headerConfig']).toEqual(component.appetiteForRiskHeader);
      });

      it('should render investment risk slider', () => {
        const slider = fixture.debugElement.query(By.css('.js-test-investment-appetite-for-risk ngx-slider'));
        expect(slider).toBeTruthy();
        expect(slider.properties['value']).toEqual(MOCK_RETURN_OBJECTIVES.minValue);
        expect(slider.properties['highValue']).toEqual(MOCK_RETURN_OBJECTIVES.maxValue);
      });

      it('should call riskReturnObjectivesChange()', () => {
        spyOn(component.riskReturnObjectivesChange, 'emit');

        const slider = fixture.debugElement.query(By.css('.js-test-investment-appetite-for-risk ngx-slider'));
        slider.triggerEventHandler('valueChange', 2);
        fixture.detectChanges();

        expect(component.riskReturnObjectivesChange.emit).toHaveBeenCalled();

        slider.triggerEventHandler('highValueChange', 2);
        fixture.detectChanges();

        expect(component.riskReturnObjectivesChange.emit).toHaveBeenCalled();
      });

      it('should show selected return objectives', () => {
        const slider = fixture.debugElement.query(By.css('.js-test-investment-appetite-for-risk ngx-slider'));
        slider.triggerEventHandler('valueChange', 0);
        fixture.detectChanges();

        slider.triggerEventHandler('highValueChange', 1);
        fixture.detectChanges();

        const selectedRange = fixture.debugElement.query(
          By.css('.js-test-investment-appetite-for-risk .js-test-selected-range')
        );
        expect(selectedRange).toBeTruthy();
        expect(selectedRange.nativeElement.textContent.trim()).toBe('You have selected:Low to Medium');
      });
    });

    describe('investment redemption frequencies', () => {
      it('should render right header', () => {
        const header = fixture.debugElement.query(By.css('.js-test-investment-asset-liquidity-needs pano-pref-header'));
        expect(header.properties['headerConfig']).toEqual(component.assetLiquidityNeedsHeader);
      });

      it('should render investment risk slider', () => {
        const slider = fixture.debugElement.query(By.css('.js-test-investment-asset-liquidity-needs ngx-slider'));
        expect(slider).toBeTruthy();
        expect(slider.properties['value']).toEqual(MOCK_REDEMPTION_FREQUENCIES.minValue);
        expect(slider.properties['highValue']).toEqual(MOCK_REDEMPTION_FREQUENCIES.maxValue);
      });

      it('should call redemptionFrequenciesChange()', () => {
        spyOn(component.redemptionFrequenciesChange, 'emit');

        const slider = fixture.debugElement.query(By.css('.js-test-investment-asset-liquidity-needs ngx-slider'));
        slider.triggerEventHandler('valueChange', 2);
        fixture.detectChanges();

        expect(component.redemptionFrequenciesChange.emit).toHaveBeenCalled();

        slider.triggerEventHandler('highValueChange', 2);
        fixture.detectChanges();

        expect(component.redemptionFrequenciesChange.emit).toHaveBeenCalled();
      });

      it('should show selected redemption frequencies', () => {
        spyOn(component.redemptionFrequenciesChange, 'emit');

        const slider = fixture.debugElement.query(By.css('.js-test-investment-asset-liquidity-needs ngx-slider'));
        slider.triggerEventHandler('valueChange', 0);
        fixture.detectChanges();

        slider.triggerEventHandler('highValueChange', 1);
        fixture.detectChanges();

        const selectedRange = fixture.debugElement.query(
          By.css('.js-test-investment-asset-liquidity-needs .js-test-selected-range')
        );
        expect(selectedRange).toBeTruthy();
        expect(selectedRange.nativeElement.textContent.trim()).toBe('You have selected:Daily to Weekly');
      });
    });
  });
});
