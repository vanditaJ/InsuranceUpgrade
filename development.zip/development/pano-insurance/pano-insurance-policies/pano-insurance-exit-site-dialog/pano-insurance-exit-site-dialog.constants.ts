import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Link } from '@bt/components/link';

export const AIA_SSO_URL = '/supermember/secure/app/sso-aia';

export const EXIT_DIALOG_ACCEPT_BUTTON: Button = {
  action: 'button',
  label: 'Accept',
  type: 'solid',
  size: 'large',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Accept'
  }
};

export const EXIT_DIALOG_CANCEL_BUTTON: Button = {
  action: 'button',
  label: 'Cancel',
  type: 'outline',
  size: 'large',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: 'Cancel and close dialog'
  }
};

export const EXIT_DIALOG_CLOSE_BUTTON: Button = {
  action: 'button',
  icon: { name: 'icon-cross' },
  size: 'small',
  colourModifier: 'basic',
  a11yProps: {
    ariaLabel: 'Close dialog'
  }
};

export const BT_PRIVACY_POLICY_LINK: Link = {
  isLinkExternal: true,
  label: 'BT Privacy policy',
  link: 'https://www.bt.com.au/personal/help/privacy.html',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  size: 'x-small',
  a11yProps: {
    ariaLabel: 'BT Privacy Policy, open in new tab.'
  }
};

export const AIA_PRIVACY_POLICY_LINK: Link = {
  isLinkExternal: true,
  label: 'AIA Australia privacy policy',
  link: 'https://www.aia.com.au/en/individual/index/privacy-policy.html',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  size: 'x-small',
  a11yProps: {
    ariaLabel: 'AIA Australia privacy policy, open in new tab.'
  }
};

export const CHECK_YOUR_DETAILS_LINK: Link = {
  isLinkExternal: true,
  label: 'check your details',
  link: '',
  openNewTab: false,
  type: 'flat',
  colourModifier: 'warning',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'Check your details'
  }
};

export const MANAGE_INSURANCE_ALERT: Alert = {
  type: 'warning',
  outline: false
};
