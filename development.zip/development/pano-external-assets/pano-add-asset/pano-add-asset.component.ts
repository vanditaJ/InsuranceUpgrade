import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';
import * as moment from 'moment-timezone';
import { of, Subscription } from 'rxjs';

import { PanoAlertDialogComponent } from '../pano-alert-dialog/pano-alert-dialog.component';
import {
  ADD_ASSET_BUTTON,
  ASSET_TYPES,
  CANCEL_ADD_ASSET_BUTTON,
  DEFAULT_ADD_ASSET_PROPS,
  MAX_ASSET_ALERT_BUTTON,
  MAX_ASSET_ALERT_HEADER,
  MAX_ASSET_COUNT
} from '../pano-external-assets-constants/pano-external-assets.constants';
import { AssetClasses, AssetType, ExternalAsset, PropertyType } from '../pano-external-assets.interfaces';

@Component({
  selector: 'pano-add-asset',
  templateUrl: './pano-add-asset.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoAddAssetComponent implements OnInit, OnDestroy {
  @Input() assetTypes: AssetType[];
  @Input() propertyTypes: PropertyType[];
  @Input() totalAssetsCount: number;

  @Output()
  assetAdd: EventEmitter<ExternalAsset> = new EventEmitter();

  ASSET_TYPES = ASSET_TYPES;
  addExternalAssetsForm: FormGroup;
  selectedAssetClasses: AssetClasses[] = [];

  addAssetButton: Button = ADD_ASSET_BUTTON;
  cancelAddAssetButton: Button = CANCEL_ADD_ASSET_BUTTON;
  showButtons: boolean = true;

  private assetClassesSubscription: Subscription = of(null).subscribe();

  constructor(
    private readonly fb: FormBuilder,
    private readonly dialog: MatDialog,
    private readonly copyMatrixPipe: CopyMatrixPipe
  ) {}

  ngOnInit(): void {
    this.addExternalAssetsForm = this.fb.group({
      assetTypeCode: [null]
    });

    this.assetClassesSubscription = this.addExternalAssetsForm.get('assetTypeCode').valueChanges.subscribe(value => {
      this.selectedAssetClasses = value
        ? this.assetTypes.find(eachAssetTypeCode => eachAssetTypeCode.assetTypeCode === value).assetClasses
        : [];
    });
  }

  ngOnDestroy(): void {
    this.assetClassesSubscription.unsubscribe();
  }

  addNewAssetFormDetails(): void {
    if (this.totalAssetsCount >= MAX_ASSET_COUNT) {
      this.showMaxAssetAlertDialog();
    } else {
      this.addExternalAssetsForm.markAllAsTouched();
      if (this.addExternalAssetsForm.valid) {
        const newAssetDetails: ExternalAsset = {
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: this.addExternalAssetsForm.get('assetDetails').get('assetClassCode').value,
          assetTypeCode: this.addExternalAssetsForm.get('assetTypeCode').value,
          marketValue: this.addExternalAssetsForm.get('assetDetails').get('marketValue').value,
          positionName: this.addExternalAssetsForm.get('assetDetails').get('positionName').value,
          valuationDate:
            this.addExternalAssetsForm.get('assetDetails').get('valuationDate').value !== ''
              ? moment(this.addExternalAssetsForm.get('assetDetails').get('valuationDate').value).tz('Australia/Sydney')
              : ''
        };
        switch (this.addExternalAssetsForm.get('assetTypeCode').value) {
          case ASSET_TYPES.cash.code:
            this.getCashAssetDetails(this.addExternalAssetsForm.get('assetDetails') as FormGroup, newAssetDetails);
            break;

          case ASSET_TYPES.td.code:
            this.getTermDepositAssetDetails(
              this.addExternalAssetsForm.get('assetDetails') as FormGroup,
              newAssetDetails
            );
            break;

          case ASSET_TYPES.ls.code:
          case ASSET_TYPES.mf.code:
            this.getManagedFundOrListedSecurityAssetDetails(
              this.addExternalAssetsForm.get('assetDetails') as FormGroup,
              newAssetDetails
            );
            break;

          case ASSET_TYPES.ils.code:
          case ASSET_TYPES.oth.code:
            this.getInternationalShareOrOtherAssetDetails(
              this.addExternalAssetsForm.get('assetDetails') as FormGroup,
              newAssetDetails
            );
            break;

          case ASSET_TYPES.dp.code:
            this.getDirectPropertyAssetDetails(
              this.addExternalAssetsForm.get('assetDetails') as FormGroup,
              newAssetDetails
            );
            break;

          case ASSET_TYPES.mp.code:
            this.getManagedPortfolioAssetDetails(
              this.addExternalAssetsForm.get('assetDetails') as FormGroup,
              newAssetDetails
            );
            break;
        }
        this.assetAdd.emit(newAssetDetails);
        this.addExternalAssetsForm.reset();
      }
    }
  }

  getCashAssetDetails(assetDetails: FormGroup, newAssetDetails: ExternalAsset): void {
    newAssetDetails['source'] = assetDetails.get('source').value;
  }

  getTermDepositAssetDetails(assetDetails: FormGroup, newAssetDetails: ExternalAsset): void {
    newAssetDetails['source'] = assetDetails.get('source').value;
    newAssetDetails['maturityDate'] = moment(assetDetails.get('maturityDate').value).tz('Australia/Sydney');
  }

  getManagedFundOrListedSecurityAssetDetails(assetDetails: FormGroup, newAssetDetails: ExternalAsset): void {
    newAssetDetails['isPanoramaAsset'] = assetDetails.get('isPanoramaAsset').value;
    newAssetDetails['assetId'] = assetDetails.get('assetId').value;
    newAssetDetails['positionCode'] = assetDetails.get('positionCode').value;
    newAssetDetails['source'] = assetDetails.get('source').value;
    newAssetDetails['quantity'] = assetDetails.get('quantity').value;
  }

  getInternationalShareOrOtherAssetDetails(assetDetails: FormGroup, newAssetDetails: ExternalAsset): void {
    newAssetDetails['source'] = assetDetails.get('source').value;
    newAssetDetails['positionCode'] = assetDetails.get('positionCode').value;
    newAssetDetails['quantity'] = assetDetails.get('quantity').value;
  }

  getDirectPropertyAssetDetails(assetDetails: FormGroup, newAssetDetails: ExternalAsset): void {
    newAssetDetails['propertyType'] = assetDetails.get('propertyType').value;
  }

  getManagedPortfolioAssetDetails(assetDetails: FormGroup, newAssetDetails: ExternalAsset): void {
    newAssetDetails['source'] = assetDetails.get('source').value;
    newAssetDetails['positionCode'] = assetDetails.get('positionCode').value;
  }

  cancelAddAsset() {
    this.addExternalAssetsForm.reset();
  }

  showOrHideButtons(event: boolean): void {
    this.showButtons = event;
  }

  showMaxAssetAlertDialog() {
    this.dialog.open(PanoAlertDialogComponent, {
      ...DIALOG_CONFIG.ALT,
      autoFocus: true,
      disableClose: true,
      data: {
        headerText: MAX_ASSET_ALERT_HEADER,
        descriptionText: this.copyMatrixPipe.transform('Err.IP-1226'),
        alertButton: MAX_ASSET_ALERT_BUTTON
      }
    });
  }
}
