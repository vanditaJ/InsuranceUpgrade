import { Link } from '@bt/components/link';
import { Optionals } from '@bt/services/data';

export const LEARN_ABOUT_INVESTMENTS_TILES_CONTENT_URL: string =
  '/content/secure/panorama/_services/tiles/learn-about-investment/_jcr_content.getAllPanoramaTiles.json';
export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0344' };

export const GENERIC_EXTERNAL_LINK: Link = {
  link: '',
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false
};
