export interface Policy {
  policyName: string;
  sumInsured: number;
  policyNumber: string;
  coverSubTypeId: number;
  premium: string;
  policyType: string;
  qualifierName: string;
  status: string;
  benefitFrequencyLabel?: string;
  commencementDate: string;
  customised: boolean;
  employerFunded: boolean;
  ageNextBirthday?: number;
  coverLevel?: string;
  policyFrequency?: string;
  newCoverType?: NewCoverType;
  customerType?: string;
  pmifDetails?: PMIFDetails;
  unitsOfCover?: number;
  personBenefitDetails?: PersonBenefitDetails[];
  external?: boolean;
  endDate?: string;
  smokerStatus?: string;
  applicableNotes?: string;
  westpacGroupPlan?: boolean;
  groupInsurance?: boolean;
  pysDetails?: PYSDetails;
  riskCommencementDate?: string;
  associatedTpd?: number[];
  decreaseAvailable?: boolean;
  insurerCode?: string;
}

export interface PysDetails {
  inactivityType: string;
  expiryDate: string;
  optInStatus: string;
  optInDate: string;
}

export interface RelatedAccounts {
  policyType: string;
  policyName: any;
  policyNumber: string;
}
export interface StaticData {
  id: string;
  code: string;
  label: string;
}
export enum PolicyStatus {
  ACTIVE = 'IN_FORCE',
  PENDING = 'PROPOSAL',
  INACTIVE = 'CANCELLED',
  DECLINED = 'DECLINED',
  NOT_ACTIVE = 'NOT_ACTIVE',
  REQUESTED = 'REQUESTED'
}

export interface PYSDetails {
  policyStatus?: string;
  optInStatus?: string;
  optInDate: string;
  paidToDate?: string;
  inactivityType?: string;
  expiryDate?: string;
  expired?: boolean;
}

export interface PersonBenefitDetails {
  benefits: Benefits[];
}

export interface Permission {
  [key: string]: string;
}

export interface Benefits {
  benefitPeriodFactor: string;
  benefitPeriodTerm: string;
  waitingPeriod: string;
  benefits?: Benefits2[];
}

export interface Benefits2 {
  occupationClass?: string;
  frequency?: string;
}

export interface InsuranceOption {
  waitingPeriod: string;
  benefitPeriods: string[];
}

export interface PMIFDetails {
  optInDate: string;
  lowBalanceThresholdDate?: string;
}

export interface PYSDetails {
  policyStatus?: string;
  optInStatus?: string;
  optInDate: string;
  paidToDate?: string;
  inactivityType?: string;
  expiryDate?: string;
  expired?: boolean;
}

export interface NewCoverType {
  coverType?: SelectCoverType;
  coverAmountType?: {
    coverSubTypeId: string | number;
    coverAmount: number | string;
    coverAmountName?: string;
    coverAmountType?: string;
    premium?: string;
    increase?: boolean;
  };
  requestCoverAmount?: number;
  requestUnitsCover?: number;
  requestWaitingPeriod?: string;
  requestBenefitPeriod?: string;
}

export interface SelectCoverType {
  policyName: string;
  policyType: string;
  description?: string;
}

export interface PolicyTitleMap {
  type: PolicyType;
  title: string;
}

export enum PolicyType {
  DEATH = 'DEATH',
  TPD = 'TPD',
  DEATH_AND_TPD = 'DEATH_AND_TPD',
  INCOME_PROTECTION = 'INCOME_PROTECTION'
}

export enum PolicyDisplayName {
  DEATH = 'Death',
  TPD = 'TPD',
  DEATH_AND_TPD = 'Death & TPD',
  INCOME_PROTECTION = 'SCI'
}
