import { Button } from '@bt/components/button';

import { SCREEN_TYPE } from './pano-external-assets.constants';

export interface Asset {
  assetId: string;
  assetName: string;
  assetCode: string;
  assetClass: string;
  assetClassId: string;
}

export interface AssetType {
  assetTypeCode: string;
  assetTypeName: string;
  assetClasses: AssetClasses[];
}

export interface AssetClasses {
  assetClassCode: string;
  assetClassName: string;
}

export interface PropertyType {
  propertyTypeCode: string;
  propertyTypeName: string;
}

export interface ExternalAssetCommon {
  assetClassCode: string;
  assetTypeCode: string;
  isNewAsset: boolean;
  positionId: string;
  positionName: string;
}

export interface ExternalAssetCash extends ExternalAssetCommon {
  marketValue: string;
  source: string;
  valuationDate: string;
}

export interface ExternalAssetTD extends ExternalAssetCommon {
  marketValue: string;
  maturityDate: string;
  source: string;
  valuationDate: string;
}

export interface ExternalAssetLS extends ExternalAssetCommon {
  assetId?: string;
  isPanoramaAsset: boolean;
  marketValue: string;
  positionCode: string;
  quantity: string;
  source: string;
  valuationDate: string;
}

export interface ExternalAssetILS extends ExternalAssetCommon {
  isPanoramaAsset: boolean;
  marketValue: string;
  positionCode: string;
  quantity: string;
  source: string;
  valuationDate: string;
}

export interface ExternalAssetMF extends ExternalAssetCommon {
  assetId?: string;
  marketValue: string;
  isPanoramaAsset: boolean;
  positionCode: string;
  quantity: string;
  source: string;
  valuationDate: string;
}

export interface ExternalAssetMP extends ExternalAssetCommon {
  assetId?: string;
  marketValue: string;
  isPanoramaAsset?: boolean;
  positionCode: string;
  source?: string;
  valuationDate: string;
}

export interface ExternalAssetDP extends ExternalAssetCommon {
  isPanoramaAsset: boolean;
  marketValue: string;
  propertyType: string;
  valuationDate: string;
}

export interface ExternalAssetOTH extends ExternalAssetCommon {
  isPanoramaAsset: boolean;
  marketValue: string;
  positionCode: string;
  quantity: string;
  source: string;
  valuationDate: string;
}

export interface ExternalAssetsValuationByType {
  cash: ExternalAssetCash[];
  td: ExternalAssetTD[];
  ls: ExternalAssetLS[];
  ils: ExternalAssetILS[];
  mf: ExternalAssetMF[];
  mp: ExternalAssetMP[];
  dp: ExternalAssetDP[];
  oth: ExternalAssetOTH[];
}

export interface ExternalAssetsValuationDetails {
  totalValuation: number;
  hasAssets: boolean;
  assets: ExternalAssetsValuationByType;
}

export interface ExternalAssetsSaveDetails {
  addedAndEdited: ExternalAssetsValuationByType;
  deleted: ExternalAssetDelete[];
}

export interface ExternalAssetDelete {
  positionId: string;
  quantity: number;
}

export interface ExternalAssetDeleteDetails {
  index: number;
  assetTypeCode: string;
  positionId: string;
  isNewAsset: boolean;
}

export interface FormControlsDetails {
  name: string;
  type: string;
}

export type ExternalAsset =
  | ExternalAssetCash
  | ExternalAssetTD
  | ExternalAssetLS
  | ExternalAssetILS
  | ExternalAssetMF
  | ExternalAssetMP
  | ExternalAssetDP
  | ExternalAssetOTH;

export type Status = 'manual' | 'awaiting' | 'received' | 'requested' | 'stop';

export type SoftwareName = 'Class Super' | 'BGL SF360';

export interface AccountingSoftwareStatus {
  status: Status;
  softwareName?: SoftwareName;
}

export interface ExternalAssetTotalValuation {
  totalValuation: number;
}

export interface SoftwareData {
  softwareStatus: AccountingSoftwareStatus;
  valuation?: ExternalAssetTotalValuation;
  screenType: SCREEN_TYPE;
  externalAssetsValuationDetails?: ExternalAssetsValuationDetails;
}

export interface AssetLatestPrice {
  lastPrice: number;
  valuationDate: string;
}

export interface AssetTypeTotalDetails {
  assetTypeTotalMarketValue: number;
  assetTypeCode: string;
}

export interface AssetTypeTotalMarketValue {
  cashTotalMarketValue: number;
  tdTotalMarketValue: number;
  lsTotalMarketValue: number;
  ilsTotalMarketValue: number;
  mfTotalMarketValue: number;
  mpTotalMarketValue: number;
  dpTotalMarketValue: number;
  othTotalMarketValue: number;
}

export interface DialogDataConfig {
  headerText: string;
  descriptionText: string;
  confirmButton?: Button;
  cancelButton?: Button;
  alertButton?: Button;
}
