import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { LayoutModule } from '@panorama/components/layout';
import { DocumentLibraryModule } from '@panorama/doc-library';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { PanoDocumentsComponent } from './pano-documents.component';

describe('PanoDocumentLibraryComponent', () => {
  let component: PanoDocumentsComponent;
  let fixture: ComponentFixture<PanoDocumentsComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoDocumentsComponent],
        imports: [LayoutModule, DocumentLibraryModule],
        schemas: [NO_ERRORS_SCHEMA],
        providers: [
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccountId: () => '12345678'
            }
          }
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoDocumentsComponent);
    component = fixture.componentInstance;
  });

  it('should exist', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should have accountId initialised', () => {
      component.ngOnInit();

      expect(component.accountId).toEqual('12345678');
    });
  });
});
