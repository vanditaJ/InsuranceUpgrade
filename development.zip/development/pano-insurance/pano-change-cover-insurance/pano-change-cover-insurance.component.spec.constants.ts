import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';

import { InsurancePolicy, NewCoverType, PolicyStatus, PolicyType } from '../pano-insurance.interface';

import { CoverAmountOptions } from './pano-change-cover-insurance.interface';
export const NEW_COVER_TYPE: NewCoverType = {
  coverType: {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH,
    description:
      'Retains Death cover only and cancels your TPD if you have bundled Death and TPD cover. Death cover pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.'
  },
  coverAmountType: {
    coverSubTypeId: '93',
    coverAmountName: 'Single cover',
    coverAmountType: 'Single',
    coverAmount: 4521,
    premium: '4586',
    increase: false
  }
};

export const DEATH_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Death cover',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const DEATH_AND_TPD_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH_AND_TPD,
  policyName: 'Death and Total Permanent Disability/Disablement (TPD)',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Single',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const TRIPLE_DEATH_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Death cover',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Triple',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const TRIPLE_DEATH_INSURANCE_POLICY_AGE_67: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Death cover',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Triple',
  ageNextBirthday: 67,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const SINGLE_DEATH_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Death cover',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Single',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const TRIPLE_DEATH_AND_TPD_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH_AND_TPD,
  policyName: 'Death and Total Permanent Disability/Disablement (TPD)',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Triple',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const SINGLE_DEATH_AND_TPD_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH_AND_TPD,
  policyName: 'Death cover',
  policyNumber: '5273590',
  qualifierName: 'Standard cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Single',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const SCI_INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance (SCI)',
  policyNumber: '5273590',
  qualifierName: 'Employee Salary Continuance Insurance',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 12,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: null,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  pmifDetails: {
    optInDate: '2020-03-01T00:00:00.000+11:00',
    lowBalanceThresholdDate: '2021-03-01T00:00:00.000+11:00'
  }
};

export const COVER_AMOUNT_OPTIONS: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Double',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single']
    }
  ]
};

export const COVER_AMOUNT_OPTIONS_MULTI: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Double',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single', 'Double']
    }
  ]
};

export const CHANGE_COVER_ACC: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountNumber: '1234',
  accountName: 'account name',
  firstMoneyReceivedDate: '2020-11-04T16:00:00.000Z',
  pdsStatus: 'WGP_CURRENT',
  owners: [
    {
      age: 25,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Female',
      lastName: 'LastName'
    }
  ],
  product: {},
  productDescription: 'BT Super'
};

export const MOCK_AEM_CONTENT_CHANGE: AemContent[] = [
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_death_tpd_info',
      description:
        'This cover pays a lump sum payment to your beneficiaries when you pass away or if you become totally and permanently disabled and are no longer able to work. You may also be able to claim if you are diagnosed with a terminal illness.'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_death_info',
      description:
        'Retains Death cover only and cancels your TPD if you have bundled Death and TPD cover. Death cover pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_death_tpd_info',
      description:
        'This cover pays a lump sum payment to your beneficiaries when you pass away or if you become totally and permanently disabled and are no longer able to work. You may also be able to claim if you are diagnosed with a terminal illness.'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_death_info',
      description:
        'Retains Death cover only and cancels your TPD if you have bundled Death and TPD cover. Death cover pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.'
    }
  }
];
