import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';

export const PAGE_SCROLL_DURATION: number = 200;
export const UPDATE_PROFILE_ALERT_ID: string = 'Err.IP-1450';
export const REQUIRE_PROFILE_REVIEW_UPDATE_ALERT_ID: string = 'Err.IP-1458';

export const ASSET_NOT_MATCH_ALERT: Alert = {
  type: 'error',
  outline: true,
  messages: 'Err.IP-1451'
};

export const NOT_WITHIN_MARKET_ALERT: Alert = {
  type: 'error',
  outline: true,
  messages: 'Err.IP-1457'
};

export const REMIND_PROFILE_REVIEW_ALERT: Alert = {
  type: 'warning',
  outline: true,
  messages: 'Err.IP-1459'
};

export const SHARES_ETFS_ALERT: Alert = {
  type: 'info',
  outline: true,
  messages: 'Help-IP-0400'
};

export const UPDATE_PROFILE_ALERT: Alert = {
  type: 'error',
  outline: true
};

export const UPDATE_PROFILE_BUTTON: Button = {
  action: 'button',
  a11yProps: {
    ariaLabel: 'Update investment profile'
  },
  label: 'Update investment profile',
  size: 'medium',
  colourModifier: 'error',
  shapeModifier: 'square',
  type: 'outline',
  icon: { name: 'icon-arrow-right', size: 'x-small' }
};
