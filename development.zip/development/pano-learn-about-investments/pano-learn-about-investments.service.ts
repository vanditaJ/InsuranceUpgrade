import { Injectable } from '@angular/core';
import { DataService } from '@bt/services/data';
import { get } from 'lodash-es';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { AEM_TEXT_URL, GENERIC_OPTIONS } from './pano-learn-about-investments.constants';
import { AemTextItem } from './pano-learn-about-investments.interface';

@Injectable()
export class PanoLearnAboutInvestmentsService {
  private cmsTextUrl: string = AEM_TEXT_URL;
  constructor(private dataService: DataService<any>) {}

  getTextContent(): Observable<object> {
    let cmsText: Observable<AemTextItem[]>;
    cmsText = this.dataService.retrieve(this.cmsTextUrl, GENERIC_OPTIONS).pipe(map(res => get(res, 'details')));
    return cmsText.pipe(
      map(res => {
        return res.reduce((contentMap, obj) => {
          contentMap[obj.data.headerText] = obj.data.description;
          return contentMap;
        }, {});
      })
    );
  }
}
