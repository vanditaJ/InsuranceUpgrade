import { INVESTMENT_TYPES } from './pano-inv-profile.constants';
import {
  InvestmentObjective,
  InvestmentProfile,
  InvestmentTimeframe,
  RedemptionFrequency,
  ReturnObjective
} from './pano-inv-profile.interface';

export const MOCK_INVESTMENT_PROFILE: InvestmentProfile = {
  accountId: '1234567801',
  profileId: '123123',
  investmentType: INVESTMENT_TYPES.ALL_INVESTMENT_TYPES,
  investmentObjectives: [InvestmentObjective.CAPITAL_GUARANTEED, InvestmentObjective.REGULAR_INCOME],
  investmentTimeframes: [InvestmentTimeframe.MEDIUM, InvestmentTimeframe.SHORT],
  riskReturnObjectives: [ReturnObjective.MEDIUM, ReturnObjective.MEDIUM],
  redemptionFrequencies: [RedemptionFrequency.WEEKLY, RedemptionFrequency.MONTHLY],
  lastUpdatedAt: '2022'
};
