export const INVESTOR_ERROR_STATE: string = 'app.investor.errors';
