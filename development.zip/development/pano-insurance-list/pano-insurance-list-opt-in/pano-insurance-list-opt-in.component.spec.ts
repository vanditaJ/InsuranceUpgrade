import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PanoInsuranceListOptInComponent } from './pano-insurance-list-opt-in.component';

describe('PanoInsuranceListOptInComponent', () => {
  let component: PanoInsuranceListOptInComponent;
  let fixture: ComponentFixture<PanoInsuranceListOptInComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PanoInsuranceListOptInComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsuranceListOptInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
