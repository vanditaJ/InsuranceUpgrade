import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment-timezone';

import {
  alphaNumericValidator,
  assetCodeValidator,
  assetSelectedValidator
} from '../pano-external-assets-custom-validator';
import { SCREEN_TYPE, SOFTWARE_NAME, SOFTWARE_STATUS } from '../pano-external-assets.constants';
import {
  AccountingSoftwareStatus,
  Asset,
  AssetLatestPrice,
  ExternalAssetCash,
  ExternalAssetDP,
  ExternalAssetILS,
  ExternalAssetLS,
  ExternalAssetMF,
  ExternalAssetMP,
  ExternalAssetOTH,
  ExternalAssetsValuationDetails,
  ExternalAssetTD,
  ExternalAssetTotalValuation,
  SoftwareData
} from '../pano-external-assets.interfaces';

export const CHARCTER_LENGTH_TEN = 'abcdefghij';

export const ASSET_LIST_CASH: ExternalAssetCash[] = [
  {
    assetClassCode: 'cash',
    assetTypeCode: 'cash',
    marketValue: '300',
    isNewAsset: false,
    positionId: '8004887',
    positionName: 'test',
    source: 'some option',
    valuationDate: '2019-10-16T00:00:00.000+11:00'
  }
];

export const ASSET_LIST_TD: ExternalAssetTD[] = [
  {
    assetClassCode: 'cash',
    assetTypeCode: 'td',
    marketValue: '300.5',
    isNewAsset: false,
    positionId: '8015573',
    positionName: 'test td',
    source: 'some option td',
    valuationDate: '2019-10-16T00:00:00.000+11:00',
    maturityDate: '2040-10-16T00:00:00.000+11:00'
  }
];

export const ASSET_LIST_LS: ExternalAssetLS[] = [
  {
    assetClassCode: 'eq_au',
    assetId: null,
    assetTypeCode: 'ls',
    marketValue: '26.84',
    isNewAsset: false,
    isPanoramaAsset: false,
    positionCode: 'QAN',
    positionId: '8030712',
    positionName: 'Qantas Airways Limited',
    quantity: '4',
    source: 'LS - external',
    valuationDate: '2019-11-08T00:00:00.000+11:00'
  }
];

export const ASSET_LIST_ILS: ExternalAssetILS[] = [
  {
    assetClassCode: 'eq_intnl',
    assetTypeCode: 'ils',
    marketValue: '500',
    isNewAsset: false,
    isPanoramaAsset: false,
    positionCode: 'OPTCODE',
    positionId: '8049611',
    positionName: 'Test International Listed Security',
    quantity: '10',
    source: 'Source of Test International Listed Security',
    valuationDate: '2019-11-22T00:00:00.000+11:00'
  }
];

export const ASSET_LIST_MF: ExternalAssetMF[] = [
  {
    assetClassCode: 'realest_au',
    assetId: null,
    assetTypeCode: 'mf',
    marketValue: '10000',
    isNewAsset: false,
    isPanoramaAsset: false,
    positionCode: 'ARM1234HH',
    positionId: '8031835',
    positionName: 'Test ManagedFund',
    quantity: '5',
    source: 'Test Source- Managed FUnd',
    valuationDate: '2019-11-11T00:00:00.000+11:00'
  }
];

export const ASSET_LIST_MP: ExternalAssetMP[] = [
  {
    assetClassCode: 'dived',
    assetId: null,
    assetTypeCode: 'mp',
    marketValue: '13000',
    isNewAsset: false,
    isPanoramaAsset: false,
    positionCode: 'ARM9998MP',
    positionId: '8031837',
    positionName: 'Test-ManagedPortfolio',
    source: 'Test source-Managed Portfolio',
    valuationDate: '2019-11-22T00:00:00.000+11:00'
  }
];

export const ASSET_LIST_DP: ExternalAssetDP[] = [
  {
    assetClassCode: 'realest_au',
    assetTypeCode: 'dp',
    isNewAsset: false,
    isPanoramaAsset: false,
    marketValue: '1000',
    propertyType: 'RES',
    positionId: '8031839',
    positionName: '111 Parrammatta Road',
    valuationDate: '2019-06-30T00:00:00.000+10:00'
  }
];

export const ASSET_LIST_OTH: ExternalAssetOTH[] = [
  {
    assetClassCode: 'oth_invst',
    assetTypeCode: 'oth',
    marketValue: '10000',
    isNewAsset: false,
    isPanoramaAsset: false,
    positionCode: 'ARM1234HH',
    positionId: '8031841',
    positionName: 'Test - Other Asset',
    quantity: '10',
    source: 'Test source- Other Assets',
    valuationDate: '2019-11-11T00:00:00.000+11:00'
  }
];

export const EXTERNAL_ASSETS_DETAILS: ExternalAssetsValuationDetails = {
  totalValuation: 150,
  hasAssets: true,
  assets: {
    cash: [...ASSET_LIST_CASH],
    td: [...ASSET_LIST_TD],
    ls: [...ASSET_LIST_LS],
    ils: [...ASSET_LIST_ILS],
    mf: [...ASSET_LIST_MF],
    mp: [...ASSET_LIST_MP],
    dp: [...ASSET_LIST_DP],
    oth: [...ASSET_LIST_OTH]
  }
};

export const PANORAMA_ASSET_DETAILS: Asset[] = [
  {
    assetId: '163196',
    assetName: 'Magellan Infrastructure Fund (Unhedged)',
    assetCode: 'MGE0006AU',
    assetClass: 'Listed infrastructure',
    assetClassId: 'infra'
  },
  {
    assetId: '111227',
    assetName: 'Cromwell Phoenix Property Securities Fund',
    assetCode: 'CRM0008AU',
    assetClass: 'Australian property',
    assetClassId: 'realest_au'
  }
];

export const TEST_CASH_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('cash'),
    assetTypeCode: new FormControl('cash'),
    marketValue: new FormControl('300', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    isNewAsset: new FormControl(false),
    positionId: new FormControl('8004887'),
    positionName: new FormControl('test'),
    source: new FormControl('some option'),
    valuationDate: new FormControl(moment('2019-10-16T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ])
  })
]);

export const TEST_TD_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('cash'),
    assetTypeCode: new FormControl('td'),
    marketValue: new FormControl('300.5', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    isNewAsset: new FormControl(false),
    positionId: new FormControl('8015573'),
    positionName: new FormControl('test td'),
    source: new FormControl('some option td'),
    valuationDate: new FormControl(moment('2019-10-16T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ]),
    maturityDate: new FormControl(moment('2040-10-16T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ]),
    isMaturityDateChanged: new FormControl(false)
  })
]);

export const TEST_LS_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('eq_au'),
    assetTypeCode: new FormControl('ls'),
    marketValue: new FormControl('26.84', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    isNewAsset: new FormControl(false),
    positionId: new FormControl('8030712'),
    positionName: new FormControl('Qantas Airways Limited'),
    source: new FormControl('LS - external'),
    valuationDate: new FormControl(moment('2019-11-08T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ]),
    assetId: new FormControl(null),
    isPanoramaAsset: new FormControl(false),
    isLastPriceLoading: new FormControl(false),
    positionCode: new FormControl('QAN'),
    quantity: new FormControl('4', [Validators.required, Validators.min(1), Validators.pattern(/^[0-9]*$/)])
  })
]);

export const TEST_ILS_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('eq_intnl'),
    assetTypeCode: new FormControl('ils'),
    marketValue: new FormControl('500', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    isNewAsset: new FormControl(false),
    positionId: new FormControl('8049611'),
    positionName: new FormControl('Test International Listed Security'),
    source: new FormControl('Source of Test International Listed Security'),
    valuationDate: new FormControl(moment('2019-11-22T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ]),
    isPanoramaAsset: new FormControl(false),
    positionCode: new FormControl('OPTCODE'),
    quantity: new FormControl('10', [Validators.required, Validators.min(1), Validators.pattern(/^[0-9]*$/)])
  })
]);

export const TEST_MF_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('realest_au'),
    assetId: new FormControl(null),
    assetTypeCode: new FormControl('mf'),
    marketValue: new FormControl('10000', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    isNewAsset: new FormControl(false),
    positionId: new FormControl('8031835'),
    positionName: new FormControl('Test ManagedFund'),
    source: new FormControl('Test Source- Managed FUnd'),
    valuationDate: new FormControl(moment('2019-11-11T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ]),
    isPanoramaAsset: new FormControl(false),
    isLastPriceLoading: new FormControl(false),
    positionCode: new FormControl('ARM1234HH'),
    quantity: new FormControl('5', [Validators.required, Validators.min(1), Validators.pattern(/^\d+(?:\.\d{1,3})?$/)])
  })
]);

export const TEST_MP_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('dived'),
    assetId: new FormControl(null),
    assetTypeCode: new FormControl('mp'),
    marketValue: new FormControl('13000', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    isNewAsset: new FormControl(false),
    positionId: new FormControl('8031837'),
    positionName: new FormControl('Test-ManagedPortfolio'),
    source: new FormControl('Test source-Managed Portfolio'),
    valuationDate: new FormControl(moment('2019-11-22T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ]),
    isPanoramaAsset: new FormControl(false),
    positionCode: new FormControl('ARM9998MP')
  })
]);

export const TEST_DP_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('realest_au'),
    assetTypeCode: new FormControl('dp'),
    isNewAsset: new FormControl(false),
    isPanoramaAsset: new FormControl(false),
    marketValue: new FormControl('1000', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    positionId: new FormControl('8031839'),
    positionName: new FormControl('111 Parrammatta Road'),
    propertyType: new FormControl('RES'),
    valuationDate: new FormControl(moment('2019-06-30T00:00:00.000+10:00').tz('Australia/Sydney'), [
      Validators.required
    ])
  })
]);

export const TEST_OTH_ASSETS_FORM_ARRAY = new FormArray([
  new FormGroup({
    assetClassCode: new FormControl('oth_invst'),
    assetTypeCode: new FormControl('oth'),
    marketValue: new FormControl('10000', [
      Validators.required,
      Validators.min(0.01),
      Validators.max(99999999999.99),
      Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
    ]),
    isNewAsset: new FormControl(false),
    isPanoramaAsset: new FormControl(false),
    positionCode: new FormControl('ARM1234HH'),
    positionId: new FormControl('8031841'),
    positionName: new FormControl('Test - Other Asset'),
    quantity: new FormControl('10', [
      Validators.min(1),
      Validators.maxLength(15),
      Validators.pattern(/^\d+(?:\.\d{1,3})?$/)
    ]),
    source: new FormControl('Test source- Other Assets'),
    valuationDate: new FormControl(moment('2019-11-11T00:00:00.000+11:00').tz('Australia/Sydney'), [
      Validators.required
    ])
  })
]);

export const TEST_ASSET_TYPES = [
  {
    assetTypeCode: 'cash',
    assetTypeName: 'Cash',
    assetClasses: [
      {
        assetClassCode: 'cash',
        assetClassName: 'Cash'
      }
    ]
  },
  {
    assetTypeCode: 'td',
    assetTypeName: 'Term deposit',
    assetClasses: [
      {
        assetClassCode: 'cash',
        assetClassName: 'Cash'
      }
    ]
  },
  {
    assetTypeCode: 'ls',
    assetTypeName: 'Australian shares or ETFs',
    assetClasses: [
      {
        assetClassCode: 'cash',
        assetClassName: 'Cash'
      },
      {
        assetClassCode: 'fi_au',
        assetClassName: 'Australian fixed interest'
      }
    ]
  },
  {
    assetTypeCode: 'ils',
    assetTypeName: 'International shares',
    assetClasses: [
      {
        assetClassCode: 'cash',
        assetClassName: 'Cash'
      },
      {
        assetClassCode: 'fi_au',
        assetClassName: 'Australian fixed interest'
      },
      {
        assetClassCode: 'fi_intnl',
        assetClassName: 'International fixed interest'
      }
    ]
  },
  {
    assetTypeCode: 'mf',
    assetTypeName: 'Managed fund',
    assetClasses: [
      {
        assetClassCode: 'cash',
        assetClassName: 'Cash'
      },
      {
        assetClassCode: 'fi_au',
        assetClassName: 'Australian fixed interest'
      },
      {
        assetClassCode: 'fi_intnl',
        assetClassName: 'International fixed interest'
      }
    ]
  },
  {
    assetTypeCode: 'mp',
    assetTypeName: 'Managed portfolio',
    assetClasses: [
      {
        assetClassCode: 'cash',
        assetClassName: 'Cash'
      },
      {
        assetClassCode: 'fi_au',
        assetClassName: 'Australian fixed interest'
      },
      {
        assetClassCode: 'fi_intnl',
        assetClassName: 'International fixed interest'
      }
    ]
  },
  {
    assetTypeCode: 'dp',
    assetTypeName: 'Direct property',
    assetClasses: [
      {
        assetClassCode: 'realest_au',
        assetClassName: 'Australian property'
      },
      {
        assetClassCode: 'realest_intnl',
        assetClassName: 'International property'
      }
    ]
  },
  {
    assetTypeCode: 'oth',
    assetTypeName: 'Other',
    assetClasses: [
      {
        assetClassCode: 'cash',
        assetClassName: 'Cash'
      },
      {
        assetClassCode: 'fi_au',
        assetClassName: 'Australian fixed interest'
      }
    ]
  }
];

export const TEST_DP_PROPERTY_TYPES = [
  {
    propertyTypeCode: 'COMM',
    propertyTypeName: 'Commercial property'
  },
  {
    propertyTypeCode: 'RES',
    propertyTypeName: 'Residential property'
  }
];

export const TEST_ADD_EXTERNAL_FORM = new FormGroup({
  assetTypeCode: new FormControl('')
});

export const TEST_ADD_CASH_EXTERNAL_FORM = new FormGroup({
  assetClassCode: new FormControl('cash'),
  assetTypeCode: new FormControl('cash'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required])
});

export const TEST_ADD_TD_EXTERNAL_FORM = new FormGroup({
  assetClassCode: new FormControl('cash'),
  assetTypeCode: new FormControl('td'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  maturityDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required]),
  isNewAsset: new FormControl(true),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required])
});

export const TEST_ADD_LS_EXTERNAL_FORM = new FormGroup({
  assetTypeCode: new FormControl('ls'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  isNewAsset: new FormControl(true),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required]),
  positionCode: new FormControl(null, [
    Validators.required,
    Validators.maxLength(9),
    alphaNumericValidator(),
    assetCodeValidator()
  ]),
  quantity: new FormControl(null, [Validators.required, Validators.min(1), Validators.pattern(/^[0-9]*$/)]),
  assetClassCode: new FormControl(null, [Validators.required]),
  panoramaAssetDetails: new FormControl(null, [Validators.required, assetSelectedValidator]),
  assetId: new FormControl(null),
  isPanoramaAsset: new FormControl(false)
});

export const TEST_ADD_ILS_EXTERNAL_FORM = new FormGroup({
  assetTypeCode: new FormControl('ils'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  isNewAsset: new FormControl(true),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required]),
  positionCode: new FormControl(null, Validators.maxLength(12)),
  quantity: new FormControl(null, [Validators.required, Validators.min(1), Validators.pattern(/^[0-9]*$/)]),
  assetClassCode: new FormControl(null, [Validators.required])
});

export const TEST_ADD_MF_EXTERNAL_FORM = new FormGroup({
  assetTypeCode: new FormControl('mf'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  isNewAsset: new FormControl(true),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required]),
  positionCode: new FormControl(null, [
    Validators.required,
    Validators.maxLength(9),
    alphaNumericValidator(),
    assetCodeValidator()
  ]),
  quantity: new FormControl(null, [Validators.required, Validators.min(1), Validators.pattern(/^[0-9]*$/)]),
  assetClassCode: new FormControl(null, [Validators.required]),
  panoramaAssetDetails: new FormControl(null, [Validators.required, assetSelectedValidator]),
  assetId: new FormControl(null),
  isPanoramaAsset: new FormControl(false)
});

export const TEST_ADD_MP_EXTERNAL_FORM = new FormGroup({
  assetTypeCode: new FormControl('mp'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  isNewAsset: new FormControl(true),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required]),
  positionCode: new FormControl(null, [
    Validators.required,
    Validators.maxLength(9),
    alphaNumericValidator(),
    assetCodeValidator()
  ]),
  assetClassCode: new FormControl(null, [Validators.required])
});

export const TEST_ADD_DP_EXTERNAL_FORM = new FormGroup({
  assetClassCode: new FormControl('realest_au'),
  assetTypeCode: new FormControl('dp'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required]),
  propertyType: new FormControl('RES', [Validators.required])
});

export const TEST_ADD_OTH_EXTERNAL_FORM = new FormGroup({
  assetTypeCode: new FormControl('oth'),
  marketValue: new FormControl(null, [
    Validators.required,
    Validators.maxLength(15),
    Validators.min(0.01),
    Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
  ]),
  isNewAsset: new FormControl(true),
  positionName: new FormControl(null, [Validators.required, Validators.maxLength(200)]),
  source: new FormControl(null, [Validators.maxLength(120)]),
  valuationDate: new FormControl(moment().tz('Australia/Sydney'), [Validators.required]),
  positionCode: new FormControl(null, Validators.maxLength(12)),
  quantity: new FormControl(null, [Validators.min(1), Validators.maxLength(15), Validators.pattern(/^[0-9]*$/)]),
  assetClassCode: new FormControl(null, [Validators.required])
});

export const SOFTWARE_STATUS_DATA_CONNECTED: AccountingSoftwareStatus = {
  status: SOFTWARE_STATUS.RECEIVED,
  softwareName: SOFTWARE_NAME.BGL_SF360
};

export const SOFTWARE_STATUS_DATA_PENDING: AccountingSoftwareStatus = {
  status: SOFTWARE_STATUS.AWAITING
};

export const SOFTWARE_STATUS_DATA_MANUAL: AccountingSoftwareStatus = {
  status: SOFTWARE_STATUS.MANUAL
};

export const SOFTWARE_STATUS_DATA_REQUESTED: AccountingSoftwareStatus = {
  status: SOFTWARE_STATUS.REQUESTED
};

export const ASSET_TOTAL_VALUATION: ExternalAssetTotalValuation = {
  totalValuation: 1234
};

export const SOFTWARE_DATA_PENDING_STATE: SoftwareData = {
  softwareStatus: SOFTWARE_STATUS_DATA_PENDING,
  screenType: SCREEN_TYPE.PENDING
};

export const SOFTWARE_DATA_CONNECTED_STATE: SoftwareData = {
  softwareStatus: SOFTWARE_STATUS_DATA_CONNECTED,
  screenType: SCREEN_TYPE.CONNECTED,
  valuation: ASSET_TOTAL_VALUATION
};

export const SOFTWARE_DATA_MANUAL_STATE: SoftwareData = {
  softwareStatus: SOFTWARE_STATUS_DATA_MANUAL,
  screenType: SCREEN_TYPE.MANUAL
};

export const SOFTWARE_DATA_MANUAL_REQUESTED_STATE: SoftwareData = {
  softwareStatus: SOFTWARE_STATUS_DATA_REQUESTED,
  screenType: SCREEN_TYPE.MANUAL
};

export const ASSET_PRICE_VALUATION_DETAILS: AssetLatestPrice = {
  lastPrice: 30,
  valuationDate: '2019-10-11T00:00:00.000+10:00'
};
