export const WGP_OPEN_URL: string =
  'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates.html#new_member_info';
export const WGP_COHORT_URL: string =
  'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-{cohort}.html#new_member_info';
export const EY_URL: string = 'https://www.bt.com.au/ey.html#new_member_info';

export const OPEN: string = 'OPEN';
