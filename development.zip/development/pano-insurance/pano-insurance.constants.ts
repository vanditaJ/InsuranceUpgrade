import { HttpHeaders } from '@angular/common/http';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Loading } from '@bt/components/loading';
import { Optionals } from '@bt/services/data';

export const REVIEW_FORM_BUTTON: Button = {
  type: 'solid',
  label: 'Review',
  size: 'large',
  action: 'submit',
  colourModifier: 'primary'
};

export const SUBMIT_FORM_BUTTON: Button = {
  type: 'solid',
  label: 'Submit',
  size: 'large',
  action: 'submit',
  disableInEmulationMode: true,
  colourModifier: 'primary'
};

export const CHANGE_FORM_BUTTON: Button = {
  type: 'outline',
  label: 'Change',
  size: 'small',
  action: 'button',
  icon: {
    name: 'icon-arrow-left'
  },
  iconPosition: 'left',
  colourModifier: 'basic'
};

export const CANCEL_FORM_BUTTON: Button = {
  type: 'outline',
  label: 'Cancel',
  size: 'large',
  action: 'button',
  colourModifier: 'primary'
};

export const RETURN_INSURANCE_OVERVIEW_BUTTON: Button = {
  type: 'solid',
  label: 'Return to Insurance overview',
  size: 'large',
  action: 'button',
  colourModifier: 'primary'
};

export const GENERIC_ERROR_ALERT: Alert = {
  type: 'error',
  messages: 'We seem to be having some technical difficulties. Please reload this page or try again later.',
  outline: true,
  showCodes: false
};

export const OUTLINE_INFO_ALERT: Alert = { type: 'info', outline: true, a11yProps: { ariaRole: 'none' } };

export const OUTLINE_WARNING_ALERT: Alert = { type: 'warning', outline: true, a11yProps: { ariaRole: 'none' } };

export const SPINNER: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const COVER_LEVEL = {
  Single: 'Single',
  Double: 'Double',
  Triple: 'Triple'
};

export const RETAIL = 'Retail';

export const STANDARD_COVER = 'Standard cover';

export const ESSENTIAL_COVER: string = 'Essential cover';

export const TAILORED_COVER: string = 'Tailored cover';

export const SUBMIT_INSURANCE_OPTIONALS: Optionals = {
  httpOptions: {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }
};

export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0344' };

export const GENERIC_CACHE_OPTIONS: Optionals = {
  errorCode: 'Err.IP-0344',
  cacheOptions: {
    cacheInterval: Number.MAX_SAFE_INTEGER,
    refreshCache: false
  }
};

export const CMS_CONTEXT_PATH = '/content/secure/panorama/_services/super-insurance/';

export const CUSTOMER_TYPE_BT_SUPER: string = 'PCS';

export const CUSTOMER_TYPE_BT_SUPER_LIFETIME: string = 'BT Super - Retail';

export const CUSTOMER_TYPE_BT_SFL: string = 'Retail';

export const CUSTOMER_TYPE_WGP: string = 'Staff (WGP)';

export const PRODUCT = {
  BT_SUPER: 'BT Super',
  BT_SUPER_FOR_LIFE: 'BT Super for Life'
};

export const PYS_DETAILS: string = 'pysDetails';

export const PMIF_DETAILS: string = 'pmifDetails';
