import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { DateAdapter } from '@angular/material/core';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { IconModule } from '@bt/components/icon';
import { LinkModule } from '@bt/components/link';
import { LoadingModule } from '@bt/components/loading';
import { SnackBarTemplateModule } from '@bt/components/snack-bar-template';
import { ClearInputDirectiveModule } from '@bt/directives/clear-input';
import { DecimalPlaceDirectiveModule } from '@bt/directives/decimal-place';
import { EntitlementDirectiveModule } from '@bt/directives/entitlement';
import { ToggleClassByBreakpointDirectiveModule } from '@bt/directives/toggle-class-by-breakpoint';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { TextHighlightPipeModule } from '@bt/pipes/text-highlight';
import { DataModule } from '@bt/services/data';
import { panoEntitlementsResolver } from '@investor/account/pano-shared/resolvers';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';
import { NgxMaskModule } from 'ngx-mask';
import { NgxPageScrollCoreModule } from 'ngx-page-scroll-core';

import { PanoAddAssetCashComponent } from './pano-add-asset/pano-add-asset-cash/pano-add-asset-cash.component';
import { PanoAddAssetDirectPropertyComponent } from './pano-add-asset/pano-add-asset-direct-property/pano-add-asset-direct-property.component';
import { PanoAddAssetFormCreator } from './pano-add-asset/pano-add-asset-form-creator';
import { PanoAddAssetIntListedSecurityComponent } from './pano-add-asset/pano-add-asset-int-listed-security/pano-add-asset-int-listed-security.component';
import { PanoAddAssetListedSecurityComponent } from './pano-add-asset/pano-add-asset-listed-security/pano-add-asset-listed-security.component';
import { PanoAddAssetManagedFundComponent } from './pano-add-asset/pano-add-asset-managed-fund/pano-add-asset-managed-fund.component';
import { PanoAddAssetManagedPortfolioComponent } from './pano-add-asset/pano-add-asset-managed-portfolio/pano-add-asset-managed-portfolio.component';
import { PanoAddAssetOtherComponent } from './pano-add-asset/pano-add-asset-other/pano-add-asset-other.component';
import { PanoAddAssetTermDepositComponent } from './pano-add-asset/pano-add-asset-term-deposit/pano-add-asset-term-deposit.component';
import { PanoAddAssetComponent } from './pano-add-asset/pano-add-asset.component';
import { PanoAlertDialogComponent } from './pano-alert-dialog/pano-alert-dialog.component';
import { PanoConfirmDialogComponent } from './pano-confirm-dialog/pano-confirm-dialog.component';
import { PanoExternalAssetsCashComponent } from './pano-external-assets-cash/pano-external-assets-cash.component';
import { PanoExternalAssetsCommonUtil } from './pano-external-assets-common.util';
import { PanoExternalAssetsConnectedComponent } from './pano-external-assets-connected/pano-external-assets-connected.component';
import { PanoExternalAssetsConnectionPendingComponent } from './pano-external-assets-connection-pending/pano-external-assets-connection-pending.component';
import { PanoExternalAssetsDirectPropertyComponent } from './pano-external-assets-direct-property/pano-external-assets-direct-property.component';
import { PanoExternalAssetsFormCreator } from './pano-external-assets-form-creator';
import { PanoExternalAssetsInternationalListedSecurityComponent } from './pano-external-assets-international-listed-security/pano-external-assets-international-listed-security.component';
import { PanoExternalAssetsListedSecurityComponent } from './pano-external-assets-listed-security/pano-external-assets-listed-security.component';
import { PanoExternalAssetsManagedFundComponent } from './pano-external-assets-managed-fund/pano-external-assets-managed-fund.component';
import { PanoExternalAssetsManagedPortfolioComponent } from './pano-external-assets-managed-portfolio/pano-external-assets-managed-portfolio.component';
import { PanoExternalAssetsOtherComponent } from './pano-external-assets-other/pano-external-assets-other.component';
import { PanoExternalAssetsTermDepositComponent } from './pano-external-assets-term-deposit/pano-external-assets-term-deposit.component';
import { PanoExternalAssetsComponent } from './pano-external-assets.component';
import { MODULE_NAME } from './pano-external-assets.constants';
import { panoExternalStateResolver } from './pano-external-assets.resolver';
import { PanoExternalAssetsService } from './pano-external-assets.service';

export const PANO_DATE_FORMATS = {
  parse: {
    dateInput: 'DD MMM YYYY'
  },
  display: {
    dateInput: 'DD MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

export function panoExternalAssetEntitlementsResolver($transition$) {
  return panoEntitlementsResolver($transition$, MODULE_NAME);
}

@NgModule({
  declarations: [
    PanoAddAssetCashComponent,
    PanoAddAssetComponent,
    PanoAddAssetDirectPropertyComponent,
    PanoAddAssetIntListedSecurityComponent,
    PanoAddAssetListedSecurityComponent,
    PanoAddAssetManagedFundComponent,
    PanoAddAssetManagedPortfolioComponent,
    PanoAddAssetOtherComponent,
    PanoAddAssetTermDepositComponent,
    PanoAlertDialogComponent,
    PanoConfirmDialogComponent,
    PanoExternalAssetsCashComponent,
    PanoExternalAssetsComponent,
    PanoExternalAssetsDirectPropertyComponent,
    PanoExternalAssetsInternationalListedSecurityComponent,
    PanoExternalAssetsListedSecurityComponent,
    PanoExternalAssetsManagedFundComponent,
    PanoExternalAssetsManagedPortfolioComponent,
    PanoExternalAssetsTermDepositComponent,
    PanoExternalAssetsOtherComponent,
    PanoExternalAssetsTermDepositComponent,
    PanoExternalAssetsConnectedComponent,
    PanoExternalAssetsConnectionPendingComponent
  ],
  providers: [
    PanoExternalAssetsService,
    PanoExternalAssetsCommonUtil,
    PanoExternalAssetsFormCreator,
    PanoAddAssetFormCreator,
    { provide: MAT_DATE_FORMATS, useValue: PANO_DATE_FORMATS },
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] }
  ],
  entryComponents: [PanoExternalAssetsComponent, PanoConfirmDialogComponent, PanoAlertDialogComponent],
  imports: [
    AlertModule,
    ButtonModule,
    ClearInputDirectiveModule,
    CommonModule,
    CopyMatrixPipeModule,
    DecimalPlaceDirectiveModule,
    DataModule,
    EntitlementDirectiveModule,
    HttpClientModule,
    IconModule,
    LayoutModule,
    LinkModule,
    LoadingModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    NgxMaskModule.forRoot({}),
    NgxPageScrollCoreModule.forRoot({}),
    ReactiveFormsModule,
    ToggleClassByBreakpointDirectiveModule,
    SnackBarTemplateModule,
    TextHighlightPipeModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.externalAssets',
          url: '/pano-external-assets',
          component: PanoExternalAssetsComponent,
          data: {
            requiredPermissions: {
              rule: 'account.portfolio.externalassets.viewng',
              targetId: 'a'
            },
            title: 'External assets'
          },
          resolve: {
            softwareData: ['$transition$', panoExternalStateResolver],
            entitlements: ['$transition$', panoExternalAssetEntitlementsResolver]
          }
        }
      ]
    })
  ],
  exports: [IconModule]
})
export class PanoExternalAssetsModule {}
