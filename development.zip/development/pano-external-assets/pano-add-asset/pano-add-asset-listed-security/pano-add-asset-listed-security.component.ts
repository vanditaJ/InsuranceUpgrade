import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { Loading } from '@bt/components/loading';
import { drop, escapeRegExp, isEqual, join, some, split, startsWith, times, trim } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators';

import { PanoExternalAssetsCommonUtil } from '../../pano-external-assets-common.util';
import {
  ARROW_RIGHT_ICON,
  CONTENT_LOADING,
  DATE_PICKER_ICON,
  DEBOUNCE_TIME,
  EXIT_MANUAL_BUTTON,
  MAGNIFY_ICON,
  MANUAL_OPTIONS
} from '../../pano-external-assets-constants/pano-external-assets.constants';
import { Asset, AssetClasses, AssetLatestPrice } from '../../pano-external-assets.interfaces';
import { PanoExternalAssetsService } from '../../pano-external-assets.service';
import { PanoAddAssetFormCreator } from '../pano-add-asset-form-creator';

@Component({
  selector: 'pano-add-asset-listed-security',
  templateUrl: './pano-add-asset-listed-security.component.html'
})
export class PanoAddAssetListedSecurityComponent implements OnInit, OnDestroy {
  @Input() addAssetForm: FormGroup;
  @Input() assetClasses: AssetClasses[];

  @Output()
  showButtons: EventEmitter<boolean> = new EventEmitter();

  assetDetails: FormGroup;
  assets: Asset[];
  assetSelected: boolean = false;
  filteredAssets: Asset[];
  latestPrice: AssetLatestPrice;
  filteredValue: string;
  manualMode: boolean = false;
  manualEntry: Array<string> = MANUAL_OPTIONS;
  assetsLoading: boolean = true;
  isUserTyping: boolean = false;
  assetCodeFound: boolean = false;

  arrowRightIcon: Icon = ARROW_RIGHT_ICON;
  magnifyIcon: Icon = MAGNIFY_ICON;
  datePickerIcon: Icon = DATE_PICKER_ICON;
  today: Date = moment().tz('Australia/Sydney');
  exitManualButton: Button = EXIT_MANUAL_BUTTON;
  loadingSpinner: Loading = CONTENT_LOADING;

  private assetsSubscription: Subscription = of(null).subscribe();
  private assetDetailsSubscription: Subscription = of(null).subscribe();
  private latestPriceSubscription: Subscription = of(null).subscribe();
  private quantitySubscription: Subscription = of(null).subscribe();
  private assetCodeSubscription: Subscription = of(null).subscribe();

  constructor(
    private externalAssetService: PanoExternalAssetsService,
    private externalAssetsAddFormCreator: PanoAddAssetFormCreator,
    private panoExternalAssetsCommonUtil: PanoExternalAssetsCommonUtil
  ) {}

  ngOnInit(): void {
    this.showButtons.emit(false);
    this.assetDetails = this.externalAssetsAddFormCreator.createAddAssetForm('ls');
    this.addAssetForm.setControl('assetDetails', this.assetDetails);

    this.assetsSubscription = this.externalAssetService
      .getPanoramaAssetDetails('ls')
      .pipe(finalize(() => this.showButtons.emit(true)))
      .subscribe((result: Asset[]) => {
        this.assets = result;
        this.assetsLoading = false;
      });

    this.assetDetailsSubscription = this.assetDetails.controls['panoramaAssetDetails'].valueChanges
      .pipe(
        tap(() => (this.isUserTyping = true)),
        debounceTime(DEBOUNCE_TIME),
        distinctUntilChanged()
      )
      .subscribe(query => {
        this.isUserTyping = false;
        /* istanbul ignore else*/
        if (query && query.length > 1) {
          this.assetSelected = false;
          const assets = this.filterAssets(query);
          this.filteredAssets = assets.length ? assets : null;
        } else if (!query || query.length === 1) {
          this.assetSelected = false;
          this.filteredAssets = null;
        }
      });

    this.quantitySubscription = this.assetDetails.controls['quantity'].valueChanges.subscribe(() => {
      if (!this.manualMode) {
        this.calculateTotalMarketValue();
      }
    });

    this.assetCodeSubscription = this.assetDetails.controls['positionCode'].valueChanges.subscribe(value => {
      if (this.manualMode) {
        if (
          some(this.assets, asset =>
            asset.assetCode && value ? asset.assetCode.toLowerCase() === value.toLowerCase() : false
          )
        ) {
          this.assetCodeFound = true;
          this.assetDetails.controls['positionCode'].setErrors({ assetCodeFound: true });
        } else {
          this.assetCodeFound = false;
        }
      }
    });
  }

  ngOnDestroy(): void {
    this.assetsSubscription.unsubscribe();
    this.assetDetailsSubscription.unsubscribe();
    this.latestPriceSubscription.unsubscribe();
    this.quantitySubscription.unsubscribe();
    this.assetCodeSubscription.unsubscribe();
  }

  displayAsset(selectedAsset?: Asset): string {
    return selectedAsset ? `${selectedAsset.assetCode} • ${selectedAsset.assetName}` : '';
  }

  selectAsset(selectedAsset: Asset): void {
    if (selectedAsset) {
      this.assetSelected = true;
      this.filteredAssets = null;
      this.latestPrice = null;
      this.externalAssetsAddFormCreator.reAssignValidatorsForMarketValueAndValuationDate(this.assetDetails, false);
      this.assetDetails.controls['isPanoramaAsset'].setValue(true);
      this.assetDetails.controls['assetId'].setValue(selectedAsset.assetId);
      this.assetDetails.controls['positionName'].setValue(selectedAsset.assetName);
      this.assetDetails.controls['positionCode'].setValue(selectedAsset.assetCode);
      this.assetDetails.controls['assetClassCode'].setValue(selectedAsset.assetClassId);
      this.latestPriceSubscription = this.externalAssetService.getAssetLatestPrice(selectedAsset.assetId).subscribe(
        (result: AssetLatestPrice) => {
          this.latestPrice = result;
          this.assetDetails.controls['valuationDate'].setValue(this.latestPrice.valuationDate);
          this.calculateTotalMarketValue();
        },
        () => {
          this.assetDetails.controls['marketValue'].setValue('');
          this.assetDetails.controls['valuationDate'].setValue('');
        }
      );
    } else {
      this.manualMode = true;
      this.assetDetails.reset();
      this.assetDetails.markAsUntouched();
      this.externalAssetsAddFormCreator.reAssignValidatorsForPanoramaAssetDetails(this.assetDetails, false);
      this.externalAssetsAddFormCreator.reAssignValidatorsForMarketValueAndValuationDate(this.assetDetails, true);
      this.assetDetails.controls['isPanoramaAsset'].setValue(false);
      this.assetDetails.controls['valuationDate'].setValue(this.today);
    }
  }

  filterAssets(query: string): Asset[] {
    this.filteredValue = escapeRegExp(trim(query.toLowerCase(), ' •'));
    const queryArray = [
      this.filteredValue.substr(0, this.filteredValue.indexOf(' ')),
      trim(this.filteredValue.substr(this.filteredValue.indexOf(' ') + 1), ' •')
    ];
    return this.assets.filter(filteredAsset => {
      let assetName = filteredAsset.assetName;
      let assetCode = filteredAsset.assetCode;
      if (assetName && assetCode) {
        assetName = escapeRegExp(assetName.toLowerCase());
        assetCode = escapeRegExp(assetCode.toLowerCase());

        if (assetCode === queryArray[0] && queryArray[1] !== '') {
          return startsWith(assetCode, queryArray[0]) && startsWith(assetName, queryArray[1]);
        }

        const name = split(assetName, ' ');
        const checkAssetName = times(name.length, n => startsWith(join(drop(name, n), ' '), this.filteredValue));

        return startsWith(assetCode, this.filteredValue) || some(checkAssetName, result => isEqual(result, true));
      } else {
        return false;
      }
    });
  }

  calculateTotalMarketValue(): void {
    const totalMarketValue =
      this.assetDetails.controls['quantity'].valid && this.assetSelected && this.latestPrice
        ? (this.latestPrice.lastPrice * this.assetDetails.controls['quantity'].value).toFixed(2)
        : null;
    this.assetDetails.controls['marketValue'].setValue(totalMarketValue);
  }

  formatDateForDisplay(dateToFormat: string): string {
    return moment(dateToFormat)
      .tz('Australia/Sydney')
      .format('DD MMM YYYY');
  }

  turnManualModeOff(): void {
    this.manualMode = false;
    this.assetDetails.reset();
    this.assetDetails.markAsUntouched();
    this.externalAssetsAddFormCreator.reAssignValidatorsForPanoramaAssetDetails(this.assetDetails, true);
  }

  getErrorMessagesForQuantity(quantityControl: FormControl): string {
    return this.panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
  }
}
