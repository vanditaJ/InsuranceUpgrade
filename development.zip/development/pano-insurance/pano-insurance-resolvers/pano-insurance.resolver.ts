import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { InsurancePolicy } from '../pano-insurance.interface';
import { PanoInsuranceService } from '../pano-insurance.service';

export function panoInsurancePolicyResolver($transition$): Promise<InsurancePolicy[]> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const panoInsuranceService = $transition$.injector().get(PanoInsuranceService);
  return panoInsuranceService.getPolicies(accountService.getAccountId()).toPromise();
}
