import { Link } from '@bt/components/link';

export interface Tile {
  heading: string;
  description: string;
  link: Link;
}
