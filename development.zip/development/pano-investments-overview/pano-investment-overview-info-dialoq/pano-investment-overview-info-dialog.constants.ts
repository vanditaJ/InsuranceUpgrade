import { Button } from '@bt/components/button';

export const EXIT_DIALOG_BUTTON: Button = {
  action: 'button',
  icon: { name: 'icon-cross' },
  size: 'small',
  colourModifier: 'basic'
};

export const CLOSE_DIALOG_BUTTON: Button = {
  action: 'button',
  label: 'Close',
  type: 'outline',
  size: 'large',
  colourModifier: 'primary'
};
