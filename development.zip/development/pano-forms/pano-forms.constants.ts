import { Button } from '@bt/components/button';
import { ServiceRequestsConfig } from '@panorama/service-requests';

export const SERVICE_REQUESTS_CONFIGS: Partial<ServiceRequestsConfig> = {
  description:
    'This page displays the forms you have submitted for this account. (There may be a 1-day delay before a form is displayed.) Dates indicate when a form was received by BT and when it is expected to be fulfilled. Status will show as either ‘Complete’, ‘In progress’ or ‘Attention required’. Any outstanding information may cause delays in completing a request by the expected due date.',
  srNumberPrefix: 'Ref # ',
  experice: 'investor',
  features: {
    sort: true
  }
};

export const GO_TO_DOCUMENT_LIBRARY_BUTTON: Button = {
  icon: { name: 'icon-chevron-right-circle-solid' },
  label: 'Go to Document Library',
  size: 'small',
  colourModifier: 'primary',
  type: 'flat',
  action: 'button',
  iconPosition: 'left'
};

export const DOCUMENT_LIBRARY_MODULE_NAME: string = 'app.investor.account.documentLibrary';
