import { Link } from '@bt/components/link';

export enum LinkType {
  PRODUCT_DISCLOSURE_STATEMENT = 'PRODUCT_DISCLOSURE_STATEMENT'
}

export type UrlCategory =
  | 'PERSONAL_SUPER'
  | 'CORPORATE_SUPER'
  | 'CORPORATE_SUPER_LIFETIME'
  | 'WGP_OPEN'
  | 'WGP_COHORT'
  | 'EY'
  | 'GENWORTH'
  | 'RUSSELL_REYNOLDS'
  | 'DEFAULT';

const PRODUCT_DISCLOSURE_STATEMENT_URLS: Record<string, string> = {
  CORPORATE_SUPER_LIFETIME: 'https://www.bt.com.au/personal/help/pds.html#super-employer',
  CORPORATE_SUPER: 'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html#employer_super_pds',
  PERSONAL_SUPER: 'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html#personal_super_pds',
  WGP_OPEN: 'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates.html#new_member_info',
  WGP_COHORT:
    'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-{cohort}.html#new_member_info',
  EY: 'https://www.bt.com.au/ey.html#new_member_info',
  GENWORTH: 'https://www.bt.com.au/genworth.html',
  RUSSELL_REYNOLDS: 'https://www.bt.com.au/russell-reynolds.html',
  DEFAULT: 'https://www.bt.com.au/personal/help/pds.html#super-employer'
};

const EXTERNAL_LINK_ANNOUNCEMENT: string = 'open in new tab.';

const PRODUCT_DISCLOSURE_STATEMENT_LINK: Link = {
  isLinkExternal: true,
  label: 'Product disclosure statement',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: 'Product Disclosure Statement, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

interface DynamicLink {
  link: Link;
  urlMap: Record<string, string>;
}

export const DYNAMIC_LINKS: Record<LinkType, DynamicLink> = {
  [LinkType.PRODUCT_DISCLOSURE_STATEMENT]: {
    urlMap: PRODUCT_DISCLOSURE_STATEMENT_URLS,
    link: PRODUCT_DISCLOSURE_STATEMENT_LINK
  }
};

export const INSURER_CODE = [
  {
    type: 'EY',
    name: 'Ernst & Young'
  },
  {
    type: 'GENWORTH',
    name: 'Genworth'
  },
  {
    type: 'RUSSELL_REYNOLDS',
    name: 'Russell Reynolds'
  }
];
