import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { PanoInvestmentProfileModule } from './components/pano-inv-profile/pano-inv-profile.module';
import { PanoDisclaimersService } from './services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from './services/pano-super-link/pano-super-link.service';

@NgModule({
  declarations: [],
  imports: [CommonModule, PanoInvestmentProfileModule],
  providers: [PanoDisclaimersService, PanoSuperLinkService]
})
export class PanoSharedModule {}
