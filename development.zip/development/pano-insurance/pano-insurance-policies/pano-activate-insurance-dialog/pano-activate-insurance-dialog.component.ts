import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { finalize } from 'rxjs/operators';

import { GENERIC_ERROR_ALERT } from '../../pano-insurance.constants';
import { PanoInsuranceService } from '../../pano-insurance.service';
import { OPT_IN_STATUS } from '../pano-insurance-policies.constants';

import { CANCEL_BUTTON, CLOSE_ICON, SUBMIT_BUTTON } from './pano-activate-insurance-dialog.constants';

@Component({
  selector: 'pano-activate-insurance-dialog',
  templateUrl: './pano-activate-insurance-dialog.component.html'
})
export class PanoActivateInsuranceDialogComponent implements OnInit {
  termsAndConditions: FormGroup;
  error: boolean = false;
  submitting: boolean = false;

  readonly submitButton: Button = SUBMIT_BUTTON;
  readonly cancelButton: Button = CANCEL_BUTTON;
  readonly closeIcon: Button = CLOSE_ICON;
  readonly errorAlert: Alert = GENERIC_ERROR_ALERT;

  constructor(
    readonly dialogRef: MatDialogRef<PanoActivateInsuranceDialogComponent>,
    private readonly formBuilder: FormBuilder,
    private readonly panoInsuranceService: PanoInsuranceService,
    @Inject(MAT_DIALOG_DATA)
    public readonly data: {
      accountId: string;
      optInToPmif: boolean;
      optInToPys: boolean;
      showStandardCoverGreaterThan30DaysText: boolean;
    }
  ) {}

  ngOnInit(): void {
    this.termsAndConditions = this.formBuilder.group({
      acknowledge: ['', [Validators.requiredTrue]]
    });
  }

  submit(): void {
    const optIn = this.data.optInToPmif || this.data.optInToPys;
    if (optIn && this.termsAndConditions.valid) {
      this.submitting = true;
      this.error = false;
      this.termsAndConditions.get('acknowledge').disable();

      if (this.data.optInToPmif && this.data.optInToPys) {
        this.optInPmifAndPys();
      } else if (this.data.optInToPmif) {
        this.optInPmif();
      } else {
        this.optInPys();
      }
    }
  }

  optInPmifAndPys(): void {
    this.panoInsuranceService.submitPmifOptInRequest(this.data.accountId).subscribe(
      () => {
        // PMIF opt in success - attempt PYS opt-in - display success regardless of outcome
        this.panoInsuranceService
          .submitPysOptInRequest(this.data.accountId, [])
          .pipe(
            finalize(() => {
              this.finish(true);
            })
          )
          .subscribe(
            () => {
              this.closeDialog(OPT_IN_STATUS.success);
            },
            () => {
              this.closeDialog(OPT_IN_STATUS.pysFail);
            }
          );
      },
      () => {
        // PMIF opt in error - don't attempt PYS opt-in - display error in modal
        this.finish(false);
      }
    );
  }

  optInPmif(): void {
    this.panoInsuranceService.submitPmifOptInRequest(this.data.accountId).subscribe(
      () => {
        this.closeDialog(OPT_IN_STATUS.pmifActivated);
      },
      () => {
        this.finish(false);
      }
    );
  }

  optInPys(): void {
    // Not implemented - see standalone PYS opt-in dialog instead (pano-pys-optin-all)
    this.finish(true);
    this.closeDialog(OPT_IN_STATUS.success);
  }

  finish(success: boolean): void {
    this.submitting = false;
    this.error = !success;
    this.termsAndConditions.get('acknowledge').enable();
  }

  closeDialog(status: string): void {
    this.dialogRef.close(status);
  }
}
