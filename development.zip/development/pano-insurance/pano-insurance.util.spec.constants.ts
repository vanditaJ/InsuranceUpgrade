import { Account } from '@investor/account/pano-shared/interfaces';

import { PolicyStatus, PolicyType } from './pano-insurance.interface';
import { InsurancePolicy } from './pano-insurance.interface';

export const MOCK_ACCOUNTS: Account[] = [
  {
    key: {
      accountId: ''
    },
    accountNumber: '1234',
    accountName: '',
    firstMoneyReceivedDate: '2021-01-12T14:00:00.000Z',
    owners: [
      {
        age: 30,
        dateOfBirth: '1990-07-22',
        emails: [],
        firstName: 'Name',
        gender: 'Male',
        lastName: 'LastName'
      }
    ],
    pdsStatus: 'DEFAULT',
    product: {}
  },
  {
    key: {
      accountId: ''
    },
    accountNumber: '1234',
    accountName: '',
    firstMoneyReceivedDate: '2020-04-22T14:00:00.000Z',
    owners: [
      {
        age: 20,
        dateOfBirth: '2000-07-22',
        emails: [],
        firstName: 'Name',
        gender: 'Male',
        lastName: 'LastName'
      }
    ],
    pdsStatus: 'DEFAULT',
    product: {}
  },
  {
    key: {
      accountId: ''
    },
    accountNumber: '1234',
    accountName: '',
    firstMoneyReceivedDate: '2020-04-22T14:00:00.000Z',
    owners: [
      {
        age: 25,
        dateOfBirth: '1995-07-22',
        emails: [],
        firstName: 'Name',
        gender: 'Male',
        lastName: 'LastName'
      }
    ],
    pdsStatus: 'DEFAULT',
    product: {}
  },
  {
    key: {
      accountId: ''
    },
    accountNumber: '1234',
    accountName: '',
    firstMoneyReceivedDate: null,
    owners: [
      {
        age: 20,
        dateOfBirth: '2000-07-22',
        emails: [],
        firstName: 'Name',
        gender: 'Male',
        lastName: 'LastName'
      }
    ],
    pdsStatus: 'DEFAULT',
    product: {}
  },
  {
    key: {
      accountId: ''
    },
    accountNumber: '1234',
    accountName: '',
    firstMoneyReceivedDate: null,
    owners: [
      {
        age: 25,
        dateOfBirth: '2001-01-01',
        emails: [],
        firstName: 'Name',
        gender: 'Male',
        lastName: 'LastName'
      }
    ],
    pdsStatus: 'DEFAULT',
    product: {}
  }
];

export const MOCK_90_DAY_POLICY: InsurancePolicy[] = [
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    customised: true,
    employerFunded: false,
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 25,
    customerType: 'PCS',
    pmifDetails: {
      optInDate: '2020-09-22T14:00:00.000Z',
      lowBalanceThresholdDate: '2020-12-22T14:00:00.000Z'
    },
    coverLevel: null,
    policyFrequency: null,
    newCoverType: null,
    benefitFrequencyLabel: null
  },
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    customised: true,
    employerFunded: false,
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 25,
    customerType: 'PCS',
    pmifDetails: null,
    coverLevel: null,
    policyFrequency: null,
    newCoverType: null,
    benefitFrequencyLabel: null
  }
];

export const MOCK_60_DAY_POLICY: InsurancePolicy[] = [
  {
    policyType: PolicyType.TPD,
    policyName: 'Total & Permanent Disablement (TDP) cover',
    policyNumber: '6542525',
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-12-01T00:00:00.000+11:00',
    customised: true,
    employerFunded: false,
    coverSubTypeId: 146,
    qualifierName: 'Essential cover',
    ageNextBirthday: 26,
    customerType: 'PCS',
    pmifDetails: {
      optInDate: '2020-09-22T14:00:00.000Z',
      lowBalanceThresholdDate: '2020-12-22T14:00:00.000Z'
    },
    coverLevel: null,
    policyFrequency: null,
    newCoverType: null,
    benefitFrequencyLabel: null
  },
  {
    policyType: PolicyType.TPD,
    policyName: 'Total & Permanent Disablement (TDP) cover',
    policyNumber: '6542523',
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-12-01T00:00:00.000+11:00',
    customised: true,
    employerFunded: false,
    coverSubTypeId: 143,
    qualifierName: 'Essential cover',
    ageNextBirthday: 25,
    customerType: 'PCS',
    pmifDetails: {
      optInDate: null,
      lowBalanceThresholdDate: null
    },
    coverLevel: null,
    policyFrequency: null,
    newCoverType: null,
    benefitFrequencyLabel: null
  }
];

export const MOCK_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2020-10-04T16:00:00.000Z',
  pdsStatus: 'DEFAULT',
  product: {}
};
