import { Link } from '@bt/components/link';

export enum LinkType {
  INVESTMENT_OPTIONS = 'INVESTMENT_OPTIONS',
  SUPER_GUIDE = 'SUPER_GUIDE',
  PRODUCT_DISCLOSURE_STATEMENT = 'PRODUCT_DISCLOSURE_STATEMENT',
  ADDITIONAL_INFORMATION_BOOKLET = 'ADDITIONAL_INFORMATION_BOOKLET',
  PRODUCT_UPDATES = 'PRODUCT_UPDATES',
  PAST_PERFORMANCE_INFORMATION = 'PAST_PERFORMANCE_INFORMATION',
  UNIT_PRICES_WGP = 'UNIT_PRICES_WGP',
  UNIT_PRICES_NON_WGP = 'UNIT_PRICES_NON_WGP',
  BUY_SELL_SPREADS = 'BUY_SELL_SPREADS',
  FEES = 'FEES',
  INVESTMENT_FEES = 'INVESTMENT_FEES',
  PUBLIC_INVESTMENT_FEES = 'PUBLIC_INVESTMENT_FEES',
  CONTACT_US = 'CONTACT_US',
  INSURANCE_COVER_TYPES = 'INSURANCE_COVER_TYPES',
  INSURANCE_GUIDE = 'INSURANCE_GUIDE',
  INSURANCE_APPLICATION_FORM = 'INSURANCE_APPLICATION_FORM',
  INSURANCE_TRANSFER_FORM = 'INSURANCE_TRANSFER_FORM'
}

export type UrlCategory = 'PERSONAL_SUPER' | 'CORPORATE_SUPER' | 'WGP_OPEN' | 'WGP_COHORT' | 'EY' | 'DEFAULT';

const PRODUCT_DISCLOSURE_STATEMENT_URLS: Record<string, string> = {
  CORPORATE_SUPER: 'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html#employer_super_pds',
  PERSONAL_SUPER: 'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html#personal_super_pds',
  WGP_OPEN: 'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates.html#new_member_info',
  WGP_COHORT:
    'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-{cohort}.html#new_member_info',
  EY: 'https://www.bt.com.au/ey.html#new_member_info'
};

const SUPER_GUIDE_URLS: Record<string, string> = {
  CORPORATE_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/forms/BT-Super-Super-Guide.pdf',
  WGP_OPEN: '',
  WGP_COHORT: ''
};

const ADDITIONAL_INFORMATION_BOOKLET_URLS: Record<string, string> = {
  PERSONAL_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/pdf/btsfl-additional-information-booklet.pdf',
  WGP_OPEN:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/bt_super_for_life_additional_information_growth.pdf',
  WGP_COHORT:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/bt_super_for_life_additional_information_{cohort}.pdf'
};

const PRODUCT_UPDATES_URLS: Record<string, string> = {
  CORPORATE_SUPER: 'https://www.bt.com.au/personal/help/product-updates.html#bt_super',
  PERSONAL_SUPER: 'https://www.bt.com.au/personal/help/product-updates.html#sfl',
  WGP_OPEN: 'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates.html',
  WGP_COHORT: 'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-{cohort}.html'
};

const PAST_PERFORMANCE_INFORMATION_URLS: Record<string, string> = {
  CORPORATE_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/factsheets/super-corporate/BT-Super-Past-performance-info-inv-options.pdf',
  PERSONAL_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/factsheets/super-personal/BT-Super-for-Life-Past-performance-info-inv-options.pdf',
  WGP_OPEN:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/factsheets/super-personal/bt-super-for-life-past-performance-info-inv-options-open.pdf',
  WGP_COHORT:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/factsheets/super-personal/bt-super-for-life-past-performance-info-inv-options-{cohort}.pdf'
};

const UNIT_PRICES_URLS: Record<string, string> = {
  CORPORATE_SUPER:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTS',
  PERSONAL_SUPER:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTSFL_SAV',
  WGP_OPEN:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTSFL_WGP&wgp=true',
  WGP_COHORT:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTSFL_WGP&wgp=true'
};

const UNIT_PRICES_NON_WGP: Record<string, string> = {
  CORPORATE_SUPER:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTS',
  PERSONAL_SUPER:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTSFL_SAV',
  WGP_OPEN:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTS',
  WGP_COHORT:
    'https://www.bt.com.au/personal/prices-and-performance/unit-prices/bt-super-product-unit-prices.html?productId=BTS'
};

const BUY_SELL_SPREADS_URLS: Record<string, string> = {
  CORPORATE_SUPER:
    'https://www.bt.com.au/personal/prices-and-performance/buy-sell-spreads/superannuation-and-retirement-buy-sell-spreads.html',
  PERSONAL_SUPER:
    'https://www.bt.com.au/personal/prices-and-performance/buy-sell-spreads/superannuation-and-retirement-buy-sell-spreads.html',
  WGP_OPEN: 'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates.html#buysellwgp',
  WGP_COHORT:
    'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-{cohort}.html#buysellwgp'
};

const FEES_URLS: Record<string, string> = {
  DEFAULT: '#/app/investor/account/{account}/pano-fees'
};

const INVESTMENT_FEES_URLS: Record<string, string> = {
  DEFAULT: '#/app/investor/account/{account}/learn-about-investments/investment-fees'
};

const PUBLIC_INVESTMENT_FEES_URLS: Record<string, string> = {
  CORPORATE_SUPER: 'https://www.bt.com.au/personal/prices-and-performance/fees-and-costs/bt-super.html',
  PERSONAL_SUPER: 'https://www.bt.com.au/personal/prices-and-performance/fees-and-costs/retail-superannuation.html',
  WGP_OPEN: 'https://www.bt.com.au/personal/prices-and-performance/fees-and-costs/bt-super.html',
  WGP_COHORT: 'https://www.bt.com.au/personal/prices-and-performance/fees-and-costs/bt-super.html'
};

const INVESTMENT_OPTIONS_URLS: Record<string, string> = {
  DEFAULT: 'https://www.bt.com.au/personal/superannuation/super-investments/investment-options.html '
};

const CONTACT_US_URLS: Record<string, string> = {
  DEFAULT: 'https://www.bt.com.au/personal/contact-us.html'
};

const INSURANCE_COVER_TYPES_URLS: Record<string, string> = {
  CORPORATE_SUPER: 'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/btsuper-kfs.pdf',
  PERSONAL_SUPER: 'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/sfl-kfs.pdf',
  WGP_OPEN:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/bt_super_for_life_additional_information_growth.pdf',
  WGP_COHORT:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/bt_super_for_life_additional_information_{cohort}.pdf'
};

const INSURANCE_GUIDE_URLS: Record<string, string> = {
  CORPORATE_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/forms/BT-Super-Employee-Insurance-Guide.pdf',
  PERSONAL_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/pdf/btsfl-additional-information-booklet.pdf',
  WGP_OPEN:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/bt_super_for_life_additional_information_growth.pdf',
  WGP_COHORT:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/bt_super_for_life_additional_information_{cohort}.pdf'
};

const INSURANCE_APPLICATION_FORM_URLS: Record<string, string> = {
  CORPORATE_SUPER: 'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html',
  PERSONAL_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/support/sfl-forms/sfl-customised-insurance-application-form.pdf',
  WGP_OPEN:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/life-events-application-form.pdf',
  WGP_COHORT:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/life-events-application-form.pdf'
};

const INSURANCE_TRANSFER_FORM_URLS: Record<string, string> = {
  CORPORATE_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/forms/bt-super-individual-insurance-consolidation-application.pdf',
  PERSONAL_SUPER:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/support/sfl-forms/sfl-customised-insurance-takeover-terms-application.pdf',
  WGP_OPEN:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/wgp-insurance-transfer.pdf',
  WGP_COHORT:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/personal/super/products/wgp-insurance-transfer.pdf'
};

const EXTERNAL_LINK_ANNOUNCEMENT: string = 'open in new tab.';

const PRODUCT_DISCLOSURE_STATEMENT_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Product disclosure statement (PDS)',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: 'Product Disclosure Statement (PDS), '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const SUPER_GUIDE_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Super guide - PDF',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: 'Super guide, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const ADDITIONAL_INFORMATION_BOOKLET_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Additional information booklet - PDF',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: 'Additional information booklet, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const PRODUCT_UPDATES_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Product updates',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: 'Product updates, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const PAST_PERFORMANCE_INFORMATION_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Past performance information - PDF',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: 'Past performance information, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const UNIT_PRICES_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Unit prices',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: false,
  iconPosition: 'left',
  a11yProps: {
    ariaLabel: 'Unit prices, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const BUY_SELL_SPREADS_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Buy-sell spreads',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: 'Buy-sell spreads, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const FEES_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Fees',
  link: '',
  openNewTab: false,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false
};

const INVESTMENT_FEES_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Ongoing fees',
  link: '',
  openNewTab: false,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false
};

const PUBLIC_INVESTMENT_FEES_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Ongoing fees',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false
};

const INVESTMENT_OPTIONS_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: "Learn more about BT's investment options",
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false,
  a11yProps: {
    ariaLabel: "Learn more about BT's investment options, ".concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const CONTACT_US_LINK: Link = {
  isLinkExternal: true,
  label: 'Contact us form',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'Contact us form, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const INSURANCE_COVER_TYPES_LINK: Link = {
  isLinkExternal: true,
  label: 'insurance cover types',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  size: 'large',
  a11yProps: {
    ariaLabel: 'insurance cover types, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const INSURANCE_GUIDE_LINK: Link = {
  isLinkExternal: true,
  label: '',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: '{label}, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const INSURANCE_APPLICATION_FORM_LINK: Link = {
  isLinkExternal: true,
  label: 'Life Insurance Application Form',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'Life Insurance Application Form, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const INSURANCE_TRANSFER_FORM_LINK: Link = {
  isLinkExternal: true,
  label: '',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: '{label}, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

interface WgpDynamicLink {
  permission?: string;
  link: Link;
  urlMap: Record<string, string>;
}

export const WGP_DYNAMIC_LINKS: Record<LinkType, WgpDynamicLink> = {
  [LinkType.PRODUCT_DISCLOSURE_STATEMENT]: {
    urlMap: PRODUCT_DISCLOSURE_STATEMENT_URLS,
    link: PRODUCT_DISCLOSURE_STATEMENT_LINK
  },
  [LinkType.SUPER_GUIDE]: {
    urlMap: SUPER_GUIDE_URLS,
    link: SUPER_GUIDE_LINK
  },
  [LinkType.ADDITIONAL_INFORMATION_BOOKLET]: {
    urlMap: ADDITIONAL_INFORMATION_BOOKLET_URLS,
    link: ADDITIONAL_INFORMATION_BOOKLET_LINK
  },
  [LinkType.PRODUCT_UPDATES]: {
    urlMap: PRODUCT_UPDATES_URLS,
    link: PRODUCT_UPDATES_LINK
  },
  [LinkType.PAST_PERFORMANCE_INFORMATION]: {
    urlMap: PAST_PERFORMANCE_INFORMATION_URLS,
    link: PAST_PERFORMANCE_INFORMATION_LINK
  },
  [LinkType.UNIT_PRICES_WGP]: {
    urlMap: UNIT_PRICES_URLS,
    link: UNIT_PRICES_LINK,
    permission: 'feature.wgpUnitPrices.view'
  },
  [LinkType.UNIT_PRICES_NON_WGP]: {
    urlMap: UNIT_PRICES_NON_WGP,
    link: UNIT_PRICES_LINK,
    permission: '!feature.wgpUnitPrices.view'
  },
  [LinkType.BUY_SELL_SPREADS]: {
    urlMap: BUY_SELL_SPREADS_URLS,
    link: BUY_SELL_SPREADS_LINK
  },
  [LinkType.FEES]: {
    urlMap: FEES_URLS,
    link: FEES_LINK,
    permission: 'account.fees.v1.view'
  },
  [LinkType.INVESTMENT_FEES]: {
    urlMap: INVESTMENT_FEES_URLS,
    link: INVESTMENT_FEES_LINK,
    permission: 'feature.investmentFees.view'
  },
  [LinkType.PUBLIC_INVESTMENT_FEES]: {
    urlMap: PUBLIC_INVESTMENT_FEES_URLS,
    link: PUBLIC_INVESTMENT_FEES_LINK,
    permission: '!feature.investmentFees.view'
  },
  [LinkType.INVESTMENT_OPTIONS]: {
    urlMap: INVESTMENT_OPTIONS_URLS,
    link: INVESTMENT_OPTIONS_LINK
  },
  [LinkType.CONTACT_US]: {
    urlMap: CONTACT_US_URLS,
    link: CONTACT_US_LINK
  },
  [LinkType.INSURANCE_COVER_TYPES]: {
    urlMap: INSURANCE_COVER_TYPES_URLS,
    link: INSURANCE_COVER_TYPES_LINK
  },
  [LinkType.INSURANCE_GUIDE]: {
    urlMap: INSURANCE_GUIDE_URLS,
    link: INSURANCE_GUIDE_LINK
  },
  [LinkType.INSURANCE_APPLICATION_FORM]: {
    urlMap: INSURANCE_APPLICATION_FORM_URLS,
    link: INSURANCE_APPLICATION_FORM_LINK
  },
  [LinkType.INSURANCE_TRANSFER_FORM]: {
    urlMap: INSURANCE_TRANSFER_FORM_URLS,
    link: INSURANCE_TRANSFER_FORM_LINK
  }
};
