import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { BtError, DataModule, DataService } from '@bt/services/data';
import { of, throwError } from 'rxjs';

import { getInvestmentProfileOptions, getInvestmentProfilePath } from './pano-inv-profile.constants';
import { MOCK_INVESTMENT_PROFILE } from './pano-inv-profile.constants.spec';
import { InvestmentProfile } from './pano-inv-profile.interface';
import { PanoInvestmentProfileService } from './pano-inv-profile.service';

describe('PanoInvestmentProfileService', () => {
  let service: PanoInvestmentProfileService;
  let dataService: DataService<InvestmentProfile | BtError>;

  const successHandler: jasmine.Spy = jasmine.createSpy();
  const errorHandler: jasmine.Spy = jasmine.createSpy();

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DataModule, HttpClientTestingModule],
      providers: [PanoInvestmentProfileService]
    });
    service = TestBed.inject(PanoInvestmentProfileService);
    dataService = TestBed.inject(DataService);
  });

  beforeEach(() => {
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getInvestmentProfile', () => {
    it('should make a call to the investmentProfile api and return the data when it resolves successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of(MOCK_INVESTMENT_PROFILE));

      service.getInvestmentProfile('1234').subscribe(successHandler, errorHandler);

      expect(dataService.retrieve).toHaveBeenCalledWith(
        getInvestmentProfilePath('1234'),
        getInvestmentProfileOptions('1234')
      );
      expect(successHandler).toHaveBeenCalledWith(MOCK_INVESTMENT_PROFILE);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should return profile as undefined when retrieve service return empty profile', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({} as InvestmentProfile));

      service.getInvestmentProfile('1234').subscribe(profile => {
        expect(profile).toBeUndefined();
      });
    });

    it('should return profile as undefined when retrieve service return undefined profile', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of(undefined));

      service.getInvestmentProfile('1234').subscribe(profile => {
        expect(profile).toBeUndefined();
      });
    });

    it('should return correct profile when retrieve service return valid profile', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of(MOCK_INVESTMENT_PROFILE));

      service.getInvestmentProfile('1234').subscribe(profile => {
        expect(profile).toEqual(MOCK_INVESTMENT_PROFILE);
      });
    });

    it('should make a call to the investmentProfile api and bounce an error if it fails', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getInvestmentProfile('1234').subscribe(successHandler, errorHandler);

      expect(dataService.retrieve).toHaveBeenCalledWith(
        getInvestmentProfilePath('1234'),
        getInvestmentProfileOptions('1234')
      );
      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalled();
    });
  });

  describe('setInvestmentProfile', () => {
    it('should make a call to the investmentProfile update api and return when it resolves successfully', () => {
      spyOn(dataService, 'update').and.returnValue(of(null));

      service.setInvestmentProfile('1234', MOCK_INVESTMENT_PROFILE).subscribe(successHandler, errorHandler);

      expect(dataService.update).toHaveBeenCalledWith(
        getInvestmentProfilePath('1234'),
        MOCK_INVESTMENT_PROFILE,
        getInvestmentProfileOptions('1234')
      );
      expect(successHandler).toHaveBeenCalled();
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should make a call to the investmentProfile update api and bounce an error if it fails', () => {
      spyOn(dataService, 'update').and.returnValue(throwError('error'));

      service.setInvestmentProfile('1234', MOCK_INVESTMENT_PROFILE).subscribe(successHandler, errorHandler);

      expect(dataService.update).toHaveBeenCalledWith(
        getInvestmentProfilePath('1234'),
        MOCK_INVESTMENT_PROFILE,
        getInvestmentProfileOptions('1234')
      );
      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalled();
    });
  });
});
