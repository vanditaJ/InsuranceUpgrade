import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

import { ModalObj } from '../pano-insurance-policies.interface';

import { CLOSE_BUTTON, CLOSE_ICON } from './pano-increase-ey-cover-dialog.constants';

@Component({
  selector: 'pano-increase-ey-cover-dialog',
  templateUrl: './pano-increase-ey-cover-dialog.component.html'
})
export class PanoIncreaseEyCoverDialogComponent {
  readonly closeButton: Button = CLOSE_BUTTON;
  readonly closeIcon: Button = CLOSE_ICON;

  constructor(
    readonly dialogRef: MatDialogRef<PanoIncreaseEyCoverDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: ModalObj
  ) {}

  closeDialog(status: string): void {
    this.dialogRef.close(status);
  }
}
