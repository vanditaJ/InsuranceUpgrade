import { HttpHeaders } from '@angular/common/http';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { Optionals } from '@bt/services/data';
import { Subject } from 'rxjs';

export const getInvestmentProfilePath: (accountId: string) => string = (accountId: string) =>
  `/investor/secure/api/v1/account/${accountId}/investment-profile`;

const HEADER = new HttpHeaders({ 'Content-Type': 'application/json' });
export const getInvestmentProfileOptions = (accountId: string): Optionals => ({
  errorCode: 'Err.IP-0344',
  cacheOptions: {
    cacheInterval: Infinity,
    invalidateCacheForURL: `/investor/secure/api/account/${accountId}/investment-profile/`
  },
  httpOptions: {
    headers: HEADER
  },
  checkList: []
});

export const INVESTMENT_TYPES = {
  ALL_INVESTMENT_TYPES: 'ALL_INVESTMENT_TYPES',
  SHARES_AND_ETFS: 'SHARES_AND_ETFS'
};

export const ACCORDION_HEADER_ICON: Icon = {
  name: 'icon-chevron-right-circle-outline',
  size: 'medium'
};

export const SHARES_AND_ETFS_ICON: Icon = {
  name: 'icon-market-result-chart',
  size: 'medium'
};
export const ALL_INVESTMENT_TYPES_ICON: Icon = {
  name: 'icon-dollar-sign',
  size: 'medium'
};

export const INVESTMENT_PROFILE_TITLE: string = 'Your investment profile';

export const EDIT_INVESTMENT_PROFILE_BUTTON: Button = {
  action: 'button',
  colourModifier: 'basic',
  icon: {
    name: 'icon-pencil',
    size: 'x-small'
  },
  iconPosition: 'left',
  label: 'Edit',
  shapeModifier: 'square',
  size: 'medium',
  type: 'outline',
  a11yProps: {
    ariaLabel: 'Edit'
  }
};

export const SET_UP_PROFILE_ALERT: Alert = {
  type: 'warning',
  outline: true,
  messages: 'Err.IP-1445'
};

export const SAVE_PROFILE_SUCCESS_ALERT: Alert = {
  type: 'success',
  outline: true,
  closeable: true,
  duration: 5000,
  visibilitySubject: new Subject<void>(),
  messages: 'Ins.IP-1446'
};

export const SAVE_PROFILE_FAILED_ALERT: Alert = {
  type: 'error',
  outline: true,
  messages: 'Err.IP-1456'
};

export const DATE_TIME_FORMAT = {
  DDMMMYYYYHMMAZ: 'DD MMM YYYY h:mma'
};

export const TIME_ZONE = 'Australia/Sydney';
