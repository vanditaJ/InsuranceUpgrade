import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Alert } from '@bt/components/alert';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { INVESTMENT_TYPES } from '../../pano-inv-profile.constants';
import { InvestmentType } from '../../pano-inv-profile.interface';

import {
  ALL_INVESTMENT_TYPES_DESCRIPTION,
  REQUIRE_INVESTMENT_TYPE_ALERT,
  SHARES_ETFS_ONLY_DESCRIPTION
} from './pano-inv-types.constants';

@Component({
  selector: 'pano-inv-types',
  templateUrl: './pano-inv-types.component.html',
  styleUrls: ['./pano-inv-types.component.scss']
})
export class PanoInvestmentTypesComponent implements OnDestroy, OnInit {
  @Input() investmentType: string;
  @Output() investmentTypeChange: EventEmitter<string> = new EventEmitter();

  readonly allInvestmentTypes: string = INVESTMENT_TYPES.ALL_INVESTMENT_TYPES;
  readonly allInvestmentTypesTitle: string = InvestmentType.ALL_INVESTMENT_TYPES;
  readonly allInvestmentTypesDescription: string = ALL_INVESTMENT_TYPES_DESCRIPTION;

  readonly sharedAndEtfs: string = INVESTMENT_TYPES.SHARES_AND_ETFS;
  readonly sharedAndEtfsTitle: string = InvestmentType.SHARES_AND_ETFS;
  readonly sharedAndEtfsDescription: string = SHARES_ETFS_ONLY_DESCRIPTION;
  readonly requireInvestmentTypeInputAlert: Alert = REQUIRE_INVESTMENT_TYPE_ALERT;

  readonly unsubscribe$: Subject<void> = new Subject();

  form: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      investmentType: [this.investmentType, Validators.required]
    });

    this.form.valueChanges.pipe(takeUntil(this.unsubscribe$)).subscribe(values => {
      this.investmentTypeChange.emit(values['investmentType']);
    });
  }
}
