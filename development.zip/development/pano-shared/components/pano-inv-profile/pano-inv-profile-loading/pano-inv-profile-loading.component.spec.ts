import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { PanoInvestmentProfileLoadingComponent } from './pano-inv-profile-loading.component';

describe('PanoInvestmentProfileLoadingComponent', () => {
  let component: PanoInvestmentProfileLoadingComponent;
  let fixture: ComponentFixture<PanoInvestmentProfileLoadingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [PanoInvestmentProfileLoadingComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentProfileLoadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('View', () => {
    it('should show loading icon', () => {
      const loading = fixture.debugElement.query(By.css('bt-loading'));
      expect(loading.properties.config).toEqual(component.saveProfileLoading);
    });

    it('should show loading title', () => {
      const loadingTitle = fixture.debugElement.query(By.css('h3'));
      expect(loadingTitle.nativeElement.textContent.trim()).toBe(component.loadingTitle);
    });
  });
});
