import { Injectable } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { attachDynamicValidators } from '@bt/helpers/attach-dynamic-validators';
import * as moment from 'moment-timezone';

import { ASSET_TYPES } from './pano-external-assets-constants/pano-external-assets.constants';
import { ExternalAsset } from './pano-external-assets.interfaces';

@Injectable()
export class PanoExternalAssetsFormCreator {
  attachDynamicValidators = attachDynamicValidators;

  constructor(private fb: FormBuilder) {}

  createAssetsFormControl(externalAssetsForm: FormGroup, assetType: string, assetList: ExternalAsset[]): void {
    const formArray = externalAssetsForm.get(`${assetType}FormArray`);
    if (formArray) {
      assetList.forEach(asset => {
        this.createAssetFormControl(formArray as FormArray, assetType, asset);
      });
    }
  }

  createAssetFormControl(assetTypeFormArray: FormArray, assetType: string, asset: ExternalAsset): void {
    const assetDetailsFormControls = ASSET_TYPES[assetType].editFormControls.reduce((accum, field) => {
      return {
        ...accum,
        [field.name]: new FormControl(this.getFieldValue(asset, field.name, field.type), {
          validators: field.validators ? [...field.validators] : [],
          updateOn: 'blur'
        })
      };
    }, {});
    const assetDetailsFormGroup = this.fb.group({ ...assetDetailsFormControls });
    if (assetType === ASSET_TYPES.ls.code || assetType === ASSET_TYPES.mf.code) {
      assetDetailsFormGroup.setControl('isLastPriceLoading', new FormControl(false));
      this.clearValidatorsForPanoramaAsset(assetDetailsFormGroup, asset['isPanoramaAsset']);
    } else if (assetType === ASSET_TYPES.td.code) {
      assetDetailsFormGroup.setControl('isMaturityDateChanged', new FormControl(false));
      assetDetailsFormGroup.get('maturityDate').markAsTouched();
    }
    assetTypeFormArray.push(assetDetailsFormGroup);
  }

  private getFieldValue(asset: ExternalAsset, name: string, type: string): any {
    const value: any = asset[name];

    // no transformation for empty value
    if (value === '') {
      return '';
    } else if (type === 'date') {
      const dateInMoment = moment(asset[name]).tz('Australia/Sydney');
      if (dateInMoment.isValid()) {
        return dateInMoment;
      }
      return '';
    } else if (type === 'amount') {
      return (+value).toFixed(2);
    }

    return value;
  }

  private clearValidatorsForPanoramaAsset(assetDetailsFormGroup: FormGroup, isPanoramaAsset: boolean): void {
    if (isPanoramaAsset) {
      this.attachDynamicValidators(assetDetailsFormGroup.controls['valuationDate']);
      this.attachDynamicValidators(assetDetailsFormGroup.controls['marketValue']);
    }
  }
}
