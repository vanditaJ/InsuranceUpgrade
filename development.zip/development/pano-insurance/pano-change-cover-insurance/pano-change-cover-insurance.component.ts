import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Loading } from '@bt/components/loading';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { AemContent } from '@panorama/services/cms';
import { UIRouter } from '@uirouter/core';
import { find, get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { finalize } from 'rxjs/operators';

import { CANCEL_FORM_BUTTON, GENERIC_ERROR_ALERT, REVIEW_FORM_BUTTON, SPINNER } from '../pano-insurance.constants';
import { findContentByKey } from '../pano-insurance.helper';
import { InsuranceOption, InsurancePolicy, PolicyType, SelectCoverType } from '../pano-insurance.interface';
import { PanoInsuranceService } from '../pano-insurance.service';

import { PanoChangeCoverInsuranceCommonUtil } from './pano-change-cover-insurance-common.util';
import {
  CHANGE_DEATH_AND_TPD_INFO_AEM_KEY,
  CHANGE_DEATH_INFO_AEM_KEY,
  DECREASE_DEATH_AND_TPD_INFO_AEM_KEY,
  DECREASE_DEATH_INFO_AEM_KEY,
  SELECT_COVER_AMOUNTS,
  SELECT_COVER_TYPES
} from './pano-change-cover-insurance.constants';
import {
  ChangeCoverMode,
  ChangeCoverState,
  CoverAmountOptions,
  CoverMode,
  CoverState,
  CoverTypeSelected,
  InsuranceRate,
  SelectCoverAmount
} from './pano-change-cover-insurance.interface';

@Component({
  selector: 'pano-change-cover-insurance',
  templateUrl: './pano-change-cover-insurance.component.html'
})
export class PanoChangeCoverInsuranceComponent implements OnInit {
  @Input() account: Account;
  @Input() cmsContent: AemContent[];

  @ViewChild('mainHeader', { static: false, read: ElementRef }) mainHeader: ElementRef;

  heading: string;
  mode: ChangeCoverMode;
  state: ChangeCoverState;
  insurance: InsurancePolicy;
  currentCoverType: CoverAmountOptions;
  selectCoverTypes = SELECT_COVER_TYPES;
  selectCoverAmounts = SELECT_COVER_AMOUNTS;
  selectedCoverLevel: CoverTypeSelected['coverLevels'];
  hideChangeButton: boolean = false;
  formValue: object;
  insuranceRates: Array<InsuranceRate>;
  insuranceOptions: Array<InsuranceOption>;
  genericError: boolean = false;
  loading: boolean = true;
  disclaimer: string;
  date: moment;

  readonly coverMode = CoverMode;
  readonly coverState = CoverState;
  readonly cancelReviewFormButton: Button = CANCEL_FORM_BUTTON;
  readonly reviewFormButton: Button = REVIEW_FORM_BUTTON;
  readonly genericErrorAlert: Alert = GENERIC_ERROR_ALERT;
  readonly loadingSpinner: Loading = SPINNER;

  constructor(
    private insuranceService: PanoInsuranceService,
    private uiRouter: UIRouter,
    private util: PanoChangeCoverInsuranceCommonUtil,
    private disclaimerService: PanoDisclaimersService
  ) {}

  ngOnInit(): void {
    this.date = moment(new Date()).format('D MMM YYYY');
    this.disclaimer = this.disclaimerService.evaluateDisclaimer(this.account);

    this.state = CoverState.OPTIONS;
    this.mode = get(this.uiRouter.stateService.params, 'mode');
    this.heading = this.mode === CoverMode.CHANGE ? 'Change your cover' : 'Decrease your cover';

    this.setAemMessages();

    this.insuranceService.getInsurance().subscribe((policy: InsurancePolicy) => {
      this.insurance = policy;
      this.insurance.policyName = this.selectCoverTypes.find(
        type => type.policyType === this.insurance.policyType
      ).policyName;

      if (this.mode !== CoverMode.DECREASE_REQUEST) {
        this.loadInsuranceRates();
      } else {
        if (this.insurance.policyType === PolicyType.INCOME_PROTECTION) {
          this.loadInsuranceOptions();
        } else {
          this.loading = false;
        }
      }
    });
  }

  resetFocus(): void {
    // The 'wizard' style component switching means focus needs to be moved back to the top of the screen manually
    // This prevents screen readers getting stuck at the bottom and not notifying users when the screen changes
    if (this.mainHeader) {
      this.mainHeader.nativeElement.focus();
    }
  }

  loadInsuranceRates(): void {
    this.insuranceService
      .getInsuranceRates(this.insurance.coverSubTypeId, this.insurance.ageNextBirthday, this.account.owners[0].gender)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        (res: Array<InsuranceRate>) => {
          this.insuranceRates = res;
          this.currentCoverType = this.util.getCoverAmountOptions(
            this.mode,
            this.insurance.policyType,
            this.insurance.coverLevel,
            this.insuranceRates
          );
          // when one unit of death left, then nagivate to preview
          if (
            this.mode === CoverMode.DECREASE &&
            this.currentCoverType.coverTypeSelected.length === 1 &&
            this.currentCoverType.coverTypeSelected[0].coverLevels.length === 1
          ) {
            const coverTypeSelected: CoverTypeSelected = this.currentCoverType.coverTypeSelected[0];
            this.setNewCoverType(coverTypeSelected);
          }
        },
        () => {
          this.genericError = true;
        }
      );
  }

  loadInsuranceOptions(): void {
    this.insuranceService
      .getInsuranceOptions(this.insurance.coverSubTypeId)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        (options: Array<InsuranceOption>) => {
          this.insuranceOptions = options;
        },
        () => {
          this.genericError = true;
        }
      );
  }

  setAemMessages(): void {
    const death = this.selectCoverTypes.find(type => type.policyType === PolicyType.DEATH);
    const deathAndTpd = this.selectCoverTypes.find(type => type.policyType === PolicyType.DEATH_AND_TPD);

    if (this.mode === CoverMode.DECREASE) {
      deathAndTpd.description = findContentByKey(this.cmsContent, DECREASE_DEATH_AND_TPD_INFO_AEM_KEY);
      death.description = findContentByKey(this.cmsContent, DECREASE_DEATH_INFO_AEM_KEY);
    } else {
      deathAndTpd.description = findContentByKey(this.cmsContent, CHANGE_DEATH_AND_TPD_INFO_AEM_KEY);
      death.description = findContentByKey(this.cmsContent, CHANGE_DEATH_INFO_AEM_KEY);
    }
  }

  setNewCoverType(coverTypeSelected: CoverTypeSelected): void {
    const insuranceRate: InsuranceRate = find(
      this.insuranceRates,
      rate => rate.policyType === coverTypeSelected.coverType && rate.coverLevel === coverTypeSelected.coverLevels[0]
    );

    const newSelectCoverType: SelectCoverType = {
      policyType: insuranceRate.policyType,
      policyName: insuranceRate.policyName,
      description: this.selectCoverTypes.find(type => type.policyType === insuranceRate.policyType).description
    };

    const newSelectedCoverAmount: SelectCoverAmount = {
      coverSubTypeId: insuranceRate.coverOptionId,
      coverAmountName: insuranceRate.coverLevel + ' cover',
      coverAmountType: insuranceRate.coverLevel,
      coverAmount: insuranceRate.coverAmount,
      premium: insuranceRate.premium,
      increase: insuranceRate.increase
    };

    this.formValue = {
      coverType: newSelectCoverType,
      coverAmountType: newSelectedCoverAmount
    };

    this.hideChangeButton = true;
    this.state = CoverState.PREVIEW;
  }

  showPreview(event: object): void {
    this.state = CoverState.PREVIEW;
    this.formValue = event;
  }

  setSelectedCoverLabel(event: CoverTypeSelected['coverLevels']): void {
    this.selectedCoverLevel = event;
  }

  updateState($event): void {
    this.state = $event;
  }

  navigateToOverview(): void {
    this.uiRouter.stateService.go('app.investor.account.insurancePolicies');
  }
}
