import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { includes } from 'lodash-es';
import { Observable } from 'rxjs';

import { SCREEN_TYPE, SOFTWARE_NAME, SOFTWARE_STATUS } from './pano-external-assets.constants';
import { AccountingSoftwareStatus, ExternalAssetTotalValuation, SoftwareData } from './pano-external-assets.interfaces';
import { PanoExternalAssetsService } from './pano-external-assets.service';

/* istanbul ignore next */
export function panoExternalStateResolver($transition$): Promise<SoftwareData> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const externalAssetsService = $transition$.injector().get(PanoExternalAssetsService);
  const observable: Observable<SoftwareData> = panoExternalAssetsResolveData(accountService, externalAssetsService);
  return observable.toPromise();
}

export function panoExternalAssetsResolveData(
  accountService: PanoUpgradeAccountService,
  externalAssetsService: PanoExternalAssetsService
): Observable<SoftwareData> {
  const observable: Observable<SoftwareData> = new Observable(observer => {
    externalAssetsService.getAccountingSoftwareStatus(accountService.getAccountId()).subscribe(
      (accountingSoftwareStatus: AccountingSoftwareStatus) => {
        const softwareNames = [SOFTWARE_NAME.CLASS_SUPER, SOFTWARE_NAME.BGL_SF360];
        let screenType: SCREEN_TYPE;
        if (
          accountingSoftwareStatus.status === SOFTWARE_STATUS.RECEIVED &&
          includes(softwareNames, accountingSoftwareStatus.softwareName)
        ) {
          externalAssetsService.getValuationForExternalAsset(accountService.getAccountId()).subscribe(
            (data: ExternalAssetTotalValuation) => {
              const softwareData: SoftwareData = {
                softwareStatus: accountingSoftwareStatus,
                valuation: data,
                screenType: SCREEN_TYPE.CONNECTED
              };
              observer.next(softwareData);
              observer.complete();
            },
            err => observer.error(err),
            () => observer.complete()
          );
        } else {
          screenType =
            accountingSoftwareStatus.status === SOFTWARE_STATUS.AWAITING ? SCREEN_TYPE.PENDING : SCREEN_TYPE.MANUAL;
          const softwareData: SoftwareData = {
            softwareStatus: accountingSoftwareStatus,
            screenType
          };
          observer.next(softwareData);
          observer.complete();
        }
      },
      err => observer.error(err)
    );
  });
  return observable;
}
