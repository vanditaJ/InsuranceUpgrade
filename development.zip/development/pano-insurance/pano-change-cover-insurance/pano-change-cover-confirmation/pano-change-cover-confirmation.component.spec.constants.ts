import { AemContent } from '@panorama/services/cms';

export const MOCK_AEM_CONTENT_CONFIRMATION: AemContent[] = [
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_confirm_useful_info_active_increase',
      description: 'mock content for change_cover_confirm_useful_info_active_increase'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_confirm_useful_info_active_decrease',
      description: 'mock content for change_cover_confirm_useful_info_active_decrease'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_confirm_useful_info_pending',
      description: 'mock content for change_cover_confirm_useful_info_pending'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_confirm_useful_info',
      description: 'mock content for decrease_cover_confirm_useful_info'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_confirm_useful_info_earthrise',
      description: 'mock content for decrease_cover_confirm_useful_info_earthrise'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_confirm_useful_info_sci_earthrise',
      description: 'mock content for decrease_cover_confirm_useful_info_sci_earthrise'
    }
  }
];
