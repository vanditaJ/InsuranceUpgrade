export enum InvestmentType {
  SHARES_AND_ETFS = 'Shares & ETFs only',
  ALL_INVESTMENT_TYPES = 'All investment types'
}

export enum InvestmentObjective {
  REGULAR_INCOME = 'REGULAR_INCOME',
  CAPITAL_GUARANTEED = 'CAPITAL_GUARANTEED',
  CAPITAL_PRESERVATION = 'CAPITAL_PRESERVATION',
  CAPITAL_GROWTH = 'CAPITAL_GROWTH'
}

export enum InvestmentTimeframe {
  SHORT = 'SHORT',
  MEDIUM = 'MEDIUM',
  LONG = 'LONG'
}

export enum ReturnObjective {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  VERY_HIGH = 'VERY_HIGH'
}

export enum RedemptionFrequency {
  DAILY = 'DAILY',
  WEEKLY = 'WEEKLY',
  MONTHLY = 'MONTHLY',
  QUARTERLY = 'QUARTERLY',
  ANNUALLY_OR_LONGER = 'ANNUALLY_OR_LONGER'
}

export interface InvestmentProfile {
  accountId: string;
  profileId?: string;
  investmentType: string;
  investmentObjectives?: InvestmentObjective[];
  investmentTimeframes?: InvestmentTimeframe[];
  riskReturnObjectives?: ReturnObjective[];
  redemptionFrequencies?: RedemptionFrequency[];
  lastUpdatedBy?: string;
  lastUpdatedAt?: string;
}
