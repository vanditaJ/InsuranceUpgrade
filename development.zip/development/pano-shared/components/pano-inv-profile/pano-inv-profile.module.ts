import { NgxSliderModule } from '@angular-slider/ngx-slider';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatRadioModule } from '@angular/material/radio';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { IconModule } from '@bt/components/icon';
import { LoadingModule } from '@bt/components/loading';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { FormatTimestampPipeModule } from '@bt/pipes/format-timestamp';
import { LayoutModule } from '@panorama/components/layout';

import { PanoInvProfileAssetMatchAlertsComponent } from './pano-inv-profile-asset-match-alerts/pano-inv-profile-asset-match-alerts.component';
import { PanoInvestmentProfileLoadingComponent } from './pano-inv-profile-loading/pano-inv-profile-loading.component';
import { PanoInvestmentPreferencesComponent } from './pano-inv-profile-setup/pano-inv-pref/pano-inv-pref.component';
import { PanoCheckboxesComponent } from './pano-inv-profile-setup/pano-inv-pref/pano-pref-checkboxes/pano-pref-checkboxes.component';
import { PanoInvestmentPreferenceDialogComponent } from './pano-inv-profile-setup/pano-inv-pref/pano-pref-header/pano-pref-dialog/pano-pref-dialog.component';
import { PanoInvestmentPreferenceHeaderComponent } from './pano-inv-profile-setup/pano-inv-pref/pano-pref-header/pano-pref-header.component';
import { PanoInvestmentProfileSetupComponent } from './pano-inv-profile-setup/pano-inv-profile-setup.component';
import { PanoInvestmentTypesComponent } from './pano-inv-profile-setup/pano-inv-types/pano-inv-types.component';
import { PanoInvestmentProfileComponent } from './pano-inv-profile.component';
import { PanoInvestmentProfileService } from './pano-inv-profile.service';

@NgModule({
  declarations: [
    PanoCheckboxesComponent,
    PanoInvestmentPreferencesComponent,
    PanoInvestmentPreferenceDialogComponent,
    PanoInvestmentPreferenceHeaderComponent,
    PanoInvestmentProfileComponent,
    PanoInvestmentProfileSetupComponent,
    PanoInvestmentProfileLoadingComponent,
    PanoInvestmentTypesComponent,
    PanoInvProfileAssetMatchAlertsComponent
  ],
  imports: [
    AlertModule,
    ButtonModule,
    CommonModule,
    CopyMatrixPipeModule,
    FormatTimestampPipeModule,
    IconModule,
    LayoutModule,
    LoadingModule,
    MatCheckboxModule,
    MatExpansionModule,
    MatRadioModule,
    NgxSliderModule,
    ReactiveFormsModule
  ],
  providers: [PanoInvestmentProfileService]
})
export class PanoInvestmentProfileModule {}
