import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { DataModule } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService, PanoUpgradePermissionService, StateParams } from '@upgrade/upgrade.services';
import { PageScrollService } from 'ngx-page-scroll-core';
import { of, throwError } from 'rxjs';

import { PanoInsuranceSharedLinkService } from '../../pano-insurance-shared-link/pano-insurance-shared-link.service';
import { IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES } from '../../pano-insurance.constants.spec';
import { PanoInsuranceService } from '../../pano-insurance.service';
import { PanoInsuranceUtil } from '../../pano-insurance.util';
import { CoverMode } from '../pano-change-cover-insurance.interface';
import {
  CLOSE_ICON_BUTTON,
  CLOSE_TEXT_BUTTON,
  PRE_EXISTING_CONDITIONS_HEADER
} from '../pano-change-cover-options/pano-change-cover-options.constants';
import { PanoContentDialogComponent } from '../pano-change-cover-options/pano-content-dialog/pano-content-dialog.component';

import { PanoChangeCoverReviewComponent } from './pano-change-cover-review.component';
import {
  CURRENT_COVER_AMOUNT_DEATH,
  CURRENT_COVER_AMOUNT_DEATH_AND_TPD,
  CURRENT_COVER_AMOUNT_TPD,
  DECREASE_REQUEST_AMOUNT_COVER_TYPE,
  DECREASE_REQUEST_UNITS_COVER_TYPE,
  INPUT_PARAMS,
  INPUT_PARAMS_AMOUNT,
  INPUT_PARAMS_SCI,
  INPUT_PARAMS_UNITS_OF_COVER,
  INSURANCE_POLICY,
  INSURANCE_POLICY_DEATH_AND_TPD,
  INSURANCE_POLICY_SCI,
  MOCK_ACCOUNT,
  MOCK_AEM_CONTENT_REVIEW,
  NEW_COVER_AMOUNT_TYPE,
  NEW_COVER_SCI_TYPE,
  NEW_COVER_TYPE,
  NEW_COVER_UNITS_TYPE,
  NEW_DECREASE_REQUEST_AMOUNT_COVER_TYPE,
  NEW_DECREASE_REQUEST_UNITS_COVER_TYPE
} from './pano-change-cover-review.component.spec.constants';

describe('PanoChangeCoverReviewComponent', () => {
  let component: PanoChangeCoverReviewComponent;
  let fixture: ComponentFixture<PanoChangeCoverReviewComponent>;
  let insuranceService: PanoInsuranceService;
  let linkService: PanoInsuranceSharedLinkService;
  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });
  const panoInsuranceUtil = jasmine.createSpyObj('panoInsuranceUtil', {
    getAccountActivationDaysFor90DaysCriteria: jasmine.createSpy(),
    isBTSFLMember: jasmine.createSpy(),
    isBTSuperMember: jasmine.createSpy()
  });

  const mockUiRouter = {
    stateService: {
      params: {
        mode: ''
      }
    }
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          ButtonModule,
          AlertModule,
          BrowserDynamicTestingModule,
          DataModule,
          RouterTestingModule,
          MatFormFieldModule,
          MatCheckboxModule,
          ReactiveFormsModule,
          HttpClientTestingModule,
          BrowserAnimationsModule,
          CommonModule,
          MatDialogModule
        ],
        declarations: [PanoChangeCoverReviewComponent],
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PageScrollService, useValue: pageScrollService },
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccountId: () => '12345'
            }
          },
          PanoInsuranceService,
          PanoInsuranceSharedLinkService,
          {
            provide: PanoUpgradePermissionService,
            useValue: { hasPermission: jasmine.createSpy() }
          },
          {
            provide: StateParams,
            useValue: {
              accountId: 'EncodedAccountId'
            }
          },
          { provide: PanoInsuranceUtil, useValue: panoInsuranceUtil }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoChangeCoverReviewComponent);
    component = fixture.componentInstance;
    insuranceService = TestBed.inject(PanoInsuranceService);
    linkService = TestBed.inject(PanoInsuranceSharedLinkService);
    component.cmsContent = MOCK_AEM_CONTENT_REVIEW;
    component.account = MOCK_ACCOUNT;
  });

  describe('Component', () => {
    beforeEach(() => {
      component.insurance = INSURANCE_POLICY;
      component.newCoverType = NEW_COVER_TYPE;
    });

    describe('ngOnInit', () => {
      it('should create a correct termsAndCondition Form', () => {
        component.ngOnInit();

        const preExistingControl = component.checkTermsAndCondition.controls['preExisting'];
        preExistingControl.setValue('');
        expect(preExistingControl.valid).toBeFalsy();

        preExistingControl.setValue(true);
        expect(preExistingControl.valid).toBeTruthy();

        const acknowledgeControl = component.checkTermsAndCondition.controls['acknowledge'];
        acknowledgeControl.setValue('');
        expect(acknowledgeControl.valid).toBeFalsy();

        preExistingControl.setValue(true);
        expect(preExistingControl.valid).toBeTruthy();

        const pageScrollOptions = {
          document: (component as any).document,
          scrollTarget: '.top-scroll',
          duration: 200
        };
        expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
      });

      it('should set cover type and check terms and conditions for decrease request', () => {
        spyOn(component, 'checkTermsAndConditionDecreaseRequestCover');
        spyOn(component, 'setDecreaseRequestCoverType');

        component.mode = CoverMode.DECREASE_REQUEST;
        component.ngOnInit();

        expect(component.checkTermsAndConditionDecreaseRequestCover).toHaveBeenCalled();
        expect(component.setDecreaseRequestCoverType).toHaveBeenCalled();
      });

      it('should show review message and check terms and conditions', () => {
        spyOn(component, 'checkTermsAndConditionChangeCover');
        spyOn(component, 'showReviewMsg');

        component.mode = CoverMode.CHANGE;
        component.ngOnInit();

        expect(component.checkTermsAndConditionChangeCover).toHaveBeenCalled();
        expect(component.showReviewMsg).toHaveBeenCalled();
      });
    });

    describe('checkTermsAndConditionDecreaseRequestCover', () => {
      it('should check terms and conditions decrease request cover', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.checkTermsAndConditionDecreaseRequestCover();

        const acknowledgeControl = component.checkTermsAndCondition.controls['acknowledge'];
        acknowledgeControl.setValue('');
        expect(acknowledgeControl.valid).toBeFalsy();

        acknowledgeControl.setValue(true);
        expect(acknowledgeControl.valid).toBeTruthy();
      });
    });

    describe('setPDSLink', () => {
      it('should populate PDS link', () => {
        const spyLink = spyOn(linkService, 'getUrl').and.returnValue('pdsUrl');

        component.setPDSLink();

        expect(spyLink).toHaveBeenCalled();
        expect(component.productDisclosureStatementLink).toBe('pdsUrl');
      });
    });

    describe('setAemMessages', () => {
      it('should populate pre-existing conditions message', () => {
        component.setAemMessages();

        expect(component.preExistingConditionsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[8].data.description);
      });

      it('should populate correct messages when changing an active policy to increase cover', () => {
        component.mode = CoverMode.CHANGE;
        component.insurance = INSURANCE_POLICY_DEATH_AND_TPD;
        component.isIncrease = true;

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[0].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[1].data.description);
      });

      it('should populate correct messages when changing an active policy to decrease cover', () => {
        component.mode = CoverMode.CHANGE;
        component.insurance = INSURANCE_POLICY_DEATH_AND_TPD;
        component.isIncrease = false;

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[2].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[3].data.description);
      });

      it('should populate correct messages when changing a pending policy', () => {
        component.mode = CoverMode.CHANGE;

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[4].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[5].data.description);
      });

      it('should populate correct messages when decreasing cover', () => {
        component.mode = CoverMode.DECREASE;
        component.currentCoverType = CURRENT_COVER_AMOUNT_DEATH;

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[6].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[7].data.description);
      });

      it('should populate correct messages when decreasing request sum insure', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insurance = INSURANCE_POLICY;
        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[9].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[12].data.description);
      });

      it('should populate correct messages when decreasing request units of cover', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insurance = INSURANCE_POLICY_DEATH_AND_TPD;

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[10].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[12].data.description);
      });

      it('should populate correct messages when decreasing request for SCI', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.insurance = INSURANCE_POLICY_SCI;

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[11].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_REVIEW[12].data.description);
      });
    });

    describe('setDecreaseRequestCoverType', () => {
      it('should set decrease request correct new amount cover type', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.newCoverType = DECREASE_REQUEST_AMOUNT_COVER_TYPE;

        component.setDecreaseRequestCoverType();

        expect(component.newCoverType.coverType).toEqual(NEW_DECREASE_REQUEST_AMOUNT_COVER_TYPE.coverType);
        expect(component.newCoverType.coverAmountType).toEqual(NEW_DECREASE_REQUEST_AMOUNT_COVER_TYPE.coverAmountType);
      });

      it('should set decrease request correct new units cover type', () => {
        component.mode = CoverMode.DECREASE_REQUEST;
        component.newCoverType = DECREASE_REQUEST_UNITS_COVER_TYPE;

        component.setDecreaseRequestCoverType();

        expect(component.newCoverType.coverType).toEqual(NEW_DECREASE_REQUEST_UNITS_COVER_TYPE.coverType);
        expect(component.newCoverType.coverAmountType).toEqual(NEW_DECREASE_REQUEST_UNITS_COVER_TYPE.coverAmountType);
        expect(component.newCoverType.requestUnitsCover).toEqual(
          NEW_DECREASE_REQUEST_UNITS_COVER_TYPE.requestUnitsCover
        );
      });
    });

    describe('ngAfterViewInit', () => {
      it('asks parent to reset focus', () => {
        spyOn(component.resetFocus, 'emit');

        component.ngAfterViewInit();

        expect(component.resetFocus.emit).toHaveBeenCalled();
      });
    });

    describe('navigateToOptionsScreen', () => {
      it('should emit updateState event', () => {
        spyOn(component.updateState, 'emit');

        component.navigateToOptionsScreen();
        expect(component.updateState.emit).toHaveBeenCalled();
      });
    });

    describe('submitForm', () => {
      beforeEach(() => {
        component.ngOnInit();
      });

      describe('for non sci', () => {
        it('should call submitForm api with correct params', () => {
          component.insurance = INSURANCE_POLICY;
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitInsurance').and.returnValue(of({}));

          component.submitForm();

          expect(insuranceService.submitInsurance).toHaveBeenCalledWith('12345', INPUT_PARAMS);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeFalsy();
          expect(component.updateState.emit).toHaveBeenCalled();
        });

        it('should not change the state and make submitting false on error', () => {
          component.insurance = INSURANCE_POLICY;
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitInsurance').and.returnValue(throwError('error'));

          component.submitForm();

          expect(insuranceService.submitInsurance).toHaveBeenCalledWith('12345', INPUT_PARAMS);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeTruthy();
          expect(component.updateState.emit).not.toHaveBeenCalled();

          const pageScrollOptions = {
            document: (component as any).document,
            scrollTarget: '.top-scroll',
            scrollViews: [document.querySelector('.layout-scroll')],
            duration: 200
          };
          expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
        });

        it('should not call submitForm api if terms and conditions not checked', () => {
          spyOn(insuranceService, 'submitInsurance');

          component.submitForm();

          expect(insuranceService.submitInsurance).not.toHaveBeenCalled();
        });

        it('should call submitForm decrease request api with correct params sum insured', () => {
          component.insurance = INSURANCE_POLICY;
          component.mode = CoverMode.DECREASE_REQUEST;
          component.newCoverType = NEW_COVER_AMOUNT_TYPE;
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitChangeRequest').and.returnValue(of({}));

          component.submitForm();

          expect(insuranceService.submitChangeRequest).toHaveBeenCalledWith('12345', INPUT_PARAMS_AMOUNT);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeFalsy();
          expect(component.updateState.emit).toHaveBeenCalled();
        });

        it('should show submit change request error', () => {
          component.insurance = INSURANCE_POLICY;
          component.mode = CoverMode.DECREASE_REQUEST;
          component.newCoverType = NEW_COVER_AMOUNT_TYPE;
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitChangeRequest').and.returnValue(throwError('error'));

          component.submitForm();

          expect(insuranceService.submitChangeRequest).toHaveBeenCalledWith('12345', INPUT_PARAMS_AMOUNT);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeTruthy();
          expect(component.updateState.emit).not.toHaveBeenCalled();
        });
      });

      describe('for non sci units', () => {
        beforeEach(() => {
          component.mode = CoverMode.DECREASE_REQUEST;
          component.insurance = INSURANCE_POLICY_DEATH_AND_TPD;
          component.newCoverType = NEW_COVER_UNITS_TYPE;
        });

        it('should call submitForm decrease request api with correct params units of cover', () => {
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitChangeRequest').and.returnValue(of({}));

          component.submitForm();

          expect(insuranceService.submitChangeRequest).toHaveBeenCalledWith('12345', INPUT_PARAMS_UNITS_OF_COVER);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeFalsy();
          expect(component.updateState.emit).toHaveBeenCalled();
        });

        it('should not change the state and make submitting false on error on units of cover', () => {
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitChangeRequest').and.returnValue(throwError('error'));

          component.submitForm();

          expect(insuranceService.submitChangeRequest).toHaveBeenCalledWith('12345', INPUT_PARAMS_UNITS_OF_COVER);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeTruthy();
          expect(component.updateState.emit).not.toHaveBeenCalled();

          const pageScrollOptions = {
            document: (component as any).document,
            scrollTarget: '.top-scroll',
            scrollViews: [document.querySelector('.layout-scroll')],
            duration: 200
          };
          expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
        });

        it('should not call submitForm api if terms and conditions not checked on units of cover', () => {
          spyOn(insuranceService, 'submitChangeRequest');

          component.submitForm();

          expect(insuranceService.submitChangeRequest).not.toHaveBeenCalled();
        });
      });

      describe('for SCI cover', () => {
        beforeEach(() => {
          component.mode = CoverMode.DECREASE_REQUEST;
          component.insurance = INSURANCE_POLICY_SCI;
          component.newCoverType = NEW_COVER_SCI_TYPE;
        });

        it('should call submitForm decrease request api with correct params SCI cover', () => {
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitChangeRequest').and.returnValue(of({}));

          component.submitForm();

          expect(insuranceService.submitChangeRequest).toHaveBeenCalledWith('12345', INPUT_PARAMS_SCI);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeFalsy();
          expect(component.updateState.emit).toHaveBeenCalled();
        });

        it('should not change the state and make submitting false on error on SCI cover', () => {
          component.checkTermsAndCondition.controls['preExisting'].setValue(true);
          component.checkTermsAndCondition.controls['acknowledge'].setValue(true);
          spyOn(component.updateState, 'emit');
          spyOn(insuranceService, 'submitChangeRequest').and.returnValue(throwError('error'));

          component.submitForm();

          expect(insuranceService.submitChangeRequest).toHaveBeenCalledWith('12345', INPUT_PARAMS_SCI);
          expect(component.submitting).toBeFalsy();
          expect(component.submitError).toBeTruthy();
          expect(component.updateState.emit).not.toHaveBeenCalled();

          const pageScrollOptions = {
            document: (component as any).document,
            scrollTarget: '.top-scroll',
            scrollViews: [document.querySelector('.layout-scroll')],
            duration: 200
          };
          expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
        });

        it('should not call submitForm api if terms and conditions not checked on SCI cover', () => {
          spyOn(insuranceService, 'submitChangeRequest');

          component.submitForm();

          expect(insuranceService.submitChangeRequest).not.toHaveBeenCalled();
        });
      });
    });

    describe('showReviewMsg', () => {
      it('should set showDecreaseReviewMsgDeath to true for policy type death when account activation days > 90', () => {
        component.mode = CoverMode.DECREASE;
        component.currentCoverType = CURRENT_COVER_AMOUNT_DEATH;
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);

        component.showReviewMsg();

        expect(component.showDecreaseReviewMsgDeath).toBe(true);
      });

      it('should set showDecreaseReviewMsgDeathAndTpd to true for policy type DeathAndTPD when account activation days > 90', () => {
        component.mode = CoverMode.DECREASE;
        component.currentCoverType = CURRENT_COVER_AMOUNT_DEATH_AND_TPD;
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(95);

        component.showReviewMsg();

        expect(component.showDecreaseReviewMsgDeathAndTpd).toBe(true);
      });

      it('should NOT set showDecreaseReviewMsgDeath or showDecreaseReviewMsgDeathAndTpd to true when account activation days < 90', () => {
        component.mode = CoverMode.DECREASE;
        component.currentCoverType = CURRENT_COVER_AMOUNT_DEATH_AND_TPD;
        panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria.and.returnValue(85);

        component.showReviewMsg();

        expect(component.showDecreaseReviewMsgDeathAndTpd).toBe(false);
        expect(component.showDecreaseReviewMsgDeath).toBe(false);
      });

      it('should not update any flag for other policy types', () => {
        component.mode = CoverMode.DECREASE;
        component.currentCoverType = CURRENT_COVER_AMOUNT_TPD;

        component.showReviewMsg();

        expect(component.showDecreaseReviewMsgDeathAndTpd).toBe(false);
        expect(component.showDecreaseReviewMsgDeath).toBe(false);
        expect(component.showReviewCancelMsg).toBe(false);
      });

      it('should set showReviewCancelMsg to true when current cover type is death and tpd', () => {
        component.mode = CoverMode.CHANGE;
        component.currentCoverType = CURRENT_COVER_AMOUNT_DEATH_AND_TPD;
        component.newCoverType = NEW_COVER_TYPE;

        component.showReviewMsg();

        expect(component.showReviewCancelMsg).toBe(true);
      });

      it('should not set showReviewCancelMsg to true when current cover type is not death and tpd', () => {
        component.mode = CoverMode.CHANGE;
        component.currentCoverType = CURRENT_COVER_AMOUNT_DEATH;
        component.newCoverType = NEW_COVER_TYPE;

        component.showReviewMsg();

        expect(component.showReviewCancelMsg).toBe(false);
      });
    });

    describe('openPreExistingConditionsDialog', () => {
      it('should open dialog with expected settings', () => {
        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        const expectedConfig = {
          ...DIALOG_CONFIG.DEFAULT,
          autoFocus: false,
          ariaLabel: 'Open pre-existing conditions information dialog',
          data: {
            headerText: PRE_EXISTING_CONDITIONS_HEADER,
            descriptionText: MOCK_AEM_CONTENT_REVIEW[8].data.description,
            closeButton: CLOSE_TEXT_BUTTON,
            closeIcon: CLOSE_ICON_BUTTON
          }
        };
        component.ngOnInit();

        component.openPreExistingConditionsDialog();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoContentDialogComponent, expectedConfig);
      });
    });
  });

  describe('View', () => {
    beforeEach(() => {
      component.hideChangeButton = false;
      component.insurance = INSURANCE_POLICY;
      component.newCoverType = NEW_COVER_TYPE;
    });

    describe('non sci', () => {
      beforeEach(() => {
        fixture.detectChanges();
      });

      it('should show the correct insurance details', () => {
        const insurancePolicyNameField = fixture.debugElement.query(By.css('.ts-insurance-policy-name'));
        expect(insurancePolicyNameField.nativeElement.innerHTML).toBe('Income Protection');

        const insuranceSumInsuredField = fixture.debugElement.query(By.css('.ts-insurance-sumInsured'));
        expect(insuranceSumInsuredField.nativeElement.innerHTML).toBe('$4,521.00');
      });

      it('should show monthly premium as Not applicable if its 0 for BYO cover', () => {
        component.insurance = IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[0];
        component.mode = CoverMode.DECREASE_REQUEST;
        fixture.detectChanges();

        const premiumEl = fixture.debugElement.query(By.css('.ts-insurance-premium'));

        expect(premiumEl.nativeElement.innerText).toBe('Not applicable');
      });

      it('should not show monthly premium as Not applicable if its not 0 or not BYO cover', () => {
        component.insurance = IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[1];
        component.mode = CoverMode.DECREASE_REQUEST;
        fixture.detectChanges();

        const premiumEl = fixture.debugElement.query(By.css('.ts-insurance-premium'));

        expect(premiumEl.nativeElement.innerText).toBe('$1.00');
      });

      it('should show changeFormButton when hideChangeButton is false', () => {
        spyOn(component, 'navigateToOptionsScreen');
        spyOn(component, 'submitForm');

        const changeFormButton = fixture.debugElement.queryAll(By.css('bt-button'))[0];
        expect(changeFormButton).toBeTruthy();

        changeFormButton.triggerEventHandler('btClick', null);
        fixture.detectChanges();
        expect(component.navigateToOptionsScreen).toHaveBeenCalled();
        expect(component.submitForm).not.toHaveBeenCalled();
      });

      it('should show submit button and should call submitForm when clicked on submit button', () => {
        spyOn(component, 'submitForm');
        component.checkTermsAndCondition.get('preExisting').setValue(true);
        component.checkTermsAndCondition.get('acknowledge').setValue(true);

        const submitButton = fixture.debugElement.queryAll(By.css('bt-button'))[1];
        expect(submitButton).toBeTruthy();

        const form = fixture.debugElement.query(By.css('form'));
        form.triggerEventHandler('ngSubmit', null);
        fixture.detectChanges();
        expect(component.submitForm).toHaveBeenCalled();
        expect(component.checkTermsAndCondition.disabled).toBe(false);
      });

      it('should navigate back when clicked on cancel', () => {
        spyOn(insuranceService, 'navigateToOverview');
        spyOn(component, 'submitForm');

        const cancelButton = fixture.debugElement.query(By.css('.js-test-cancel-button'));
        expect(cancelButton).toBeTruthy();

        cancelButton.triggerEventHandler('btClick', null);
        expect(insuranceService.navigateToOverview).toHaveBeenCalled();
        expect(component.submitForm).not.toHaveBeenCalled();
      });

      it('should have product disclosure statement Link', () => {
        const el = fixture.debugElement.query(By.css('.js-test-product-disclosure-statement-Link'));

        expect(el.nativeElement.innerText).toBe('Product Disclosure Statement');
      });

      it('should have pre existing conditions button', () => {
        const el = fixture.debugElement.query(By.css('.js-test-pre-existing-conditions'));

        expect(el.nativeElement.innerText).toBe('pre-existing conditions');
      });
    });

    describe('for SCI', () => {
      beforeEach(() => {
        component.insurance = INSURANCE_POLICY_SCI;
        component.newCoverType = NEW_COVER_SCI_TYPE;
        fixture.detectChanges();
      });

      it('should show waiting period, benefit period under current cover section', () => {
        const insuranceWaitingPeriodField = fixture.debugElement.query(By.css('.ts-insurance-waiting-period'));
        expect(insuranceWaitingPeriodField.nativeElement.innerText).toBe('2 days');

        const insuranceBenefitPeriodField = fixture.debugElement.query(By.css('.ts-insurance-benefit-period'));
        expect(insuranceBenefitPeriodField.nativeElement.innerText).toBe('30 years');
      });

      it('should show waiting period, benefit period under new cover section', () => {
        const insuranceWaitingPeriodField = fixture.debugElement.query(
          By.css('.ts-insurance-waiting-period-new-cover')
        );
        expect(insuranceWaitingPeriodField.nativeElement.innerText).toBe('30 days');

        const insuranceBenefitPeriodField = fixture.debugElement.query(
          By.css('.ts-insurance-benefit-period-new-cover')
        );
        expect(insuranceBenefitPeriodField.nativeElement.innerText).toBe('2 years');
      });
    });
  });
});
