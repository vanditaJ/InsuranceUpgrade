import { TestBed, waitForAsync } from '@angular/core/testing';

import { PMIF_DETAILS, PYS_DETAILS } from './pano-insurance-policies.constants';
import { PanoInsurancePoliciesUtil } from './pano-insurance-policies.util';
import {
  MOCK_BTSFL_POLICY_ACTIVE_AFTER_30_DAYS,
  MOCK_BTSFL_POLICY_AFTER_30_DAYS,
  MOCK_BTSFL_POLICY_WITHIN_30_DAYS,
  MOCK_CANCELLED_POLICY,
  MOCK_EMPLOYER_FUNDED_POLICY,
  MOCK_MULTIPLE_POLICY_PYSPMIF_REQUIRED,
  MOCK_NOT_COMBINEDPYSPMIF_POLICY,
  MOCK_NO_OCCUPATION_CODE_POLICY,
  MOCK_OCCUPATION_CODE_POLICY,
  MOCK_SINGLE_ACTIVE_FUTURE_POLICY_PYS_REQUIRED,
  MOCK_SINGLE_ACTIVE_POLICY_PYS_REQUIRED,
  MOCK_SINGLE_POLICY_PMIF_OPTED_IN,
  MOCK_SINGLE_POLICY_PMIF_REQUIRED,
  MOCK_SINGLE_POLICY_PMIF_REQUIRED_RISK_COMMENCEMENT,
  MOCK_SINGLE_POLICY_PYSPMIF_REQUIRED,
  MOCK_SINGLE_POLICY_PYS_OPTED_IN,
  MOCK_SINGLE_POLICY_PYS_REQUIRED,
  MOCK_SINGLE_POLICY_PYS_REQUIRED_RISK_COMMENCEMENT,
  MOCK_WGP_POLICY
} from './pano-insurance-policies.util.spec.constants';

describe('PanoInsurancePoliciesUtil ', () => {
  let panoInsurancePoliciesUtil: PanoInsurancePoliciesUtil;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        providers: [PanoInsurancePoliciesUtil]
      });
    })
  );
  beforeEach(() => {
    panoInsurancePoliciesUtil = TestBed.inject(PanoInsurancePoliciesUtil);
  });

  describe('pysAndPMIFOptInRequired', () => {
    it('should be false When pmif not required', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequiredForPolicies([]);
      expect(response).toBe(false);
    });

    it('should be true When both pmif and pys not opted in single policy', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequiredForPolicies([MOCK_SINGLE_POLICY_PYSPMIF_REQUIRED]);
      expect(response).toBe(true);
    });

    it('should be true When both pmif and pys not opted in across multiple policies', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequiredForPolicies(MOCK_MULTIPLE_POLICY_PYSPMIF_REQUIRED);
      expect(response).toBe(true);
    });
  });

  describe('pysOptInRequiredForPolicies', () => {
    it('should be false When no policies', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequiredForPolicies([]);
      expect(response).toBe(false);
    });

    it('should be true When pys not opted in', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequiredForPolicies([MOCK_SINGLE_POLICY_PYS_REQUIRED]);
      expect(response).toBe(true);
    });
  });

  describe('pmifOptInRequiredForPolicies', () => {
    it('should be false When no policies', () => {
      const response = panoInsurancePoliciesUtil.pmifOptInRequiredForPolicies([]);
      expect(response).toBe(false);
    });

    it('should be true When the pmif not opted in', () => {
      const response = panoInsurancePoliciesUtil.pmifOptInRequiredForPolicies([MOCK_SINGLE_POLICY_PMIF_REQUIRED]);
      expect(response).toBe(true);
    });
  });

  describe('pmifOptInRequired', () => {
    it('should be false When active', () => {
      const response = panoInsurancePoliciesUtil.pmifOptInRequired(MOCK_SINGLE_ACTIVE_POLICY_PYS_REQUIRED);
      expect(response).toBe(false);
    });

    it('should be true When the pmif not opted in', () => {
      const response = panoInsurancePoliciesUtil.pmifOptInRequired(MOCK_SINGLE_POLICY_PMIF_REQUIRED);
      expect(response).toBe(true);
    });
  });

  describe('pysOptInRequired', () => {
    it('should be false When start date in the future', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequired(MOCK_SINGLE_ACTIVE_FUTURE_POLICY_PYS_REQUIRED);
      expect(response).toBe(false);
    });

    it('should be true When active pys not opted in', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequired(MOCK_SINGLE_ACTIVE_POLICY_PYS_REQUIRED);
      expect(response).toBe(true);
    });

    it('should be true When the pys not opted in', () => {
      const response = panoInsurancePoliciesUtil.pysOptInRequired(MOCK_SINGLE_POLICY_PYS_REQUIRED);
      expect(response).toBe(true);
    });
  });

  describe('optInRequired', () => {
    it('should be true When the policy is pys', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(MOCK_EMPLOYER_FUNDED_POLICY, PYS_DETAILS);
      expect(response).toBe(true);
    });

    it('should be false When the automatic cover message is required', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(MOCK_BTSFL_POLICY_AFTER_30_DAYS, PYS_DETAILS);
      expect(response).toBe(false);
    });

    it('should be false When pys opt in date is greater than the risk commencement date', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(MOCK_SINGLE_POLICY_PYS_OPTED_IN, PYS_DETAILS);
      expect(response).toBe(false);
    });

    it('should be false When pmif opt in date is greater than the risk commencement date', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(MOCK_SINGLE_POLICY_PMIF_OPTED_IN, PMIF_DETAILS);
      expect(response).toBe(false);
    });

    it('should be true When no pys opt in date', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(MOCK_SINGLE_POLICY_PYS_REQUIRED, PYS_DETAILS);
      expect(response).toBe(true);
    });

    it('should be true When no pmif opt in date', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(MOCK_SINGLE_POLICY_PMIF_REQUIRED, PMIF_DETAILS);
      expect(response).toBe(true);
    });

    it('should be true When no pys/pmif detail specified', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(MOCK_SINGLE_POLICY_PMIF_REQUIRED, null);
      expect(response).toBe(true);
    });

    it('should be true When pys opt in date less than the risk commencement date', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(
        MOCK_SINGLE_POLICY_PYS_REQUIRED_RISK_COMMENCEMENT,
        PYS_DETAILS
      );
      expect(response).toBe(true);
    });

    it('should be true When pmif opt in date less than the risk commencement date', () => {
      const response = panoInsurancePoliciesUtil.optInRequired(
        MOCK_SINGLE_POLICY_PMIF_REQUIRED_RISK_COMMENCEMENT,
        PMIF_DETAILS
      );
      expect(response).toBe(true);
    });
  });

  describe('automaticCoverMessageRequired', () => {
    it('should be false When the policy is wgp', () => {
      const response = panoInsurancePoliciesUtil.automaticCoverMessageRequired(MOCK_WGP_POLICY);
      expect(response).toBe(false);
    });

    it('should be false When the policy is active', () => {
      const response = panoInsurancePoliciesUtil.automaticCoverMessageRequired(MOCK_SINGLE_ACTIVE_POLICY_PYS_REQUIRED);
      expect(response).toBe(false);
    });

    it('should be false When the policy is within 30 days', () => {
      const response = panoInsurancePoliciesUtil.automaticCoverMessageRequired(MOCK_BTSFL_POLICY_WITHIN_30_DAYS);
      expect(response).toBe(false);
    });

    it('should be true When the policy is after 30 days', () => {
      const response = panoInsurancePoliciesUtil.automaticCoverMessageRequired(MOCK_BTSFL_POLICY_AFTER_30_DAYS);
      expect(response).toBe(true);
    });
  });

  describe('checkActive', () => {
    it('should return false if status is not active', () => {
      const response = panoInsurancePoliciesUtil.checkActive(MOCK_NOT_COMBINEDPYSPMIF_POLICY[0]);
      expect(response).toBe(false);
    });

    it('should return true if status is cancelled', () => {
      const response = panoInsurancePoliciesUtil.checkActive(MOCK_CANCELLED_POLICY[1]);
      expect(response).toBe(true);
    });

    it('should return true if status is active and commencement date less than today', () => {
      const response = panoInsurancePoliciesUtil.checkActive(MOCK_CANCELLED_POLICY[2]);
      expect(response).toBe(true);
    });
  });

  describe('getSFLPolicyWithRiskCommencementDateGreaterThan30', () => {
    it('should return true if there is any one BT SFL policy with qualifier name as standard cover and the time since riskCommencementDate is 30 days', () => {
      const response = panoInsurancePoliciesUtil.getSFLPolicyWithRiskCommencementDateGreaterThan30([
        MOCK_BTSFL_POLICY_AFTER_30_DAYS
      ]);
      expect(response).toBe(true);
    });

    it('should return false if there is not single BT SFL policy with qualifier name as standard cover and the time since riskCommencementDate is 30 days', () => {
      const response = panoInsurancePoliciesUtil.getSFLPolicyWithRiskCommencementDateGreaterThan30([
        MOCK_BTSFL_POLICY_WITHIN_30_DAYS
      ]);
      expect(response).toBe(false);
    });

    it('should return false if policy is active', () => {
      const response = panoInsurancePoliciesUtil.getSFLPolicyWithRiskCommencementDateGreaterThan30([
        MOCK_BTSFL_POLICY_ACTIVE_AFTER_30_DAYS
      ]);
      expect(response).toBe(false);
    });
  });

  describe('isPolicySuitableForNoOccupationCodeAlert', () => {
    it('should return true if policy customer type is PCS and policy is not external and occupation class is null', () => {
      const isPolicySuitableForNoOccupationCodeAlert = panoInsurancePoliciesUtil.isPolicySuitableForNoOccupationCodeAlert(
        MOCK_NO_OCCUPATION_CODE_POLICY
      );
      expect(isPolicySuitableForNoOccupationCodeAlert).toBe(true);
    });

    it('should return false if policy customer type is NOT PCS', () => {
      const isPolicySuitableForNoOccupationCodeAlert = panoInsurancePoliciesUtil.isPolicySuitableForNoOccupationCodeAlert(
        MOCK_OCCUPATION_CODE_POLICY
      );
      expect(isPolicySuitableForNoOccupationCodeAlert).toBe(false);
    });

    it('should return false if policy is external', () => {
      const isPolicySuitableForNoOccupationCodeAlert = panoInsurancePoliciesUtil.isPolicySuitableForNoOccupationCodeAlert(
        MOCK_OCCUPATION_CODE_POLICY
      );
      expect(isPolicySuitableForNoOccupationCodeAlert).toBe(false);
    });

    it('should return false if occupation class is NOT null', () => {
      const isPolicySuitableForNoOccupationCodeAlert = panoInsurancePoliciesUtil.isPolicySuitableForNoOccupationCodeAlert(
        MOCK_OCCUPATION_CODE_POLICY
      );
      expect(isPolicySuitableForNoOccupationCodeAlert).toBe(false);
    });
  });

  describe('checkPmifPolicy', () => {
    it('should filter not active and requested policies when not pmif permission', () => {
      const response = panoInsurancePoliciesUtil.checkPmifPolicy(MOCK_MULTIPLE_POLICY_PYSPMIF_REQUIRED, false);
      expect(response.length).toEqual(1);
    });

    it('should not filter policies when pmif permission', () => {
      const response = panoInsurancePoliciesUtil.checkPmifPolicy(MOCK_MULTIPLE_POLICY_PYSPMIF_REQUIRED, true);
      expect(response.length).toEqual(2);
    });
  });
});
