export type FormFieldBoolean = {
  [key: string]: boolean;
};
