import { Component, HostListener, Input, OnInit } from '@angular/core';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';
import { UIRouter } from '@uirouter/core';
import { StateParams } from '@upgrade/upgrade.services';
import * as moment from 'moment-timezone';
import { finalize, take } from 'rxjs/operators';

import {
  ACCORDION_HEADER_ICON,
  DEFAULT_PAGE_LOADING,
  INVESTOR_ACCOUNT_ERROR_STATE,
  LEARN_ABOUT_INVESTMENTS_LINK,
  MAX_COLLAPSED_WIDTH,
  NEW_WINDOW_ICON
} from './pano-investment-fees.constants';
import { AemInvestmentFee } from './pano-investment-fees.interface';
import { PanoInvestmentFeesService } from './pano-investment-fees.service';

@Component({
  selector: 'pano-investment-fees',
  templateUrl: './pano-investment-fees.component.html',
  styleUrls: ['./pano-investment-fees.component.scss']
})
export class PanoInvestmentFeesComponent implements OnInit {
  @Input()
  account: Account;

  loading: boolean = true;
  dataLoading: boolean = true;
  textLoading: boolean = true;

  now: moment;
  disclaimer: string;

  lifestageFunds: AemInvestmentFee[];
  otherFunds: AemInvestmentFee[];
  textContent: object;
  navigationLinks: Array<Link>;

  screenWidth: number;
  expanded: boolean = true;

  readonly learnAboutLink: Link = LEARN_ABOUT_INVESTMENTS_LINK;
  readonly newWindowIcon: Icon = NEW_WINDOW_ICON;
  readonly accordionHeaderIcon: Icon = ACCORDION_HEADER_ICON;

  readonly loadingSpinner: Loading = DEFAULT_PAGE_LOADING;

  constructor(
    private panoInvestmentFeesService: PanoInvestmentFeesService,
    private route: UIRouter,
    private stateParams: StateParams,
    private disclaimerService: PanoDisclaimersService,
    private superLinkService: PanoSuperLinkService
  ) {}

  ngOnInit(): void {
    this.now = moment(new Date()).format('D MMM YYYY');
    this.disclaimer = this.disclaimerService.evaluateDisclaimer(this.account);

    this.configureLearnAboutLink();
    this.configureNavigationLinks();
    this.loadTextContent();
    this.loadInvestments();

    this.getScreenSize();
  }

  private loadInvestments(): void {
    this.panoInvestmentFeesService
      .getInvestments(this.account)
      .pipe(
        finalize(() => {
          this.dataLoading = false;
          this.loading = this.dataLoading || this.textLoading;
        })
      )
      .pipe(take(1))
      .subscribe(
        (fees: AemInvestmentFee[]) => {
          this.lifestageFunds = fees.filter(fee => fee.lifestage);
          this.otherFunds = fees.filter(fee => !fee.lifestage);
        },
        () => this.route.stateService.go(INVESTOR_ACCOUNT_ERROR_STATE, { accountId: this.account.key.accountId })
      );
  }

  private loadTextContent(): void {
    this.panoInvestmentFeesService
      .getTextContent()
      .pipe(
        finalize(() => {
          this.textLoading = false;
          this.loading = this.dataLoading || this.textLoading;
        })
      )
      .pipe(take(1))
      .subscribe(
        (textContent: object) => (this.textContent = textContent),
        () => this.route.stateService.go(INVESTOR_ACCOUNT_ERROR_STATE, { accountId: this.account.key.accountId })
      );
  }

  private configureLearnAboutLink() {
    const accountId = this.stateParams.accountId;
    // can't use internal link in pano as it is not using angular router
    this.learnAboutLink.link = `#/app/investor/account/${accountId}/learn-about-investments`;
  }

  private configureNavigationLinks() {
    const accountId = this.stateParams.accountId;
    this.navigationLinks = this.superLinkService.getLinks(
      [
        LinkType.PRODUCT_DISCLOSURE_STATEMENT,
        LinkType.SUPER_GUIDE,
        LinkType.ADDITIONAL_INFORMATION_BOOKLET,
        LinkType.PRODUCT_UPDATES,
        LinkType.PAST_PERFORMANCE_INFORMATION,
        LinkType.UNIT_PRICES_WGP,
        LinkType.UNIT_PRICES_NON_WGP,
        LinkType.BUY_SELL_SPREADS,
        LinkType.FEES
      ],
      accountId,
      this.account
    );
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize() {
    this.screenWidth = window.innerWidth;
    this.expanded = this.screenWidth > MAX_COLLAPSED_WIDTH;
  }
}
