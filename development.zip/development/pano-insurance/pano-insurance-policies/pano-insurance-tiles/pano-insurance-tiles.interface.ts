import { Icon } from '@bt/components/icon';

export interface InsuranceTile {
  icon: Icon;
  heading: string;
  align?: string;
  description: string;
}
