import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

@Component({
  selector: 'pano-pano-alert-dialog',
  templateUrl: './pano-alert-dialog.component.html'
})
export class PanoAlertDialogComponent {
  constructor(
    private readonly dialogRef: MatDialogRef<PanoAlertDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      headerText: string;
      descriptionText: string;
      alertButton: Button;
    }
  ) {}

  closeDialog(): void {
    this.dialogRef.close();
  }
}
