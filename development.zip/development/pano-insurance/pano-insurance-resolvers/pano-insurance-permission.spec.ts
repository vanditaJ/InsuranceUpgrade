import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { of } from 'rxjs';

import { PanoInsuranceService } from '../pano-insurance.service';

import { panoInsurancePermissionResolver } from './pano-insurance-permission.resolver';

describe('panoInsurancePermissionResolver', () => {
  let accountServiceSpyObj: jasmine.SpyObj<PanoUpgradeAccountService>;
  let panoInsuranceServiceSpyObj: jasmine.SpyObj<PanoInsuranceService>;
  let transition;
  let mockPermissions;
  const getObj: any = { get: () => {} };

  beforeEach(() => {
    accountServiceSpyObj = jasmine.createSpyObj('PanoUpgradeAccountService', ['getAccountId']);
    panoInsuranceServiceSpyObj = jasmine.createSpyObj('PanoInsuranceService', ['getPermissions']);
    transition = {
      injector: () => getObj
    };
    mockPermissions = {
      'insurance.aia.showManageInsurancePanel': 'true'
    };
  });

  it('calls panoInsurancePermissionResolver method', async () => {
    const accountId = '123';
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');
    getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
    getSpy.withArgs(PanoInsuranceService).and.returnValue(panoInsuranceServiceSpyObj);
    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoInsuranceServiceSpyObj.getPermissions.and.returnValue(of(mockPermissions));
    const promise = panoInsurancePermissionResolver(transition);
    const permission = await promise;
    expect(permission).toEqual(mockPermissions);
  });
});
