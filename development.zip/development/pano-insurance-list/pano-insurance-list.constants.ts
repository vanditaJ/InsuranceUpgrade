import { MatSnackBarConfig, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { SNACK_BAR_ACTION, SNACK_BAR_DEFAULT_CONFIG } from '@bt/components/snack-bar-template';
export const NOT_AVAIL: Icon = {
  name: 'icon-error',
  type: 'error',
  size: 'x-small'
};

export const IN_SUSPENSE: Icon = {
  name: 'icon-in-progress',

  size: 'x-small'
};

export const IN_FORCE: Icon = {
  name: 'icon-tick',
  type: 'success',
  size: 'x-small'
};
export const CONFIG = {
  type: 'info',
  shapeModifier: 'square',
  size: 'small'
};
export const KEEP_BTN: Button = {
  action: 'button',
  colourModifier: 'primary',
  label: 'Keep insurance',
  shapeModifier: 'square',
  size: 'medium',
  type: 'outline'
};

export const KEEP_LINK = {
  action: 'link',
  colourModifier: 'primary',
  label: 'keep your insurance',
  size: 'small',
  type: 'flat'
};

export const DIALOG_CANCEL_BUTTON: Button = {
  action: 'button',
  label: 'Cancel',
  size: 'large',
  colourModifier: 'primary',
  type: 'outline'
};

export const DIALOG_SUBMIT_BUTTON: Button = {
  action: 'button',
  label: 'Submit',
  size: 'large',
  colourModifier: 'primary',
  shapeModifier: 'square',
  type: 'solid'
};
export const DIALOG_SUCCESS = {
  type: 'success'
};

export const DIALOG_CLOSE_BUTTON: Button = {
  a11yProps: {
    ariaLabel: 'Close modal dialog'
  },
  action: 'button',
  icon: { name: 'icon-cross' },
  size: 'small',
  colourModifier: 'basic',
  type: 'flat'
};
export const SNACK_BAR_EXTERNAL_ASSETS_SUCCESS: MatSnackBarConfig<{
  header: string;
  message: string;
  action: string;
}> = {
  data: {
    header: 'Your insurance opt-in request has been submitted.',
    message: 'This may take up to 24 hours to process.',
    action: SNACK_BAR_ACTION.SUCCESS
  },
  duration: SNACK_BAR_DEFAULT_CONFIG.DURATION,
  panelClass: SNACK_BAR_DEFAULT_CONFIG.PANEL_CLASS,
  verticalPosition: SNACK_BAR_DEFAULT_CONFIG.VERTICAL_POSITION as MatSnackBarVerticalPosition
};
export const SNACK_BAR_EXTERNAL_ASSETS_NO_UNSAVED_CHANGES: MatSnackBarConfig<{ header: string; action: string }> = {
  data: {
    header: 'You have not made any changes.',
    action: SNACK_BAR_ACTION.INFO
  },
  duration: SNACK_BAR_DEFAULT_CONFIG.DURATION,
  panelClass: SNACK_BAR_DEFAULT_CONFIG.PANEL_CLASS,
  verticalPosition: SNACK_BAR_DEFAULT_CONFIG.VERTICAL_POSITION as MatSnackBarVerticalPosition
};
export const INVESTOR_INSURANCE_PYSOPTIN = 'investor.insurance.pysOptIn';
