import { EventEmitter, Injectable } from '@angular/core';
import { AbstractControl, FormArray, FormControl } from '@angular/forms';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';
import { Subscription } from 'rxjs';

import {
  MANAGED_FUND_ASSET_QUANTITY_REGEX,
  OTHER_ASSET_QUANTITY_REGEX
} from './pano-external-assets-constants/pano-external-assets.constants';
import { AssetTypeTotalDetails, ExternalAssetDeleteDetails } from './pano-external-assets.interfaces';

@Injectable()
export class PanoExternalAssetsCommonUtil {
  constructor(private copyMatrixPipe: CopyMatrixPipe) {}

  calculateAssetTypeTotalMarketValue(
    assetFormArray: FormArray,
    assetType: string,
    assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails>
  ): number {
    const totalMarketValue = assetFormArray
      ? assetFormArray.controls.reduce(
          (total: number, control: AbstractControl) => total + +control.get('marketValue').value,
          0
        )
      : 0;
    assetTotalMarketValueUpdate.emit({
      assetTypeTotalMarketValue: totalMarketValue,
      assetTypeCode: assetType
    });
    return totalMarketValue;
  }

  deleteAsset(
    assetToDeleteDetails: ExternalAssetDeleteDetails,
    assetToDelete: EventEmitter<ExternalAssetDeleteDetails>
  ): void {
    assetToDelete.emit(assetToDeleteDetails);
  }

  unregisterAssetEditControlsValueChanges(controlsValueChangesSubscriptions: Array<Subscription>): Array<Subscription> {
    controlsValueChangesSubscriptions.forEach(subscription => subscription.unsubscribe());
    return [];
  }

  registerAssetEditMarketValueControlsValueChanges(
    assetFormArray: FormArray,
    callbackCalculateTotalFunction: () => void
  ): Array<Subscription> {
    const controlsValueChangesSubscriptions: Subscription[] = [];
    assetFormArray.controls.forEach(fg => {
      controlsValueChangesSubscriptions.push(
        fg.get('marketValue').valueChanges.subscribe(() => {
          if (fg.get('marketValue').valid) {
            callbackCalculateTotalFunction();
          }
        })
      );
    });
    return controlsValueChangesSubscriptions;
  }

  getErrorMessagesForQuantity(quantityControl: FormControl): string {
    let errMessage: string = '';
    if (quantityControl.errors) {
      if (quantityControl.errors.required) {
        errMessage = this.copyMatrixPipe.transform('Err.IP-0398');
      } else if (quantityControl.errors.min) {
        if (Number(quantityControl.value) <= 0) {
          errMessage = this.copyMatrixPipe.transform('Err.IP-0382');
        } else {
          errMessage = this.copyMatrixPipe.transform('Err.IP-0381');
        }
      } else if (quantityControl.errors.pattern) {
        if (
          quantityControl.errors.pattern.requiredPattern === MANAGED_FUND_ASSET_QUANTITY_REGEX.toString() &&
          !isNaN(quantityControl.value)
        ) {
          errMessage = this.copyMatrixPipe.transform('Err.IP-1210');
        } else if (
          quantityControl.errors.pattern.requiredPattern === OTHER_ASSET_QUANTITY_REGEX.toString() &&
          !isNaN(quantityControl.value)
        ) {
          errMessage = this.copyMatrixPipe.transform('Err.IP-0384');
        } else if (quantityControl.errors.pattern.requiredPattern === '/^[0-9]*$/' && !isNaN(quantityControl.value)) {
          errMessage = this.copyMatrixPipe.transform('Err.IP-0381');
        } else {
          errMessage = this.copyMatrixPipe.transform('Err.IP-0387');
        }
      } else {
        errMessage = this.copyMatrixPipe.transform('Err.IP-1240');
      }
    }
    return errMessage;
  }
}
