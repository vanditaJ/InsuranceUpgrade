import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

@Component({
  selector: 'pano-pano-confirm-dialog',
  templateUrl: './pano-confirm-dialog.component.html'
})
export class PanoConfirmDialogComponent {
  constructor(
    public readonly dialogRef: MatDialogRef<PanoConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      actionConfirm: boolean;
      actionCancel: boolean;
      headerText: string;
      descriptionText: string;
      confirmButton: Button;
      cancelButton: Button;
    }
  ) {}

  confirmAction(action: boolean): void {
    this.dialogRef.close(action);
  }
}
