import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Icon } from '@bt/components/icon';
import * as moment from 'moment-timezone';

import * as EXTERNAL_ASSETS from '../../pano-external-assets-constants/pano-external-assets.constants';
import { AssetClasses } from '../../pano-external-assets.interfaces';
import { PanoAddAssetFormCreator } from '../pano-add-asset-form-creator';

@Component({
  selector: 'pano-add-asset-managed-portfolio',
  templateUrl: './pano-add-asset-managed-portfolio.component.html'
})
export class PanoAddAssetManagedPortfolioComponent implements OnInit {
  @Input() addAssetForm: FormGroup;
  @Input() assetClasses: AssetClasses[];

  assetDetails: FormGroup;
  datePickerIcon: Icon = EXTERNAL_ASSETS.DATE_PICKER_ICON;
  today: Date = moment().tz('Australia/Sydney');

  constructor(private externalAssetsAddFormCreator: PanoAddAssetFormCreator) {}

  ngOnInit(): void {
    this.assetDetails = this.externalAssetsAddFormCreator.createAddAssetForm('mp');
    this.addAssetForm.setControl('assetDetails', this.assetDetails);
  }
}
