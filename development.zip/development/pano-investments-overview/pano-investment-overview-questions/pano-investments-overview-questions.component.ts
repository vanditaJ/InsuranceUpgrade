import { Component, Input, OnInit } from '@angular/core';
import { Icon } from '@bt/components/icon';
import { AemTitleLink } from '@investor/account/pano-shared/interfaces';
import { finalize, take } from 'rxjs/operators';

import { EXPANSION_ICON } from './pano-investments-overview-questions.constants';
import { FaqContent } from './pano-investments-overview-questions.interface';
import { PanoInvestmentsOverviewQuestionsService } from './pano-investments-overview-questions.service';

@Component({
  selector: 'pano-investments-overview-questions',
  templateUrl: './pano-investments-overview-questions.component.html',
  styleUrls: ['./pano-investments-overview-questions.component.scss']
})
export class PanoInvestmentsOverviewQuestionsComponent implements OnInit {
  @Input() apirCode: string;

  faqContent: FaqContent[];
  loading: boolean = true;
  expansionIcon: Icon = EXPANSION_ICON;

  constructor(private service: PanoInvestmentsOverviewQuestionsService) {}

  ngOnInit(): void {
    this.loadContent();
  }

  private loadContent() {
    this.service
      .getAemContent(this.apirCode)
      .pipe(
        take(1),
        finalize(() => (this.loading = false))
      )
      .subscribe((res: AemTitleLink) => {
        this.faqContent = res.details.map(content => {
          return {
            header: content.data.headerText,
            description: content.data.description
          };
        });
      });
  }
}
