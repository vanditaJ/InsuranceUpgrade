import { AbstractControl, FormControl, ValidatorFn } from '@angular/forms';

export function assetCodeValidator(): ValidatorFn {
  const assetCode = new RegExp(/^[a-zA-Z]{3}[0-9]{4}[a-zA-Z]{2}/);

  return (control: AbstractControl): { [key: string]: boolean | null } => {
    if (!control.value) {
      return null;
    }
    return assetCode.test(control.value) ? null : { assetCode: true };
  };
}

export function alphaNumericValidator(): ValidatorFn {
  const alphanumeric = new RegExp(/^[A-Za-z0-9]*$/);

  return (control: AbstractControl): { [key: string]: boolean | null } => {
    if (!control.value) {
      return null;
    }
    return alphanumeric.test(control.value) ? null : { nonAlphaNumeric: true };
  };
}

export const assetSelectedValidator = (control: FormControl) => {
  return control.value && !(control.value.assetCode || control.value.assetName) ? { assetSelected: true } : null;
};
