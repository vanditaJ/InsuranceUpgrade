import { Injectable } from '@angular/core';
import { BtError, DataService } from '@bt/services/data';
import { Observable } from 'rxjs';

import {
  API_GET_ACCOUNTING_SOFTWARE_URL,
  API_GET_ASSETS_URL,
  API_GET_EXTERNAL_ASSETS_DETAILED_URL,
  API_GET_EXTERNAL_ASSETS_SUMMARY_URL,
  API_GET_INVESTOR_ASSET_TYPES,
  API_GET_INVESTOR_PROPERTY_TYPES,
  API_INVESTOR_ACCOUNTS_BASE_URL,
  API_INVESTOR_ASSET_BASE_URL,
  API_POST_EXTERNAL_ASSETS_URL
} from './pano-external-assets-constants/pano-external-assets.constants';
import {
  GENERIC_CACHE_OPTIONS,
  GENERIC_OPTIONS,
  GENERIC_SAVE_OPTIONS,
  GET_INVESTOR_ASSET_TYPES_OPTIONS
} from './pano-external-assets.constants';
import {
  AccountingSoftwareStatus,
  Asset,
  AssetLatestPrice,
  AssetType,
  ExternalAssetsSaveDetails,
  ExternalAssetsValuationDetails,
  ExternalAssetTotalValuation,
  PropertyType
} from './pano-external-assets.interfaces';

@Injectable()
export class PanoExternalAssetsService {
  constructor(
    private externalAssetsDataService: DataService<ExternalAssetsValuationDetails | BtError>,
    private assetTypeDataService: DataService<Array<AssetType> | BtError>,
    private softWareStatusDataService: DataService<AccountingSoftwareStatus | BtError>,
    private valuationDataService: DataService<ExternalAssetTotalValuation | BtError>,
    private assetPriceDataService: DataService<AssetLatestPrice | BtError>,
    private assetDetailsDataService: DataService<Array<Asset> | BtError>,
    private propertyTypeDataService: DataService<Array<PropertyType> | BtError>
  ) {}

  getExternalAssets(accountId: string): Observable<ExternalAssetsValuationDetails | BtError> {
    return this.externalAssetsDataService.retrieve(
      `${API_INVESTOR_ACCOUNTS_BASE_URL}${accountId}${API_GET_EXTERNAL_ASSETS_DETAILED_URL}`,
      GENERIC_OPTIONS
    );
  }

  saveExternalAssets(
    accountId: string,
    externalAssetsSaveDetails: ExternalAssetsSaveDetails
  ): Observable<ExternalAssetsValuationDetails | BtError> {
    return this.externalAssetsDataService.update(
      `${API_INVESTOR_ACCOUNTS_BASE_URL}${accountId}${API_POST_EXTERNAL_ASSETS_URL}`,
      externalAssetsSaveDetails,
      GENERIC_SAVE_OPTIONS
    );
  }

  getAssetTypes(): Observable<Array<AssetType> | BtError> {
    return this.assetTypeDataService.retrieve(`${API_GET_INVESTOR_ASSET_TYPES}`, GET_INVESTOR_ASSET_TYPES_OPTIONS);
  }

  getAccountingSoftwareStatus(accountId: string): Observable<AccountingSoftwareStatus | BtError> {
    return this.softWareStatusDataService.retrieve(
      `${API_INVESTOR_ACCOUNTS_BASE_URL}${accountId}${API_GET_ACCOUNTING_SOFTWARE_URL}`,
      GENERIC_OPTIONS
    );
  }

  getValuationForExternalAsset(accountId: string): Observable<ExternalAssetTotalValuation | BtError> {
    return this.valuationDataService.retrieve(
      `${API_INVESTOR_ACCOUNTS_BASE_URL}${accountId}${API_GET_EXTERNAL_ASSETS_SUMMARY_URL}`,
      GENERIC_OPTIONS
    );
  }

  getAssetLatestPrice(assetId: string): Observable<AssetLatestPrice | BtError> {
    return this.assetPriceDataService.retrieve(`${API_INVESTOR_ASSET_BASE_URL}${assetId}`, GENERIC_CACHE_OPTIONS);
  }

  getPanoramaAssetDetails(assetTypeCode: string): Observable<Array<Asset> | BtError> {
    return this.assetDetailsDataService.retrieve(
      `${API_GET_INVESTOR_ASSET_TYPES}/${assetTypeCode}${API_GET_ASSETS_URL}`,
      GENERIC_CACHE_OPTIONS
    );
  }

  getPropertyTypes(): Observable<Array<PropertyType> | BtError> {
    return this.propertyTypeDataService.retrieve(`${API_GET_INVESTOR_PROPERTY_TYPES}`, GENERIC_CACHE_OPTIONS);
  }
}
