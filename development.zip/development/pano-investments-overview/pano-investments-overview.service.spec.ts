import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { DataModule, DataService } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeClientInfoService } from '@upgrade/upgrade.services';
import * as moment from 'moment-timezone';
import { of, throwError } from 'rxjs';

import {
  CMS_CONTENT_PATH_SUFFIX,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_SECTOR_WEIGHTS_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_TOP_10_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_REGION_WEIGHTS_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_TOP_10_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_COMMON_CONTENT_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH,
  GENERIC_OPTIONS
} from './pano-investments-overview.constants';
import { MOCK_FULLY_ALLOCATED_LIFESTAGE } from './pano-investments-overview.constants.spec';
import { InvestmentAllocation, PersonalRateOfReturn } from './pano-investments-overview.interface';
import { PanoInvestmentsOverviewService } from './pano-investments-overview.service';

describe('PanoInvestmentsOverviewService', () => {
  let investmentsOverviewService: PanoInvestmentsOverviewService;

  let dataService: DataService<any>;

  const successHandler: jasmine.Spy = jasmine.createSpy('successHandler');
  const errorHandler: jasmine.Spy = jasmine.createSpy('errorHandler');

  const PERSONAL_RATE_OF_RETURN: PersonalRateOfReturn = {
    apirCode: 'BT888AU',
    rateOfReturn: 10.52,
    investmentOptionName: '1980s Lifestage',
    startDate: '2020-11-21',
    endDate: '2021-07-01'
  };

  const INVESTMENT_ALLOCATIONS: InvestmentAllocation[] = [
    {
      allocation: '8.97%',
      name: 'CSL Limited'
    }
  ];

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy()
    }
  };

  const mockClientInfo = {
    send: jasmine.createSpy()
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [DataModule, HttpClientTestingModule],
        providers: [
          PanoInvestmentsOverviewService,
          PanoUpgradeClientInfoService,
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradeClientInfoService, useValue: mockClientInfo }
        ]
      });
    })
  );

  beforeEach(() => {
    investmentsOverviewService = TestBed.inject(PanoInvestmentsOverviewService);
    dataService = TestBed.inject(DataService);
  });

  afterEach(() => {
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  it('should be created', () => {
    expect(investmentsOverviewService).toBeTruthy();
  });

  describe('getCurrentInvestments', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of(MOCK_FULLY_ALLOCATED_LIFESTAGE));

        investmentsOverviewService.getCurrentInvestments('1234eLMO').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalled();
        expect(successHandler).toHaveBeenCalledWith(MOCK_FULLY_ALLOCATED_LIFESTAGE);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

        investmentsOverviewService.getCurrentInvestments('1234eLMO').subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('getPersonalRateOfReturn', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of(PERSONAL_RATE_OF_RETURN));
        const startDate: Date = moment();
        const endDate: Date = moment();

        investmentsOverviewService
          .getPersonalRateOfReturn('1234eLMO', 'BT888AU', startDate, endDate)
          .subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalled();
        expect(successHandler).toHaveBeenCalledWith(PERSONAL_RATE_OF_RETURN);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));
        const startDate: Date = moment();
        const endDate: Date = moment();

        investmentsOverviewService
          .getPersonalRateOfReturn('1234eLMO', 'BT888AU', startDate, endDate)
          .subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('getCommonCmsContent', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of({}));

        investmentsOverviewService.getCommonCmsContent().subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH + CMS_INVESTMENTS_OVERVIEW_COMMON_CONTENT_PATH_FRAGMENT,
          GENERIC_OPTIONS
        );
        expect(successHandler).toHaveBeenCalledWith({});
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

        investmentsOverviewService.getCommonCmsContent().subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH + CMS_INVESTMENTS_OVERVIEW_COMMON_CONTENT_PATH_FRAGMENT,
          GENERIC_OPTIONS
        );
        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('getAssetSpecificCmsContent', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of({}));

        investmentsOverviewService.getAssetSpecificCmsContent('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
        expect(successHandler).toHaveBeenCalledWith({});
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

        investmentsOverviewService.getAssetSpecificCmsContent('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('getAustralianSharesTopTenCmsContent', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of(INVESTMENT_ALLOCATIONS));

        investmentsOverviewService
          .getAustralianSharesTopTenCmsContent('BTA888AU')
          .subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_TOP_10_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

        investmentsOverviewService
          .getAustralianSharesTopTenCmsContent('BTA888AU')
          .subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_TOP_10_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('getAustralianSectorWeights', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of({}));

        investmentsOverviewService.getAustralianSectorWeights('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_SECTOR_WEIGHTS_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

        investmentsOverviewService.getAustralianSectorWeights('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_SECTOR_WEIGHTS_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('getInternationalTopTen', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of({}));

        investmentsOverviewService.getInternationalTopTen('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_TOP_10_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

        investmentsOverviewService.getInternationalTopTen('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_TOP_10_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('getInternationalRegionWeights', () => {
    describe('retrieves from data service', () => {
      it('should call successHandler with correct argument when dataService resolved successfully', () => {
        spyOn(dataService, 'retrieve').and.returnValue(of({}));

        investmentsOverviewService.getInternationalRegionWeights('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_REGION_WEIGHTS_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
      });

      it('should call errorHandler with correct arguments when dataService resolved in error', () => {
        spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

        investmentsOverviewService.getInternationalRegionWeights('BTA888AU').subscribe(successHandler, errorHandler);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
            CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_REGION_WEIGHTS_PATH_FRAGMENT +
            'BTA888AU' +
            CMS_CONTENT_PATH_SUFFIX,
          GENERIC_OPTIONS
        );
        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });

  describe('parseTableData', () => {
    it('should return the correct investment allocation', () => {
      const alloc: InvestmentAllocation[] = investmentsOverviewService.parseTableData({
        data: '\u003cp\u003eCSL Limited,8.97%\u003c/p\u003e\r\n\r\n'
      });

      expect(alloc).toEqual(INVESTMENT_ALLOCATIONS);
    });

    it('should have an empty allocation when no data', () => {
      const alloc: InvestmentAllocation[] = investmentsOverviewService.parseTableData(undefined);
      expect(alloc).toBeFalsy();
    });
  });

  describe('navigateAndLog', () => {
    it('should call the router to navigate and client info to log', () => {
      investmentsOverviewService.navigateAndLog(
        'app.investor.account.investments',
        {},
        'clicked: Your investments link',
        'unanswered',
        'BTA0288AU',
        '1234eLMO',
        false
      );

      expect(mockUiRouter.stateService.go).toHaveBeenCalledWith('app.investor.account.investments', {});
      expect(mockClientInfo.send).toHaveBeenCalled();
    });
  });

  describe('logActivity', () => {
    it('should call the client info service to log', () => {
      investmentsOverviewService.logActivity(
        'app.investor.account.investments',
        '',
        'no',
        'unanswered',
        '12324_',
        false
      );

      expect(mockClientInfo.send).toHaveBeenCalled();
    });
    it('should not call the client info service to log when emulating', () => {
      mockClientInfo.send.calls.reset();
      investmentsOverviewService.logActivity(
        'app.investor.account.investments',
        '',
        'no',
        'unanswered',
        '12324_',
        true
      );

      expect(mockClientInfo.send).not.toHaveBeenCalled();
    });
  });
});
