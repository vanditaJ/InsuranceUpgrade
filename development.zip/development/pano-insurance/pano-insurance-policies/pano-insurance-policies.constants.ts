import { MatDialogConfig } from '@angular/material/dialog';
import { MatSnackBarConfig, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { SNACK_BAR_ACTION, SNACK_BAR_DEFAULT_CONFIG } from '@bt/components/snack-bar-template';

import { InsuranceHelpTile, PoliciesInScope } from './pano-insurance-policies.interface';

export const INVESTOR_ACCOUNT_ERROR_STATE = 'app.investor.account.systemError';

export const INVESTOR_BTSUPER_IISCOP = 'feature.insurance.investor.btsuper.iiscop';

export const INVESTOR_BTSUPER_PMIF = 'feature.insurance.investor.btsuper.pmif';

export const INVESTOR_BTSUPER_UPDATE = 'feature.insurance.investor.btsuper.update';

export const INVESTOR_INSURANCE_PYSOPTIN = 'investor.insurance.pysOptIn';

export const INVESTOR_GLOBAL_DISCLAIMER_BTSUPER = 'investor.global.disclaimer.btSuper';

export const INSURANCE_SSO_AIA_FEATURE = 'feature.insurance.sso.aia';

export const INSURANCE_DISPLAY_PANEL = 'insurance.aia.showManageInsurancePanel';

export const INSURANCE: string = 'Insurance';

export const INSURANCE_INFO_GENERIC_AEM_KEY: string = 'generic_insurance_info';

export const INSURANCE_INFO_AEM_KEY: string = 'insurance_info';

export const INSURANCE_INFO_EXTERNAL_AEM_KEY: string = 'insurance_info_byo';

export const NO_INSURANCE_INFO_AEM_KEY: string = 'no_insurance_info_{productFamily}';

export const PYS_DETAILS: string = 'pysDetails';

export const PMIF_DETAILS: string = 'pmifDetails';

export const CALCULATE_COVER_MESSAGE: string =
  'Calculate how much cover you need, apply for cover, and start or view an existing claim.';

export const PYS_OPT_IN_ALL_DIALOG_CONFIG: MatDialogConfig = {
  ...DIALOG_CONFIG.DEFAULT,
  autoFocus: false,
  ariaLabel: 'Open keep your insurance dialog'
};

export const ACTIVATE_INSURANCE_DIALOG_CONFIG: MatDialogConfig = {
  ...DIALOG_CONFIG.DEFAULT,
  autoFocus: false,
  ariaLabel: 'Open activate your insurance cover dialog'
};

export const DEFAULT_PAGE_LOADING: Loading = {
  type: 'page',
  spinnerSize: 'large'
};

export const INACTIVITY_INFO_ALERT: Alert = {
  type: 'info',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const POLICIES_INFO_ALERT: Alert = {
  type: 'info',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const ACTIVATE_INSURANCE_REQUESTED_ALERT: Alert = {
  type: 'success',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const NO_INSURANCE_ALERT: Alert = {
  type: 'info',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const PYS_SUBMIT_FAIL_ALERT: Alert = {
  type: 'warning',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const NO_OCCUPATION_CODE_ALERT: Alert = {
  type: 'warning',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const KEEP_INSURANCE_BUTTON: Button = {
  action: 'button',
  type: 'outline',
  colourModifier: 'primary',
  size: 'medium',
  label: 'Keep Insurance'
};

export const INSURANCE_PORTAL_BUTTON: Button = {
  action: 'button',
  label: 'Manage your Insurance',
  type: 'outline',
  colourModifier: 'primary',
  icon: {
    name: 'icon-arrow-right'
  },
  size: 'large'
};

export const CALCULATOR_ICON: Icon = {
  name: 'icon-calculator',
  type: 'brand-primary',
  size: 'large'
};

export const PHONE_ICON: Icon = {
  name: 'icon-phone',
  type: 'brand-primary',
  size: 'large'
};

export const SNACK_BAR_PYS_SUCCESS_CONFIG: MatSnackBarConfig<any> = {
  data: {
    action: SNACK_BAR_ACTION.SUCCESS,
    header: 'Insurance opt-in request confirmed.',
    message: 'We will send you a letter confirming your opt-in request.'
  },
  panelClass: SNACK_BAR_DEFAULT_CONFIG.PANEL_CLASS,
  verticalPosition: SNACK_BAR_DEFAULT_CONFIG.VERTICAL_POSITION as MatSnackBarVerticalPosition
};

export const INSURANCE_HELP_TILE_CONTENT: InsuranceHelpTile = {
  phoneIcon: PHONE_ICON,
  contactNumberText: 'Call 132 135',
  contactDetails: 'Speak with a BT super consultant to discuss your insurance needs.'
};

export const POLICIES_IN_SCOPE: PoliciesInScope = {
  coverSubTypeIds: [314],
  coverSubTypeIdRange: [
    { start: 14, end: 52 },
    { start: 57, end: 92 },
    { start: 141, end: 236 },
    { start: 258, end: 308 }
  ]
};

export const ACTIVATE_INFO_ALERT: Alert = {
  type: 'warning',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const ACTIVATE_COVER_BUTTON: Button = {
  action: 'button',
  colourModifier: 'warning',
  size: 'medium',
  label: 'Activate cover',
  shapeModifier: 'square',
  type: 'outline'
};

export const EMULATING: string = 'emulating';

export const BASE: string = 'base';

export const OPT_IN_STATUS = {
  success: 'success',
  pmifActivated: 'pmifActivated',
  none: 'none',
  pysFail: 'pysFail'
};

const EXTERNAL_LINK_ANNOUNCEMENT: string = 'open in new tab.';

export const OCCUPATION_GUIDE_LINK: Link = {
  isLinkExternal: true,
  label: 'BT Super Occupation Guide',
  link:
    'https://www.bt.com.au/content/dam/public/btfg-bt/documents/legacy/downloads/forms/btsuper-occupation-guide.pdf#page=3',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'warning',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'BT Super Occupation Guide, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

const OCCUPATION_CATEGORY_EMAIL_ADDRESS: string = 'btsuperinsurancequeries@btfinancialgroup.com';
const OCCUPATION_CATEGORY_EMAIL_SUBJECT: string = 'Occupation category verification';
const OCCUPATION_CATEGORY_EMAIL_BODY: string =
  'Dear member,%0A%0ATo ensure you are paying the correct amount in premiums, we need you to confirm your occupation category.%0A%0APlease add your occupation category (e.g. ‘Professional’ or ‘Blue Collar’) to this email before sending it. If you’re unsure, you can look up your category in the BT Super Occupation Guide.%0A%0AMember number: {accountNumber} %0AOccupation category: %0A%0AIf you need more information or assistance with confirming your occupation category, you can call 132 135 between 8.30am and 5.30pm (Sydney time) Monday to Friday, or contact us any time at http:%2F%2Fbt.com.au/contact-us%0A%0AKind regards,%0ABT Super';

export const OCCUPATION_CATEGORY_EMAIL_LINK: Link = {
  isLinkExternal: true,
  label: 'email us',
  link: `mailto:${OCCUPATION_CATEGORY_EMAIL_ADDRESS}?subject=${OCCUPATION_CATEGORY_EMAIL_SUBJECT}&body=${OCCUPATION_CATEGORY_EMAIL_BODY}`,
  openNewTab: true,
  type: 'flat',
  colourModifier: 'warning',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'email us, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

export const INSURANCE_INFO_PDS_LINK: Link = {
  isLinkExternal: true,
  label: 'disclosure documents',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  isUnderlined: true,
  a11yProps: {
    ariaLabel: 'disclosure documents, '.concat(EXTERNAL_LINK_ANNOUNCEMENT)
  }
};

export const CUSTOMER_TYPE_PCS: string = 'PCS';

export const PRODUCT_FAMILY = {
  BT_SUPER: 'bts',
  BT_SUPER_FOR_LIFE: 'btsfl',
  WGP: 'wgp',
  EY: 'ey'
};
