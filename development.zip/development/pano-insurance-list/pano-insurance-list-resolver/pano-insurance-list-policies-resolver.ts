import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { Policy } from '../pano-insurance-list.interface';
import { PanoInsuranceListService } from '../pano-insurance-list.service';

export function panoInsuranceListPoliciesResolver($transition$): Promise<Policy[]> {
  const accountService = $transition$.injector().get(PanoUpgradeAccountService);
  const panoInsuranceListService = $transition$.injector().get(PanoInsuranceListService);

  return panoInsuranceListService.getPolicies(accountService.getAccountId()).toPromise();
}
