import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { PanoInsuranceListService } from '../pano-insurance-list.service';

import { panoInsuranceListRelatedPoliciesResolver } from '../pano-insurance-list-resolver/pano-insurance-list-related-policies-resolver';
import { MOCK_RELATED_POLICIES } from '../pano-insurance-list.constants.spec';
import { of } from 'rxjs';

describe('panoInsuranceListRelatedPoliciesResolver', () => {
  let accountServiceSpyObj: jasmine.SpyObj<PanoUpgradeAccountService>;
  let panoInsuranceServiceSpyObj: jasmine.SpyObj<PanoInsuranceListService>;
  let transition;

  const getObj: any = { get: () => {} };

  beforeEach(() => {
    accountServiceSpyObj = jasmine.createSpyObj('PanoUpgradeAccountService', ['getAccountId']);
    panoInsuranceServiceSpyObj = jasmine.createSpyObj('PanoInsuranceListService', ['getRelatedAccounts']);
    transition = {
      injector: () => getObj
    };
  });

 
  it('calls panoInsuranceListRelatedPoliciesResolver method', async () => {

    const accountId = '123';
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');
    getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
    getSpy.withArgs(PanoInsuranceListService).and.returnValue(panoInsuranceServiceSpyObj);
    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoInsuranceServiceSpyObj.getRelatedAccounts.and.returnValues(of([MOCK_RELATED_POLICIES]));  
    const promise = panoInsuranceListRelatedPoliciesResolver(transition);  
    const policies = await promise;  
    expect(policies).toEqual([MOCK_RELATED_POLICIES]);

  });
});
