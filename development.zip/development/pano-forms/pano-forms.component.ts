import { Component, Inject, OnInit } from '@angular/core';
import { Button } from '@bt/components/button';
import { AnalyticsService } from '@bt/services/analytics';
import { API_BASE_PATH } from '@bt/tokens';
import { ServiceRequestsConfig } from '@panorama/service-requests';
import { UIRouter } from '@uirouter/angular';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import {
  DOCUMENT_LIBRARY_MODULE_NAME,
  GO_TO_DOCUMENT_LIBRARY_BUTTON,
  SERVICE_REQUESTS_CONFIGS
} from './pano-forms.constants';

@Component({
  selector: 'pano-forms',
  templateUrl: './pano-forms.component.html',
  styleUrls: ['./pano-forms.component.scss']
})
export class PanoFormsComponent implements OnInit {
  readonly goToDocumentLibrabry: Button = GO_TO_DOCUMENT_LIBRARY_BUTTON;

  serviceRequestsConfig: Partial<ServiceRequestsConfig>;

  constructor(
    @Inject(API_BASE_PATH) private readonly apiBasePath,
    private readonly accountService: PanoUpgradeAccountService,
    private readonly uiRouter: UIRouter,
    private readonly analyticsService: AnalyticsService
  ) {}

  ngOnInit(): void {
    this.analyticsService.track({
      pageName: 'investor-forms'
    });

    const apiUrl: string = `${
      this.apiBasePath['investor']
    }/api/v1/account/${this.accountService.getAccountId()}/service-requests`;

    this.serviceRequestsConfig = {
      apiUrl,
      ...SERVICE_REQUESTS_CONFIGS
    };
  }

  navigateToDocumentLibrary(): void {
    this.uiRouter.stateService.go(DOCUMENT_LIBRARY_MODULE_NAME);
  }
}
