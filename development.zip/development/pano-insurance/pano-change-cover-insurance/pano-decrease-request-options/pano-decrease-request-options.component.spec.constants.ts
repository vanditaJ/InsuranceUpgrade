import { Account } from '@investor/account/pano-shared/interfaces';

import {
  InsuranceOption,
  InsurancePolicy,
  NewCoverType,
  PersonBenefitDetails,
  PolicyStatus,
  PolicyType
} from '../../pano-insurance.interface';

export const NEW_COVER_TYPE: NewCoverType = {
  coverType: {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH,
    description:
      'Retains Death cover only and cancels your TPD if you have bundled Death and TPD cover. Death cover pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.'
  },
  coverAmountType: {
    coverSubTypeId: '93',
    coverAmountName: 'Single cover',
    coverAmountType: 'Single',
    coverAmount: 4521,
    premium: '4586',
    increase: false
  }
};

export const INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Death',
  policyNumber: '5273590',
  qualifierName: 'Essential cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: null,
  customerType: 'Retail',
  employerFunded: false
};

export const INSURANCE_POLICY_UNITS: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Death',
  policyNumber: '5273590',
  qualifierName: 'Tailored cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4500,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  unitsOfCover: 3
};

export const INSURANCE_POLICY_SCI: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Income Protection',
  policyNumber: '5273590',
  qualifierName: 'Salary continuance insurance cover',
  premium: '0.00',
  status: PolicyStatus.ACTIVE,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4500,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: null,
  customerType: 'Retail',
  employerFunded: false,
  personBenefitDetails: [
    {
      benefits: [
        {
          waitingPeriod: '2',
          benefitPeriodTerm: '42',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              occupationClass: ''
            }
          ]
        }
      ]
    }
  ]
};

export const MOCK_PERSONAL_BENEFIT_DETAILS: PersonBenefitDetails[] = [
  {
    benefits: [
      {
        waitingPeriod: '2',
        benefitPeriodTerm: '42',
        benefitPeriodFactor: 'years',
        benefits: [
          {
            occupationClass: ''
          }
        ]
      }
    ]
  }
];

export const NEW_COVER_TYPE_AMOUNT: NewCoverType = {
  coverType: {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH
  },
  coverAmountType: {
    coverSubTypeId: '93',
    coverAmount: 3000
  },
  requestCoverAmount: 3000
};

export const NEW_COVER_TYPE_UNITS: NewCoverType = {
  coverType: {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH
  },
  coverAmountType: {
    coverSubTypeId: '93',
    coverAmount: 3000
  },
  requestCoverAmount: 3000,
  requestUnitsCover: 3
};

export const INSURANCE_OPTIONS_DATA: InsuranceOption[] = [
  {
    waitingPeriod: '30 days',
    benefitPeriods: ['2 years', '5 years', 'Age 65']
  },
  {
    waitingPeriod: '90 days',
    benefitPeriods: ['2 years', '5 years', 'Age 65']
  },
  {
    waitingPeriod: '180 days',
    benefitPeriods: ['Age 65']
  },
  {
    waitingPeriod: '720 days',
    benefitPeriods: ['Age 65']
  }
];

export const NEW_COVER_TYPE_SCI: NewCoverType = {
  coverType: {
    policyName: 'Income Protection',
    policyType: PolicyType.INCOME_PROTECTION
  },
  coverAmountType: {
    coverSubTypeId: '159',
    coverAmount: 1222
  },
  requestCoverAmount: 1222,
  requestWaitingPeriod: '90 days',
  requestBenefitPeriod: '5 years'
};

export const MOCK_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2021-02-04T16:00:00.000Z',
  pdsStatus: 'WGP_CEASED',
  product: {}
};
