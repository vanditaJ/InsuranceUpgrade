import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';

export interface CheckboxField {
  name: string;
  descripton: string;
  value: boolean;
}

export interface InvestmentPreferenceHeader {
  icon: Icon;
  title: string;
  helpInfoId: string;
  learnMore: Button;
}
