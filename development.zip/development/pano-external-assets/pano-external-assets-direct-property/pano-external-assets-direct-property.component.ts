import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { FormArray } from '@angular/forms';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';
import { get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { Subscription } from 'rxjs';

import { PanoExternalAssetsCommonUtil } from '../pano-external-assets-common.util';
import {
  ASSET_TYPES,
  DATE_PICKER_ICON,
  DELETE_BUTTON,
  DIRECT_PROPERTY_TYPES
} from '../pano-external-assets-constants/pano-external-assets.constants';
import { AssetTypeTotalDetails, ExternalAssetDeleteDetails } from '../pano-external-assets.interfaces';

@Component({
  selector: 'pano-external-assets-direct-property',
  templateUrl: './pano-external-assets-direct-property.component.html',
  styleUrls: ['../pano-external-assets.scss']
})
export class PanoExternalAssetsDirectPropertyComponent implements OnChanges, OnDestroy {
  @Input() dpFormArray: FormArray;
  @Input() assetCount: number;

  @Output()
  assetDelete: EventEmitter<ExternalAssetDeleteDetails> = new EventEmitter();
  @Output()
  assetTotalMarketValueUpdate: EventEmitter<AssetTypeTotalDetails> = new EventEmitter();

  DIRECT_PROPERTY_TYPES = DIRECT_PROPERTY_TYPES;
  datePickerIcon: Icon = DATE_PICKER_ICON;
  deleteButton: Button = DELETE_BUTTON;
  today: Date = moment().tz('Australia/Sydney');
  totalMarketValue: number;

  private controlsValueChangesSubscriptions: Subscription[] = [];

  constructor(private panoExtAssetsCommonUtil: PanoExternalAssetsCommonUtil) {}

  ngOnDestroy(): void {
    this.calculateTotal();
    this.unregisterControlsValueChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      get(changes, 'assetCount.currentValue') !== get(changes, 'assetCount.previousValue') ||
      get(changes, 'dpFormArray.currentValue') !== get(changes, 'dpFormArray.previousValue')
    ) {
      this.unregisterControlsValueChanges();
      this.registerControlsValueChanges();
      this.calculateTotal();
    }
  }

  registerControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.registerAssetEditMarketValueControlsValueChanges(
      this.dpFormArray,
      this.calculateTotal.bind(this)
    );
  }

  unregisterControlsValueChanges(): void {
    this.controlsValueChangesSubscriptions = this.panoExtAssetsCommonUtil.unregisterAssetEditControlsValueChanges(
      this.controlsValueChangesSubscriptions
    );
  }

  deleteDirectProperty(index: number, positionId: string, isNewAsset: boolean): void {
    this.panoExtAssetsCommonUtil.deleteAsset(
      {
        index,
        assetTypeCode: ASSET_TYPES.dp.code,
        positionId,
        isNewAsset
      },
      this.assetDelete
    );
  }

  calculateTotal(): void {
    this.totalMarketValue = this.panoExtAssetsCommonUtil.calculateAssetTypeTotalMarketValue(
      this.dpFormArray,
      ASSET_TYPES.dp.code,
      this.assetTotalMarketValueUpdate
    );
  }
}
