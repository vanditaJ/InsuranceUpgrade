import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Alert } from '@bt/components/alert';

import { RangeSliderModel } from '../pano-inv-profile-setup.interface';

import {
  APPETITE_FOR_RISK_HEADER,
  ASSET_LIQUIDITY_NEEDS_HEADER,
  INVESTMENT_OBJECTIVES_HEADER,
  INVESTMENT_PREFERENCE_DESCRIPTION,
  INVESTMENT_PREFERENCE_TITLE,
  INVESTMENT_TIMEFRAME_HEADER,
  NO_INVESTMENT_OBJECTIVE_CHECKED_ALERT,
  NO_INVESTMENT_TIMEFRAMES_CHECKED_ALERT
} from './pano-inv-pref.constant';
import { CheckboxField } from './pano-inv-pref.interface';

@Component({
  selector: 'pano-inv-pref',
  templateUrl: './pano-inv-pref.component.html'
})
export class PanoInvestmentPreferencesComponent {
  @Input() investmentObjectives: CheckboxField[];
  @Output() investmentObjectivesChange: EventEmitter<CheckboxField[]> = new EventEmitter();

  @Input() investmentTimeframes: CheckboxField[];
  @Output() investmentTimeframesChange: EventEmitter<CheckboxField[]> = new EventEmitter();

  @Input() riskReturnObjectives: RangeSliderModel;
  @Output() riskReturnObjectivesChange: EventEmitter<RangeSliderModel> = new EventEmitter();

  @Input() redemptionFrequencies: RangeSliderModel;
  @Output() redemptionFrequenciesChange: EventEmitter<RangeSliderModel> = new EventEmitter();

  noInvestmentObjectivesChecked: boolean;
  noInvestmentTimeframesChecked: boolean;

  readonly investmentObjectivesHeader = INVESTMENT_OBJECTIVES_HEADER;
  readonly investmentTimeframeHeader = INVESTMENT_TIMEFRAME_HEADER;
  readonly appetiteForRiskHeader = APPETITE_FOR_RISK_HEADER;
  readonly assetLiquidityNeedsHeader = ASSET_LIQUIDITY_NEEDS_HEADER;

  readonly noInvestmentTimeframesCheckedAlert: Alert = NO_INVESTMENT_TIMEFRAMES_CHECKED_ALERT;
  readonly noInvestmentObjectivesCheckedAlert: Alert = NO_INVESTMENT_OBJECTIVE_CHECKED_ALERT;

  readonly investPreferenceTitle: string = INVESTMENT_PREFERENCE_TITLE;
  readonly investPreferenceDescription: string = INVESTMENT_PREFERENCE_DESCRIPTION;

  updateInvestmentObjectivesState(): void {
    this.noInvestmentObjectivesChecked = false;
    if (!this.investmentObjectives.find(objective => objective.value)) {
      this.noInvestmentObjectivesChecked = true;
    }
    this.investmentObjectivesChange.emit(this.investmentObjectives);
  }

  updateInvestmentTimeframesState(): void {
    this.noInvestmentTimeframesChecked = false;
    if (!this.investmentTimeframes.find(timeframe => timeframe.value)) {
      this.noInvestmentTimeframesChecked = true;
    }
    this.investmentTimeframesChange.emit(this.investmentTimeframes);
  }
}
