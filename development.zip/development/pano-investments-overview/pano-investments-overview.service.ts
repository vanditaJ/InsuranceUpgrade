import { Injectable } from '@angular/core';
import { BtError, DataService } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeClientInfoService } from '@upgrade/upgrade.services';
import { get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { parse } from 'papaparse';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  API_INVESTMENTS_ASSETS_PATH_FRAGMENT,
  API_INVESTMENTS_BASE_PATH,
  API_INVESTMENTS_OVERVIEW_SERVICE_PATH_FRAGMENT,
  API_PORTFOLIO_BASE_PATH,
  API_PORTFOLIO_INVESTMENTS_SERVICE_PATH_FRAGMENT,
  CMS_CONTENT_PATH_SUFFIX,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_SECTOR_WEIGHTS_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_TOP_10_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_REGION_WEIGHTS_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_TOP_10_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_COMMON_CONTENT_PATH_FRAGMENT,
  CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH,
  GENERIC_OPTIONS
} from './pano-investments-overview.constants';
import { InvestmentAllocation, Investments, PersonalRateOfReturn } from './pano-investments-overview.interface';

@Injectable()
export class PanoInvestmentsOverviewService {
  constructor(
    private personalRateOfReturnDataService: DataService<PersonalRateOfReturn | BtError>,
    private currentInvestmentsDataService: DataService<Investments | BtError>,
    private cmsDataService: DataService<any | BtError>,
    private uiRouter: UIRouter,
    private clientInfoService: PanoUpgradeClientInfoService
  ) {}

  getPersonalRateOfReturn(
    accountKey: string,
    apirCode: string,
    startDate: Date,
    endDate: Date
  ): Observable<PersonalRateOfReturn | BtError> {
    const formattedStartDate: string = moment(startDate).format('YYYY-MM-DD');
    const formattedEndDate: string = moment(endDate).format('YYYY-MM-DD');

    return this.personalRateOfReturnDataService.retrieve(
      `${API_INVESTMENTS_BASE_PATH}${accountKey}${API_INVESTMENTS_ASSETS_PATH_FRAGMENT}${apirCode}${API_INVESTMENTS_OVERVIEW_SERVICE_PATH_FRAGMENT}` +
        `?startDate=${formattedStartDate}&endDate=${formattedEndDate}`,
      GENERIC_OPTIONS
    );
  }

  getCurrentInvestments(accountKey: string): Observable<Investments | BtError> {
    return this.currentInvestmentsDataService.retrieve(
      `${API_PORTFOLIO_BASE_PATH}${accountKey}${API_PORTFOLIO_INVESTMENTS_SERVICE_PATH_FRAGMENT}`,
      GENERIC_OPTIONS
    );
  }

  getCommonCmsContent(): Observable<any | BtError> {
    return this.cmsDataService.retrieve(
      CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH + CMS_INVESTMENTS_OVERVIEW_COMMON_CONTENT_PATH_FRAGMENT,
      GENERIC_OPTIONS
    );
  }

  getAssetSpecificCmsContent(apirCode: string): Observable<any | BtError> {
    return this.cmsDataService.retrieve(
      CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
        CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_PATH_FRAGMENT +
        apirCode +
        CMS_CONTENT_PATH_SUFFIX,
      GENERIC_OPTIONS
    );
  }

  getAustralianSharesTopTenCmsContent(apirCode: string): Observable<InvestmentAllocation[] | BtError> {
    return this.getAllocationContent(
      CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
        CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_TOP_10_PATH_FRAGMENT +
        apirCode +
        CMS_CONTENT_PATH_SUFFIX
    );
  }

  getAustralianSectorWeights(apirCode: string): Observable<InvestmentAllocation[] | BtError> {
    return this.getAllocationContent(
      CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
        CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_SECTOR_WEIGHTS_PATH_FRAGMENT +
        apirCode +
        CMS_CONTENT_PATH_SUFFIX
    );
  }

  getInternationalTopTen(apirCode: string): Observable<InvestmentAllocation[] | BtError> {
    return this.getAllocationContent(
      CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
        CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_TOP_10_PATH_FRAGMENT +
        apirCode +
        CMS_CONTENT_PATH_SUFFIX
    );
  }

  getInternationalRegionWeights(apirCode: string): Observable<InvestmentAllocation[] | BtError> {
    return this.getAllocationContent(
      CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH +
        CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_REGION_WEIGHTS_PATH_FRAGMENT +
        apirCode +
        CMS_CONTENT_PATH_SUFFIX
    );
  }

  getAllocationContent(contentPath: string): Observable<InvestmentAllocation[] | BtError> {
    return this.cmsDataService
      .retrieve(contentPath, GENERIC_OPTIONS)
      .pipe(map(res => get(res, 'details')))
      .pipe(map(res => this.parseTableData(res[0])));
  }

  parseTableData(table: any): InvestmentAllocation[] {
    if (table && table.data) {
      const doc = new DOMParser().parseFromString(table.data, 'text/html');
      const rows: string[][] = parse(doc.body.textContent).data;
      return rows
        .filter((row: string[]) => {
          return row[0];
        })
        .map((row: string[]) => this.investmentDataFromRow(row));
    }
  }

  investmentDataFromRow(row: string[]): InvestmentAllocation {
    return { name: row[0], allocation: row[1] };
  }

  navigateAndLog(
    state: string,
    params,
    event: string,
    happy: string,
    apirCode: string,
    accountNumber: string,
    emulating: boolean
  ) {
    this.logActivity(state, event, happy, apirCode, accountNumber, emulating);
    this.uiRouter.stateService.go(state, params);
  }

  logActivity(
    state: string,
    event: string,
    happy: string,
    apirCode: string,
    accountNumber: string,
    emulating: boolean
  ) {
    if (!emulating) {
      this.clientInfoService.send({
        activityLogs: [
          {
            triggerState: 'app.investor.account.investmentsOverview',
            targetState: state,
            triggerEvent: event,
            activityData: { happyWithInvestments: happy, fundCode: apirCode, accountNumber }
          }
        ]
      });
    }
  }
}
