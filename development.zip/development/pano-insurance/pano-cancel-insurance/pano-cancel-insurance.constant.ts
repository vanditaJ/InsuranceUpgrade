import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';

import { PolicyTitleMap, PolicyType } from '../pano-insurance.interface';

export const REVIEW_FORM_BUTTON: Button = {
  type: 'solid',
  label: 'Submit',
  size: 'large',
  action: 'submit',
  disableInEmulationMode: true,
  colourModifier: 'primary'
};

export const CANCEL_REVIEW_FORM_BUTTON: Button = {
  type: 'outline',
  label: 'Back',
  size: 'large',
  action: 'button',
  colourModifier: 'primary'
};

export const REDUCE_COVER_INFO_ALERT: Alert = {
  type: 'info',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const REDUCE_COVER_INSTEAD_MESSAGE: string =
  'If you wish to reduce your cover and monthly premium, instead of cancelling, you can ';

export const DECREASE_COVER_INSTEAD_MESSAGE: string = 'decrease your cover';

export const CHANGE_COVER_INSTEAD_MESSAGE: string = 'change your cover';

export const RETURN_INSURANCE_OVERVIEW: Button = {
  type: 'solid',
  label: 'Return to Insurance overview',
  size: 'large',
  action: 'button',
  colourModifier: 'primary'
};

export const SUCCESS_CANCEL_INSURANCE: Alert = {
  type: 'success',
  outline: true,
  messages: {
    message: 'Your cover has now been cancelled'
  },
  a11yProps: {
    ariaRole: 'none'
  }
};

export const CANCELLED_DISPLAY_STATUS: string = 'Cancelled';

export const POLICY_TITLE: PolicyTitleMap[] = [
  {
    type: PolicyType.DEATH,
    title: 'Death cover'
  },
  {
    type: PolicyType.TPD,
    title: 'Total Permanent Disability/Disablement (TPD)'
  },
  {
    type: PolicyType.DEATH_AND_TPD,
    title: 'Death and Total Permanent Disability/Disablement (TPD)'
  },
  {
    type: PolicyType.INCOME_PROTECTION,
    title: 'Salary Continuance Insurance (SCI)'
  }
];

export const BENEFIT_FREQUENCY = [
  {
    type: 'MONTHLY',
    name: 'per month'
  },
  {
    type: 'FORTNIGHTLY',
    name: 'per fortnight'
  }
];

export const SUBMIT_ERROR_ALERT: Alert = {
  type: 'error',
  messages:
    'Something unexpected has happened. We are unable to cancel your cover at this time – please contact BT on 132 135 Monday to Friday 8.30am – 5.30pm (Sydney time).',
  outline: true,
  showCodes: false
};

export const TPD_CANCEL_WARNING_DEATH_TPD_AEM_KEY = 'tpd_cancel_warning_death_tpd';

export const DEATH_TPD_PARTIAL_SUBMIT_AEM_KEY = 'no_cancel_death';

export const CANCEL_ACTIVE_COVER_INFO_AEM_KEY: string = 'cancel_cover_review_useful_info_active';

export const CANCEL_ACTIVE_COVER_TERMS_AEM_KEY: string = 'cancel_cover_review_confirm_check_active';

export const CANCEL_ACTIVE_COVER_CONFIRM_AEM_KEY: string = 'cancel_cover_confirm_useful_info_active';

export const CANCEL_PENDING_COVER_INFO_AEM_KEY: string = 'cancel_cover_review_useful_info_pending';

export const CANCEL_PENDING_COVER_TERMS_AEM_KEY: string = 'cancel_cover_review_confirm_check_pending';

export const CANCEL_PENDING_COVER_CONFIRM_AEM_KEY: string = 'cancel_cover_confirm_useful_info_pending';

export const CANCEL_COVER_OVER_60_CANCEL_MESSAGE_AEM_KEY: string = 'cancel_cover_over_60_cancel_message';
