import { MatDialogConfig } from '@angular/material/dialog';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Optionals } from '@bt/services/data';

export const INVESTMENTS_BUTTON_LINK: Button = {
  action: 'button',
  colourModifier: 'primary',
  icon: {
    name: 'icon-chevron-left-circle-solid'
  },
  iconPosition: 'left',
  label: 'Your investments',
  shapeModifier: 'square',
  size: 'medium',
  type: 'flat'
};

export const SIMPLE_INVESTMENTS_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Simple investment menu',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false
};

export const DIY_INVESTMENTS_LINK: Link = {
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  isLinkExternal: true,
  label: 'Full investment menu',
  link: '',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  iconPosition: 'left',
  isUnderlined: false
};

export const HOW_ARE_THESE_CALCULATED_BUTTON: Button = {
  action: 'button',
  colourModifier: 'primary',
  icon: {
    name: 'icon-chevron-right-circle-solid'
  },
  iconPosition: 'left',
  label: 'How are these numbers calculated?',
  shapeModifier: 'square',
  size: 'medium',
  type: 'flat'
};

export const CHANGE_INVESTMENT_STRATEGY_BUTTON: Button = {
  action: 'button',
  label: 'Change investment strategy',
  type: 'solid',
  colourModifier: 'primary',
  isUnderlined: false,
  size: 'large'
};

export const OVERVIEW_PAGE_BUTTON: Button = {
  action: 'button',
  label: 'Overview page',
  type: 'solid',
  colourModifier: 'primary',
  isUnderlined: false,
  size: 'large'
};

export const NEW_WINDOW_ICON: Icon = {
  name: 'icon-external-link',
  size: 'x-small',
  type: 'info'
};

export const DEFAULT_PAGE_LOADING: Loading = {
  type: 'page',
  spinnerSize: 'large'
};
export const GENERIC_OPTIONS: Optionals = { errorCode: 'Err.IP-0344' };

export const API_INVESTMENTS_BASE_PATH: string = '../panorama-inv-ui/api/v1/investment/accounts/';
export const API_INVESTMENTS_ASSETS_PATH_FRAGMENT: string = '/assets/';
export const API_INVESTMENTS_OVERVIEW_SERVICE_PATH_FRAGMENT: string = '/investment-overview';

export const API_PORTFOLIO_BASE_PATH: string = '../api/portfolio/v3_0/';
export const API_PORTFOLIO_INVESTMENTS_SERVICE_PATH_FRAGMENT: string =
  '/investments?includeInvestmentsAndStrategy=true';

export const LIFE_STAGE_FUND: string = 'Lifestage';

export const CMS_INVESTMENTS_OVERVIEW_CONTENT_BASE_PATH = '/content/secure/panorama/_services/investments-overview';
export const CMS_CONTENT_PATH_SUFFIX = '/_jcr_content.getAggr.getContentPage.json';
export const CMS_INVESTMENTS_OVERVIEW_COMMON_CONTENT_PATH_FRAGMENT: string =
  '/common-content' + CMS_CONTENT_PATH_SUFFIX;
export const CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_PATH_FRAGMENT: string = '/asset-content/';
export const CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_TOP_10_PATH_FRAGMENT: string =
  '/australian-shares-top-ten/';
export const CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_AUSTRALIAN_SHARES_SECTOR_WEIGHTS_PATH_FRAGMENT: string =
  '/australian-shares-sector-weights/';
export const CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_TOP_10_PATH_FRAGMENT: string =
  '/international-shares-top-ten/';
export const CMS_INVESTMENTS_OVERVIEW_ASSET_CONTENT_INTERNATIONAL_SHARES_REGION_WEIGHTS_PATH_FRAGMENT: string =
  '/international-shares-region-weights/';

export const VIDEO_MODAL_DIALOG_CONFIG: MatDialogConfig = {
  ...DIALOG_CONFIG.DEFAULT,
  autoFocus: false,
  disableClose: false,
  ariaLabelledBy: 'modal-title'
};

export const CMS_CONTENT_KEYS: any = {
  fundName: 'fundName',
  pageIntro: 'pageIntro',

  australianShareDisclaimer: 'australianShareDisclaimer',
  internationalShareDisclaimer: 'internationalShareDisclaimer',
  investmentOverviewKeyPoints: 'investmentOverviewKeyPoints',

  performanceComparisonHeading: 'performanceComparisonHeading',
  performanceRate1IntroText: 'performanceRate1IntroText',
  performanceRate2IntroText: 'performanceRate2IntroText',
  performanceRate1Value: 'performanceRate1Value',
  performanceRate1WGPValue: 'performanceRate1WGPValue',
  performanceRate2Value: 'performanceRate2Value',
  performanceRate2WGPValue: 'performanceRate2WGPValue',
  performanceComparisonDate: 'performanceComparisonDate',

  totalAustralianShareAllocation: 'totalAustralianShareAllocation',
  totalInternationalShareAllocation: 'totalInternationalShareAllocation',

  whereYourMoneyIsInvestedPanelContent: 'whereYourMoneyIsInvestedPanelContent',
  whereYourMoneyIsInvestedPanelImage: 'whereYourMoneyIsInvestedPanelImage',
  whereYourMoneyIsInvestedOverallTabContent: 'whereYourMoneyIsInvestedOverallTabContent',

  whatIsMyPersonalRateOfReturn: 'whatIsMyPersonalRateOfReturn',

  videoHeading: 'videoHeading',
  videoIntro: 'videoIntro',
  videoIframe: 'videoIframe',

  areYouHappyYesIam: 'areYouHappyYesIam',
  areYouHappyOtherInvestments: 'areYouHappyOtherInvestments',
  areYouHappySimpleInvestments: 'areYouHappySimpleInvestments',
  areYouHappyDiyInvestments: 'areYouHappyDiyInvestments',

  fullInvestmentLink: 'fullInvestmentLink',
  simpleInvestmentLink: 'simpleInvestmentLink'
};

export const CMS_ROR_KEYS = {
  HOW_ROR_CALCULATED_HEADING: 'howRateOfReturnCalculatedHeading',
  HOW_ROR_CALCULATED_BODY: 'howRateOfReturnCalculatedBody'
};

export const INVESTMENT_OPTIONS_SHOW_ROR_FEATURE: string = 'feature.super.investments.overview.showPersonalRor';
