import { AemContent, PanoCmsService } from '@panorama/services/cms';
import { PanoUpgradeEnvService } from '@upgrade/upgrade.services';
import { get } from 'lodash-es';

export function panoInsuranceContentResolver($transition$): Promise<AemContent[]> {
  const envService = $transition$.injector().get(PanoUpgradeEnvService);
  const cmsHost = get(envService.getEnv(), 'cmsHostForAem', '');

  const panoCmsService = $transition$.injector().get(PanoCmsService);
  return panoCmsService.getContent(cmsHost).toPromise();
}
