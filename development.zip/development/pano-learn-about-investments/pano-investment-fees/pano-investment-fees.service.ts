import { Injectable } from '@angular/core';
import { DataService } from '@bt/services/data';
import { Account } from '@investor/account/pano-shared/interfaces';
import { get } from 'lodash-es';
import { parse } from 'papaparse';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { AEM_DATA_URL, AEM_TEXT_URL, DEFAULT_COHORT, GENERIC_OPTIONS } from './pano-investment-fees.constants';
import { AemInvestmentFee, AemRichTextItem, AemTextItem } from './pano-investment-fees.interface';

@Injectable()
export class PanoInvestmentFeesService {
  private cmsDataUrl: string = AEM_DATA_URL;
  private cmsTextUrl: string = AEM_TEXT_URL;
  constructor(private dataService: DataService<any>) {}

  getInvestments(account: Account): Observable<AemInvestmentFee[]> {
    const csvData: Observable<AemRichTextItem[]> = this.dataService
      .retrieve(this.cmsDataUrl, GENERIC_OPTIONS)
      .pipe(map(res => get(res, 'details')));

    const cohort: string = account.heritageCohort || DEFAULT_COHORT;
    return csvData.pipe(
      map(res => {
        return this.parseRow(cohort, res[0]);
      })
    );
  }

  private parseRow(cohort: string, textContent: AemRichTextItem): AemInvestmentFee[] {
    const doc = new DOMParser().parseFromString(textContent.data, 'text/html');
    const rows: string[][] = parse(doc.body.textContent).data;

    const allPossibleFees: AemInvestmentFee[] = rows
      .filter((row: string[]) => {
        return row[0] && (row[0] === cohort || row[0] === DEFAULT_COHORT);
      })
      .map((row: string[]) => this.investmentFeeFromRow(row));

    const cohortFees: AemInvestmentFee[] = allPossibleFees.filter(fee => fee.cohort === cohort);
    if (cohortFees.length > 0) {
      return cohortFees;
    }
    return allPossibleFees;
  }

  private investmentFeeFromRow(row: string[]): AemInvestmentFee {
    return {
      cohort: row[0],
      investmentName: row[1],
      apirCode: row[2],
      indirectCosts: Number(row[3]),
      otherFees: Number(row[4]),
      borrowingCosts: Number(row[5]),
      lifestage: JSON.parse(row[6].toLocaleLowerCase())
    };
  }

  getTextContent(): Observable<object> {
    let cmsText: Observable<AemTextItem[]>;
    cmsText = this.dataService.retrieve(this.cmsTextUrl, GENERIC_OPTIONS).pipe(map(res => get(res, 'details')));
    return cmsText.pipe(
      map(res => {
        return res.reduce((contentMap, obj) => {
          contentMap[obj.data.headerText] = obj.data.description;
          return contentMap;
        }, {});
      })
    );
  }
}
