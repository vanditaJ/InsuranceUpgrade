import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import * as moment from 'moment-timezone';
import { PageScrollService } from 'ngx-page-scroll-core';
import { of, throwError } from 'rxjs';

import {
  CHANGE_COVER_ACC,
  SINGLE_DEATH_INSURANCE_POLICY,
  TRIPLE_DEATH_INSURANCE_POLICY,
  TRIPLE_DEATH_INSURANCE_POLICY_AGE_67
} from '../pano-change-cover-insurance/pano-change-cover-insurance.component.spec.constants';
import { CHANGE_INSURANCE_STATE } from '../pano-insurance-policies/pano-insurance-tables/pano-insurance-tables.component.constants';
import { IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES } from '../pano-insurance.constants.spec';
import { PanoInsuranceService } from '../pano-insurance.service';
import { PanoInsuranceUtil } from '../pano-insurance.util';

import { PanoCancelInsuranceComponent } from './pano-cancel-insurance.component';
import {
  DEATH_AND_TPD_INSURANCE_POLICY_NOT_ACTIVE,
  MOCK_ACCOUNT,
  MOCK_AEM_CONTENT_CANCEL,
  MOCK_CANCEL_ACCOUNT,
  POLICIES
} from './pano-cancel-insurance.component.spec.constants';

describe('PanoCancelInsuranceComponent', () => {
  let component: PanoCancelInsuranceComponent;
  let fixture: ComponentFixture<PanoCancelInsuranceComponent>;
  let service: PanoInsuranceService;
  let disclaimerService: PanoDisclaimersService;
  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });

  const mockUiRouter = {
    stateService: {
      params: {
        insurance: POLICIES[0],
        policyNumber: '5273590'
      },
      go: jasmine.createSpy()
    }
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoCancelInsuranceComponent],
        imports: [
          AlertModule,
          ButtonModule,
          DataModule,
          HttpClientTestingModule,
          LayoutModule,
          RouterTestingModule,
          PipesTestingModule
        ],
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PageScrollService, useValue: pageScrollService },
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccountId: () => {
                return '1234';
              }
            }
          },
          PanoInsuranceService,
          PanoDisclaimersService,
          PanoInsuranceUtil
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoCancelInsuranceComponent);
    component = fixture.componentInstance;
    component.cmsContent = MOCK_AEM_CONTENT_CANCEL;
    service = TestBed.inject(PanoInsuranceService);
    disclaimerService = TestBed.inject(PanoDisclaimersService);
    component.account = MOCK_ACCOUNT;
    spyOn(disclaimerService, 'evaluateDisclaimer').and.returnValue('disclaimer');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Component', () => {
    describe('ngOnInit', () => {
      it('should call getInsurance from policies service to fetch insurance details and retrieve disclaimer and set canCancelCoverOver60 to true', () => {
        spyOn(service, 'getInsurance').and.returnValue(of(POLICIES[0]));
        component.ngOnInit();
        expect(component.insurance.policyName).toEqual('Salary Continuance Insurance (SCI)');
        expect(component.insurance.benefitFrequencyLabel).toEqual('per month');
        expect(component.date).toBeTruthy();
        expect(component.disclaimer).toBeTruthy();
        expect(component.canCancelCoverOver60).toBeFalsy();
      });

      it('should call getAssociatedTpdCovers from policies service to fetch associatedTpdCovers', () => {
        spyOn(service, 'getAssociatedTpdCovers').and.returnValue(of([POLICIES[0]]));
        component.ngOnInit();

        expect(component.associatedTpdCovers).toEqual([POLICIES[0]]);
      });
    });

    describe('showChangeDecreaseMsgForCancel ', () => {
      it('decrease show msg for cancel status should return true for triple death cover with all satified conditions', () => {
        const cancelAcc = MOCK_CANCEL_ACCOUNT;
        cancelAcc.firstMoneyReceivedDate = '2020-08-04T16:00:00.000Z';

        component.showChangeDecreaseMsgForCancel(TRIPLE_DEATH_INSURANCE_POLICY, cancelAcc);
        expect(component.showChangeCoverInsteadInfo).toBe(false);
        expect(component.showDecreaseCoverInsteadInfo).toBe(true);
      });

      it('change show msg for cancel status should return true for triple death cover with all satified conditions', () => {
        const cancelAcc = MOCK_CANCEL_ACCOUNT;
        cancelAcc.firstMoneyReceivedDate = moment().tz('Australia/Sydney');

        component.showChangeDecreaseMsgForCancel(TRIPLE_DEATH_INSURANCE_POLICY, MOCK_CANCEL_ACCOUNT);
        expect(component.showChangeCoverInsteadInfo).toBe(true);
        expect(component.showDecreaseCoverInsteadInfo).toBe(false);
      });

      it('decrease and change show msg for cancel status should return false for single death cover with all satified conditions', () => {
        const cancelAcc = MOCK_CANCEL_ACCOUNT;
        cancelAcc.firstMoneyReceivedDate = '2020-08-04T16:00:00.000Z';

        component.showChangeDecreaseMsgForCancel(SINGLE_DEATH_INSURANCE_POLICY, MOCK_CANCEL_ACCOUNT);
        expect(component.showChangeCoverInsteadInfo).toBe(false);
        expect(component.showDecreaseCoverInsteadInfo).toBe(false);
      });

      it('decrease and change show msg for cancel status should return false if age is greater than 60', () => {
        component.showChangeDecreaseMsgForCancel(TRIPLE_DEATH_INSURANCE_POLICY_AGE_67, MOCK_CANCEL_ACCOUNT);
        expect(component.showChangeCoverInsteadInfo).toBe(false);
        expect(component.showDecreaseCoverInsteadInfo).toBe(false);
      });

      it('decrease show msg for cancel status should return true  if activation date is greater than 90 days', () => {
        component.showChangeDecreaseMsgForCancel(TRIPLE_DEATH_INSURANCE_POLICY, CHANGE_COVER_ACC);
        expect(component.showChangeCoverInsteadInfo).toBe(false);
        expect(component.showDecreaseCoverInsteadInfo).toBe(true);
      });

      it('change show msg for cancel status should return false for triple death cover with NOT ACTIVE status', () => {
        component.showChangeDecreaseMsgForCancel(DEATH_AND_TPD_INSURANCE_POLICY_NOT_ACTIVE, MOCK_CANCEL_ACCOUNT);
        expect(component.showChangeCoverInsteadInfo).toBe(false);
        expect(component.showDecreaseCoverInsteadInfo).toBe(false);
      });
    });

    describe('setAemMessages', () => {
      it('should populate correct messages when cancelling an active policy', () => {
        component.insurance = POLICIES[0];

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_CANCEL[0].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_CANCEL[1].data.description);
        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CANCEL[4].data.description);
      });

      it('should populate correct messages when cancelling a pending policy', () => {
        component.insurance = POLICIES[1];

        component.setAemMessages();

        expect(component.infoAemMessage).toBe(MOCK_AEM_CONTENT_CANCEL[2].data.description);
        expect(component.termsAemMessage).toBe(MOCK_AEM_CONTENT_CANCEL[3].data.description);
        expect(component.confirmAemMessage).toBe(MOCK_AEM_CONTENT_CANCEL[5].data.description);
      });

      it('should populate correct message when cancelling death and associated tpd policy', () => {
        component.setAemMessages();

        expect(component.cancelDeathTpdAemMessage).toBe(MOCK_AEM_CONTENT_CANCEL[6].data.description);
      });
    });

    describe('submitReviewForm', () => {
      describe('when single cover to cancel', () => {
        it('should call submitCancelInsurance', () => {
          component.insurance = POLICIES[0];
          component.associatedTpdCovers = [];
          spyOn(service, 'submitCancelInsurance').and.returnValue(of(POLICIES));

          component.submitReviewForm();
          expect(service.submitCancelInsurance).toHaveBeenCalledWith('1234', '5273590');
          expect(component.inProgress).toBeFalsy();
          expect(component.partialSubmit).toBe(false);
          expect(component.state).toEqual('confirmation');
        });

        it('should not change the state and make inProgress false on error', () => {
          component.insurance = POLICIES[0];
          component.associatedTpdCovers = [];
          spyOn(service, 'submitCancelInsurance').and.returnValue(throwError('error'));

          component.submitReviewForm();
          expect(service.submitCancelInsurance).toHaveBeenCalledWith('1234', '5273590');
          expect(component.inProgress).toBeFalsy();
          expect(component.partialSubmit).toBe(false);
          expect(component.state).toBeUndefined();

          const pageScrollOptions = {
            document: (component as any).document,
            scrollTarget: '.top-scroll',
            scrollViews: [document.querySelector('.layout-scroll')],
            duration: 200
          };
          expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
        });
      });

      describe('when associated tpd covers to cancel', () => {
        it('should call submitCancelInsurance', () => {
          component.insurance = POLICIES[0];
          component.associatedTpdCovers = [POLICIES[3]];
          spyOn(service, 'submitCancelInsurance').and.returnValue(of(POLICIES));

          component.submitReviewForm();
          expect(service.submitCancelInsurance).toHaveBeenCalledWith('1234', '5273593');
          expect(service.submitCancelInsurance).toHaveBeenCalledWith('1234', '5273590');
          expect(component.inProgress).toBeFalsy();
          expect(component.partialSubmit).toBe(false);
          expect(component.submittedPolicies).toEqual([POLICIES[0], POLICIES[3]]);
          expect(component.state).toEqual('confirmation');
        });

        it('should change the state and make inProgress false on partial success', () => {
          component.insurance = POLICIES[0];
          component.associatedTpdCovers = [POLICIES[3]];
          spyOn(service, 'submitCancelInsurance')
            .withArgs('1234', '5273593')
            .and.returnValue(of(POLICIES))
            .withArgs('1234', '5273590')
            .and.returnValue(throwError('error'));

          component.submitReviewForm();
          expect(service.submitCancelInsurance).toHaveBeenCalledWith('1234', '5273593');
          expect(service.submitCancelInsurance).toHaveBeenCalledWith('1234', '5273590');
          expect(component.inProgress).toBeFalsy();
          expect(component.partialSubmit).toBe(true);
          expect(component.submittedPolicies).toEqual([POLICIES[3]]);
          expect(component.state).toEqual('confirmation');

          const pageScrollOptions = {
            document: (component as any).document,
            scrollTarget: '.top-scroll',
            scrollViews: [document.querySelector('.layout-scroll')],
            duration: 200
          };
          expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
        });

        it('should not change the state and make inProgress false on error', () => {
          component.insurance = POLICIES[0];
          component.associatedTpdCovers = [POLICIES[3]];
          spyOn(service, 'submitCancelInsurance').and.returnValue(throwError('error'));

          component.submitReviewForm();
          expect(service.submitCancelInsurance).toHaveBeenCalledWith('1234', '5273593');
          expect(service.submitCancelInsurance).not.toHaveBeenCalledWith('1234', '5273590');
          expect(component.inProgress).toBeFalsy();
          expect(component.partialSubmit).toBe(false);
          expect(component.submittedPolicies).toEqual([]);
          expect(component.state).toBeUndefined();

          const pageScrollOptions = {
            document: (component as any).document,
            scrollTarget: '.top-scroll',
            scrollViews: [document.querySelector('.layout-scroll')],
            duration: 200
          };
          expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
        });
      });
    });

    describe('navigateToOverview', () => {
      it('should navigate to insurancePolicies screen', () => {
        component.navigateToOverview();

        expect((component as any).uiRouter.stateService.go).toHaveBeenCalledWith(
          'app.investor.account.insurancePolicies',
          {},
          { reload: true }
        );
      });
    });

    describe('navigateToChangeOrDecreaseCover', () => {
      it('navigateToDecreaseCover', () => {
        component.insurance = POLICIES[0];
        component.navigateToChangeOrDecreaseCover('decrease');
        expect((component as any).uiRouter.stateService.go).toHaveBeenCalledWith(CHANGE_INSURANCE_STATE, {
          insurance: POLICIES[0],
          policyNumber: '5273590',
          mode: 'decrease'
        });
      });

      it('navigateToChangeCover', () => {
        component.insurance = POLICIES[0];
        component.navigateToChangeOrDecreaseCover('change');
        expect((component as any).uiRouter.stateService.go).toHaveBeenCalledWith(CHANGE_INSURANCE_STATE, {
          insurance: POLICIES[0],
          policyNumber: '5273590',
          mode: 'change'
        });
      });
    });
  });

  describe('View', () => {
    describe('review', () => {
      it('show header', () => {
        const headerText = fixture.debugElement.query(By.css('.js-test-header-text')).nativeElement.innerHTML.trim();

        expect(headerText).toEqual('Cancel your cover');
      });

      it('show associated tpd covers alert if associated tpd covers are being cancelled', () => {
        component.associatedTpdCovers = [POLICIES[2]];

        component.state = 'review';
        fixture.detectChanges();
        const btAlert = fixture.debugElement.query(By.css('.ts-associated-tpd-covers-alert'));

        expect(btAlert).toBeTruthy();
      });

      it('show review section', () => {
        const reviewHeader = fixture.debugElement.query(By.css('.ts-info-message'));

        expect(reviewHeader).not.toBeNull();
      });

      it('should show cover to cancel', () => {
        component.state = 'review';
        fixture.detectChanges();
        const cover = fixture.debugElement.query(By.css('.ts-cover-to-cancel'));

        expect(cover).toBeTruthy();
      });

      it('should show associated cover to cancel', () => {
        component.associatedTpdCovers = [POLICIES[2]];

        component.state = 'review';
        fixture.detectChanges();
        const cover = fixture.debugElement.query(By.css('.ts-associated-tpd-covers-details'));

        expect(cover).toBeTruthy();
      });

      it('should show cancel cover over 60 alert message if members age next birthday is less than 60', () => {
        const insurance = { ...POLICIES[0] };
        insurance.ageNextBirthday = 61;
        component.state = 'review';
        component.insurance = insurance;
        component.canCancelCoverOver60 = true;

        fixture.detectChanges();
        const alert = fixture.debugElement.query(By.css('.ts-cancel-cover-over-60'));

        expect(alert).toBeTruthy();
      });
    });

    describe('confirmation', () => {
      it('do not show review section when state is not review', () => {
        component.state = 'confirmation';
        fixture.detectChanges();

        const reviewHeader = fixture.debugElement.query(By.css('.ts-info-message'));

        expect(reviewHeader).toBeNull();
      });

      it('should show cover to cancel confirmation', () => {
        component.submittedPolicies = [POLICIES[2]];
        component.partialSubmit = false;
        component.state = 'confirmation';
        fixture.detectChanges();

        const partialSubmitMessage = fixture.debugElement.query(By.css('.ts-partial-submit-alert'));
        const cover = fixture.debugElement.queryAll(By.css('.ts-submitted-policy-type'));
        expect(partialSubmitMessage).toBeNull();
        expect(cover[0].nativeElement.innerText).toContain('Death cover');
      });

      it('should show associated cover to cancel confirmation', () => {
        component.submittedPolicies = [POLICIES[2], POLICIES[3]];
        component.partialSubmit = false;
        component.state = 'confirmation';
        fixture.detectChanges();

        const partialSubmitMessage = fixture.debugElement.query(By.css('.ts-partial-submit-alert'));
        const cover = fixture.debugElement.queryAll(By.css('.ts-submitted-policy-type'));
        expect(partialSubmitMessage).toBeNull();
        expect(cover[0].nativeElement.innerText).toContain('Death cover');
        expect(cover[1].nativeElement.innerText).toContain('Total Permanent Disability/Disablement (TPD)');
      });

      it('should not show death cover on partial success', () => {
        component.submittedPolicies = [POLICIES[3]];
        component.partialSubmit = true;

        component.state = 'confirmation';
        fixture.detectChanges();

        const partialSubmitMessage = fixture.debugElement.query(By.css('.ts-partial-submit-alert'));
        const cover = fixture.debugElement.queryAll(By.css('.ts-submitted-policy-type'));
        expect(partialSubmitMessage).toBeTruthy();
        expect(cover[0].nativeElement.innerText).toContain('Total Permanent Disability/Disablement (TPD)');
      });

      it('do not show confirmation section when state is not confirmation', () => {
        component.state = 'review';
        fixture.detectChanges();

        const confirmationHeader = fixture.debugElement.query(By.css('.cancel-cover-confirmation-header'));

        expect(confirmationHeader).toBeNull();
      });

      it('show employer paid warning when paid by employer', () => {
        component.insurance = POLICIES[2];
        fixture.detectChanges();

        const employerPaidAlert = fixture.debugElement.query(By.css('.ts-employer-paid-warning-alert'));

        expect(employerPaidAlert.nativeElement.innerText).toContain('Ins-IP-1085');
      });

      it('should show submit button and should call submitForm when clicked on submit button', () => {
        component.insurance = POLICIES[0];
        spyOn(component, 'submitReviewForm');

        const submitButton = fixture.debugElement.query(By.css('.js-test-review-form-button'));
        expect(submitButton).toBeTruthy();

        submitButton.triggerEventHandler('btClick', null);
        expect(component.submitReviewForm).toHaveBeenCalled();
      });

      it('should navigate back when clicked on cancel', () => {
        spyOn(component, 'navigateToOverview');
        spyOn(component, 'submitReviewForm');

        const cancelButton = fixture.debugElement.query(By.css('.js-test-cancel-button'));
        expect(cancelButton).toBeTruthy();

        cancelButton.triggerEventHandler('btClick', null);
        expect(component.navigateToOverview).toHaveBeenCalled();
        expect(component.submitReviewForm).not.toHaveBeenCalled();
      });

      it('should show monthly premium as Not applicable if its 0 for BYO cover', () => {
        component.state = 'confirmation';
        component.submittedPolicies = [IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[0]];
        component.insurance = IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[0];
        fixture.detectChanges();

        const premiumEl = fixture.debugElement.query(By.css('.ts-confirmation-premium'));

        expect(premiumEl.nativeElement.innerText).toBe('Not applicable');
      });

      it('should not show monthly premium as Not applicable if its not 0 or not BYO cover', () => {
        component.state = 'confirmation';
        component.submittedPolicies = [IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[1]];
        component.insurance = IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES[1];
        fixture.detectChanges();

        const premiumEl = fixture.debugElement.query(By.css('.ts-confirmation-premium'));

        expect(premiumEl.nativeElement.innerText).toBe('$1.00');
      });
    });
  });
});
