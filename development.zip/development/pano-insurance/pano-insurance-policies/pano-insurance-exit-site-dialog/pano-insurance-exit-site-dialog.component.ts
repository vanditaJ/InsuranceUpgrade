import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Link } from '@bt/components/link';
import { WINDOW } from '@bt/tokens';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { INVESTOR_ACCOUNT_ERROR_STATE } from '../pano-insurance-policies.constants';

import {
  AIA_PRIVACY_POLICY_LINK,
  AIA_SSO_URL,
  BT_PRIVACY_POLICY_LINK,
  CHECK_YOUR_DETAILS_LINK,
  EXIT_DIALOG_ACCEPT_BUTTON,
  EXIT_DIALOG_CANCEL_BUTTON,
  EXIT_DIALOG_CLOSE_BUTTON,
  MANAGE_INSURANCE_ALERT
} from './pano-insurance-exit-site-dialog.constants';

@Component({
  selector: 'pano-insurance-exit-site-dialog',
  templateUrl: './pano-insurance-exit-site-dialog.component.html'
})
export class PanoInsuranceExitSiteDialogComponent implements OnInit {
  acceptButton: Button = EXIT_DIALOG_ACCEPT_BUTTON;
  cancelButton: Button = EXIT_DIALOG_CANCEL_BUTTON;
  checkYourDetailsLink: Link = CHECK_YOUR_DETAILS_LINK;
  closeButton: Button = EXIT_DIALOG_CLOSE_BUTTON;
  btPrivacyPolicyLink: Link = BT_PRIVACY_POLICY_LINK;
  aiaPrivacyPolicyLink: Link = AIA_PRIVACY_POLICY_LINK;
  manageInsuranceAlert: Alert = MANAGE_INSURANCE_ALERT;
  account: any;
  isAccountValid: boolean;

  constructor(
    public readonly dialogRef: MatDialogRef<PanoInsuranceExitSiteDialogComponent>,
    @Inject(WINDOW) private readonly window: Window,
    private route: UIRouter,
    private accountService: PanoUpgradeAccountService
  ) {}

  ngOnInit(): void {
    this.account = this.accountService.get();
    this.isAccountValid = this.account && this.account.accountId;
    if (this.isAccountValid) {
      this.checkYourDetailsLink.link = `#/app/investor/account/${this.account.accountId}/your-details`;
    }
  }

  cancel(): void {
    this.dialogRef.close();
  }

  goToAiaDashboard(): void {
    if (this.isAccountValid) {
      this.window.open(`${AIA_SSO_URL}?accountId=${this.account.accountId}`, '_blank');
    } else {
      this.route.stateService.go(INVESTOR_ACCOUNT_ERROR_STATE);
    }
    this.dialogRef.close();
  }
}
