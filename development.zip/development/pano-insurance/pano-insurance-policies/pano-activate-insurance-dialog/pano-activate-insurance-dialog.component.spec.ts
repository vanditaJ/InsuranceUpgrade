import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { PipesTestingModule } from '@bt/pipes/testing';
import { of, throwError } from 'rxjs';

import { PanoInsuranceService } from '../../pano-insurance.service';
import { OPT_IN_STATUS } from '../pano-insurance-policies.constants';

import { PanoActivateInsuranceDialogComponent } from './pano-activate-insurance-dialog.component';
import { CANCEL_BUTTON, CLOSE_ICON, SUBMIT_BUTTON } from './pano-activate-insurance-dialog.constants';

describe('PanoActivateInsuranceDialogComponent', () => {
  let component: PanoActivateInsuranceDialogComponent;
  let fixture: ComponentFixture<PanoActivateInsuranceDialogComponent>;
  let service: PanoInsuranceService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          MatDialogModule,
          MatFormFieldModule,
          MatCheckboxModule,
          ReactiveFormsModule,
          PipesTestingModule,
          HttpClientTestingModule
        ],
        declarations: [PanoActivateInsuranceDialogComponent],
        providers: [
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          {
            provide: PanoInsuranceService,
            useValue: {
              submitPysOptInRequest: () => {},
              submitPmifOptInRequest: () => {}
            }
          },
          {
            provide: MAT_DIALOG_DATA,
            useValue: {
              accountId: '1234'
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [PanoActivateInsuranceDialogComponent]
        }
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoActivateInsuranceDialogComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(PanoInsuranceService);
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create component', () => {
      expect(component).toBeTruthy();
    });

    describe('ngOnInit', () => {
      it('should create form', () => {
        component.ngOnInit();
        expect(component.termsAndConditions.get('acknowledge')).toBeTruthy();
      });
    });

    describe('submit', () => {
      it('should not submit when terms and conditions are not acknowledged', () => {
        component.termsAndConditions.controls['acknowledge'].setValue(false);
        component.data.optInToPmif = true;
        component.data.optInToPys = true;

        component.optInPmifAndPys = jasmine.createSpy();
        component.optInPmif = jasmine.createSpy();
        component.optInPys = jasmine.createSpy();

        component.submit();

        expect(component.submitting).toBe(false);
        expect(component.optInPmifAndPys).not.toHaveBeenCalled();
        expect(component.optInPmif).not.toHaveBeenCalled();
        expect(component.optInPys).not.toHaveBeenCalled();
      });

      it('should not submit when no opt-in requested', () => {
        component.termsAndConditions.controls['acknowledge'].setValue(true);
        component.data.optInToPmif = false;
        component.data.optInToPys = false;

        component.optInPmifAndPys = jasmine.createSpy();
        component.optInPmif = jasmine.createSpy();
        component.optInPys = jasmine.createSpy();

        component.submit();

        expect(component.submitting).toBe(false);
        expect(component.optInPmifAndPys).not.toHaveBeenCalled();
        expect(component.optInPmif).not.toHaveBeenCalled();
        expect(component.optInPys).not.toHaveBeenCalled();
      });

      it('should request combined pmif and pys opt-in', () => {
        component.termsAndConditions.controls['acknowledge'].setValue(true);
        component.data.optInToPmif = true;
        component.data.optInToPys = true;

        component.optInPmifAndPys = jasmine.createSpy();
        component.optInPmif = jasmine.createSpy();
        component.optInPys = jasmine.createSpy();

        component.submit();

        expect(component.submitting).toBe(true);
        expect(component.optInPmifAndPys).toHaveBeenCalled();
        expect(component.optInPmif).not.toHaveBeenCalled();
        expect(component.optInPys).not.toHaveBeenCalled();
      });

      it('should request pmif only opt-in', () => {
        component.termsAndConditions.controls['acknowledge'].setValue(true);
        component.data.optInToPmif = true;
        component.data.optInToPys = false;

        component.optInPmifAndPys = jasmine.createSpy();
        component.optInPmif = jasmine.createSpy();
        component.optInPys = jasmine.createSpy();

        component.submit();

        expect(component.submitting).toBe(true);
        expect(component.optInPmifAndPys).not.toHaveBeenCalled();
        expect(component.optInPmif).toHaveBeenCalled();
        expect(component.optInPys).not.toHaveBeenCalled();
      });

      it('should request pys only opt-in', () => {
        component.termsAndConditions.controls['acknowledge'].setValue(true);
        component.data.optInToPmif = false;
        component.data.optInToPys = true;

        component.optInPmifAndPys = jasmine.createSpy();
        component.optInPmif = jasmine.createSpy();
        component.optInPys = jasmine.createSpy();

        component.submit();

        expect(component.submitting).toBe(true);
        expect(component.optInPmifAndPys).not.toHaveBeenCalled();
        expect(component.optInPmif).not.toHaveBeenCalled();
        expect(component.optInPys).toHaveBeenCalled();
      });
    });

    describe('optInPmifAndPys', () => {
      it('submits pmif and pys opt-in and returns success if they both pass', () => {
        service.submitPmifOptInRequest = jasmine.createSpy().and.returnValue(of('success'));
        service.submitPysOptInRequest = jasmine.createSpy().and.returnValue(of('success'));

        component.optInPmifAndPys();

        expect(service.submitPmifOptInRequest).toHaveBeenCalled();
        expect(service.submitPysOptInRequest).toHaveBeenCalled();
        expect(component.submitting).toBe(false);
        expect(component.error).toBe(false);
        expect(component.termsAndConditions.get('acknowledge').disabled).toBe(false);
        expect(component.dialogRef.close).toHaveBeenCalledWith(OPT_IN_STATUS.success);
      });

      it('submits pmif and pys opt-in and returns success if pmif passes and pys fails', () => {
        service.submitPmifOptInRequest = jasmine.createSpy().and.returnValue(of('success'));
        service.submitPysOptInRequest = jasmine.createSpy().and.returnValue(throwError({}));

        component.optInPmifAndPys();

        expect(service.submitPmifOptInRequest).toHaveBeenCalled();
        expect(service.submitPysOptInRequest).toHaveBeenCalled();
        expect(component.submitting).toBe(false);
        expect(component.error).toBe(false);
        expect(component.termsAndConditions.get('acknowledge').disabled).toBe(false);
        expect(component.dialogRef.close).toHaveBeenCalledWith(OPT_IN_STATUS.pysFail);
      });

      it('submits pmif and pys opt-in and returns error if pmif fails and pys is not run', () => {
        service.submitPmifOptInRequest = jasmine.createSpy().and.returnValue(throwError({}));
        service.submitPysOptInRequest = jasmine.createSpy();

        component.optInPmifAndPys();

        expect(service.submitPmifOptInRequest).toHaveBeenCalled();
        expect(service.submitPysOptInRequest).not.toHaveBeenCalled();
        expect(component.submitting).toBe(false);
        expect(component.error).toBe(true);
        expect(component.termsAndConditions.get('acknowledge').disabled).toBe(false);
        expect(component.dialogRef.close).not.toHaveBeenCalled();
      });
    });

    describe('optInPmif', () => {
      it('submits pmif opt-in and runs success handler on success', () => {
        service.submitPmifOptInRequest = jasmine.createSpy().and.returnValue(of('success'));

        component.optInPmif();

        expect(service.submitPmifOptInRequest).toHaveBeenCalled();
        expect(component.submitting).toBe(false);
        expect(component.error).toBe(false);
        expect(component.termsAndConditions.get('acknowledge').disabled).toBe(false);
        expect(component.dialogRef.close).toHaveBeenCalled();
      });

      it('submits pmif opt-in and runs error handler on error', () => {
        service.submitPmifOptInRequest = jasmine.createSpy().and.returnValue(throwError({}));

        component.optInPmif();

        expect(service.submitPmifOptInRequest).toHaveBeenCalled();
        expect(component.submitting).toBe(false);
        expect(component.error).toBe(true);
        expect(component.termsAndConditions.get('acknowledge').disabled).toBe(false);
        expect(component.dialogRef.close).not.toHaveBeenCalled();
      });
    });

    describe('optInPys', () => {
      it('just resets state as pys only opt-in is not implemented', () => {
        service.submitPysOptInRequest = jasmine.createSpy();

        component.optInPys();

        expect(service.submitPysOptInRequest).not.toHaveBeenCalled();
        expect(component.submitting).toBe(false);
        expect(component.error).toBe(false);
        expect(component.termsAndConditions.get('acknowledge').disabled).toBe(false);
        expect(component.dialogRef.close).toHaveBeenCalled();
      });
    });

    describe('closeDialog', () => {
      it('should close dialog with parameter', () => {
        component.closeDialog(OPT_IN_STATUS.success);

        expect(component.dialogRef.close).toHaveBeenCalledWith(OPT_IN_STATUS.success);
      });
    });
  });

  describe('view', () => {
    it('should have header', () => {
      expect(fixture.debugElement.query(By.css('h1'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.ts-header')).nativeElement.innerHTML).toBe(
        'Activate your insurance cover'
      );
    });

    describe('should have correct description', () => {
      it('should show description for pmif', () => {
        component.data.optInToPmif = true;
        component.data.optInToPys = false;
        component.data.showStandardCoverGreaterThan30DaysText = false;
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.ts-body')).nativeElement.innerHTML).toContain(
          'test-copy-matrix__DS-IP-0364'
        );
      });

      it('should show description for pmif with 30days less riskCommencementDate', () => {
        component.data.optInToPmif = true;
        component.data.optInToPys = false;
        component.data.showStandardCoverGreaterThan30DaysText = true;
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.ts-body')).nativeElement.innerHTML).toContain(
          'test-copy-matrix__DS-IP-0365'
        );
      });

      it('should show description for pys', () => {
        component.data.optInToPmif = false;
        component.data.optInToPys = true;
        component.data.showStandardCoverGreaterThan30DaysText = false;
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.ts-body')).nativeElement.innerHTML).toContain(
          'test-copy-matrix__DS-IP-0362'
        );
      });

      it('should show description for pys with 30 days less riskCommencementDate', () => {
        component.data.optInToPmif = false;
        component.data.optInToPys = true;
        component.data.showStandardCoverGreaterThan30DaysText = true;
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.ts-body')).nativeElement.innerHTML).toContain(
          'test-copy-matrix__DS-IP-0367'
        );
      });
    });

    it('should have submit button', () => {
      component.submit = jasmine.createSpy();
      const submitButton = fixture.debugElement.query(By.css('.ts-submit'));
      expect(submitButton.properties.config).toEqual(SUBMIT_BUTTON);

      fixture.debugElement.query(By.css('form')).triggerEventHandler('ngSubmit', null);
      expect(component.submit).toHaveBeenCalled();
    });

    it('should have cancel button', () => {
      const cancelButton = fixture.debugElement.query(By.css('.ts-cancel'));
      expect(cancelButton.properties.config).toEqual(CANCEL_BUTTON);

      cancelButton.nativeElement.dispatchEvent(new Event('btClick', null));
      expect(component.dialogRef.close).toHaveBeenCalled();
    });

    it('should have close button with X icon', () => {
      const closeIcon = fixture.debugElement.query(By.css('.ts-close-icon'));
      expect(closeIcon.properties.config).toEqual(CLOSE_ICON);

      closeIcon.nativeElement.dispatchEvent(new Event('btClick', null));
      expect(component.dialogRef.close).toHaveBeenCalled();
    });
  });
});
