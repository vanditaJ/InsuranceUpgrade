export const MOCK_INVESTMENT_OBJECTIVES = [
  { name: 'REGULAR_INCOME', value: true, descripton: 'Regular income' },
  { name: 'CAPITAL_GUARANTEED', value: true, descripton: 'Capital guaranteed' },
  { name: 'CAPITAL_PRESERVATION', value: false, descripton: 'Capital preservation' },
  { name: 'CAPITAL_GROWTH', value: false, descripton: 'Capital growth' }
];

export const MOCK_INVESTMENT_TIMEFRAMES = [
  { name: 'SHORT', value: true, descripton: 'Short (less than 2 years)' },
  { name: 'MEDIUM', value: true, descripton: 'Medium (2 to 8 years)' },
  { name: 'LONG', value: false, descripton: 'Long (8 or more years)' }
];
export const MOCK_RETURN_OBJECTIVES = {
  maxValue: 1,
  minValue: 0,
  options: {
    ceil: 3,
    floor: 0,
    showTicksValues: true
  }
};

export const MOCK_REDEMPTION_FREQUENCIES = {
  maxValue: 1,
  minValue: 0,
  options: {
    ceil: 3,
    floor: 0,
    showTicksValues: true
  }
};
