import { Button } from '@bt/components/button';

export const SCI_HINT_AEM_KEY: string = 'sci_hint_message';

export const SCI_AEM_KEY: string = 'decrease_selection_sci_summary';

export const SUM_INSURED_AEM_KEY: string = 'decrease_selection_sum_summary';

export const UNITS_OF_COVER_AEM_KEY: string = 'decrease_selection_units_summary';

export const CLOSE_TEXT_BUTTON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  iconPosition: 'right',
  colourModifier: 'primary',
  label: 'Close',
  size: 'large',
  type: 'solid',
  a11yProps: {
    ariaLabel: 'Dialog close button'
  }
};

export const CLOSE_ICON_BUTTON: Button = {
  action: 'button',
  icon: {
    name: 'icon-cross'
  },
  size: 'medium',
  colourModifier: 'basic',
  a11yProps: {
    ariaLabel: 'Dialog close button'
  }
};
