import { Link } from '@bt/components/link';
import { Account } from '@investor/account/pano-shared/interfaces';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';

import { PRODUCT } from '../../pano-insurance.constants';
import { InsurancePolicy } from '../../pano-insurance.interface';

import { OCCUPATION_CATEGORY_INFO_TITLE, TRANSFER_INSURANCE_TITLE } from './pano-insurance-links.constants';
import { InsuranceLink } from './pano-insurance-links.interface';

export const POLICY_II1: InsurancePolicy = {
  applicableNotes: 'II1',
  policyType: '',
  policyName: '',
  sumInsured: null,
  premium: '',
  status: '',
  commencementDate: null,
  endDate: null,
  external: false,
  personBenefitDetails: null,
  smokerStatus: '',
  customised: false,
  employerFunded: false,
  westpacGroupPlan: false,
  ageNextBirthday: 65,
  customerType: 'Retail',
  policyNumber: '',
  coverSubTypeId: null,
  qualifierName: ''
};

export const POLICY_II2: InsurancePolicy = {
  applicableNotes: 'II2',
  policyType: '',
  policyName: '',
  sumInsured: null,
  premium: '',
  status: '',
  commencementDate: null,
  endDate: null,
  external: false,
  personBenefitDetails: null,
  smokerStatus: '',
  customised: false,
  employerFunded: false,
  westpacGroupPlan: false,
  ageNextBirthday: 65,
  customerType: 'Retail',
  policyNumber: '',
  coverSubTypeId: null,
  qualifierName: ''
};

export const POLICY_II1_II2: InsurancePolicy = {
  applicableNotes: 'II1,II2',
  policyType: '',
  policyName: '',
  sumInsured: null,
  premium: '',
  status: '',
  commencementDate: null,
  endDate: null,
  external: false,
  personBenefitDetails: null,
  smokerStatus: '',
  customised: false,
  employerFunded: false,
  westpacGroupPlan: false,
  ageNextBirthday: 65,
  customerType: 'Retail',
  policyNumber: '',
  coverSubTypeId: null,
  qualifierName: ''
};

export const POLICY_FN1: InsurancePolicy = {
  applicableNotes: 'FN1',
  policyType: '',
  policyName: '',
  sumInsured: null,
  premium: '',
  status: '',
  commencementDate: null,
  endDate: null,
  external: false,
  personBenefitDetails: null,
  smokerStatus: '',
  customised: false,
  employerFunded: false,
  westpacGroupPlan: false,
  ageNextBirthday: 65,
  customerType: 'Retail',
  policyNumber: '',
  coverSubTypeId: null,
  qualifierName: ''
};

export const POLICY_LIFETIME: InsurancePolicy = {
  applicableNotes: 'II1',
  policyType: '',
  policyName: '',
  sumInsured: null,
  premium: '',
  status: '',
  commencementDate: null,
  endDate: null,
  external: false,
  personBenefitDetails: null,
  smokerStatus: '',
  customised: false,
  employerFunded: false,
  westpacGroupPlan: false,
  ageNextBirthday: 65,
  customerType: 'BT Super - Retail',
  policyNumber: '',
  coverSubTypeId: null,
  qualifierName: ''
};

export const BTSFL_ACCOUNT: Account = {
  key: {
    accountId: null
  },
  accountName: '',
  accountNumber: '1234',
  firstMoneyReceivedDate: '',
  pdsStatus: 'DEFAULT',
  product: { productSubType: 'PERSONAL_SUPER' },
  productDescription: PRODUCT.BT_SUPER_FOR_LIFE
};

export const BTS_ACCOUNT: Account = {
  key: {
    accountId: null
  },
  accountName: '',
  accountNumber: '1234',
  firstMoneyReceivedDate: '',
  pdsStatus: 'DEFAULT',
  product: { productSubType: 'CORPORATE_SUPER' },
  productDescription: PRODUCT.BT_SUPER
};

export const WGP_ACCOUNT: Account = {
  key: {
    accountId: null
  },
  accountName: '',
  accountNumber: '1234',
  firstMoneyReceivedDate: '',
  pdsStatus: 'WGP_CURRENT',
  product: { productSubType: 'CORPORATE_SUPER' },
  productDescription: PRODUCT.BT_SUPER
};

export const TEST_INSURANCE_LINKS: InsuranceLink[] = [
  {
    title: 'Title',
    content: 'Content',
    linkType: LinkType.INSURANCE_APPLICATION_FORM,
    index: 1,
    applicableNote: 'II1'
  },
  {
    title: 'Title',
    content: 'Content',
    index: 2,
    applicableNote: 'II1'
  },
  {
    title: 'title',
    content: 'Content',
    linkType: LinkType.INSURANCE_APPLICATION_FORM,
    index: 3,
    applicableNote: 'II2'
  },
  {
    title: 'title',
    content: 'Content',
    index: 4,
    applicableNote: 'II3'
  },
  {
    title: 'Title',
    content: 'Content',
    index: 5
  }
];

export const LINK: Link = {
  isLinkExternal: true,
  label: 'test link',
  link: 'test url',
  openNewTab: true,
  type: 'flat',
  colourModifier: 'primary',
  a11yProps: {
    ariaLabel: '{label}'
  }
};

export const INTERNAL_LINK: Link = {
  isLinkExternal: false,
  label: 'test link',
  link: 'test url',
  openNewTab: false,
  type: 'flat',
  colourModifier: 'primary'
};

export const TEST_ACTIVE_LINKS: InsuranceLink[] = [
  {
    title: 'Title',
    content: 'Content',
    index: 1,
    applicableNote: 'II1'
  },
  {
    title: 'Title2',
    content: 'Content2',
    linkType: LinkType.INSURANCE_APPLICATION_FORM,
    link: INTERNAL_LINK,
    index: 2,
    applicableNote: 'II1'
  },
  {
    title: 'Title3',
    content: 'Content3',
    linkType: LinkType.INSURANCE_APPLICATION_FORM,
    link: LINK,
    contentAfterLink: 'ContentAfterLink3',
    index: 3,
    applicableNote: 'II1'
  }
];

export const TEST_OCCUPATION_CATEGORY_INFO_LINK: InsuranceLink = {
  title: OCCUPATION_CATEGORY_INFO_TITLE,
  content: '{information} Refer to the ',
  linkType: LinkType.INSURANCE_GUIDE,
  contentAfterLink: ' for more information',
  index: 4,
  applicableNote: 'II1'
};

export const TEST_TRANSFER_INSURANCE_LINK: InsuranceLink = {
  title: TRANSFER_INSURANCE_TITLE,
  content: `You can apply to transfer your non-BT Super insurance cover to your BT Super account at any time by completing the `,
  linkType: LinkType.INSURANCE_TRANSFER_FORM,
  index: 5,
  applicableNote: 'II2'
};
