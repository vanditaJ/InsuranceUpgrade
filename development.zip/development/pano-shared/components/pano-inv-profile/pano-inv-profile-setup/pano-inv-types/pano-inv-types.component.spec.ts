import { HarnessLoader } from '@angular/cdk/testing';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';
import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatRadioButtonHarness, MatRadioGroupHarness } from '@angular/material/radio/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { INVESTMENT_TYPES } from '../../pano-inv-profile.constants';

import { PanoInvestmentTypesComponent } from './pano-inv-types.component';

@Component({
  template: `
    <pano-inv-types [(investmentType)]="investmentType" (investmentTypeChange)="investmentTypeChange($event)">
    </pano-inv-types>
  `
})
class TestHostComponent {
  investmentType: string = INVESTMENT_TYPES.ALL_INVESTMENT_TYPES;
  investmentTypeChange(): void {}
}

describe('PanoInvestmentTypesComponent', () => {
  let component: PanoInvestmentTypesComponent;
  let fixture: ComponentFixture<PanoInvestmentTypesComponent>;
  let loader: HarnessLoader;

  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [PanoInvestmentTypesComponent, TestHostComponent],
      imports: [ReactiveFormsModule, NoopAnimationsModule, MatRadioModule],
      providers: [{ provide: FormBuilder, useValue: formBuilder }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    loader = TestbedHarnessEnvironment.loader(fixture);
  });

  describe('view', () => {
    it('should load investment types radio button group', async () => {
      const groups = await loader.getAllHarnesses(MatRadioGroupHarness);
      expect(groups.length).toBe(1);
    });

    it('should have correct label text for sharedAndEtfs, allInvestmentTypes radio buttons', async () => {
      const [sharedAndEtfs, allInvestmentTypes] = await loader.getAllHarnesses(MatRadioButtonHarness);
      expect(await sharedAndEtfs.getLabelText()).toContain(component.sharedAndEtfsTitle);
      expect(await sharedAndEtfs.getLabelText()).toContain(component.sharedAndEtfsDescription);

      expect(await allInvestmentTypes.getLabelText()).toContain(component.allInvestmentTypesTitle);
      expect(await allInvestmentTypes.getLabelText()).toContain(component.allInvestmentTypesDescription);
    });

    it('should check investment types with SHARES_AND_ETFS', async () => {
      spyOn(component.investmentTypeChange, 'emit').and.stub();
      const [sharedAndEtfs, allInvestmentTypes] = await loader.getAllHarnesses(MatRadioButtonHarness);

      await sharedAndEtfs.check();

      expect(await sharedAndEtfs.isChecked()).toBeTrue();
      expect(await allInvestmentTypes.isChecked()).toBeFalse();
      expect(component.investmentTypeChange.emit).toHaveBeenCalledOnceWith(INVESTMENT_TYPES.SHARES_AND_ETFS);
    });

    it('should check investment types with ALL_INVESTMENT_TYPES', async () => {
      spyOn(component.investmentTypeChange, 'emit').and.stub();
      const [sharedAndEtfs, allInvestmentTypes] = await loader.getAllHarnesses(MatRadioButtonHarness);

      await allInvestmentTypes.check();

      expect(await sharedAndEtfs.isChecked()).toBeFalse();
      expect(await allInvestmentTypes.isChecked()).toBeTrue();
      expect(component.investmentTypeChange.emit).toHaveBeenCalledOnceWith(INVESTMENT_TYPES.ALL_INVESTMENT_TYPES);
    });

    it('should show investment types warning if no option is checked', async () => {
      component.form.controls.investmentType.markAsTouched();
      fixture.detectChanges();

      const warning = fixture.debugElement.query(By.css('bt-alert'));
      expect(warning).toBeTruthy();
      expect(warning.properties.config).toEqual(component.requireInvestmentTypeInputAlert);
    });
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
      expect(component.form).toBeTruthy();
    });

    it('should have correct input and output mapping with its host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);

      const hostComponent = hostFixture.componentInstance;
      const currentComp: PanoInvestmentTypesComponent = hostFixture.debugElement.query(
        By.directive(PanoInvestmentTypesComponent)
      ).componentInstance;

      spyOn(hostComponent, 'investmentTypeChange');

      hostFixture.detectChanges();
      currentComp.investmentTypeChange.emit(component.allInvestmentTypes);

      expect(currentComp.investmentType).toEqual(hostComponent.investmentType);
      expect(hostComponent.investmentTypeChange).toHaveBeenCalled();
    });

    describe('OnDestroy()', () => {
      it('should call unsubscribe$.complete', () => {
        const unsubSpy = spyOn(component.unsubscribe$, 'complete').and.stub();

        component.ngOnDestroy();

        expect(unsubSpy).toHaveBeenCalled();
      });
    });

    describe('ngOnInit()', () => {
      it('should create form', () => {
        component.ngOnInit();
        expect(component.form).toBeTruthy();
      });
    });
  });
});
