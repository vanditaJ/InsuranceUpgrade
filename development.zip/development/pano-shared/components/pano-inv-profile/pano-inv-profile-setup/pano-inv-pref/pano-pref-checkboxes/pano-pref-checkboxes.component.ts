import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { CheckboxField } from '../pano-inv-pref.interface';

import { FormFieldBoolean } from './pano-pref-checkboxes.interface';

@Component({
  selector: 'pano-pref-checkboxes',
  templateUrl: './pano-pref-checkboxes.component.html',
  styleUrls: ['./pano-pref-checkboxes.component.scss']
})
export class PanoCheckboxesComponent implements OnChanges, OnDestroy {
  @Input() checkBoxFields: CheckboxField[];
  @Output() checkBoxFieldsChange: EventEmitter<CheckboxField[]> = new EventEmitter();

  form: FormGroup;
  fieldGroup: FormFieldBoolean = {};

  readonly unsubscribe$: Subject<void> = new Subject();

  constructor(private fb: FormBuilder) {}

  ngOnChanges(changes: SimpleChanges): void {
    this.checkBoxFields = changes?.checkBoxFields?.currentValue;

    this.form = this.fb.group({});
    if (this.checkBoxFields) {
      this.checkBoxFields.forEach((field: CheckboxField) =>
        this.form.addControl(field.name, this.fb.control(field.value))
      );

      this.form.valueChanges.pipe(takeUntil(this.unsubscribe$)).subscribe(values => {
        this.checkBoxFields = this.checkBoxFields.map((field: CheckboxField) => {
          return { ...field, value: values[field.name] };
        });

        this.checkBoxFieldsChange.emit(this.checkBoxFields);
      });
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
