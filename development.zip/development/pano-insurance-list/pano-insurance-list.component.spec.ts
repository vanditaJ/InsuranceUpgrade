import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PanoInsuranceListComponent } from './pano-insurance-list.component';
import { PanoInsuranceListService } from './pano-insurance-list.service';

describe('PanoInsuranceListComponent', () => {
  let component: PanoInsuranceListComponent;
  let fixture: ComponentFixture<PanoInsuranceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PanoInsuranceListComponent],
      providers: [PanoInsuranceListService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsuranceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
