import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';

import { PanoInvestmentsOverviewVideoModalComponent } from './pano-investments-overview-video-modal.component';

describe('PanoPysOptInAllComponent', () => {
  let fixture: ComponentFixture<PanoInvestmentsOverviewVideoModalComponent>;
  let component: PanoInvestmentsOverviewVideoModalComponent;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInvestmentsOverviewVideoModalComponent],
        imports: [],
        providers: [
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          {
            provide: MAT_DIALOG_DATA,
            useValue: {
              content: '1244'
            }
          }
        ],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentsOverviewVideoModalComponent);
    component = fixture.componentInstance;
  });

  describe('View', () => {
    it('should show correct heading from data', () => {
      component.data.heading = 'Video heading';
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('h1')).nativeElement.innerHTML).toContain('Video heading');
    });
    it('should show correct content from data', () => {
      component.data.content = 'video content';
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.video-dialog')).nativeElement.innerHTML).toContain('video content');
    });
  });
});
