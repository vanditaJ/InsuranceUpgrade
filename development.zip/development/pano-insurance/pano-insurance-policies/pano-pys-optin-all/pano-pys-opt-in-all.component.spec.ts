import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { PipesTestingModule } from '@bt/pipes/testing';
import { AlertModule } from 'ngx-bootstrap/alert';
import { of, throwError } from 'rxjs';

import { GENERIC_ERROR_ALERT } from '../../pano-insurance.constants';
import { PanoInsuranceService } from '../../pano-insurance.service';

import { PanoPysOptInAllComponent } from './pano-pys-opt-in-all.component';
import { DIALOG_CLOSE_BUTTON, SUBMIT_BUTTON } from './pano-pys-opt-in-all.component.constants';

describe('PanoPysOptInAllComponent', () => {
  let component: PanoPysOptInAllComponent;
  let fixture: ComponentFixture<PanoPysOptInAllComponent>;
  let service: PanoInsuranceService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoPysOptInAllComponent],
        imports: [
          RouterTestingModule,
          AlertModule,
          BrowserAnimationsModule,
          HttpClientTestingModule,
          MatCheckboxModule,
          CopyMatrixPipeModule,
          MatDialogModule,
          ReactiveFormsModule,
          PipesTestingModule
        ],
        providers: [
          {
            provide: PanoInsuranceService,
            useValue: {
              submitPysOptInRequest: () => {}
            }
          },
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          {
            provide: MAT_DIALOG_DATA,
            useValue: {
              accountId: '1234'
            }
          }
        ],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoPysOptInAllComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(PanoInsuranceService);
    fixture.detectChanges();
  });

  describe('Component', () => {
    describe('ngOnInit', () => {
      it('should create pysOptIn form correctly', () => {
        component.ngOnInit();

        expect(component.pysOptInForm.get('termsAndCondition').valid).toBeFalsy();
        expect(component.pysOptInForm.get('termsAndCondition').errors['required']).toBeTruthy();

        component.pysOptInForm.get('termsAndCondition').setValue(true);
        expect(component.pysOptInForm.get('termsAndCondition').valid).toBeTruthy();
      });
    });

    describe('submit', () => {
      it('should return if terms and conditions are not checked', () => {
        spyOn(service, 'submitPysOptInRequest');
        component.pysOptInForm.get('termsAndCondition').setValue(false);

        component.submit();
        expect(service.submitPysOptInRequest).not.toHaveBeenCalled();
      });

      it('should call submit api successfully', () => {
        spyOn(service, 'submitPysOptInRequest').and.returnValue(of([]));
        component.pysOptInForm.get('termsAndCondition').setValue(true);

        component.submit();

        expect(service.submitPysOptInRequest).toHaveBeenCalledWith('1234', []);
        expect(component.submitting).toEqual(false);
        expect(component.error).toEqual(false);
        expect(component.dialogRef.close).toHaveBeenCalled();
      });

      it('should set error to true when submit api returns error', () => {
        spyOn(service, 'submitPysOptInRequest').and.returnValue(throwError({}));
        component.pysOptInForm.get('termsAndCondition').setValue(true);

        component.submit();
        expect(service.submitPysOptInRequest).toHaveBeenCalledWith('1234', []);
        expect(component.submitting).toEqual(false);
        expect(component.error).toEqual(true);
      });
    });
  });

  describe('View', () => {
    it('should show the dialog close button correctly', () => {
      const dialogCloseButton = fixture.debugElement.queryAll(By.css('bt-button'))[0];

      expect(dialogCloseButton).toBeTruthy();
      expect(dialogCloseButton.properties.config).toEqual(DIALOG_CLOSE_BUTTON);
    });

    it('should show the alert with error if there is api error', () => {
      component.error = true;
      fixture.detectChanges();

      const alert = fixture.debugElement.query(By.css('bt-alert'));
      expect(alert).toBeTruthy();
      expect(alert.properties.config).toEqual(GENERIC_ERROR_ALERT);
    });

    it('should show the the error when checkbox is not checked', () => {
      component.pysOptInForm.markAllAsTouched();
      component.pysOptInForm.get('termsAndCondition').setValue(false);
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('.js-checkbox-error')).nativeElement.innerHTML.trim()).toBe(
        'Please acknowledge that you have read and understood the terms and conditions.'
      );
    });

    it('should call submit function when submit button is clicked', () => {
      const submitButton = fixture.debugElement.queryAll(By.css('bt-button'))[1];
      spyOn(component, 'submit');

      expect(submitButton.properties.config).toEqual(SUBMIT_BUTTON);

      const form = fixture.debugElement.query(By.css('form'));
      form.triggerEventHandler('ngSubmit', null);
      expect(component.submit).toHaveBeenCalled();
    });

    it('should close the dialog on click of cancel button', () => {
      const cancelButton = fixture.debugElement.queryAll(By.css('bt-button'))[2];
      expect(cancelButton).toBeTruthy();

      cancelButton.triggerEventHandler('btClick', null);
      fixture.detectChanges();
      expect(component.dialogRef.close).toHaveBeenCalled();
    });
  });
});
