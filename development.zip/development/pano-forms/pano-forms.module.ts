import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { ButtonModule } from '@bt/components/button';
import { LayoutModule } from '@panorama/components/layout';
import { ServiceRequestsModule } from '@panorama/service-requests';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';

import { PanoFormsComponent } from './pano-forms.component';

@NgModule({
  declarations: [PanoFormsComponent],
  imports: [
    CommonModule,
    ButtonModule,
    LayoutModule,
    MatTabsModule,
    ServiceRequestsModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.forms',
          url: '/forms',
          component: PanoFormsComponent,
          data: {
            title: 'Forms',
            requiredPermissions: [
              {
                rule: 'account.serviceRequests.view',
                targetId: 'a'
              },
              {
                rule: 'feature.serviceRequests.investor.view'
              }
            ]
          }
        }
      ]
    })
  ]
})
export class PanoFormsModule {}
