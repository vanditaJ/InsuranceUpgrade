import { InvestmentPreferenceHeader } from '../pano-inv-pref.interface';

export const MOCK_HEADER_CONFIG: InvestmentPreferenceHeader = {
  icon: { name: 'icon-licence', size: 'large' },
  title: 'TEST TITLE',
  helpInfoId: '',
  learnMore: {
    action: 'button',
    label: 'Set investment profile',
    size: 'large',
    type: 'solid',
    shapeModifier: 'square',
    colourModifier: 'primary',
    a11yProps: {
      ariaLabel: 'Set investment profile'
    }
  }
};
