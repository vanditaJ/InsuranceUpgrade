import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesTestingModule } from '@bt/pipes/testing';
import { DataModule } from '@bt/services/data';
import * as moment from 'moment-timezone';

import { PanoExternalAssetsCommonUtil } from '../../pano-external-assets-common.util';
import {
  CHARCTER_LENGTH_TEN,
  TEST_ADD_EXTERNAL_FORM,
  TEST_ADD_ILS_EXTERNAL_FORM
} from '../../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { TEST_ASSET_TYPES } from '../../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { AssetClasses } from '../../pano-external-assets.interfaces';
import { PanoAddAssetFormCreator } from '../pano-add-asset-form-creator';

import { PanoAddAssetIntListedSecurityComponent } from './pano-add-asset-int-listed-security.component';

@Component({
  template: `
    <pano-add-asset-int-listed-security [addAssetForm]="addAssetForm" [assetClasses]="assetClasses">
    </pano-add-asset-int-listed-security>
  `
})
class TestHostComponent {
  addAssetForm: FormGroup = TEST_ADD_ILS_EXTERNAL_FORM as FormGroup;
  assetClasses: AssetClasses[] = TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'ils').assetClasses;
}

describe('PanoAddAssetIntListedSecurityComponent', () => {
  let component: PanoAddAssetIntListedSecurityComponent;
  let fixture: ComponentFixture<PanoAddAssetIntListedSecurityComponent>;
  let externalAssetsAddFormCreator: PanoAddAssetFormCreator;
  let hostFixture: ComponentFixture<TestHostComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoAddAssetIntListedSecurityComponent, TestHostComponent],
        providers: [PanoAddAssetFormCreator, PanoExternalAssetsCommonUtil],
        imports: [
          DataModule,
          MatSelectModule,
          MatDatepickerModule,
          MatInputModule,
          MatMomentDateModule,
          NoopAnimationsModule,
          ReactiveFormsModule,
          PipesTestingModule
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoAddAssetIntListedSecurityComponent);
    externalAssetsAddFormCreator = TestBed.inject(PanoAddAssetFormCreator);
    component = fixture.componentInstance;
    component.addAssetForm = TEST_ADD_EXTERNAL_FORM as FormGroup;
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('ngOnInit() should set assetDetails FormGroup with control to the addAssetForm', () => {
      const assetDetailsFormGroup = TEST_ADD_ILS_EXTERNAL_FORM as FormGroup;
      spyOn(externalAssetsAddFormCreator, 'createAddAssetForm').and.returnValue(assetDetailsFormGroup);
      component.ngOnInit();

      expect(externalAssetsAddFormCreator.createAddAssetForm).toHaveBeenCalled();
      expect(component.addAssetForm.get('assetDetails')).toBeTruthy();
    });
  });

  describe('view', () => {
    it('should accept the inputs correctly', () => {
      hostFixture = TestBed.createComponent(TestHostComponent);
      hostFixture.detectChanges();
      const cmp = hostFixture.debugElement.query(By.directive(PanoAddAssetIntListedSecurityComponent))
        .componentInstance;

      expect(cmp.addAssetForm).toEqual(TEST_ADD_ILS_EXTERNAL_FORM);
      expect(cmp.assetClasses).toEqual(TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'ils').assetClasses);
    });

    it('should show all the form controls are available', () => {
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-position-name'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-asset-code'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-quantity'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-market-value'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-select'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-value-date'))).toBeTruthy();
      expect(
        fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-value-date-datepicker-toggle'))
      ).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-input-source'))).toBeTruthy();
    });

    it('should hide all Errors by default', () => {
      expect(fixture.debugElement.queryAll(By.css('mat-error')).length).toBe(0);
    });

    it('should have btClearInput on appropriate inputs', () => {
      expect(
        fixture.debugElement
          .query(By.css('.js-test-extassets-add-ils-form-input-position-name'))
          .nativeElement.getAttribute('btClearInput')
      ).toBeDefined();
      expect(
        fixture.debugElement
          .query(By.css('.js-test-extassets-add-ils-form-input-source'))
          .nativeElement.getAttribute('btClearInput')
      ).toBeDefined();
    });

    describe('validate form control', () => {
      let assetDetailsFormGroup: FormGroup;
      beforeEach(() => {
        component.ngOnInit();
        fixture.detectChanges();
        assetDetailsFormGroup = component.addAssetForm.get('assetDetails') as FormGroup;
        assetDetailsFormGroup.markAllAsTouched();
      });

      describe('validate positionName', () => {
        it('should show error message when no value entered', () => {
          assetDetailsFormGroup.get('positionName').setValue('');
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-ils-form-position-name-invalid-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0394');
        });

        it('should show error message when exceeds max length', () => {
          const positionNameTextMoreThanMax = CHARCTER_LENGTH_TEN.repeat(21);
          assetDetailsFormGroup.get('positionName').setValue(positionNameTextMoreThanMax);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-ils-form-position-name-invalid-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0394');
        });

        it('should not show error message when valid value entered', () => {
          assetDetailsFormGroup.get('positionName').setValue('asset name');
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-position-name-invalid-error'))
          ).toBeNull();
        });
      });

      describe('validate asset code', () => {
        it('should show error message when non alphanumeric charcter', () => {
          assetDetailsFormGroup.get('positionCode').setValue('+/asdg1');
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-ils-form-asset-code-pattern-alphanumeric-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0397');
        });

        it('should not show error message when valid value entered', () => {
          assetDetailsFormGroup.get('positionCode').setValue('AAA9999AA');
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-asset-code-invalid-error'))
          ).toBeNull();
        });
      });

      describe('validate quantity', () => {
        it('should show error message when invalid value entered and getErrorMessagesForQuantity method should have been called', () => {
          spyOn(component, 'getErrorMessagesForQuantity').and.returnValue('Enter a valid quantity.');
          assetDetailsFormGroup.get('quantity').setValue('hdgddhdhd');
          component.assetDetails.get('quantity').markAsTouched();
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-quantity-error'));
          expect(component.getErrorMessagesForQuantity).toHaveBeenCalled();
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('Enter a valid quantity.');
        });
      });

      describe('validate marketValue', () => {
        it('should show error message when no value entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-ils-form-market-value-required-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1235');
        });

        it('should not show error message when valid value entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue(12);
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-market-value-required-error'))
          ).toBeNull();
        });

        it('should show error message when invalid number is entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue('12.3.5');
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-ils-form-market-value-pattern-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1236');
        });

        it('should show error message when minimum number is entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue('0.');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-market-value-min-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1233');
        });

        it('should show error message maximum number is entered', () => {
          assetDetailsFormGroup.get('marketValue').setValue('999999999999');
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-market-value-max-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1227');
        });
      });

      describe('validate valuationDate', () => {
        it('should show error message when no value entered', () => {
          assetDetailsFormGroup.get('valuationDate').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-ils-form-value-date-required-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0181');
        });

        it('should not show error message when valid value entered', () => {
          assetDetailsFormGroup.get('valuationDate').setValue(moment().tz('Australia/Sydney'));
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-value-date-required-error'))
          ).toBeNull();
        });

        it('should show error message when future date is entered', () => {
          assetDetailsFormGroup.get('valuationDate').setValue(
            moment()
              .add(4, 'day')
              .tz('Australia/Sydney')
          );
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-value-date-max-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0386');
        });
      });

      describe('validate asset class', () => {
        it('should show error message when no value entered', () => {
          assetDetailsFormGroup.get('assetClassCode').setValue(null);
          fixture.detectChanges();
          const element = fixture.debugElement.query(
            By.css('.js-test-extassets-add-ils-form-asset-class-invalid-error')
          );
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-0388');
        });

        it('should not show error message when valid value entered', () => {
          assetDetailsFormGroup.get('assetClassCode').setValue('cash');
          fixture.detectChanges();
          expect(
            fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-asset-class-invalid-error'))
          ).toBeNull();
        });
      });

      describe('validate source', () => {
        it('should show error message when exceeds maximum charcter length', () => {
          const sourceTextMoreThanMax = CHARCTER_LENGTH_TEN.repeat(13);
          assetDetailsFormGroup.get('source').setValue(sourceTextMoreThanMax);
          fixture.detectChanges();
          const element = fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-source-invalid-error'));
          expect(element).toBeTruthy();
          expect(element.nativeElement.innerHTML.trim()).toBe('test-copy-matrix__Err.IP-1239');
        });

        it('should not show error message when valid value entered', () => {
          const sourceTextOnMax = CHARCTER_LENGTH_TEN.repeat(12);
          assetDetailsFormGroup.get('source').setValue(sourceTextOnMax);
          fixture.detectChanges();
          expect(fixture.debugElement.query(By.css('.js-test-extassets-add-ils-form-source-invalid-error'))).toBeNull();
        });
      });
    });
  });
});
