import { TestBed } from '@angular/core/testing';
import { Account } from '@investor/account/pano-shared/interfaces';

import { PanoInsuranceSharedLinkService } from './pano-insurance-shared-link.service';
import { LinkType } from './pano-insurance-shared-link.service.constants';
import {
  MOCK_BTSFL_POLICY,
  MOCK_BTSUPER,
  MOCK_BTSUPER_LIFETIME,
  MOCK_EMPLOYER_FUNDED_POLICY,
  MOCK_WGP_POLICY
} from './pano-insurance-shared-link.service.spec.constants';

describe('PanoInsuraceSharedLinkService', () => {
  let linkService: PanoInsuranceSharedLinkService;

  const TEST_ACCOUNT_ID: string = 'accountId';
  const TEST_ACCOUNT: Partial<Account> = {
    key: {
      accountId: TEST_ACCOUNT_ID
    },
    product: {
      productSubType: 'PERSONAL_SUPER'
    },
    pdsStatus: 'WGP_CURRENT',
    heritageCohort: 'LSEP'
  };

  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [],
      providers: [PanoInsuranceSharedLinkService]
    });
  });

  beforeEach(() => {
    linkService = TestBed.inject(PanoInsuranceSharedLinkService);
  });

  it('should be created', () => {
    expect(linkService).toBeTruthy();
  });

  describe('getUrl', () => {
    it('should return matched url byo', () => {
      expect(
        linkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, MOCK_EMPLOYER_FUNDED_POLICY, TEST_ACCOUNT as Account)
      ).toEqual('https://www.bt.com.au/genworth.html');
    });

    it('should return first matched url in the url hierarchy based on the policy and account data', () => {
      const account: Account = { ...TEST_ACCOUNT } as Account;
      expect(linkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, MOCK_WGP_POLICY, account)).toEqual(
        'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates-lsep.html#new_member_info'
      );

      account.heritageCohort = 'OPEN';
      expect(linkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, MOCK_WGP_POLICY, account)).toEqual(
        'https://www.bt.com.au/staff/information/factsheets-product-dashboard-and-updates.html#new_member_info'
      );

      expect(linkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, MOCK_BTSFL_POLICY, account)).toEqual(
        'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html#personal_super_pds'
      );

      expect(linkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, MOCK_BTSUPER, account)).toEqual(
        'https://www.bt.com.au/personal/superannuation/support/documents-downloads.html#employer_super_pds'
      );

      expect(linkService.getUrl(LinkType.PRODUCT_DISCLOSURE_STATEMENT, MOCK_BTSUPER_LIFETIME, account)).toEqual(
        'https://www.bt.com.au/personal/help/pds.html#super-employer'
      );
    });
  });
});
