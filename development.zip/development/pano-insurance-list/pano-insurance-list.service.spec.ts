import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { DataModule, DataService } from '@bt/services/data';
import { UIRouter } from '@uirouter/angular';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { of, throwError } from 'rxjs';
import { MOCK_POLICIES, MOCK_RELATED_POLICIES, MOCK_STATIC_POLICIES } from './pano-insurance-list.constants.spec';

import { PanoInsuranceListService } from './pano-insurance-list.service';

fdescribe('PanoInsuranceListService', () => {
  let service: PanoInsuranceListService;
  let dataService: DataService<any>;
  // let httpController : HttpTestingController;
  const successHandler: jasmine.Spy = jasmine.createSpy();
  const errorHandler: jasmine.Spy = jasmine.createSpy();

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy(),
      params: {
        insurance: MOCK_POLICIES
      }
    }
  };

  const mockAccountService = {
    getAccountId: () => '12345'
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [DataModule, HttpClientTestingModule, RouterTestingModule], 
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradeAccountService, useValue: mockAccountService },
          PanoInsuranceListService, MatDialog
        
        ]
      });
    })
  );
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PanoInsuranceListService);
    dataService = TestBed.inject(DataService);
    // httpController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  fdescribe('getPolicies', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({ MOCK_POLICIES }));

      service.getPolicies('1234').subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(MOCK_POLICIES);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getPolicies('1234').subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('getRelatedAccounts', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({ resultList: MOCK_RELATED_POLICIES }));

      service.getRelatedAccounts('1234').subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(MOCK_RELATED_POLICIES);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getPolicies('1234').subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('getStaticPolicyData', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({ resultList: MOCK_STATIC_POLICIES }));

      service.getStaticPolicyData().subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(MOCK_STATIC_POLICIES);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getStaticPolicyData().subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('submitPysOptInRequest', () => {
    it('should send pysOptIn', () => {

    });
  });
});