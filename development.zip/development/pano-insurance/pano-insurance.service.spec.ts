import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DataModule, DataService } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { of, throwError } from 'rxjs';

import { SUBMIT_INSURANCE_OPTIONALS } from './pano-insurance.constants';
import { PanoInsuranceService } from './pano-insurance.service';
import {
  INSURANCE_OPTIONS,
  INSURANCE_POLICY,
  INSURANCE_RATES,
  PARAMS,
  PERMISSIONS,
  POLICIES
} from './pano-insurance.service.spec.constants';
import { PanoInsuranceUtil } from './pano-insurance.util';

describe('PanoInsuranceService', () => {
  let service: PanoInsuranceService;
  let dataService: DataService<any>;
  let util: PanoInsuranceUtil;

  const successHandler: jasmine.Spy = jasmine.createSpy();
  const errorHandler: jasmine.Spy = jasmine.createSpy();

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy(),
      params: {
        insurance: INSURANCE_POLICY
      }
    }
  };

  const mockAccountService = {
    getAccountId: () => '12345'
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [DataModule, BrowserDynamicTestingModule, HttpClientTestingModule, RouterTestingModule],
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradeAccountService, useValue: mockAccountService },
          PanoInsuranceService,
          PanoInsuranceUtil
        ]
      });
    })
  );

  beforeEach(() => {
    service = TestBed.inject(PanoInsuranceService);
    dataService = TestBed.inject(DataService);
    util = TestBed.inject(PanoInsuranceUtil);
  });

  afterEach(() => {
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  describe('getPolicies', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({ resultList: POLICIES }));

      service.getPolicies('1234').subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(POLICIES);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getPolicies('1234').subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('getPermissions', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({ permissions: PERMISSIONS }));

      service.getPermissions('1234').subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(PERMISSIONS);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getPermissions('1234').subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('submitCancelInsurance', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'update').and.returnValue(of({}));

      service.submitCancelInsurance('1234', '9876').subscribe(successHandler, errorHandler);

      expect(dataService.update).toHaveBeenCalledWith(
        '../panorama-inv-ui/api/v1/insurance/accounts/1234/policies/9876/cancel',
        SUBMIT_INSURANCE_OPTIONALS
      );

      expect(successHandler).toHaveBeenCalledWith({});
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'update').and.returnValue(throwError('error'));

      service.submitCancelInsurance('1234', '9876').subscribe(successHandler, errorHandler);

      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalledWith('error');
    });
  });

  describe('submitInsurance', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'update').and.returnValue(of({}));

      service.submitInsurance('1234', PARAMS).subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith({});
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'update').and.returnValue(throwError('error'));

      service.submitInsurance('1234', PARAMS).subscribe(successHandler, errorHandler);

      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalledWith('error');
    });
  });

  describe('getInsurance', () => {
    it('should not load policies if insurance policy is already populated', () => {
      spyOn(service, 'getPolicies');
      (service as any).uiRouter.stateService.params.insurance = POLICIES;

      service.getInsurance();

      expect(service.getPolicies).not.toHaveBeenCalled();
    });

    it('should load policies if insurance policy is not already populated', () => {
      (service as any).uiRouter.stateService.params.insurance = null;
      (service as any).uiRouter.stateService.params.policyNumber = '5273591';
      spyOn(service, 'getPolicies').and.returnValue(of(POLICIES));

      service.getInsurance().subscribe(successHandler, errorHandler);

      expect(service.getPolicies).toHaveBeenCalledWith('12345');
      expect(successHandler).toHaveBeenCalledWith(POLICIES[1]);
      expect(errorHandler).not.toHaveBeenCalled();
    });
  });

  describe('getAssociatedTpdCovers', () => {
    it('should return associatedTpdCovers if its available in the state service params', () => {
      (service as any).uiRouter.stateService.params.associatedTpdCovers = POLICIES;

      service.getAssociatedTpdCovers().subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(POLICIES);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should return associatedTpdCovers from getDeathAssociatedTPDPolicies if its not available in the state service params', () => {
      (service as any).uiRouter.stateService.params.insurance = null;
      (service as any).uiRouter.stateService.params.associatedTpdCovers = null;
      (service as any).uiRouter.stateService.params.policyNumber = '5273590';
      spyOn(service, 'getPolicies').and.returnValue(of(POLICIES));
      spyOn(service, 'getInsurance').and.returnValue(of(POLICIES[0]));
      spyOn(util, 'getDeathAssociatedTPDPolicies').and.returnValue([POLICIES[2]]);

      service.getAssociatedTpdCovers().subscribe(successHandler, errorHandler);

      expect(service.getPolicies).toHaveBeenCalled();
      expect(service.getInsurance).toHaveBeenCalled();

      expect(successHandler).toHaveBeenCalledWith([POLICIES[2]]);
      expect(errorHandler).not.toHaveBeenCalled();
    });
  });

  describe('getInsuranceRates', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({ insuranceRates: INSURANCE_RATES }));

      service.getInsuranceRates(94, 16, 'FEMALE').subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(INSURANCE_RATES);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getInsuranceRates(94, 16, 'FEMALE').subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('getInsuranceOptions', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'retrieve').and.returnValue(of({ insuranceOptions: INSURANCE_OPTIONS }));

      service.getInsuranceOptions(110).subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith(INSURANCE_OPTIONS);
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'retrieve').and.returnValue(throwError('error'));

      service.getInsuranceOptions(110).subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('navigateToOverview', () => {
    it('should navigate to correct route', () => {
      service.navigateToOverview(undefined);

      expect((service as any).uiRouter.stateService.go).toHaveBeenCalledWith('app.investor.account.insurancePolicies');
    });

    it('should navigate to correct route with refresh', () => {
      service.navigateToOverview(true);

      expect((service as any).uiRouter.stateService.go).toHaveBeenCalledWith(
        'app.investor.account.insurancePolicies',
        {},
        { reload: true }
      );
    });
  });

  describe('submitPysOptInRequest', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'update').and.returnValue(of({}));

      service.submitPysOptInRequest('1234', []).subscribe(successHandler, errorHandler);

      expect(dataService.update).toHaveBeenCalledWith(
        '../api/v1/investor/accounts/1234/insurance-policy/opt-in',
        '[]',
        SUBMIT_INSURANCE_OPTIONALS
      );

      expect(successHandler).toHaveBeenCalledWith({});
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'update').and.returnValue(throwError('error'));

      service.submitPysOptInRequest('1234', []).subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('submitPmifOptInRequest', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'update').and.returnValue(of({}));

      service.submitPmifOptInRequest('1234').subscribe(successHandler, errorHandler);

      expect(dataService.update).toHaveBeenCalledWith(
        '../panorama-inv-ui/api/v1/insurance/accounts/1234/pmif-opt-in',
        SUBMIT_INSURANCE_OPTIONALS
      );

      expect(successHandler).toHaveBeenCalledWith({});
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'update').and.returnValue(throwError('error'));

      service.submitPmifOptInRequest('1234').subscribe(successHandler, errorHandler);

      expect(errorHandler).toHaveBeenCalledWith('error');
      expect(successHandler).not.toHaveBeenCalled();
    });
  });

  describe('submitChangeRequest', () => {
    it('should call successHandler with correct argument when dataService resolved successfully', () => {
      spyOn(dataService, 'update').and.returnValue(of({}));

      service.submitChangeRequest('1234', PARAMS).subscribe(successHandler, errorHandler);

      expect(successHandler).toHaveBeenCalledWith({});
      expect(errorHandler).not.toHaveBeenCalled();
    });

    it('should call errorHandler with correct argument when dataService resolved in error', () => {
      spyOn(dataService, 'update').and.returnValue(throwError('error'));

      service.submitChangeRequest('1234', PARAMS).subscribe(successHandler, errorHandler);

      expect(successHandler).not.toHaveBeenCalled();
      expect(errorHandler).toHaveBeenCalledWith('error');
    });
  });
});
