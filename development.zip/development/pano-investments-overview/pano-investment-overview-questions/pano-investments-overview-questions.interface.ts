export interface FaqContent {
  header: string;
  description: string;
}
