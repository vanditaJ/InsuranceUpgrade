import { Link } from '@bt/components/link';
import { Account } from '@investor/account/pano-shared/interfaces';

import { AemContent } from './pano-fees.interface';
export const MOCK_ACCOUNT_ID: string = '123';
export const MOCK_ACCOUNT_NUMBER: string = '12345';

export const BTSFL_RETAIL_ACCOUNT: Partial<Account> = {
  accountNumber: MOCK_ACCOUNT_NUMBER,
  productDescription: 'BT Super for Life',
  heritageCohort: 'RETAIL'
};

export const BTSLF_WGP_OPEN_ACCOUNT: Partial<Account> = {
  accountNumber: MOCK_ACCOUNT_NUMBER,
  productDescription: 'BT Super for Life',
  pdsStatus: 'WGP_CURRENT',
  heritageCohort: 'OPEN'
};

export const BTSLF_WGP_LEGACY_LSEP_ACCOUNT: Partial<Account> = {
  accountNumber: MOCK_ACCOUNT_NUMBER,
  productDescription: 'BT Super for Life',
  pdsStatus: 'WGP_CURRENT',
  heritageCohort: 'LSEP'
};

export const MOCK_AEM_CONTENT_TEST: AemContent = {
  details: [
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_description',
        description:
          '\u003cp\u003eThis table is a summary of the fees that you may be charged. Other fees and costs may also apply depending on investment, insurance and advice decisions.\u003c/p\u003e\r\n\r\n\r\n\r\n\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_charges_info_ongoing_investment_fees',
        description:
          '\u003cp\u003eThe percentage-based Administration fee, Investment fee and Indirect cost ratio are deducted from the investment option and reflected in the daily unit price.\u003c/p\u003e\r\n\r\n\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_charges_info_lifestage_investment',
        description:
          '\u003cp\u003eAs a member of the Westpac Group Plan, your administration fee for Lifestage investment options is discounted. A fee of 0.28% pa of your will be deducted from the investment option and a rebate equal to 0.16% pa of your account balance is then deposited into your account every month when you are still a member at the end of the month. (i.e. net administration fee of 0.12% pa).\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_charges_info_legacy_admin_fee',
        description:
          '\u003cp\u003eAs a member of the Westpac Group Plan, your administration fee for certain choice investments is discounted\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_charges_info_buy_sell_spread',
        description:
          '\u003cp\u003eBuy-sell spreads are an additional cost to you when you make a new or an additional investment, withdraw from or switch investment options.\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_tooltip_admin_fee',
        description:
          '\u003cp\u003eAdministration fee is a fee that relates to the administration or operation of a superannuation entity and includes costs incurred by\u0026nbsp;the trustee.\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_tooltip_investment_fee',
        description:
          '\u003cp\u003eInvestment fee is the cost of managing the investments within your chosen investment option.\u003c/p\u003e\r\n\r\n\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_tooltip_indirect_cost_ratio',
        description:
          '\u003cp\u003eIndirect cost ratio is the ratio of the total of the indirect costs to the total average net assets attributed to the investment option.\u003c/p\u003e\r\n\r\n\r\n\u003cp\u003eThey include Regulatory Change Expense Recovery (RCER) amounts, performance-related fees and other indirect costs incurred in managing the underlying investment option.\u003c/p\u003e\r\n\r\n\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_tooltip_buy_sell_spread',
        description:
          '\u003cp\u003eA Buy-sell spread is a fee to recover transaction costs incurred by the trustee of a superannuation entity in relation to the sale and purchase of investments.\u003c/p\u003e\r\n\r\n\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_retail_admin_fee',
        description:
          '\u003cp\u003eA flat fee of $9.00 per month is deducted from your account balance\u0026nbsp;plus 0.28%\u0026nbsp;pa\u0026nbsp;(0.24% for cash)\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_wgp_admin_fee',
        description:
          '\u003cp\u003eLifestage\u0026nbsp;investment options: 0.12%\u0026nbsp;pa\u0026nbsp;of the amount invested.\u003c/p\u003e\r\n\u003cp\u003eAll other options: Up to 0.28%\u0026nbsp;pa\u0026nbsp;of the amount invested\u0026nbsp;depending on your investment option\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_retail_investment_fee',
        description:
          '\u003cp\u003eBetween 0.10% and\u0026nbsp;1.38%\u0026nbsp;pa\u0026nbsp;depending on your investment option\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_wgp_investment_fee',
        description:
          '\u003cp\u003eBetween 0.10% and 1.38% pa depending on your investment option\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_retail_indirect_cost_ratio',
        description:
          '\u003cp\u003eBetween 0.05% and\u0026nbsp;0.49%\u0026nbsp;pa\u0026nbsp;depending on your investment option\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_wgp_indirect_cost_ratio',
        description:
          '\u003cp\u003eUp\u0026nbsp;to\u0026nbsp;0.49%\u0026nbsp;pa\u0026nbsp;depending on your investment option\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_retail_buy_sell_spread',
        description:
          '\u003cp\u003eBetween 0% and 0.60%\u0026nbsp;pa\u0026nbsp;depending on your investment option\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'fees_table_summary_wgp_buy_sell_spread',
        description:
          '\u003cp\u003eBetween 0% and 0.60% pa depending on your investment option\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_description',
        description:
          '\u003cp\u003eThis\u0026nbsp;table gives an example of how the fees and costs for the\u0026nbsp;1980s BT\u0026nbsp;Lifestage\u0026nbsp;investment option for BT Super for Life can affect your superannuation investment over a 1 year period. You should use this table to compare BT Super for Life with other superannuation product.\u003c/p\u003e\r\n\u003cp\u003eIf your balance was\u0026nbsp;$50,000\u0026nbsp;then for that year\u0026nbsp;you will be charged\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_admin_rate',
        description:
          '\u003cp\u003e$9.00 per month ($108 pa)\u003c/p\u003e\r\n\u003cp\u003ePlus 0.28% pa\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_admin_fee',
        description:
          '\u003cp\u003eYou will be charged $108 each year regardless of your balance plus $140 in administration fees\u0026nbsp;will be deducted from your investment\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_admin_rate',
        description: '\u003cp\u003e0.12% pa\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_admin_fee',
        description:
          '\u003cp\u003e$140 each year will be deducted from your investment and $80 will be\u0026nbsp;rebated to your account.\u0026nbsp; The net cost will be $60 per year.\u0026nbsp;\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_investment_rate',
        description: '\u003cp\u003e0.50% pa\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_investment_fee',
        description: '\u003cp\u003e$250 each year will be deducted from your investment\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_investment_rate',
        description: '\u003cp\u003e0.50% pa\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_investment_fee',
        description: '\u003cp\u003e$250 each year will be deducted from your investment\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_indirect_cost_rate',
        description: '\u003cp\u003e0.15% pa\u003c/p\u003e\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_indirect_cost_ratio',
        description:
          '\u003cp\u003eIndirect costs of $75 each year will be deducted from your investment.\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_indirect_cost_rate',
        description: '\u003cp\u003e0.15% pa\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_indirect_cost_ratio',
        description:
          '\u003cp\u003eIndirect costs of $75 each year will be deducted from your investment.\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_total_cost_rate',
        description:
          '\u003cp\u003e$9.00 per month ($108 pa)\u003c/p\u003e\r\n\r\n\r\n\u003cp\u003ePlus 0.93% pa\u003c/p\u003e\r\n\r\n\r\n\r\n\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_retail_total_cost',
        description:
          '\u003cp\u003eIf your balance was $50,000 then for that year you will be charged fees of $573 for BT Super for Life.\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_total_cost_rate',
        description:
          '\u003cp\u003e$9.00 per month ($108 pa)\u003c/p\u003e\r\n\u003cp\u003ePlus 0.77% pa\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_table_summary_wgp_total_cost',
        description:
          '\u003cp\u003eIf your balance was $50,000 then for that year you will be charged fees of $385 for BT Super for Life.\u003c/p\u003e\r\n'
      }
    },
    {
      type: 'title_link',
      id: 'important-super-changes',
      data: {
        headerText: 'example_footnote',
        description:
          '\u003cp\u003eEstimated indirect costs above include an estimated Regulatory Change Expense Recovery of\u0026nbsp;0.01% pa, estimated performance-related fees of 0.00% pa and estimated other indirect costs of\u0026nbsp;0.14% pa.\u003c/p\u003e\r\n'
      }
    }
  ]
};

export const TEST_LINK: Partial<Link> = {};
