import { Component, Input, OnInit } from '@angular/core';
// import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'pano-insurance-list',
  templateUrl: './pano-insurance-list.component.html',
  styleUrls: ['./pano-insurance-list.component.scss']
})
export class PanoInsuranceListComponent implements OnInit {
  @Input() policy;
  @Input() policyAccounts;
  @Input() policyData;

  constructor() {}

  ngOnInit(): void {}
}
