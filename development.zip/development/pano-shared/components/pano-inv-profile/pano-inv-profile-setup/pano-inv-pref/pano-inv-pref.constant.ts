import { Alert } from '@bt/components/alert';

import { InvestmentPreferenceHeader } from './pano-inv-pref.interface';

export const PREFERENCE_HEADER: Partial<InvestmentPreferenceHeader> = {
  learnMore: {
    action: 'button',
    colourModifier: 'primary',
    icon: {
      name: 'icon-chevron-right-circle-solid',
      size: 'large'
    },
    iconPosition: 'left',
    label: 'Learn more',
    shapeModifier: 'square',
    size: 'medium',
    type: 'flat'
  }
};

export const INVESTMENT_OBJECTIVES_HEADER: Partial<InvestmentPreferenceHeader> = {
  ...PREFERENCE_HEADER,
  icon: { name: 'icon-investment-objective', size: 'medium' },
  title: 'Your investment objectives',
  helpInfoId: 'Help-IP-0395'
};

export const INVESTMENT_TIMEFRAME_HEADER: Partial<InvestmentPreferenceHeader> = {
  ...PREFERENCE_HEADER,
  icon: { name: 'icon-investment-timeframe', size: 'medium' },
  title: 'Your investment timeframe',
  helpInfoId: 'Help-IP-0396'
};

export const APPETITE_FOR_RISK_HEADER: Partial<InvestmentPreferenceHeader> = {
  ...PREFERENCE_HEADER,
  icon: { name: 'icon-investment-risk', size: 'medium' },
  title: 'Your appetite for risk',
  helpInfoId: 'Help-IP-0397'
};

export const ASSET_LIQUIDITY_NEEDS_HEADER: Partial<InvestmentPreferenceHeader> = {
  ...PREFERENCE_HEADER,
  icon: { name: 'icon-investment-liquidity', size: 'medium' },
  title: 'Your asset liquidity needs',
  helpInfoId: 'Help-IP-0398'
};

export const NO_INVESTMENT_TIMEFRAMES_CHECKED_ALERT: Alert = {
  type: 'error',
  outline: true,
  inline: true,
  messages: 'Select at least one investment timeframe.'
};

export const NO_INVESTMENT_OBJECTIVE_CHECKED_ALERT: Alert = {
  type: 'error',
  outline: true,
  inline: true,
  messages: 'Select at least one investment objective.'
};

export const INVESTMENT_PREFERENCE_TITLE: string = 'Set your investment preferences';
export const INVESTMENT_PREFERENCE_DESCRIPTION: string =
  'You can choose one or multiple preferences for each question.';
