import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CopyMatrixPipe, CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataModule } from '@bt/services/data';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoUpgradePermissionService } from '@upgrade/upgrade.services';
import { of, throwError } from 'rxjs';

import { PanoEmployerContributionsDetailsComponent } from './pano-employer-contributions-details.component';
import {
  EMAIL_OPTION_ACCOUNT_DETAILS,
  EMAIL_OPTION_ACCOUNT_DETAILS_PDF,
  NOTIFICATION_TYPE_DO_IT_FOR_ME,
  NOTIFICATION_TYPE_NOTIFY_ME,
  NOTIFICATION_TYPE_PDF_NOTIFY_ME,
  SETUP_TYPE_ON_MY_BEHALF,
  SETUP_TYPE_SELF,
  SUBMITTED_FOR_ME_ALERT,
  SUBMITTED_MYSELF_ALERT
} from './pano-employer-contributions-details.constants';
import {
  TEST_ACCOUNT,
  TEST_ACCOUNT_NO_EMAIL,
  TEST_ACCOUNT_NO_OWNER,
  TEST_INVALID_EMPLOYEE_CONTACT_NAME,
  TEST_NOTIFICATION_RESPONSE
} from './pano-employer-contributions-details.constants.spec';
import { PanoEmployerContributionsDetailsService } from './pano-employer-contributions-details.service';

describe('PanoEmployerContributionsDetailsComponent', () => {
  let component: PanoEmployerContributionsDetailsComponent;
  let fixture: ComponentFixture<PanoEmployerContributionsDetailsComponent>;
  let service: PanoEmployerContributionsDetailsService;
  let permissionService: PanoUpgradePermissionService;
  let copyMatrixPipe: CopyMatrixPipe;
  let disclaimerService: PanoDisclaimersService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoEmployerContributionsDetailsComponent],
        imports: [
          BrowserAnimationsModule,
          MatButtonToggleModule,
          MatFormFieldModule,
          MatInputModule,
          MatRadioModule,
          ReactiveFormsModule,
          CopyMatrixPipeModule,
          DataModule,
          HttpClientTestingModule,
          RouterTestingModule
        ],
        schemas: [NO_ERRORS_SCHEMA],
        providers: [
          PanoDisclaimersService,
          CopyMatrixPipe,
          PanoEmployerContributionsDetailsService,
          { provide: PanoUpgradePermissionService, useValue: { hasPermission: jasmine.createSpy() } }
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoEmployerContributionsDetailsComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(PanoEmployerContributionsDetailsService);
    permissionService = TestBed.inject(PanoUpgradePermissionService);
    copyMatrixPipe = TestBed.inject(CopyMatrixPipe);
    disclaimerService = TestBed.inject(PanoDisclaimersService);
    permissionService.hasPermission.withArgs('emulating', 'base').and.returnValue(false);
    spyOn(disclaimerService, 'evaluateDisclaimer').and.returnValue('disclaimer');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should have variables initialised', () => {
      component.account = TEST_ACCOUNT;
      spyOn(copyMatrixPipe, 'transform').and.returnValue('{1}');

      component.ngOnInit();

      expect(component.submitted).toEqual(false);
      expect(component.formGroup).not.toBeNull();
      expect(component.formGroup.controls.setupType.value).toEqual(SETUP_TYPE_SELF);
      expect(component.formGroup.controls.emailOption.value).toEqual('');
      expect(component.formGroup.controls.emailAddress.value).toEqual('my@email.com');
      expect(component.originalEmail).toEqual('my@email.com');
      expect(component.disclaimer).not.toBeNull();
      expect(component.productDisclaimer).not.toBeNull();
      expect(component.hasSubmitPermission).toEqual(true);
      expect(copyMatrixPipe.transform).toHaveBeenCalledWith('DS-IP-0327');
    });

    it('should not have submit permission', () => {
      component.account = TEST_ACCOUNT;
      spyOn(copyMatrixPipe, 'transform').and.returnValue('{1}');
      permissionService.hasPermission.withArgs('emulating', 'base').and.returnValue(true);

      component.ngOnInit();

      expect(component.hasSubmitPermission).toEqual(false);
    });

    it('should have no email if no owners', () => {
      component.account = TEST_ACCOUNT_NO_OWNER;

      component.ngOnInit();

      expect(component.originalEmail).toBeUndefined();
    });

    it('should have no email if owner has no email', () => {
      component.account = TEST_ACCOUNT_NO_EMAIL;

      component.ngOnInit();

      expect(component.originalEmail).toBeUndefined();
    });
  });

  describe('ngOnDestroy', () => {
    it('should unsubscribe from submit notification subscription', () => {
      spyOn((component as any).submitNotificationSubscription, 'unsubscribe');

      component.ngOnDestroy();

      expect((component as any).submitNotificationSubscription.unsubscribe).toHaveBeenCalled();
    });
  });

  describe('reset', () => {
    it('should have reset variables', () => {
      component.account = TEST_ACCOUNT;

      component.ngOnInit();

      component.submitted = true;
      component.submitting = true;
      component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);
      component.formGroup.controls.emailAddress.setValue('dummy@email.com');

      component.reset();

      expect(component.submitted).toEqual(false);
      expect(component.submitting).toEqual(false);
      expect(component.formGroup.controls.setupType.value).toEqual(SETUP_TYPE_SELF);
      expect(component.formGroup.controls.emailAddress.value).toEqual('my@email.com');
    });
  });

  describe('hasInvalidInput', () => {
    beforeEach(() => {
      component.account = TEST_ACCOUNT;
      component.ngOnInit();
    });

    it('should be true when self-setup and either email address or email option is invalid', () => {
      component.formGroup.controls.emailAddress.setValue('xyz');
      expect(component.hasInvalidInput()).toEqual(true);

      component.formGroup.controls.emailOption.setValue(EMAIL_OPTION_ACCOUNT_DETAILS);
      expect(component.hasInvalidInput()).toEqual(true);

      component.formGroup.controls.emailOption.setValue(null);
      expect(component.hasInvalidInput()).toEqual(true);

      component.formGroup.controls.emailAddress.setValue('my@email.com');
      expect(component.hasInvalidInput()).toEqual(true);
    });

    it('should be false when self-setup and email address and email option are valid', () => {
      component.formGroup.controls.emailAddress.setValue('my@email.com');
      component.formGroup.controls.emailOption.setValue(EMAIL_OPTION_ACCOUNT_DETAILS);
      expect(component.hasInvalidInput()).toEqual(false);
    });

    it('should be true when setup-on-my-behalf and either email address or employer contact name/email is invalid', () => {
      component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);
      // emailAddress invalid
      component.formGroup.controls.employerEmailAddress.setValue('my@email.com');
      component.formGroup.controls.employerContactName.setValue('');
      component.formGroup.controls.emailAddress.setValue('xyz');
      expect(component.hasInvalidInput()).toEqual(true);
      // employerEmailAddress invalid
      component.formGroup.controls.employerEmailAddress.setValue('xyz');
      component.formGroup.controls.employerContactName.setValue('');
      component.formGroup.controls.emailAddress.setValue('my@email.com');
      expect(component.hasInvalidInput()).toEqual(true);
      // employerContactName invalid
      component.formGroup.controls.employerEmailAddress.setValue('my@email.com');
      component.formGroup.controls.employerContactName.setValue(TEST_INVALID_EMPLOYEE_CONTACT_NAME);
      component.formGroup.controls.emailAddress.setValue('my@email.com');
      expect(component.hasInvalidInput()).toEqual(true);
    });

    it('should be false when self-setup and email address and email option are valid', () => {
      component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);
      component.formGroup.controls.emailAddress.setValue('my@email.com');
      component.formGroup.controls.employerContactName.setValue('Employer Name');
      component.formGroup.controls.employerEmailAddress.setValue('employer@email.com');
      expect(component.hasInvalidInput()).toEqual(false);
    });
  });

  describe('submitNotification', () => {
    beforeEach(() => {
      component.account = TEST_ACCOUNT;
      component.ngOnInit();
    });

    it('should mark emailAddress and emailOption as touched for self-setup', () => {
      component.submitNotification();

      expect(component.formGroup.controls.emailAddress.touched).toEqual(true);
      expect(component.formGroup.controls.emailOption.touched).toEqual(true);
      expect(component.formGroup.controls.employerContactName.touched).toEqual(false);
      expect(component.formGroup.controls.employerEmailAddress.touched).toEqual(false);
    });

    it('should mark emailAddress, employerContactName and employerEmailAddress as touched for setup-on-my-behalf', () => {
      component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);

      component.submitNotification();

      expect(component.formGroup.controls.emailAddress.touched).toEqual(true);
      expect(component.formGroup.controls.emailOption.touched).toEqual(false);
      expect(component.formGroup.controls.employerContactName.touched).toEqual(true);
      expect(component.formGroup.controls.employerEmailAddress.touched).toEqual(true);
    });

    it('should call submitNotification service with correct params for self-setup', () => {
      spyOn(service, 'submitNotification').and.returnValue(of(TEST_NOTIFICATION_RESPONSE));

      component.formGroup.controls.emailAddress.setValue('my@email.com');
      component.formGroup.controls.emailOption.setValue(EMAIL_OPTION_ACCOUNT_DETAILS);

      component.submitNotification();

      expect(component.submitted).toEqual(true);
      expect(component.submitError).toEqual(false);
      expect(component.submitting).toEqual(false);
      expect(component.receiptId).toEqual(TEST_NOTIFICATION_RESPONSE.receiptId);
      expect(service.submitNotification).toHaveBeenCalledWith(
        NOTIFICATION_TYPE_NOTIFY_ME,
        'James',
        'Bond',
        '05 Aug 1951',
        '',
        '',
        'my@email.com'
      );

      component.formGroup.controls.emailOption.setValue(EMAIL_OPTION_ACCOUNT_DETAILS_PDF);

      component.submitNotification();

      expect(component.submitted).toEqual(true);
      expect(component.submitError).toEqual(false);
      expect(component.submitting).toEqual(false);
      expect(service.submitNotification).toHaveBeenCalledWith(
        NOTIFICATION_TYPE_PDF_NOTIFY_ME,
        'James',
        'Bond',
        '05 Aug 1951',
        '',
        '',
        'my@email.com'
      );
    });

    it('should call submitNotification service with correct params for setup-on-my-behalf', () => {
      spyOn(service, 'submitNotification').and.returnValue(of(TEST_NOTIFICATION_RESPONSE));

      component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);
      component.formGroup.controls.emailAddress.setValue('my@email.com');
      component.formGroup.controls.employerContactName.setValue('Employer Name');
      component.formGroup.controls.employerEmailAddress.setValue('employer@email.com');

      component.submitNotification();

      expect(component.submitted).toEqual(true);
      expect(component.submitError).toEqual(false);
      expect(component.submitting).toEqual(false);
      expect(component.receiptId).toEqual(TEST_NOTIFICATION_RESPONSE.receiptId);
      expect(service.submitNotification).toHaveBeenCalledWith(
        NOTIFICATION_TYPE_DO_IT_FOR_ME,
        'James',
        'Bond',
        '05 Aug 1951',
        'Employer Name',
        'employer@email.com',
        'my@email.com'
      );
    });

    it('should set submit error flag to true', () => {
      spyOn(service, 'submitNotification').and.returnValue(throwError({}));

      component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);
      component.formGroup.controls.emailAddress.setValue('my@email.com');
      component.formGroup.controls.employerContactName.setValue('Employer Name');
      component.formGroup.controls.employerEmailAddress.setValue('employer@email.com');

      component.submitNotification();

      expect(component.submitError).toEqual(true);
    });
  });

  describe('View', () => {
    beforeEach(() => {
      component.account = TEST_ACCOUNT;
      component.ngOnInit();
      fixture.detectChanges();
    });

    it('should show introduction text', () => {
      const introEl = fixture.debugElement.query(By.css('.js-test-introduction'));
      expect(introEl).toBeTruthy();
    });

    describe('Self-setup option', () => {
      it('should show self-setup instruction', () => {
        const setupTypeEl = fixture.debugElement.query(By.css('.js-test-self-setup-ins'));
        expect(setupTypeEl).toBeTruthy();
      });

      it('should show email options', () => {
        const optionAEl = fixture.debugElement.query(By.css('.js-test-send-email-template'));
        expect(optionAEl).toBeTruthy();

        const optionBEl = fixture.debugElement.query(By.css('.js-test-send-email-form'));
        expect(optionBEl).toBeTruthy();
      });

      it('should show email option required error', () => {
        component.formGroup.controls.emailOption.markAsTouched({ onlySelf: true });
        fixture.detectChanges();

        const optionErrEl = fixture.debugElement.query(By.css('.js-test-email-option-required-error'));
        expect(optionErrEl).toBeTruthy();
      });

      it('should not show setup on-my-behalf instruction', () => {
        const setupTypeEl = fixture.debugElement.query(By.css('.js-test-on-my-behalf-ins'));
        expect(setupTypeEl).toBeFalsy();
      });

      it('should not show employer contact name field', () => {
        const employerNameEl = fixture.debugElement.query(By.css('.js-test-employer-contact-name'));
        expect(employerNameEl).toBeFalsy();
      });

      it('should not show employer email address field', () => {
        const employerEmailAddressEl = fixture.debugElement.query(By.css('.js-test-employer-email'));
        expect(employerEmailAddressEl).toBeFalsy();
      });
    });

    describe('Setup on-my-behalf option', () => {
      beforeEach(() => {
        component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);
        fixture.detectChanges();
      });

      it('should show setup on-my-behalf instruction', () => {
        const setupTypeEl = fixture.debugElement.query(By.css('.js-test-on-my-behalf-ins'));
        expect(setupTypeEl).toBeTruthy();
      });

      it('should show employer contact name field', () => {
        const employerNameEl = fixture.debugElement.query(By.css('.js-test-employer-contact-name'));
        expect(employerNameEl).toBeTruthy();
      });

      it('should show employer contact name max length error', () => {
        component.formGroup.controls.employerContactName.setValue(TEST_INVALID_EMPLOYEE_CONTACT_NAME);
        component.formGroup.controls.employerContactName.markAsTouched({ onlySelf: true });
        fixture.detectChanges();

        const employerNameErrEl = fixture.debugElement.query(By.css('.js-test-employer-contact-name-invalid-error'));
        expect(employerNameErrEl).toBeTruthy();
      });

      it('should show employer email address field', () => {
        const employerEmailAddressEl = fixture.debugElement.query(By.css('.js-test-employer-email'));
        expect(employerEmailAddressEl).toBeTruthy();
      });

      it('should show employer email address required error', () => {
        component.formGroup.controls.employerEmailAddress.markAsTouched({ onlySelf: true });
        fixture.detectChanges();

        const employerEmailAddressErrEl = fixture.debugElement.query(By.css('.js-test-employer-email-required-error'));
        expect(employerEmailAddressErrEl).toBeTruthy();
      });

      it('should show employer email address invalid error', () => {
        component.formGroup.controls.employerEmailAddress.setValue('xyz');
        component.formGroup.controls.employerEmailAddress.markAsTouched({ onlySelf: true });
        fixture.detectChanges();

        const employerEmailAddressErrEl = fixture.debugElement.query(By.css('.js-test-employer-email-invalid-error'));
        expect(employerEmailAddressErrEl).toBeTruthy();
      });

      it('should not show self-setup instruction', () => {
        const setupTypeEl = fixture.debugElement.query(By.css('.js-test-self-setup-ins'));
        expect(setupTypeEl).toBeFalsy();
      });

      it('should not show email options', () => {
        const optionAEl = fixture.debugElement.query(By.css('.js-test-send-email-template'));
        expect(optionAEl).toBeFalsy();

        const optionBEl = fixture.debugElement.query(By.css('.js-test-send-email-form'));
        expect(optionBEl).toBeFalsy();
      });
    });

    describe('Recipient email address', () => {
      it('should show email address confirmation field', () => {
        const emailAddressEl = fixture.debugElement.query(By.css('.js-test-email-address'));
        expect(emailAddressEl).toBeTruthy();
        expect(emailAddressEl.nativeElement.value).toEqual('my@email.com');
      });

      it('should show email address required error', () => {
        component.formGroup.controls.emailAddress.setValue('');
        component.formGroup.controls.emailAddress.markAsTouched({ onlySelf: true });
        fixture.detectChanges();

        const emailAddressErrEl = fixture.debugElement.query(By.css('.js-test-email-address-required-error'));
        expect(emailAddressErrEl).toBeTruthy();
      });

      it('should show email address invalid error', () => {
        component.formGroup.controls.emailAddress.setValue('xyz');
        component.formGroup.controls.emailAddress.markAsTouched({ onlySelf: true });
        fixture.detectChanges();

        const emailAddressErrEl = fixture.debugElement.query(By.css('.js-test-email-address-invalid-error'));
        expect(emailAddressErrEl).toBeTruthy();
      });
    });

    describe('Submit spinner', () => {
      it('should not show submit spinner', () => {
        const submitSpinnerEl = fixture.debugElement.query(By.css('.js-test-submit-spinner'));
        expect(submitSpinnerEl).toBeFalsy();
      });

      it('should show submit spinner', () => {
        component.submitting = true;
        fixture.detectChanges();

        const submitSpinnerEl = fixture.debugElement.query(By.css('.js-test-submit-spinner'));
        expect(submitSpinnerEl).toBeTruthy();
      });
    });

    describe('Submit error alert', () => {
      it('should not show submit error alert', () => {
        const submitErrorEl = fixture.debugElement.query(By.css('.js-test-submit-error'));
        expect(submitErrorEl).toBeFalsy();
      });

      it('should show submit error alert', () => {
        component.submitError = true;
        fixture.detectChanges();

        const submitErrorEl = fixture.debugElement.query(By.css('.js-test-submit-error'));
        expect(submitErrorEl).toBeTruthy();
      });
    });

    describe('Submit success alert and information', () => {
      it('should display success alert and next steps for self-setup', () => {
        spyOn(service, 'submitNotification').and.returnValue(of(TEST_NOTIFICATION_RESPONSE));

        component.formGroup.controls.emailOption.setValue(EMAIL_OPTION_ACCOUNT_DETAILS);
        component.formGroup.controls.emailAddress.setValue('my@email.com');

        component.submitNotification();
        fixture.detectChanges();

        const selfAlertEl = fixture.debugElement.query(By.css('.js-test-submit-alert'));
        expect(selfAlertEl).toBeTruthy();
        expect(component.submittedAlertConfig).toBe(SUBMITTED_MYSELF_ALERT);
        const nextStepsEl = fixture.debugElement.query(By.css('.js-test-next-steps-self'));
        expect(nextStepsEl).toBeTruthy();
      });

      it('should display success alert and next steps for self-setup PDF', () => {
        spyOn(service, 'submitNotification').and.returnValue(of(TEST_NOTIFICATION_RESPONSE));

        component.formGroup.controls.emailOption.setValue(EMAIL_OPTION_ACCOUNT_DETAILS_PDF);
        component.formGroup.controls.emailAddress.setValue('my@email.com');

        component.submitNotification();
        fixture.detectChanges();

        const selfAlertEl = fixture.debugElement.query(By.css('.js-test-submit-alert'));
        expect(selfAlertEl).toBeTruthy();
        expect(component.submittedAlertConfig).toBe(SUBMITTED_MYSELF_ALERT);
        const nextStepsEl = fixture.debugElement.query(By.css('.js-test-next-steps-self-pdf'));
        expect(nextStepsEl).toBeTruthy();
      });

      it('should display success alert and next steps for setup-on-my-behalf', () => {
        spyOn(service, 'submitNotification').and.returnValue(of(TEST_NOTIFICATION_RESPONSE));

        component.formGroup.controls.setupType.setValue(SETUP_TYPE_ON_MY_BEHALF);
        component.formGroup.controls.emailAddress.setValue('my@email.com');
        component.formGroup.controls.employerContactName.setValue('Employer Name');
        component.formGroup.controls.employerEmailAddress.setValue('employer@email.com');

        component.submitNotification();
        fixture.detectChanges();

        const selfAlertEl = fixture.debugElement.query(By.css('.js-test-submit-alert'));
        expect(selfAlertEl).toBeTruthy();
        expect(component.submittedAlertConfig).toBe(SUBMITTED_FOR_ME_ALERT);
        const nextStepsEl = fixture.debugElement.query(By.css('.js-test-next-steps-for-me'));
        expect(nextStepsEl).toBeTruthy();
      });
    });

    describe('Submit button', () => {
      it('should not be disabled', () => {
        component.hasSubmitPermission = true;
        fixture.detectChanges();
        const submitButtons = fixture.debugElement.queryAll(By.css('bt-button'));
        expect(submitButtons[0].properties.disabled).toEqual(false);
      });

      it('should be disabled', () => {
        component.hasSubmitPermission = false;
        fixture.detectChanges();
        const submitButtons = fixture.debugElement.queryAll(By.css('bt-button'));
        expect(submitButtons[0].properties.disabled).toEqual(true);
      });
    });
  });
});
