import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';

export const DECREASE_REVIEW_MSG_DEATH: Alert = {
  type: 'info',
  outline: true,
  messages: {
    message: 'You can only reduce your Death cover from double cover to single cover.'
  },
  a11yProps: {
    ariaRole: 'none'
  }
};

export const DECREASE_REVIEW_MSG_DEATH_AND_TPD: Alert = {
  type: 'info',
  outline: true,
  messages: {
    message: 'You can only reduce your Death and TPD cover to Death cover only. You are unable to hold TPD cover only.'
  },
  a11yProps: {
    ariaRole: 'none'
  }
};

export const REVIEW_CANCEL_MSG: Alert = {
  type: 'warning',
  outline: true,
  messages: {
    message: 'Your TPD cover will be cancelled upon submitting this request.'
  },
  a11yProps: {
    ariaRole: 'none'
  }
};

export const CHANGE_INCREASE_ACTIVE_COVER_INFO_AEM_KEY: string = 'change_cover_review_useful_info_active_increase';

export const CHANGE_INCREASE_ACTIVE_COVER_TERMS_AEM_KEY: string = 'change_cover_review_confirm_check_active_increase';

export const CHANGE_REDUCE_ACTIVE_COVER_INFO_AEM_KEY: string = 'change_cover_review_useful_info_active_decrease';

export const CHANGE_REDUCE_ACTIVE_COVER_TERMS_AEM_KEY: string = 'change_cover_review_confirm_check_active_decrease';

export const CHANGE_PENDING_COVER_INFO_AEM_KEY: string = 'change_cover_review_useful_info_pending';

export const CHANGE_PENDING_COVER_TERMS_AEM_KEY: string = 'change_cover_review_confirm_check_pending';

export const DECREASE_COVER_INFO_AEM_KEY: string = 'decrease_cover_review_useful_info';

export const DECREASE_COVER_TERMS_AEM_KEY: string = 'decrease_cover_review_confirm_check';

export const DECREASE_REQUEST_COVER_TERMS_AEM_KEY: string = 'decrease_cover_review_earthrise_confirm_check';

export const DECREASE_REQUEST_SUM_INSURED_AEM_KEY: string = 'decrease_review_sum_summary';

export const DECREASE_REQUEST_SCI_AEM_KEY: string = 'decrease_review_sci_summary';

export const DECREASE_REQUEST_UNITS_AEM_KEY: string = 'decrease_review_units_summary';

export const PRODUCT_DISCLOSURE_STATEMENT_BTSUPER: string =
  'https://www.bt.com.au/personal/help/pds.html#super-employer';

export const PRODUCT_DISCLOSURE_STATEMENT_BTSFL: string = 'https://www.bt.com.au/personal/help/pds.html#super-personal';

export const PRE_EXISTING_CONDITIONS_BUTTON: Button = {
  action: 'button',
  colourModifier: 'primary',
  size: 'small',
  type: 'flat',
  label: 'pre-existing conditions'
};

export const SUBMIT_ERROR_ALERT: Alert = {
  type: 'error',
  messages:
    'Something unexpected has happened. We are unable to change your cover at this time – please contact BT on 132 135 Monday to Friday 8.30am – 5.30pm (Sydney time).',
  outline: true,
  showCodes: false
};
