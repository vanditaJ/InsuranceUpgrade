import { Component, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Button } from '@bt/components/button';
import { SnackBarTemplateComponent } from '@bt/components/snack-bar-template';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { PanoInsuranceListTableComponent } from '../pano-insurance-list-table/pano-insurance-list-table.component';
import {
  DIALOG_CANCEL_BUTTON,
  DIALOG_CLOSE_BUTTON,
  DIALOG_SUBMIT_BUTTON,
  SNACK_BAR_EXTERNAL_ASSETS_SUCCESS
} from '../pano-insurance-list.constants';
import { Policy } from '../pano-insurance-list.interface';
import { PanoInsuranceListService } from '../pano-insurance-list.service';
@Component({
  selector: 'pano-insurance-list-opt-in',
  templateUrl: './pano-insurance-list-opt-in.component.html',
  styleUrls: ['./pano-insurance-list-opt-in.component.scss']
})
export class PanoInsuranceListOptInComponent implements OnInit {
  @Input() Policy: Policy[];
  policyNumber: number;
  resultList: any;
  readonly cancelBtn: Button = DIALOG_CANCEL_BUTTON;
  readonly closeBtn: Button = DIALOG_CLOSE_BUTTON;
  readonly submitBtn: Button = DIALOG_SUBMIT_BUTTON;
  pysOptInForm: FormGroup;
  submitted = false;
  availablePoliciesForOptIn: any;
  filterResultListData: any;
  selectedRecord = [];

  @ViewChild('panoTable', { static: false }) panoTable: PanoInsuranceListTableComponent;

  constructor(
    public dialogRef: MatDialogRef<PanoInsuranceListOptInComponent>,
    private readonly snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data,
    private panoInsuranceListService: PanoInsuranceListService,
    private formBuilder: FormBuilder,
    private panoService: PanoUpgradeAccountService
  ) {}
  ngOnInit(): void {
    this.filterResultListData = this.data;
    this.pysOptInForm = this.formBuilder.group({
      selectPolicy: [false, Validators.requiredTrue],
      acceptTerms: [false, Validators.requiredTrue]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.pysOptInForm.controls;
  }

  public checked(list, i) {
    this.panoInsuranceListService.selectedIndex = i;
    this.selectedRecord.push(list.policyNumber);
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.pysOptInForm.invalid) {
      return;
    }
    this.panoInsuranceListService
      .submitPysOptInRequest(this.selectedRecord, this.panoService.getAccountId())
      .subscribe(x => {
        if (x) {
          this.dialogRef.close(true);
        }
        this.snackBar.openFromComponent(SnackBarTemplateComponent, SNACK_BAR_EXTERNAL_ASSETS_SUCCESS);
      });
  }
  onClose() {
    this.onCancel();
  }

  onCancel() {
    this.dialogRef.close();
  }
}
