import { Account, NotificationResponse, Profile } from './pano-employer-contributions-details.interfaces';

export const TEST_ACCOUNT: Account = {
  accountNumber: '12345789',
  owners: [
    {
      firstName: 'James',
      lastName: 'Bond',
      dateOfBirth: '05 Aug 1951',
      emails: [
        {
          email: 'my@email.com'
        }
      ]
    }
  ]
};

export const TEST_ACCOUNT_NO_EMAIL: Account = {
  accountNumber: '12345789',
  owners: [
    {
      firstName: 'James',
      lastName: 'Bond',
      dateOfBirth: '05 Aug 1951',
      emails: []
    }
  ]
};

export const TEST_ACCOUNT_NO_OWNER: Account = {
  accountNumber: '12345789'
};

/** Max valid length is 50. This string is 51 chars */
export const TEST_INVALID_EMPLOYEE_CONTACT_NAME: string = '123456789012345678901234567890123456789012345678901';

export const TEST_NOTIFICATION_RESPONSE: NotificationResponse = {
  receiptId: '123456789'
};

export const TEST_PROFILE: Profile = {
  clientId: '4113589DB47F06D0026D9BCD395287ADCA2404268F509DC1DE5C0564323E8CD7'
};
