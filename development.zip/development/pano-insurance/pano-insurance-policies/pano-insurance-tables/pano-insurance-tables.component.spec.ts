import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { PipesTestingModule } from '@bt/pipes/testing';
import { TotalOfPipe, TotalOfPipeModule } from '@bt/pipes/total-of';
import { WINDOW } from '@bt/tokens';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouter } from '@uirouter/core';
import {
  PanoUpgradeAccountService,
  PanoUpgradeFeatureService,
  PanoUpgradePermissionService
} from '@upgrade/upgrade.services';
import { cloneDeep, forEach } from 'lodash-es';
import * as moment from 'moment-timezone';
import { of } from 'rxjs';

import { CoverMode } from '../../pano-change-cover-insurance/pano-change-cover-insurance.interface';
import { PanoInsuranceSharedLinkService } from '../../pano-insurance-shared-link/pano-insurance-shared-link.service';
import { LinkType } from '../../pano-insurance-shared-link/pano-insurance-shared-link.service.constants';
import { ESSENTIAL_COVER, STANDARD_COVER, TAILORED_COVER } from '../../pano-insurance.constants';
import { InsurancePolicy, PolicyStatus, PolicyType } from '../../pano-insurance.interface';
import { PanoInsuranceAlertModalComponent } from '../pano-insurance-alert-modal/pano-insurance-alert-modal.component';
import { InsuranceDetail, Insurances } from '../pano-insurance-policies.interface';
import { PanoInsurancePoliciesUtil } from '../pano-insurance-policies.util';

import { PanoInsuranceTablesComponent } from './pano-insurance-tables.component';
import {
  ACTION_BUTTON,
  BASIC_ALERT,
  BENEFIT_FREQUENCY,
  CANCEL_COVER_BUTTON,
  CANCEL_INSURANCE_STATE,
  CHANGE_COVER_BUTTON,
  CHANGE_INSURANCE_STATE,
  EY_INSURER_CODE,
  INACTIVE_FOOTNOTE,
  INSURANCE_DETAILS,
  NOT_OPTED_IN,
  NO_OCCUPATION_CODE_INLINE_ALERT,
  PENDING_FOOTNOTE,
  PMIF_NOT_ACTIVE_GT_30_DAYS_ALERT,
  PMIF_PENDING_STATUS_ALERT,
  POLICY_GT_60_DAYS_ALERT,
  POLICY_LT_90_DAYS_ALERT,
  POLICY_STATUS,
  POPOVER_ICON
} from './pano-insurance-tables.component.constants';
import {
  MOCK_60_90_DAYS_INSURANCE_DETAIL,
  MOCK_60_DAYS_POLICIES,
  MOCK_ACCOUNT,
  MOCK_AEM_CONTENT_INSURANCE_TABLES,
  MOCK_ALL_POLICIES,
  MOCK_BT_SUPER_ACCOUNT,
  MOCK_INSURANCE_DETAILS,
  MOCK_INSURANCE_DETAIL_FOR_TOTAL_ROW,
  MOCK_NO_OCCUPATION_CODE_INSURANCE_DETAIL,
  TPD_INSURANCE
} from './pano-insurance-tables.component.spec.constants';

describe('PanoInsuranceTablesComponent', () => {
  const successHandler: jasmine.Spy = jasmine.createSpy();
  const errorHandler: jasmine.Spy = jasmine.createSpy();

  let component: PanoInsuranceTablesComponent;
  let fixture: ComponentFixture<PanoInsuranceTablesComponent>;
  let panoInsurancePoliciesUtil: PanoInsurancePoliciesUtil;
  let panoUpgradePermissionService: PanoUpgradePermissionService;
  let linkService: PanoInsuranceSharedLinkService;
  let dialog: MatDialog;

  const totalOfPipeTransformSpy: jasmine.Spy = jasmine.createSpy();
  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy()
    }
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInsuranceTablesComponent],

        imports: [
          LayoutModule,
          RouterTestingModule,
          MatMenuModule,
          MatDialogModule,
          PipesTestingModule,
          TotalOfPipeModule,
          BrowserAnimationsModule
        ],
        providers: [
          { provide: UIRouter, useValue: mockUiRouter },
          { provide: PanoUpgradePermissionService, useValue: { hasPermission: () => true } },
          {
            provide: PanoUpgradeFeatureService,
            useValue: {
              hasAccess: () => true
            }
          },
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              getAccountId: () => '1234'
            }
          },
          PanoInsurancePoliciesUtil,
          {
            provide: TotalOfPipe,
            useValue: {
              transform: totalOfPipeTransformSpy
            }
          },
          {
            provide: PanoInsuranceSharedLinkService,
            useValue: {
              getUrl: () => 'https://hello'
            }
          },
          { provide: WINDOW, useValue: { open: jasmine.createSpy() } }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsuranceTablesComponent);
    panoInsurancePoliciesUtil = TestBed.inject(PanoInsurancePoliciesUtil);
    component = fixture.componentInstance;
    component.policies = MOCK_ALL_POLICIES;
    component.cmsContent = MOCK_AEM_CONTENT_INSURANCE_TABLES;
    component.account = MOCK_ACCOUNT;
    dialog = TestBed.inject(MatDialog);
    panoInsurancePoliciesUtil = TestBed.inject(PanoInsurancePoliciesUtil);
    panoUpgradePermissionService = TestBed.inject(PanoUpgradePermissionService);
    linkService = TestBed.inject(PanoInsuranceSharedLinkService);
    fixture.detectChanges();
  });

  afterEach(() => {
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  it('should have correct value for its properties', () => {
    expect(component.insuranceDetails).toEqual(INSURANCE_DETAILS);
    expect(component.changeCoverButton).toBe(CHANGE_COVER_BUTTON);
    expect(component.cancelCoverButton).toBe(CANCEL_COVER_BUTTON);
    expect(component.policyGT60DaysAlert).toBe(POLICY_GT_60_DAYS_ALERT);
    expect(component.pmifNotActiveGT30DaysAlert).toBe(PMIF_NOT_ACTIVE_GT_30_DAYS_ALERT);
    expect(component.actionButton).toBe(ACTION_BUTTON);
    expect(component.policyStatusLabels).toEqual(POLICY_STATUS);
    expect(component.benefitFrequencyLabels).toEqual(BENEFIT_FREQUENCY);
    expect(component.popoverIcon).toBe(POPOVER_ICON);
    expect(component.basicAlert).toBe(BASIC_ALERT);
    expect(component.policies).toEqual(MOCK_ALL_POLICIES);
  });

  describe('Component', () => {
    beforeEach(() => {
      component.policies = MOCK_ALL_POLICIES;
      component.account = MOCK_ACCOUNT;
    });

    describe('ngOnInit', () => {
      beforeEach(() => {
        spyOn(component as any, 'setPendingPolicies');
        spyOn(component as any, 'getInsuranceTableData');
      });
      it('add insurances to each policy and call pending policy function and should set permission for showing action menu', () => {
        component.ngOnInit();
        expect((component as any).getInsuranceTableData).toHaveBeenCalled();
        expect((component as any).setPendingPolicies).toHaveBeenCalled();
        expect(component.showMenuActionPermission).toBeTruthy();
      });

      it('should filter not active and requested policies when not pmif feature toggle ', () => {
        spyOn(panoUpgradePermissionService, 'hasPermission').and.returnValue(false);
        component.ngOnInit();
        expect(component.policies.length).toEqual(6);
      });
    });

    describe('setAemMessages', () => {
      it('should populate correct messages', () => {
        component.setAemMessages();

        expect(component.changeCoverModalAemMessage).toBe(MOCK_AEM_CONTENT_INSURANCE_TABLES[0].data.description);
        expect(component.cancelCoverModalAemMessage).toBe(MOCK_AEM_CONTENT_INSURANCE_TABLES[1].data.description);
        expect(component.viewCover90DaysAemMessage).toBe(MOCK_AEM_CONTENT_INSURANCE_TABLES[3].data.description);
        expect(component.viewCoverNoOccupationCodeAemMessage).toBe(
          MOCK_AEM_CONTENT_INSURANCE_TABLES[4].data.description
        );
        expect(component.increaseCoverEyModalAemMessage).toBe(MOCK_AEM_CONTENT_INSURANCE_TABLES[5].data.description);
      });
    });

    describe('getInsuranceTableData', () => {
      it('should return table data for Death policy', () => {
        const detail: InsuranceDetail = cloneDeep(INSURANCE_DETAILS[0]);
        const mockDetail: InsuranceDetail = cloneDeep(MOCK_INSURANCE_DETAILS[0]);
        totalOfPipeTransformSpy.and.returnValue(1076);
        spyOn(component as any, 'sortInsurances');
        spyOn(component as any, 'getNonPendingPolicies');
        spyOn(component as any, 'showMenuAction').and.returnValue(true);
        spyOn(component as any, 'showChangeMenuAction').and.returnValue(true);
        spyOn(component as any, 'showDecreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showIISCOPDecreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showIncreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showEyIncreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showPolicyGT60DaysAlert').and.returnValue(false);
        spyOn(component as any, 'showPolicyLT90DaysAlert').and.returnValue(false);
        spyOn(component as any, 'showStatusFootNote').and.returnValue(true);
        spyOn(panoInsurancePoliciesUtil, 'isPolicySuitableForNoOccupationCodeAlert').and.returnValue(true);

        (component as any).getInsuranceTableData(detail);

        expect(detail.insurances).toEqual(mockDetail.insurances);
        expect(detail.showDeathFootNote).toEqual(mockDetail.showDeathFootNote);
        expect(detail.showInsuranceFootNote).toEqual(mockDetail.showInsuranceFootNote);
        expect(detail.showPendingFootNote).toEqual(mockDetail.showPendingFootNote);
        expect(detail.showInactiveFootNote).toEqual(mockDetail.showInactiveFootNote);
        expect(detail.showWhoPays).toEqual(mockDetail.showWhoPays);
        expect(detail.showSmokerStatus).toEqual(mockDetail.showSmokerStatus);
        expect(detail.totalCoverAmount).toEqual(1076);
        expect(detail.totalPremiumAmount).toEqual(1076);
        expect((component as any).sortInsurances).toHaveBeenCalled();
        expect((component as any).getNonPendingPolicies).toHaveBeenCalled();
      });

      it('should return table data for TPD policy', () => {
        const detail = cloneDeep(INSURANCE_DETAILS[1]);
        detail.insurances.forEach(insurance => {
          insurance.customised = true;
          insurance.smokerStatus = 'Non smoker';
        });
        detail.showSmokerStatus = true;
        const updatedInsuranceDetails = (component as any).getInsuranceTableData(detail);
        expect(component.insuranceDetails[1]).toEqual(updatedInsuranceDetails);
      });

      it('should return table data for Death & TPD policy', () => {
        const detail = cloneDeep(INSURANCE_DETAILS[2]);
        detail.insurances.forEach(insurance => {
          insurance.customised = true;
          insurance.smokerStatus = 'Non smoker';
        });
        detail.showSmokerStatus = true;
        const updatedInsuranceDetails = (component as any).getInsuranceTableData(detail);
        expect(component.insuranceDetails[2]).toEqual(updatedInsuranceDetails);
      });

      it('should return table data for Salary Continuance policy', () => {
        const detail = cloneDeep(INSURANCE_DETAILS[3]);
        const updatedInsuranceDetails = (component as any).getInsuranceTableData(detail);
        expect(component.insuranceDetails[3]).toEqual(updatedInsuranceDetails);
      });
    });

    describe('getNonPendingPolicies', () => {
      it('should return non pending policies', () => {
        let nonPendingPolicies: Insurances[] = (component as any).getNonPendingPolicies(MOCK_INSURANCE_DETAILS[0]);
        expect(nonPendingPolicies.length).toEqual(0);

        nonPendingPolicies = (component as any).getNonPendingPolicies(MOCK_INSURANCE_DETAILS[3]);
        expect(nonPendingPolicies).toEqual(MOCK_INSURANCE_DETAILS[3].insurances);
      });
    });

    describe('removeTableTitles', () => {
      describe('when title is Smoker status', () => {
        it('then do not remove title if account has Customised insurance & insurance has a value for smokerStatus', () => {
          const policyDetail = cloneDeep(MOCK_INSURANCE_DETAILS[3]);
          const filteredTitles = (component as any).removeTableTitles(policyDetail);
          expect(filteredTitles).toEqual(policyDetail.tableTitles);
        });

        it('then remove title if smokerStatus is not defined for insurance', () => {
          const policyDetail = cloneDeep(MOCK_INSURANCE_DETAILS[2]);
          const filteredTitles = (component as any).removeTableTitles(policyDetail);
          expect(filteredTitles).not.toContain({
            name: 'Smoker status',
            smoking: true
          });
        });
      });
    });

    describe('when title is Who pays?', () => {
      it('then do not Who Pays if westpacGroupPlan  is false for insurance', () => {
        const policyDetail = cloneDeep(MOCK_INSURANCE_DETAILS[3]);
        const filteredTitles = (component as any).removeTableTitles(policyDetail);
        expect(filteredTitles).toEqual(policyDetail.tableTitles);
      });

      it('then remove Who Pays if westpacGroupPlan  is true for insurance', () => {
        const policyDetail = cloneDeep(MOCK_INSURANCE_DETAILS[1]);
        const filteredTitles = (component as any).removeTableTitles(policyDetail);
        expect(filteredTitles).not.toContain({
          name: 'Who pays?',
          whoPays: true
        });
      });
    });

    describe('checkConditionAndOpenAlertModal', () => {
      it('should open alert modal if age is greater than or equal to 60 when action is change', () => {
        const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[0];
        spyOn(component, 'openAlertModal');

        component.checkConditionAndOpenAlertModal(CoverMode.CHANGE, insurance);

        expect(component.openAlertModal).toHaveBeenCalled();
      });

      it('should directly redirect to change screen if age is less than 60 when action is change', () => {
        const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[1];
        spyOn(component, 'navigateToChangeOrDecreaseCover');

        component.checkConditionAndOpenAlertModal(CoverMode.CHANGE, insurance);

        expect(component.navigateToChangeOrDecreaseCover).toHaveBeenCalledWith(insurance, CoverMode.CHANGE);
      });

      it('should open alert model if current policy is death with an associated tpd policy and the policies statuses are not Active^', () => {
        component.visiblePolicies = [MOCK_ALL_POLICIES[1], MOCK_ALL_POLICIES[2]];
        const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[0];
        spyOn(component, 'openAlertModal');

        component.checkConditionAndOpenAlertModal(CoverMode.CANCEL, insurance);
        expect(component.openAlertModal).toHaveBeenCalled();
      });

      it('should not open alert model and directly navigate to cancel screen if current death policy is not associated with a tpd ', () => {
        component.visiblePolicies = [MOCK_ALL_POLICIES[1], MOCK_ALL_POLICIES[2], MOCK_ALL_POLICIES[4]];
        const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[1];
        spyOn(component, 'openAlertModal');
        spyOn(component, 'navigateToCancelCover');

        component.checkConditionAndOpenAlertModal(CoverMode.CANCEL, insurance);
        expect(component.openAlertModal).not.toHaveBeenCalled();
        expect(component.navigateToCancelCover).toHaveBeenCalledWith(insurance);
      });

      it('should directly navigate to cancel screen if current policy type is not death', () => {
        const insurance: Insurances = MOCK_INSURANCE_DETAILS[1].insurances[0];
        spyOn(panoInsurancePoliciesUtil, 'getDeathAssociatedTPDPolicies').and.returnValue([]);
        spyOn(component, 'navigateToCancelCover');

        component.checkConditionAndOpenAlertModal(CoverMode.CANCEL, insurance);

        expect(component.navigateToCancelCover).toHaveBeenCalledWith(insurance);
      });
    });

    describe('openExitSiteDialog', () => {
      it('should open dialog', () => {
        spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(true) } as MatDialogRef<any>);
        component.openExitSiteDialog();

        expect(dialog.open).toHaveBeenCalled();
      });
    });

    describe('openIncreaseEyCoverDialog', () => {
      it('should open dialog', () => {
        spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(true) } as MatDialogRef<any>);
        component.openIncreaseEyCoverDialog();

        expect(dialog.open).toHaveBeenCalled();
      });
    });

    describe('openAlertModal', () => {
      describe('when dialog returns true', () => {
        it('should open the dialog box', () => {
          spyOn(component, 'setData').and.returnValue({ heading: 'Change cover', description: 'test' });
          spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(true) } as MatDialogRef<any>);
          component.openAlertModal(CoverMode.CHANGE);

          expect(dialog.open).toHaveBeenCalled();
        });

        it('should open the dialog box for cancel cover', () => {
          const insurance: Insurances = MOCK_INSURANCE_DETAILS[0].insurances[1];
          spyOn(component, 'setData').and.returnValue({
            heading: 'Cancel your cover',
            description: 'test',
            showContinueButton: true
          });
          spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(true) } as MatDialogRef<any>);
          component.openAlertModal(CoverMode.CANCEL, insurance);

          expect(dialog.open).toHaveBeenCalled();
        });

        it('should call successHandler if continue button is clicked', () => {
          spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of('continue') } as MatDialogRef<any>);
          spyOn(component, 'navigateToCancelCover');

          const data = {
            heading: 'Cancel your cover',
            description: 'test',
            showContinueButton: true
          };

          dialog
            .open(PanoInsuranceAlertModalComponent, { data })
            .afterClosed()
            .subscribe(successHandler, errorHandler);
          expect(successHandler).toHaveBeenCalled();
          expect(errorHandler).not.toHaveBeenCalled();
        });
      });
    });

    describe('setData', () => {
      beforeEach(() => {
        component.cmsContent = [
          {
            type: 'test',
            id: 'change_cover_age_modal',
            data: {
              headerText: 'Change cover',
              description: 'test'
            }
          },
          {
            type: 'test',
            id: 'cancel_cover_death_modal',
            data: {
              headerText: 'Cancel your cover',
              description: 'test'
            }
          }
        ];
      });

      it('should set change data if action is change', () => {
        const result = (component as any).setData(CoverMode.CHANGE);

        expect(result.heading).toBe('Change cover');
      });

      it('should set cancel data if action is cancel', () => {
        const result = (component as any).setData(CoverMode.CANCEL);

        expect(result.heading).toBe('Cancel your cover');
        expect(result.showContinueButton).toBe(true);
      });
    });

    describe('setData', () => {
      it('should add content to dataObj when action is change', () => {
        component.dataObj = {
          heading: '',
          description: ''
        };

        component.setData(CoverMode.CHANGE);

        expect(component.dataObj.heading).toBe('Change cover');
        expect(component.dataObj.description).toBe(MOCK_AEM_CONTENT_INSURANCE_TABLES[0].data.description);
      });

      it('should do nothing when is not change', () => {
        component.dataObj = {
          heading: '',
          description: ''
        };

        component.setData(CoverMode.DECREASE);

        expect(component.dataObj.heading).toBe('');
        expect(component.dataObj.description).toBe('');
      });
    });

    describe('setBenefits', () => {
      beforeEach(() => {
        spyOn(component as any, 'showMenuAction').and.returnValue(true);
        spyOn(component as any, 'showChangeMenuAction').and.returnValue(true);
        spyOn(component as any, 'showDecreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showIISCOPDecreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showIncreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showEyIncreaseMenuAction').and.returnValue(false);
        spyOn(component as any, 'showPolicyLT90DaysAlert').and.returnValue(false);
        spyOn(component as any, 'showPmifNotActiveGT30DaysAlert').and.returnValue(false);
        spyOn(panoInsurancePoliciesUtil, 'isPolicyAvailableForInsuranceTable').and.returnValue(true);
        spyOn(panoInsurancePoliciesUtil, 'isPolicySuitableForNoOccupationCodeAlert').and.returnValue(true);
      });

      it('should set benefits & other data', () => {
        spyOn(component as any, 'showPolicyGT60DaysAlert').and.returnValue(false);

        const modifiedInsurances: Insurances[] = (component as any).setBenefits(MOCK_ALL_POLICIES);

        expect(modifiedInsurances[0].benefits).toEqual(MOCK_ALL_POLICIES[0].personBenefitDetails[0].benefits[0]);
        expect(modifiedInsurances[0].occupationClass).toEqual(
          MOCK_ALL_POLICIES[0].personBenefitDetails[0].benefits[0].benefits[0].occupationClass
        );
        expect(modifiedInsurances[0].policyStatusLabel).toBe('Active');
        expect(modifiedInsurances[0].benefitFrequencyLabel).toBe('per month');
        expect(modifiedInsurances[0].popoverText).toBe('Help-IP-0334');
        expect(modifiedInsurances[0]['showMenuAction']).toBe(true);
        expect(modifiedInsurances[0]['showChangeMenuAction']).toBe(true);
        expect(modifiedInsurances[0]['showDecreaseMenuAction']).toBe(false);
        expect(modifiedInsurances[0]['showIncreaseMenuAction']).toBe(false);
        expect(modifiedInsurances[0]['showEyIncreaseMenuAction']).toBe(false);
        expect(modifiedInsurances[0]['policyGT60DaysMessage']).toBe(null);
        expect(modifiedInsurances[0]['showPolicyLT90DaysAlert']).toBe(false);
        expect(modifiedInsurances[0]['showPmifNotActiveGT30DaysAlert']).toBe(false);
        expect(modifiedInsurances[0]['isOccupationCodeAbsent']).toBe(true);
        expect(modifiedInsurances[1].policyStatusLabel).toBe('Pending');
        expect(modifiedInsurances[1].popoverText).toBe('');
      });

      it('should set benefits & 60 days messages', () => {
        spyOn(component as any, 'showPolicyGT60DaysAlert').and.returnValue(true);

        const insurances: Insurances[] = (component as any).setBenefits(MOCK_60_DAYS_POLICIES);

        expect(insurances[0]['policyGT60DaysMessage']).toBe(MOCK_AEM_CONTENT_INSURANCE_TABLES[2].data.description);
        expect(insurances[1]['policyGT60DaysMessage']).toBe(MOCK_AEM_CONTENT_INSURANCE_TABLES[6].data.description);
      });
    });

    describe('setPendingPolicies', () => {
      it('should set the pending policies to be shown in alert and should set the correct alert message', () => {
        component.pendingPolicies = [];

        (component as any).setPendingPolicies(MOCK_ALL_POLICIES);

        expect(component.pendingPolicies.length).toEqual(2);
        expect(component.pendingPolicies[0]).toEqual(MOCK_ALL_POLICIES[0]);
      });
    });

    describe('sortInsurances', () => {
      it('should sort insurances by coverSubTypeId and status', () => {
        const deathInsuranceData: InsuranceDetail = cloneDeep(MOCK_INSURANCE_DETAILS[1]);
        deathInsuranceData.insurances.push(TPD_INSURANCE);
        const sortedInsurances: InsuranceDetail = (component as any).sortInsurances(deathInsuranceData);
        expect(sortedInsurances.insurances[0].coverSubTypeId).toBe(10);
        expect(sortedInsurances.insurances[1].coverSubTypeId).toBe(110);
        expect(sortedInsurances.insurances[2].coverSubTypeId).toBe(71);
      });
    });

    describe('setPopoverText', () => {
      it('should return copyID for popover test if applicable noteID includes TT1/TT2/TT3', () => {
        let copyID: string;
        const policy: InsurancePolicy = cloneDeep(MOCK_INSURANCE_DETAILS[3].insurances[0]);
        copyID = (component as any).setPopoverText(policy);
        expect(copyID).toBe('Help-IP-0334');

        policy.applicableNotes = 'TT2';
        copyID = (component as any).setPopoverText(policy);
        expect(copyID).toBe('Help-IP-0335');

        policy.applicableNotes = 'TT3';
        copyID = (component as any).setPopoverText(policy);
        expect(copyID).toBe('Help-IP-0336');
      });

      it('should return empty string if applicable noteID does not include TT1/TT2/TT3', () => {
        expect((component as any).setPopoverText(MOCK_ALL_POLICIES[1])).toBe('');
      });
    });

    describe('showMenuAction', () => {
      describe('inactive and end of month', () => {
        it('return false', () => {
          const policy = {
            status: PolicyStatus.INACTIVE,
            endDate: moment()
              .endOf('month')
              .format()
          };
          const result = (component as any).showMenuAction(policy);

          expect(result).toEqual(false);
        });
      });

      describe('when active', () => {
        it('return true', () => {
          const policy = {
            status: PolicyStatus.ACTIVE,
            external: false
          };
          const result = (component as any).showMenuAction(policy);

          expect(result).toEqual(true);
        });
      });

      describe('when pending and not external', () => {
        it('return true', () => {
          const policy = {
            status: PolicyStatus.PENDING,
            external: false
          };
          const result = (component as any).showMenuAction(policy);

          expect(result).toEqual(true);
        });
      });
    });

    describe('showChangeMenuAction', () => {
      beforeEach(() => {
        jasmine.clock().install();
        jasmine.clock().mockDate(new Date('2021-01-22'));
      });

      afterEach(() => {
        jasmine.clock().uninstall();
      });

      describe('when policyType is Death or Death TPD', () => {
        it('return true when customerType is retail and age is greater than 60', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH_AND_TPD,
            ageNextBirthday: 61,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE,
            customised: false
          };
          const result = (component as any).showChangeMenuAction(policy);

          expect(result).toEqual(true);
        });

        it('return true when customerType is retail, age is less than 60, and activation days are less than equal to 90', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH,
            ageNextBirthday: 59,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE,
            customised: false
          };
          spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor90DaysCriteria').and.returnValue(90);
          const result = (component as any).showChangeMenuAction(policy);

          expect(result).toEqual(true);
        });

        it('return false when customised', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH_AND_TPD,
            ageNextBirthday: 61,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE,
            customised: true
          };
          const result = (component as any).showChangeMenuAction(policy);

          expect(result).toEqual(false);
        });
      });

      describe('when policy type is not death or death tpd', () => {
        it('return false', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.INCOME_PROTECTION,
            ageNextBirthday: 59,
            customerType: 'Retail'
          };
          const result = (component as any).showChangeMenuAction(policy);

          expect(result).toEqual(false);
        });
      });
    });

    describe('showMenuActionAmend', () => {
      it('return true when customerType is retail and not customised and (active or pending)', () => {
        const policy = {
          customerType: 'Retail',
          status: PolicyStatus.ACTIVE,
          customised: false
        };
        const result = (component as any).showMenuActionAmend(policy);

        expect(result).toEqual(true);
      });

      it('return false when customerType is retail and customised and (active or pending)', () => {
        const policy = {
          customerType: 'Retail',
          status: PolicyStatus.ACTIVE,
          customised: true
        };
        const result = (component as any).showMenuActionAmend(policy);

        expect(result).toEqual(false);
      });
    });

    describe('showIISCOPDecreaseMenuAction', () => {
      it('return true when iiscop permission and decrease available', () => {
        component.iiscopPermission = true;
        const policy = {
          status: PolicyStatus.ACTIVE,
          qualifierName: ESSENTIAL_COVER,
          decreaseAvailable: true
        };
        const result = (component as any).showIISCOPDecreaseMenuAction(policy);

        expect(result).toEqual(true);
      });

      it('return false when iiscop permission and not decrease available', () => {
        component.iiscopPermission = true;
        const policy = {
          status: PolicyStatus.PENDING,
          qualifierName: ESSENTIAL_COVER,
          decreaseAvailable: false
        };
        const result = (component as any).showIISCOPDecreaseMenuAction(policy);

        expect(result).toEqual(false);
      });

      it('return false when not iiscop permission and decrease available', () => {
        component.iiscopPermission = false;
        const policy = {
          status: PolicyStatus.ACTIVE,
          qualifierName: ESSENTIAL_COVER,
          decreaseAvailable: true
        };
        const result = (component as any).showIISCOPDecreaseMenuAction(policy);

        expect(result).toEqual(false);
      });
    });

    describe('showIncreaseMenuAction', () => {
      beforeEach(() => {
        component.account.pdsStatus = 'DEFAULT';

        spyOn(component as any, 'isPolicyInScope').and.returnValue(true);
      });

      it('should return true when policy status is active', () => {
        const policy = {
          status: PolicyStatus.ACTIVE,
          coverSubTypeId: 14
        };

        expect((component as any).showIncreaseMenuAction(policy)).toEqual(true);
      });

      it('should return false when policy status is cancelled', () => {
        const policy = {
          status: PolicyStatus.INACTIVE,
          coverSubTypeId: 14
        };

        expect((component as any).showIncreaseMenuAction(policy)).toEqual(false);
      });

      it('should return false when policy status is pending', () => {
        const policy = {
          status: PolicyStatus.PENDING,
          coverSubTypeId: 14
        };

        expect((component as any).showIncreaseMenuAction(policy)).toEqual(false);
      });

      it('should return false when policy status is not active', () => {
        const policy = {
          status: PolicyStatus.NOT_ACTIVE,
          coverSubTypeId: 14
        };

        expect((component as any).showIncreaseMenuAction(policy)).toEqual(false);
      });

      it('should return false when account is employed by EY', () => {
        component.account.pdsStatus = 'EY';

        const policy = {
          status: PolicyStatus.ACTIVE,
          coverSubTypeId: 14
        };

        expect((component as any).showIncreaseMenuAction(policy)).toEqual(false);
      });
    });

    describe('showEyIncreaseMenuAction', () => {
      it('should return true when account is employed by EY and the policy is an active EY policy', () => {
        component.account.pdsStatus = 'EY';
        const policy = {
          status: PolicyStatus.ACTIVE,
          insurerCode: EY_INSURER_CODE
        };

        expect((component as any).showEyIncreaseMenuAction(policy)).toEqual(true);
      });

      it('should return true when account is employed by EY and the policy is a pending EY policy', () => {
        component.account.pdsStatus = 'EY';
        const policy = {
          status: PolicyStatus.PENDING,
          insurerCode: EY_INSURER_CODE
        };

        expect((component as any).showEyIncreaseMenuAction(policy)).toEqual(true);
      });

      it('should return false when account is not employed by EY', () => {
        component.account.pdsStatus = 'DEFAULT';
        const policy = {
          status: PolicyStatus.ACTIVE,
          insurerCode: EY_INSURER_CODE
        };

        expect((component as any).showEyIncreaseMenuAction(policy)).toEqual(false);
      });

      it('should return false when policy is not an EY policy', () => {
        component.account.pdsStatus = 'EY';
        const policy = {
          status: PolicyStatus.ACTIVE
        };

        expect((component as any).showEyIncreaseMenuAction(policy)).toEqual(false);
      });
    });

    describe('isPolicyInRangeForBTS', () => {
      it('should return true when coverSubTypeId matches range', () => {
        const policy: any = {
          status: PolicyStatus.ACTIVE
        };

        [14, 24, 50, 76, 150, 200, 220, 260, 285, 271, 290, 300].forEach(id => {
          policy.coverSubTypeId = id;
          expect((component as any).isPolicyInScope(component.superPolicyScope, policy)).toEqual(true);
        });
      });

      it('should return false when coverSubTypeId does not match range', () => {
        const policy: any = {
          status: PolicyStatus.ACTIVE
        };

        [13, 53, 100, 146, 240, 400].forEach(id => {
          policy.coverSubTypeId = id;
          expect((component as any).isPolicyInScope(component.superPolicyScope, policy)).toEqual(false);
        });
      });
    });

    describe('isPolicyInRangeFor60DayBTS', () => {
      it('should return true when coverSubTypeId matches range', () => {
        spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor60DaysCriteria').and.returnValue(61);

        const policy: any = {
          status: PolicyStatus.ACTIVE
        };

        [144, 146].forEach(id => {
          policy.coverSubTypeId = id;
          expect((component as any).isPolicyInScope(component.super60dayPolicyScope, policy)).toEqual(true);
        });
      });

      it('should return false when coverSubTypeId does not match range', () => {
        spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor60DaysCriteria').and.returnValue(61);

        const policy: any = {
          status: PolicyStatus.ACTIVE
        };

        [135, 149, 160, 170, 300, 315].forEach(id => {
          policy.coverSubTypeId = id;
          expect((component as any).isPolicyInScope(component.super60dayPolicyScope, policy)).toEqual(false);
        });
      });

      it('should return false when getAccountActivationDaysFor60DaysCriteria is lesser than 60 days', () => {
        spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor60DaysCriteria').and.returnValue(59);

        const policy: any = {
          status: PolicyStatus.ACTIVE
        };

        [144, 146].forEach(id => {
          policy.coverSubTypeId = id;
          expect((component as any).isPolicyInScope(component.super60dayPolicyScope, policy)).toEqual(true);
        });
      });
    });

    describe('showDecreaseMenuAction', () => {
      beforeEach(() => {
        jasmine.clock().install();
        jasmine.clock().mockDate(new Date('2021-01-22'));
      });

      afterEach(() => {
        jasmine.clock().uninstall();
      });

      describe('when policyType is Death and TPD', () => {
        it('return true when customerType is retail, status is active or pending, age is less than 60, and activation days is greater than 90', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH_AND_TPD,
            ageNextBirthday: 59,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE
          };
          spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor90DaysCriteria').and.returnValue(91);
          const result = (component as any).showDecreaseMenuAction(policy);

          expect(result).toEqual(true);
        });
      });

      describe('when policyType is Death and TPD and customised', () => {
        it('return false when customerType is retail, status is active or pending, age is less than 60, and activation days is greater than 90', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH_AND_TPD,
            ageNextBirthday: 59,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE,
            customised: true
          };
          const result = (component as any).showDecreaseMenuAction(policy);

          expect(result).toEqual(false);
        });
      });

      describe('when policyType is Death', () => {
        it('return true when not customised, cover level not single, customerType is retail, status is active or pending, age is less than 60, and activation days is greater than 90', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH,
            ageNextBirthday: 59,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE,
            coverLevel: 'Double'
          };
          spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor90DaysCriteria').and.returnValue(91);
          const result = (component as any).showDecreaseMenuAction(policy);

          expect(result).toEqual(true);
        });

        it('return true when not customised, cover level is single, customerType is retail, status is active or pending, age is less than 60, and activation days is greater than 90', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH,
            ageNextBirthday: 59,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE,
            coverLevel: 'Single'
          };
          spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor90DaysCriteria').and.returnValue(98);
          const result = (component as any).showDecreaseMenuAction(policy);

          expect(result).toEqual(false);
        });
      });

      describe('when policyType is Death and customised', () => {
        it('return false when cover level not single, customerType is retail, status is active or pending, age is less than 60, and activation days is greater than 90', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.DEATH,
            ageNextBirthday: 59,
            customerType: 'Retail',
            status: PolicyStatus.ACTIVE,
            coverLevel: 'Double',
            customised: true
          };
          const result = (component as any).showDecreaseMenuAction(policy);

          expect(result).toEqual(false);
        });
      });

      describe('when policy type is not death, tpd, death tpd', () => {
        it('return false', () => {
          component.account = MOCK_ACCOUNT;
          const policy = {
            policyType: PolicyType.INCOME_PROTECTION,
            ageNextBirthday: 59,
            customerType: 'Retail'
          };
          const result = (component as any).showDecreaseMenuAction(policy);

          expect(result).toEqual(false);
        });
      });
    });

    describe('showPolicyGT60DaysAlert', () => {
      beforeEach(() => {
        jasmine.clock().install();
        jasmine.clock().mockDate(new Date('2021-04-29'));
      });

      afterEach(() => {
        jasmine.clock().uninstall();
      });

      it('should return true if account has groupInsurance, isPolicyNameEssentialCover, policy type is not SCI, status is pending, customerType is not BT Super - Retail, age is LT 60 and account activation days are LT 60', () => {
        component.account = MOCK_BT_SUPER_ACCOUNT;
        spyOn(component as any, 'getAccountActivationDaysFor60DaysAlert').and.returnValue(50);

        const policy = {
          groupInsurance: true,
          policyType: 'DEATH',
          status: 'PROPOSAL',
          customerType: 'PCS',
          ageNextBirthday: 50,
          qualifierName: ESSENTIAL_COVER,
          external: false,
          pmifDetails: {
            optInDate: '2009-08-04T00:00:00.000+10:00',
            lowBalanceThresholdDate: '2013-08-04T00:00:00.000+10:00'
          }
        };
        const result = (component as any).showPolicyGT60DaysAlert(policy);

        expect(result).toBeTruthy();
      });

      it('should return true if tailored and account has groupInsurance, isPolicyNameEssentialCover, policy type is not SCI, status is pending, customerType is not BT Super - Retail, age is LT 60 and account activation days are LT 60', () => {
        component.account = MOCK_BT_SUPER_ACCOUNT;
        spyOn(component as any, 'getAccountActivationDaysFor60DaysAlert').and.returnValue(50);

        const policy = {
          groupInsurance: true,
          policyType: 'DEATH',
          status: 'PROPOSAL',
          customerType: 'PCS',
          ageNextBirthday: 50,
          qualifierName: TAILORED_COVER,
          external: false,
          pmifDetails: {
            optInDate: '2009-08-04T00:00:00.000+10:00',
            lowBalanceThresholdDate: '2013-08-04T00:00:00.000+10:00'
          }
        };
        const result = (component as any).showPolicyGT60DaysAlert(policy);

        expect(result).toBeTruthy();
      });
    });

    describe('getAccountActivationDaysFor60DaysAlert', () => {
      beforeEach(() => {
        jasmine.clock().install();
        jasmine.clock().mockDate(new Date('2020-11-21'));
      });

      afterEach(() => {
        jasmine.clock().uninstall();
      });

      it('should get days for 60 days alert msg', () => {
        const accountActivationDate = spyOn(component as any, 'getAccountActivationDateFor60DaysAlert').and.returnValue(
          '2020-11-04T00:00:00.000+10:00'
        );
        const result = (component as any).getAccountActivationDaysFor60DaysAlert(accountActivationDate);

        expect(result).toBe(17);
      });
    });

    describe('getAccountActivationDateFor60DaysAlert', () => {
      describe('when member is bt super member and policy is not BYO insurance', () => {
        beforeEach(() => {
          component.account = MOCK_BT_SUPER_ACCOUNT;
        });

        it('should return pmif opt in date if member has opted in pmif and member has reached automatic cover date and optindate is earlier than acd', () => {
          const policy = {
            external: false,
            pmifDetails: {
              optInDate: '2019-08-04T16:00:00.000Z',
              lowBalanceThresholdDate: '2013-08-04T16:00:00.000Z'
            }
          };
          const automaticCoverDate = '2013-08-04T16:00:00.000Z';

          spyOn(panoInsurancePoliciesUtil, 'getAutomaticCoverDate').and.returnValue(automaticCoverDate);

          const result = (component as any).getAccountActivationDateFor60DaysAlert(policy);

          expect(result).toBe(automaticCoverDate);
        });

        it('should return automatic cover date if member has opted in pmif and member has reached acd and acd is earlier than optindate', () => {
          const policy = {
            external: false,
            pmifDetails: {
              optInDate: '2009-08-04T16:00:00.000Z',
              lowBalanceThresholdDate: '2013-08-04T16:00:00.000Z'
            }
          };

          spyOn(panoInsurancePoliciesUtil, 'getAutomaticCoverDate').and.returnValue('2013-08-04T16:00:00.000Z');

          const result = (component as any).getAccountActivationDateFor60DaysAlert(policy);

          expect(result).toBe(policy.pmifDetails.optInDate);
        });

        it('should return pmif opt in date if member has opted in pmif and member has NOT reached automatic cover date', () => {
          const policy = {
            external: false,
            pmifDetails: {
              optInDate: '2013-08-04T16:00:00.000Z',
              lowBalanceThresholdDate: null
            }
          };

          const result = (component as any).getAccountActivationDateFor60DaysAlert(policy);

          expect(result).toBe(policy.pmifDetails.optInDate);
        });

        it('should return automatic cover date if member has NOT opted in pmif and member has reached automatic cover date', () => {
          const policy = {
            external: false,
            pmifDetails: {
              optInDate: null,
              lowBalanceThresholdDate: '2009-08-04T16:00:00.000Z'
            }
          };
          component.account.owners[0].age = 30;

          spyOn(panoInsurancePoliciesUtil, 'getAutomaticCoverDate').and.returnValue('2009-08-04T16:00:00.000Z');

          const result = (component as any).getAccountActivationDateFor60DaysAlert(policy);

          expect(result).toBe(policy.pmifDetails.lowBalanceThresholdDate);
        });

        it('should return null if member has NOT opted in pmif and member has not reached automatic cover date', () => {
          const policy = {
            external: false,
            pmifDetails: {
              optInDate: null,
              lowBalanceThresholdDate: '2009-08-04T16:00:00.000Z'
            }
          };
          component.account.owners[0].age = 24;

          spyOn(panoInsurancePoliciesUtil, 'getAutomaticCoverDate').and.returnValue(undefined);

          const result = (component as any).getAccountActivationDateFor60DaysAlert(policy);

          expect(result).toBeNull();
        });

        it('should return null if pmif Details are null', () => {
          const policy = {
            external: false
          };
          component.account.owners[0].age = 30;

          spyOn(panoInsurancePoliciesUtil, 'getAutomaticCoverDate').and.returnValue('2009-08-04T16:00:00.000Z');

          const result = (component as any).getAccountActivationDateFor60DaysAlert(policy);

          expect(result).toBeNull();
        });
      });
    });

    describe('getPMIFDetails', () => {
      it('should return pmif details', () => {
        const policy = {
          pmifDetails: {
            optInDate: '2009-08-04T16:00:00.000Z',
            lowBalanceThresholdDate: '2013-08-04T16:00:00.000Z'
          }
        };

        expect((component as any).getPMIFDetails(policy)).toBe(policy.pmifDetails);
      });
    });

    describe('showPolicyLT90DaysAlert', () => {
      beforeEach(() => {
        jasmine.clock().install();
        jasmine.clock().mockDate(new Date('2021-05-29'));
      });

      afterEach(() => {
        jasmine.clock().uninstall();
      });

      it('should return true if accounts status is pending, customerType is Retail, qulifierName is standard cover, age is LT 60 and account activation days are LT or equal to 90', () => {
        component.account = MOCK_ACCOUNT;

        const policy = {
          groupInsurance: true,
          policyType: 'DEATH',
          status: 'PROPOSAL',
          customerType: 'Retail',
          ageNextBirthday: 50,
          qualifierName: STANDARD_COVER
        };
        spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor90DaysCriteria').and.returnValue(85);

        const result = (component as any).showPolicyLT90DaysAlert(policy);

        expect(result).toBeTruthy();
      });
    });

    describe('showPmifNotActiveGT30DaysAlert', () => {
      it('should return true if automatic cover message required and not opted in', () => {
        const policy = {
          policyType: 'DEATH',
          status: 'NOT_ACTIVE',
          customerType: 'Retail',
          external: false
        };

        spyOn(panoInsurancePoliciesUtil, 'automaticCoverMessageRequired').and.returnValue(true);

        const result = (component as any).showPmifNotActiveGT30DaysAlert(policy);

        expect(result).toEqual(true);
      });

      it('should return true if automatic cover message required and opted in date less than risk commencement date', () => {
        const policy = {
          policyType: 'DEATH',
          status: 'NOT_ACTIVE',
          customerType: 'Retail',
          external: false,
          pmifDetails: {
            optInDate: '2021-02-12T14:00:00.000Z',
            lowBalanceThresholdDate: null
          },
          riskCommencementDate: '2021-03-02T14:00:00.000Z'
        };

        spyOn(panoInsurancePoliciesUtil, 'automaticCoverMessageRequired').and.returnValue(true);

        const result = (component as any).showPmifNotActiveGT30DaysAlert(policy);

        expect(result).toEqual(true);
      });

      it('should return false if not automatic cover message required', () => {
        const policy = {
          policyType: 'DEATH',
          status: 'IN_FORCE',
          customerType: 'Retail'
        };

        spyOn(panoInsurancePoliciesUtil, 'automaticCoverMessageRequired').and.returnValue(false);

        const result = (component as any).showPmifNotActiveGT30DaysAlert(policy);

        expect(result).toEqual(false);
      });
    });

    describe('showApplicableNote', () => {
      it('should return false if applicable noteID present in insurances', () => {
        const showFootNote = (component as any).showApplicableNote(MOCK_INSURANCE_DETAILS[0], 'TT1');
        expect(showFootNote).toBeFalsy();
      });

      it('should return true if applicable noteID present in insurances', () => {
        const showFootNote = (component as any).showApplicableNote(MOCK_INSURANCE_DETAILS[0], 'FN2');
        expect(showFootNote).toBeTruthy();
      });
    });

    describe('setIcon', () => {
      it('should set icon ^ when status is inactive and endDate is end of the month', () => {
        const icon = (component as any).setIcon(MOCK_ALL_POLICIES[3]);
        expect(icon).toEqual('^');
      });

      it('should set icon * when status is Pending and endDate is null', () => {
        const icon = (component as any).setIcon(MOCK_ALL_POLICIES[1]);
        expect(icon).toEqual('*');
      });
    });

    describe('setPdsLink', () => {
      it('should return the url of the PDS for this insurance policy', () => {
        linkService.getUrl = jasmine.createSpy().and.returnValue('https://hello');

        const link = (component as any).setPdsLink(MOCK_ALL_POLICIES[3]);

        expect(linkService.getUrl).toHaveBeenCalledWith(
          LinkType.PRODUCT_DISCLOSURE_STATEMENT,
          MOCK_ALL_POLICIES[3],
          component.account
        );
        expect(link).toEqual('https://hello');
      });
    });

    describe('navigateToPds', () => {
      it('should open the provided url in a new tab', () => {
        (component as any).window.open = jasmine.createSpy();

        (component as any).navigateToPds('https://pdsLink');

        expect((component as any).window.open).toHaveBeenCalledWith('https://pdsLink', '_blank');
      });
    });

    describe('setStatusLabel', () => {
      it('should set the status label as Active when status is Inactive and endDate is end of the month', () => {
        const label = (component as any).setStatusLabel(MOCK_ALL_POLICIES[2]);
        expect(label).toEqual('Active');
      });

      it('should set the status label as pending when status is PROPOSAL ', () => {
        const label = (component as any).setStatusLabel(MOCK_ALL_POLICIES[1]);
        expect(label).toEqual('Pending');
      });
    });

    describe('setOptInDateLabel', () => {
      it('should set the OptInDate label as Not opted In when the Policy is Non BYO Insurance and not opted In', () => {
        const label = (component as any).setOptInDateLabel(MOCK_ALL_POLICIES[1]);
        expect(label).toEqual(NOT_OPTED_IN);
      });

      it('should set the OptInDate label as opt In date in dd MMM yyyy format when the Policy is Non BYO Insurance and opted In', () => {
        const policy = {
          external: false,
          pysDetails: {
            optInDate: '2021-02-17T13:00:00.000Z'
          }
        };
        const label = (component as any).setOptInDateLabel(policy);
        expect(label).toEqual('18 Feb 2021');
      });

      it('should set the OptInDate label as opt In date in Not opted In  when the Policy is Non BYO and PYS opted in and it is less than risk commencement date', () => {
        const policy = {
          external: false,
          pysDetails: {
            optInDate: '2021-02-17T13:00:00.000Z'
          },
          riskCommencementDate: '2021-04-17T13:00:00.000Z'
        };
        component.isAvailableForPysOptIn = true;
        component.isAvailableForPmifPysOptIn = false;
        const label = (component as any).setOptInDateLabel(policy);
        expect(label).toEqual(NOT_OPTED_IN);
      });

      it('should set the OptInDate label as opt In date in Not opted In  when the Policy is Non BYO and PMIF_PYS opted in and it is less than risk commencement date', () => {
        const policy = {
          external: false,
          pysDetails: {
            optInDate: '2021-02-17T13:00:00.000Z'
          },
          riskCommencementDate: '2021-04-17T13:00:00.000Z'
        };
        component.isAvailableForPysOptIn = false;
        component.isAvailableForPmifPysOptIn = true;
        const label = (component as any).setOptInDateLabel(policy);
        expect(label).toEqual(NOT_OPTED_IN);
      });

      it('should set the OptInDate label as opt In date in Not opted In when not pmif permission and the Policy is Non BYO and PMIF_PYS opted in and it is less than risk commencement date', () => {
        const policy = {
          external: false,
          pysDetails: {
            optInDate: '2021-02-17T13:00:00.000Z'
          },
          riskCommencementDate: '2021-04-17T13:00:00.000Z'
        };
        component.pmifPermission = true;
        component.isAvailableForPysOptIn = false;
        component.isAvailableForPmifPysOptIn = true;
        const label = (component as any).setOptInDateLabel(policy);
        expect(label).toEqual(NOT_OPTED_IN);
      });
    });

    describe('showStatusFootNote', () => {
      it('should show status foot note if status is active', () => {
        const isStatusActive = (component as any).showStatusFootNote(MOCK_INSURANCE_DETAILS[3], '^');
        expect(isStatusActive).toBeTruthy();
      });

      it('should show status foot note if status is pending', () => {
        const isStatusPending = (component as any).showStatusFootNote(MOCK_INSURANCE_DETAILS[0], '*');
        expect(isStatusPending).toBeTruthy();
      });
    });

    describe('navigateToCancelCover', () => {
      it('should navigate to cancel cover', () => {
        const insurance = MOCK_INSURANCE_DETAILS[0].insurances[0];
        const params = {
          insurance,
          policyNumber: insurance.policyNumber
        };
        component.navigateToCancelCover(insurance);
        expect((component as any).router.stateService.go).toHaveBeenCalledWith(CANCEL_INSURANCE_STATE, params);
      });

      it('should navigate to cancel cover with param associatedTpdCovers', () => {
        const insurance = MOCK_INSURANCE_DETAILS[0].insurances[0];
        const associatedTpdCovers = [];
        const params = {
          insurance,
          associatedTpdCovers,
          policyNumber: insurance.policyNumber
        };
        component.navigateToCancelCover(insurance, associatedTpdCovers);
        expect((component as any).router.stateService.go).toHaveBeenCalledWith(CANCEL_INSURANCE_STATE, params);
      });
    });

    describe('navigateToChangeOrDecreaseCover', () => {
      it('should navigate to decrease cover', () => {
        spyOn(component as any, 'showIISCOPDecreaseMenuAction').and.returnValue(false);
        spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor90DaysCriteria').and.returnValue(95);

        component.navigateToChangeOrDecreaseCover(MOCK_INSURANCE_DETAILS[0].insurances[0], CoverMode.DECREASE);

        expect((component as any).router.stateService.go).toHaveBeenCalledWith(CHANGE_INSURANCE_STATE, {
          insurance: MOCK_INSURANCE_DETAILS[0].insurances[0],
          policyNumber: '12300',
          mode: CoverMode.DECREASE
        });
      });

      it('should navigate to decrease cover', () => {
        spyOn(component as any, 'showIISCOPDecreaseMenuAction').and.returnValue(true);
        spyOn(panoInsurancePoliciesUtil, 'getAccountActivationDaysFor90DaysCriteria').and.returnValue(25);

        component.navigateToChangeOrDecreaseCover(MOCK_INSURANCE_DETAILS[0].insurances[0], CoverMode.DECREASE);

        expect((component as any).router.stateService.go).toHaveBeenCalledWith(CHANGE_INSURANCE_STATE, {
          insurance: MOCK_INSURANCE_DETAILS[0].insurances[0],
          policyNumber: '12300',
          mode: CoverMode.DECREASE_REQUEST
        });
      });
    });
  });

  describe('view', () => {
    beforeEach(() => {
      component.insuranceDetails = MOCK_INSURANCE_DETAILS;
      component.showMenuActionPermission = true;
      fixture.detectChanges();
    });

    it('should show options button when permission is true', () => {
      fixture.detectChanges();
      const actionMenuButton = fixture.debugElement.query(By.css('.js-test-insurance-action-button'));
      expect(actionMenuButton).toBeTruthy();
      expect(actionMenuButton.query(By.css('bt-button')).properties.config).toEqual(ACTION_BUTTON);
      expect(actionMenuButton.query(By.css('mat-menu'))).toBeTruthy();
    });

    describe('Death cover table', () => {
      it('should have title', () => {
        expect(fixture.debugElement.queryAll(By.css('.js-test-insurance-title'))[0].nativeElement.innerText).toBe(
          MOCK_INSURANCE_DETAILS[0].title
        );
      });

      it('should have table headers', () => {
        const deathCoverTable = fixture.debugElement.queryAll(By.css('table'))[0];
        const tableHeaders = deathCoverTable.queryAll(By.css('th'));
        forEach(tableHeaders, (header, index) => {
          // SR label
          const expectedSrLabel =
            MOCK_INSURANCE_DETAILS[0].tableTitles[index].label || MOCK_INSURANCE_DETAILS[0].tableTitles[index].name;
          expect(header.children[0].properties.className).toBe('sr-only');
          expect(header.nativeElement.children[0].innerText).toBe(expectedSrLabel);

          // Visible text
          expect(header.children[1].properties.className).not.toBe('sr-only');
          expect(header.nativeElement.children[1].innerText).toBe(MOCK_INSURANCE_DETAILS[0].tableTitles[index].name);
        });
      });

      it('should render table data', () => {
        const deathCoverTable = fixture.debugElement.queryAll(By.css('table'))[0];
        const tableRow = deathCoverTable.queryAll(By.css('tr td'));

        expect(tableRow[0].nativeElement.innerText).toBe('test-or-dash__Employee Tailored Cover');
        expect(tableRow[1].nativeElement.innerText).toBe('test-or-dash__$7,000.00');
        expect(tableRow[3].nativeElement.innerText).toBe('You');
        expect(tableRow[4].nativeElement.innerText).toBe(MOCK_INSURANCE_DETAILS[0].insurances[0].occupationClass);
        expect(tableRow[5].nativeElement.innerText).toBe(MOCK_INSURANCE_DETAILS[0].insurances[0].optInDateLabel);
        expect(tableRow[6].nativeElement.innerText).toBe(
          MOCK_INSURANCE_DETAILS[0].insurances[0].policyStatusLabel + MOCK_INSURANCE_DETAILS[0].insurances[0].icon
        );

        component.insuranceDetails[0].insurances[0].premium = '0';
        fixture.detectChanges();
        expect(tableRow[2].nativeElement.innerText).toBe('Not applicable');

        component.insuranceDetails[0].insurances[0].premium = '1.19';
        fixture.detectChanges();
        expect(tableRow[2].nativeElement.innerText).toBe('$1.19');
      });

      it('should show action menu when button pressed', () => {
        const deathCoverTable = fixture.debugElement.queryAll(By.css('table'))[0];
        const tableRow = deathCoverTable.queryAll(By.css('tr td'));
        const actionMenuButton = tableRow[7].query(By.css('bt-button'));

        expect(actionMenuButton).toBeTruthy();
        expect(actionMenuButton.properties.config).toEqual(ACTION_BUTTON);

        actionMenuButton.nativeElement.click();
        const actionMenu = tableRow[7].query(By.css('.e2e-policy-cover-menu'));
        const accessPdsAction = actionMenu.query(By.css('.test-access-pds-action'));

        expect(accessPdsAction).toBeTruthy();
        expect(accessPdsAction.nativeElement.innerText).toBe('Access PDS');

        const cancelAction = actionMenu.query(By.css('.e2e-policy-cancel-cover-menu-action'));
        expect(cancelAction).toBeTruthy();
        expect(cancelAction.nativeElement.innerText).toBe('Cancel cover');
      });

      it('show pmif not active message', () => {
        const pmifNotActive = fixture.debugElement.query(By.css('.ts-pmif-status-warning-alert'));
        expect(pmifNotActive.properties.config).toEqual(PMIF_PENDING_STATUS_ALERT);
      });

      it('show pmif not active risk commencement less than 30 days message', () => {
        const pmifNotActiveGT30DaysAlert = fixture.debugElement.query(By.css('.ts-pmif-gt-30-warning-alert'));
        expect(pmifNotActiveGT30DaysAlert.properties.config).toEqual(PMIF_NOT_ACTIVE_GT_30_DAYS_ALERT);
      });

      it('should show 60 days alert message', () => {
        component.insuranceDetails = [MOCK_60_90_DAYS_INSURANCE_DETAIL];
        fixture.detectChanges();
        const el60DaysAlert = fixture.debugElement.query(By.css('.ts-60-day-alert'));
        expect(el60DaysAlert.properties.config).toEqual(POLICY_GT_60_DAYS_ALERT);
      });

      it('should show 90 days alert message', () => {
        component.insuranceDetails = [MOCK_60_90_DAYS_INSURANCE_DETAIL];
        fixture.detectChanges();
        const el90DaysAlert = fixture.debugElement.query(By.css('.ts-90-day-alert'));
        expect(el90DaysAlert.properties.config).toEqual(POLICY_LT_90_DAYS_ALERT);
      });

      it('should show no occupation code table inline alert message', () => {
        component.insuranceDetails = [MOCK_NO_OCCUPATION_CODE_INSURANCE_DETAIL];
        fixture.detectChanges();
        const elNoOccupationsAlert = fixture.debugElement.query(By.css('.ts-no-occupation-alert'));
        expect(elNoOccupationsAlert.properties.config).toEqual(NO_OCCUPATION_CODE_INLINE_ALERT);
      });

      it('should render correct total cover amount and premium amount', () => {
        component.insuranceDetails = MOCK_INSURANCE_DETAIL_FOR_TOTAL_ROW;
        fixture.detectChanges();
        const deathCoverTable = fixture.debugElement.queryAll(By.css('table'))[0];
        const tableRow = deathCoverTable.queryAll(By.css('tfoot tr td'));
        expect(tableRow[1].nativeElement.innerText).toBe('$1,076.00');
        expect(tableRow[2].nativeElement.innerText).toBe('Not applicable');
      });
    });

    describe('TPD table', () => {
      it('should have title', () => {
        expect(fixture.debugElement.queryAll(By.css('.js-test-insurance-title'))[1].nativeElement.innerText).toBe(
          MOCK_INSURANCE_DETAILS[1].title
        );
      });

      it('should have table headers', () => {
        const tpdTable = fixture.debugElement.queryAll(By.css('table'))[1];
        const tableHeaders = tpdTable.queryAll(By.css('th'));
        forEach(tableHeaders, (header, index) => {
          // SR label
          const expectedSrLabel =
            MOCK_INSURANCE_DETAILS[1].tableTitles[index].label || MOCK_INSURANCE_DETAILS[1].tableTitles[index].name;
          expect(header.children[0].properties.className).toBe('sr-only');
          expect(header.nativeElement.children[0].innerText).toBe(expectedSrLabel);

          // Visible text
          expect(header.children[1].properties.className).not.toBe('sr-only');
          expect(header.nativeElement.children[1].innerText).toBe(MOCK_INSURANCE_DETAILS[1].tableTitles[index].name);
        });
      });

      it('should render table data', () => {
        const tpdTable = fixture.debugElement.queryAll(By.css('table'))[1];
        const tableRow = tpdTable.queryAll(By.css('tr td'));

        expect(tableRow[0].nativeElement.innerText).toBe('test-or-dash__Employer Cover');
        expect(tableRow[1].nativeElement.innerText).toBe('test-or-dash__$7,000.00');
        expect(tableRow[3].nativeElement.innerText).toBe(MOCK_INSURANCE_DETAILS[1].insurances[0].occupationClass);
        expect(tableRow[4].nativeElement.innerText).toBe(NOT_OPTED_IN);
        expect(tableRow[5].nativeElement.innerText).toBe('Active');

        component.insuranceDetails[1].insurances[0].premium = '0';
        fixture.detectChanges();
        expect(tableRow[2].nativeElement.innerText).toBe('Not applicable');

        component.insuranceDetails[1].insurances[0].premium = '1.19';
        fixture.detectChanges();
        expect(tableRow[2].nativeElement.innerText).toBe('$1.19');
      });

      it('should show action menu when button pressed', () => {
        const tpdTable = fixture.debugElement.queryAll(By.css('table'))[1];
        const tableRow = tpdTable.queryAll(By.css('tr td'));
        const actionMenuButton = tableRow[6].query(By.css('bt-button'));

        expect(actionMenuButton).toBeTruthy();
        expect(actionMenuButton.properties.config).toEqual(ACTION_BUTTON);

        actionMenuButton.nativeElement.click();
        const actionMenu = tableRow[6].query(By.css('.e2e-policy-cover-menu'));
        const accessPdsAction = actionMenu.query(By.css('.test-access-pds-action'));

        expect(accessPdsAction).toBeTruthy();
        expect(accessPdsAction.nativeElement.innerText).toBe('Access PDS');
      });

      it('should not show cancel action menu when button pressed', () => {
        const tpdTable = fixture.debugElement.queryAll(By.css('table'))[1];
        const tableRow = tpdTable.queryAll(By.css('tr td'));
        const actionMenuButton = tableRow[6].query(By.css('bt-button'));

        expect(actionMenuButton).toBeTruthy();
        expect(actionMenuButton.properties.config).toEqual(ACTION_BUTTON);

        actionMenuButton.nativeElement.click();
        const actionMenu = tableRow[6].query(By.css('.e2e-policy-cover-menu'));
        const cancelAction = actionMenu.query(By.css('.e2e-policy-cancel-cover-menu-action'));

        expect(cancelAction).toBeNull();
      });
    });

    describe('Death and TPD table', () => {
      it('should have title', () => {
        expect(fixture.debugElement.queryAll(By.css('.js-test-insurance-title'))[2].nativeElement.innerText).toBe(
          MOCK_INSURANCE_DETAILS[2].title
        );
      });

      it('should have table headers', () => {
        const deathTpdTable = fixture.debugElement.queryAll(By.css('table'))[2];
        const tableHeaders = deathTpdTable.queryAll(By.css('th'));
        forEach(tableHeaders, (header, index) => {
          // SR label
          const expectedSrLabel =
            MOCK_INSURANCE_DETAILS[2].tableTitles[index].label || MOCK_INSURANCE_DETAILS[2].tableTitles[index].name;
          expect(header.children[0].properties.className).toBe('sr-only');
          expect(header.nativeElement.children[0].innerText).toBe(expectedSrLabel);

          // Visible text
          expect(header.children[1].properties.className).not.toBe('sr-only');
          expect(header.nativeElement.children[1].innerText).toBe(MOCK_INSURANCE_DETAILS[2].tableTitles[index].name);
        });
      });

      it('should render table data', () => {
        const deathTpdTable = fixture.debugElement.queryAll(By.css('table'))[2];
        const tableRow = deathTpdTable.queryAll(By.css('tr td'));

        expect(tableRow[0].nativeElement.innerText).toBe('test-or-dash__Standard Cover');
        expect(tableRow[1].nativeElement.innerText).toBe('test-or-dash__$24,500.00');
        expect(tableRow[3].nativeElement.innerText).toBe('You');
        expect(tableRow[4].nativeElement.innerText).toBe(MOCK_INSURANCE_DETAILS[2].insurances[0].occupationClass);
        expect(tableRow[5].nativeElement.innerText).toBe('Not opted in');
        expect(tableRow[6].nativeElement.innerText).toBe(
          MOCK_INSURANCE_DETAILS[2].insurances[0].policyStatusLabel + MOCK_INSURANCE_DETAILS[3].insurances[0].icon
        );

        component.insuranceDetails[2].insurances[0].premium = '0';
        fixture.detectChanges();
        expect(tableRow[2].nativeElement.innerText).toBe('Not applicable');

        component.insuranceDetails[2].insurances[0].premium = '21.78';
        fixture.detectChanges();
        expect(tableRow[2].nativeElement.innerText).toBe('$21.78');
      });

      it('should show action menu when button pressed', () => {
        const deathTpdTable = fixture.debugElement.queryAll(By.css('table'))[2];
        const tableRow = deathTpdTable.queryAll(By.css('tr td'));
        const actionMenuButton = tableRow[7].query(By.css('bt-button'));

        expect(actionMenuButton).toBeTruthy();
        expect(actionMenuButton.properties.config).toEqual(ACTION_BUTTON);

        actionMenuButton.nativeElement.click();
        const actionMenu = tableRow[7].query(By.css('.e2e-policy-cover-menu'));
        const accessPdsAction = actionMenu.query(By.css('.test-access-pds-action'));

        expect(accessPdsAction).toBeTruthy();
        expect(accessPdsAction.nativeElement.innerText).toBe('Access PDS');
      });

      it('should not show total row when cover amount and premium are zero', () => {
        expect(fixture.debugElement.queryAll(By.css('.ts-total-row'))[2]).toBeFalsy();
      });
    });

    describe('Income Protection table', () => {
      it('should have title', () => {
        expect(fixture.debugElement.queryAll(By.css('.js-test-insurance-title'))[3].nativeElement.innerText).toBe(
          MOCK_INSURANCE_DETAILS[3].title
        );
      });

      it('should have table headers', () => {
        const incomeProtectionTable = fixture.debugElement.queryAll(By.css('table'))[3];
        const tableHeaders = incomeProtectionTable.queryAll(By.css('th'));
        forEach(tableHeaders, (header, index) => {
          // SR label
          const expectedSrLabel =
            MOCK_INSURANCE_DETAILS[3].tableTitles[index].label || MOCK_INSURANCE_DETAILS[3].tableTitles[index].name;
          expect(header.children[0].properties.className).toBe('sr-only');
          expect(header.nativeElement.children[0].innerText).toBe(expectedSrLabel);

          // Visible text
          expect(header.children[1].properties.className).not.toBe('sr-only');
          expect(header.nativeElement.children[1].innerText).toBe(MOCK_INSURANCE_DETAILS[3].tableTitles[index].name);
        });
      });

      it('should render table data', () => {
        const incomeProtectionTable = fixture.debugElement.queryAll(By.css('table'))[3];
        const tableRow = incomeProtectionTable.queryAll(By.css('tr td'));

        expect(tableRow[0].nativeElement.innerText).toBe('test-or-dash__Employee Salary Continuance Insurance');
        expect(tableRow[1].nativeElement.innerText).toBe('test-or-dash__90 days');
        expect(tableRow[2].nativeElement.innerText).toBe('test-or-dash__2 years');
        expect(tableRow[3].nativeElement.innerText).toContain('test-or-dash__$6,000.00');
        expect(tableRow[3].nativeElement.innerText).toContain('per month');
        expect(tableRow[4].nativeElement.innerText).toBe('$30.00');
        expect(tableRow[5].nativeElement.innerText).toBe('Not applicable');
        expect(tableRow[6].nativeElement.innerText).toBe(MOCK_INSURANCE_DETAILS[3].insurances[0].smokerStatus);
        expect(tableRow[7].nativeElement.innerText).toBe('Not opted in');
        expect(tableRow[8].nativeElement.innerText).toBe(
          MOCK_INSURANCE_DETAILS[3].insurances[0].policyStatusLabel + MOCK_INSURANCE_DETAILS[3].insurances[0].icon
        );
      });

      it('should show action menu when button pressed', () => {
        const incomeProtectionTable = fixture.debugElement.queryAll(By.css('table'))[3];
        const tableRow = incomeProtectionTable.queryAll(By.css('tr td'));
        const actionMenuButton = tableRow[9].query(By.css('bt-button'));

        expect(actionMenuButton).toBeTruthy();
        expect(actionMenuButton.properties.config).toEqual(ACTION_BUTTON);

        actionMenuButton.nativeElement.click();
        const actionMenu = tableRow[9].query(By.css('.e2e-policy-cover-menu'));
        const accessPdsAction = actionMenu.query(By.css('.test-access-pds-action'));

        expect(accessPdsAction).toBeTruthy();
        expect(accessPdsAction.nativeElement.innerText).toBe('Access PDS');
      });
    });

    describe('alert with pending policies', () => {
      it('should show the alert box whenever there are pending policies', () => {
        component.pendingPolicies = [MOCK_ALL_POLICIES[2]];
        fixture.detectChanges();
        const alert = fixture.debugElement.query(By.css('.ts-pending-policy-info'));
        expect(alert).toBeTruthy();
        expect(alert.nativeElement.innerText).toContain('TPD Employer Cover of $7,000.00');
      });
    });

    describe('foot note below table', () => {
      it('show pending cover message', () => {
        expect(fixture.debugElement.query(By.css('.js-test-pending-cover-message')).nativeElement.innerText).toBe(
          PENDING_FOOTNOTE
        );
      });

      it('show inactive cover message', () => {
        expect(fixture.debugElement.query(By.css('.js-test-inactive-cover-message')).nativeElement.innerText).toBe(
          INACTIVE_FOOTNOTE
        );
      });

      it('show death message', () => {
        const deathAlert = fixture.debugElement.query(By.css('.js-test-death-foot-alert'));
        expect(deathAlert.properties.config).toEqual(BASIC_ALERT);
        expect(deathAlert.nativeElement.innerText).toBe('test-copy-matrix__Ins-IP-1076');
      });

      it('show lifetime message', () => {
        const lifetimeAlert = fixture.debugElement.query(By.css('.js-test-insurance-foot-alert'));
        expect(lifetimeAlert.properties.config).toEqual(BASIC_ALERT);
        expect(lifetimeAlert.nativeElement.innerText).toBe('test-copy-matrix__Ins-IP-0657');
      });
    });
  });
});
