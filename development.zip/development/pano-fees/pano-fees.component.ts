import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { Alert } from '@bt/components/alert';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Tooltip } from '@bt/components/tooltip';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';
import { StateParams } from '@upgrade/upgrade.services';
import { first, get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { finalize, take } from 'rxjs/operators';

import {
  ADMINISTRATION_FEE_TOOLTIP,
  ADMIN_FEE,
  BUY_SELL_SPREAD,
  BUY_SELL_SPREADS_LINK_NO_ICON,
  BUY_SELL_SPREADS_TOOLTIP,
  BUY_SELL_SPREAD_INFO,
  EXAMPLE_ADMIN_FEE,
  EXAMPLE_ADMIN_RATE,
  EXAMPLE_DESCRIPTION,
  EXAMPLE_FOOTNOTE,
  EXAMPLE_INDIRECT_COST_RATE,
  EXAMPLE_INDIRECT_COST_RATIO,
  EXAMPLE_INVESTMENT_FEE,
  EXAMPLE_INVESTMENT_RATE,
  EXAMPLE_TOTAL_COST,
  EXAMPLE_TOTAL_RATE,
  FEES_DESCRIPTION,
  GENERIC_ERROR_ALERT,
  INDIRECT_COST_RATIO,
  INDIRECT_COST_RATIO_TOOLTIP,
  INVESTMENT_FEE,
  INVESTMENT_FEE_TOOLTIP,
  LEGACY_ADMIN_FEE,
  LIFESTAGE_INVESTMENT_INFO,
  LOADING_SPINNER,
  NEW_WINDOW_ICON,
  ONGOING_FEES_LINK_NO_ICON,
  ONGOING_INVESTMENT_INFO,
  RETAIL,
  TOOLTIP_ADMIN_FEE,
  TOOLTIP_BUY_SELL_SPREAD,
  TOOLTIP_INDIRECT_COST_RATIO,
  TOOLTIP_INVESTMENT_FEE,
  WGP,
  WGP_LSEP_COHORT,
  WGP_PLUM_COHORT,
  WGP_WSSP_COHORT
} from './pano-fees.constants';
import { AemContent, AemFragment } from './pano-fees.interface';
import { PanoFeesService } from './pano-fees.service';

@Component({
  selector: 'pano-fees',
  templateUrl: './pano-fees.component.html',
  styleUrls: ['./pano-fees.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PanoFeesComponent implements OnInit {
  @Input() account: Account;

  loading: boolean = true;
  error: boolean = false;

  date: moment;
  disclaimer: string;

  accountId: string;

  navigationLinks: Link[];

  ongoingFeesLinkNoIcon: Link = ONGOING_FEES_LINK_NO_ICON;
  buySellSpreadLinkNoIcon: Link = BUY_SELL_SPREADS_LINK_NO_ICON;

  readonly newWindowIcon: Icon = NEW_WINDOW_ICON;

  adminFeeTooltip: Tooltip = ADMINISTRATION_FEE_TOOLTIP;
  investmentFeeTooltip: Tooltip = INVESTMENT_FEE_TOOLTIP;
  indirectCostRatioTooltip: Tooltip = INDIRECT_COST_RATIO_TOOLTIP;
  buySellSpreadTooltip: Tooltip = BUY_SELL_SPREADS_TOOLTIP;

  readonly loadingSpinner: Loading = LOADING_SPINNER;
  readonly errorAlert: Alert = GENERIC_ERROR_ALERT;

  isLegacyWgp: boolean;
  isRetail: boolean;

  // cmsContent
  feesDescription: string;

  adminFee: string;
  investmentFee: string;
  indirectCostRatio: string;
  buySellSpread: string;

  ongoingInvestmentInfo: string;
  lifestageInvestmentInfo: string;
  legacyAdminFeeInfo: string;
  buySellSpreadInfo: string;

  exampleDescription: string;
  exampleFootnote: string;

  exampleAdminRate: string;
  exampleAdminFee: string;
  exampleInvestmentRate: string;
  exampleInvestmentFee: string;
  exampleIndirectCostRate: string;
  exampleIndirectCostRatio: string;
  exampleTotalRate: string;
  exampleTotalCost: string;

  constructor(
    private service: PanoFeesService,
    private disclaimerService: PanoDisclaimersService,
    private superLinkService: PanoSuperLinkService,
    private stateParams: StateParams
  ) {}

  ngOnInit(): void {
    this.date = moment(new Date()).format('D MMM YYYY');
    this.disclaimer = this.disclaimerService.evaluateDisclaimer(this.account);

    this.configureAccountState();
    this.configureNavigationLinks();
    this.loadContent();
  }

  private configureAccountState(): void {
    this.isRetail = this.account.heritageCohort === RETAIL;
    this.isLegacyWgp =
      this.account.heritageCohort === WGP_PLUM_COHORT ||
      this.account.heritageCohort === WGP_LSEP_COHORT ||
      this.account.heritageCohort === WGP_WSSP_COHORT;
  }

  private configureNavigationLinks(): void {
    const accountId = this.stateParams.accountId;
    this.navigationLinks = this.superLinkService.getLinks(
      [
        LinkType.PRODUCT_DISCLOSURE_STATEMENT,
        LinkType.ADDITIONAL_INFORMATION_BOOKLET,
        LinkType.PRODUCT_UPDATES,
        LinkType.INVESTMENT_FEES,
        LinkType.BUY_SELL_SPREADS
      ],
      accountId,
      this.account
    );

    this.ongoingFeesLinkNoIcon.link = this.superLinkService.getUrl(LinkType.INVESTMENT_FEES, accountId, this.account);
    if (!this.ongoingFeesLinkNoIcon.link) {
      this.ongoingFeesLinkNoIcon.link = this.superLinkService.getUrl(
        LinkType.PUBLIC_INVESTMENT_FEES,
        accountId,
        this.account
      );
      this.ongoingFeesLinkNoIcon.openNewTab = true;
    }

    this.buySellSpreadLinkNoIcon.link = this.superLinkService.getUrl(
      LinkType.BUY_SELL_SPREADS,
      accountId,
      this.account
    );
  }

  private loadContent() {
    this.service
      .getAemContent()
      .pipe(finalize(() => (this.loading = false)))
      .pipe(take(1))
      .subscribe(
        (res: AemContent) => {
          this.mapContent(res.details);
        },
        () => {
          this.error = true;
        }
      );
  }

  private mapContent(res: AemFragment[]) {
    const accountType: string = this.isWgp() ? WGP : RETAIL;

    // fees section content
    this.feesDescription = this.findContentByKey(res, FEES_DESCRIPTION);

    this.adminFee = this.findContentByKey(res, ADMIN_FEE[accountType]);
    this.investmentFee = this.findContentByKey(res, INVESTMENT_FEE[accountType]);
    this.indirectCostRatio = this.findContentByKey(res, INDIRECT_COST_RATIO[accountType]);
    this.buySellSpread = this.findContentByKey(res, BUY_SELL_SPREAD[accountType]);

    this.adminFeeTooltip.message = this.findContentByKey(res, TOOLTIP_ADMIN_FEE);
    this.investmentFeeTooltip.message = this.findContentByKey(res, TOOLTIP_INVESTMENT_FEE);
    this.indirectCostRatioTooltip.message = this.findContentByKey(res, TOOLTIP_INDIRECT_COST_RATIO);
    this.buySellSpreadTooltip.message = this.findContentByKey(res, TOOLTIP_BUY_SELL_SPREAD);

    this.ongoingInvestmentInfo = this.findContentByKey(res, ONGOING_INVESTMENT_INFO);
    this.lifestageInvestmentInfo = this.findContentByKey(res, LIFESTAGE_INVESTMENT_INFO);
    this.legacyAdminFeeInfo = this.findContentByKey(res, LEGACY_ADMIN_FEE);
    this.buySellSpreadInfo = this.findContentByKey(res, BUY_SELL_SPREAD_INFO);

    // example fees section content
    this.exampleDescription = this.findContentByKey(res, EXAMPLE_DESCRIPTION);
    this.exampleFootnote = this.findContentByKey(res, EXAMPLE_FOOTNOTE);

    this.exampleAdminRate = this.findContentByKey(res, EXAMPLE_ADMIN_RATE[accountType]);
    this.exampleAdminFee = this.findContentByKey(res, EXAMPLE_ADMIN_FEE[accountType]);
    this.exampleInvestmentRate = this.findContentByKey(res, EXAMPLE_INVESTMENT_RATE[accountType]);
    this.exampleInvestmentFee = this.findContentByKey(res, EXAMPLE_INVESTMENT_FEE[accountType]);
    this.exampleIndirectCostRate = this.findContentByKey(res, EXAMPLE_INDIRECT_COST_RATE[accountType]);
    this.exampleIndirectCostRatio = this.findContentByKey(res, EXAMPLE_INDIRECT_COST_RATIO[accountType]);
    this.exampleTotalRate = this.findContentByKey(res, EXAMPLE_TOTAL_RATE[accountType]);
    this.exampleTotalCost = this.findContentByKey(res, EXAMPLE_TOTAL_COST[accountType]);
  }

  private isWgp(): boolean {
    return this.account.pdsStatus === 'WGP_CURRENT' || this.account.pdsStatus === 'WGP_CEASED';
  }

  private findContentByKey(cms: AemFragment[], fragmentId: string): string {
    return get(
      first(cms.filter((item: AemFragment) => get(item, 'data.headerText') === fragmentId)),
      'data.description'
    );
  }
}
