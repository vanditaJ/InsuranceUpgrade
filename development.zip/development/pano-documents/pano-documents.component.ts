import { Component, Input, OnInit } from '@angular/core';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

@Component({
  selector: 'pano-documents',
  templateUrl: './pano-documents.component.html'
})
export class PanoDocumentsComponent implements OnInit {
  @Input()
  account: Account;

  accountId: string;

  constructor(private accountService: PanoUpgradeAccountService) {}

  ngOnInit(): void {
    this.accountId = this.accountService.getAccountId();
  }
}
