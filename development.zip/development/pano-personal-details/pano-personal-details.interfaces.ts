export interface PersonalDetailsPermissions {
  hasWestpacLive: boolean;
  emulating: boolean;
  addessUpdate: boolean;
  primaryEmailUpdate: boolean;
  additionalContactUpdate: boolean;
  additionalContactDetailsView: boolean;
  userNameUpdate: boolean;
  passwordUpdate: boolean;
}
