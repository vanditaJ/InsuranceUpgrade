import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

import { PanoInvestmentOverviewInfoDialogComponent } from './pano-investment-overview-info-dialog.component';

describe('PanoInvestmentOverviewInfoDialogComponent', () => {
  let component: PanoInvestmentOverviewInfoDialogComponent;
  let fixture: ComponentFixture<PanoInvestmentOverviewInfoDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInvestmentOverviewInfoDialogComponent],
        providers: [
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          {
            provide: MAT_DIALOG_DATA,
            useValue: {
              headerText: 'header text',
              bodyText: 'body text'
            }
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [PanoInvestmentOverviewInfoDialogComponent]
        }
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentOverviewInfoDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('closeDialog()', () => {
      it('should call dialog close method', () => {
        component.close();
        expect((component as any).dialogRef.close).toHaveBeenCalled();
      });
    });
  });

  describe('view', () => {
    it('should have correct header', () => {
      expect(fixture.debugElement.query(By.css('.ts-test-info-dialog-header')).nativeElement.innerHTML.trim()).toBe(
        'header text'
      );
    });

    it('should have correct sub heading', () => {
      expect(fixture.debugElement.query(By.css('.ts-test-info-dialog-body')).nativeElement.innerHTML.trim()).toBe(
        'body text'
      );
    });

    describe('bt-buttons', () => {
      it('should call correct method when exit/top-right button clicked', () => {
        spyOn(component, 'close');
        fixture.debugElement
          .query(By.css('.ts-test-info-dialog-exit'))
          .nativeElement.dispatchEvent(new Event('btClick', null));

        expect(component.close).toHaveBeenCalled();
      });

      it('should call correct method when close button clicked', () => {
        spyOn(component, 'close');
        fixture.debugElement
          .query(By.css('.ts-test-info-dialog-close'))
          .nativeElement.dispatchEvent(new Event('btClick', null));

        expect(component.close).toHaveBeenCalled();
      });
    });
  });
});
