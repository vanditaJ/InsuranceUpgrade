import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { AemContent } from '@panorama/services/cms';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { find, get } from 'lodash-es';
import * as moment from 'moment-timezone';
import { PageScrollService } from 'ngx-page-scroll-core';

import { ChangeCoverMode } from '../pano-change-cover-insurance/pano-change-cover-insurance.interface';
import { CHANGE_INSURANCE_STATE } from '../pano-insurance-policies/pano-insurance-tables/pano-insurance-tables.component.constants';
import { COVER_LEVEL, OUTLINE_WARNING_ALERT, RETAIL } from '../pano-insurance.constants';
import { findContentByKey } from '../pano-insurance.helper';
import { InsurancePolicy, PolicyStatus, PolicyTitleMap, PolicyType } from '../pano-insurance.interface';
import { PanoInsuranceService } from '../pano-insurance.service';
import { PanoInsuranceUtil } from '../pano-insurance.util';

import {
  BENEFIT_FREQUENCY,
  CANCELLED_DISPLAY_STATUS,
  CANCEL_ACTIVE_COVER_CONFIRM_AEM_KEY,
  CANCEL_ACTIVE_COVER_INFO_AEM_KEY,
  CANCEL_ACTIVE_COVER_TERMS_AEM_KEY,
  CANCEL_COVER_OVER_60_CANCEL_MESSAGE_AEM_KEY,
  CANCEL_PENDING_COVER_CONFIRM_AEM_KEY,
  CANCEL_PENDING_COVER_INFO_AEM_KEY,
  CANCEL_PENDING_COVER_TERMS_AEM_KEY,
  CANCEL_REVIEW_FORM_BUTTON,
  CHANGE_COVER_INSTEAD_MESSAGE,
  DEATH_TPD_PARTIAL_SUBMIT_AEM_KEY,
  DECREASE_COVER_INSTEAD_MESSAGE,
  POLICY_TITLE,
  REDUCE_COVER_INFO_ALERT,
  REDUCE_COVER_INSTEAD_MESSAGE,
  RETURN_INSURANCE_OVERVIEW,
  REVIEW_FORM_BUTTON,
  SUBMIT_ERROR_ALERT,
  SUCCESS_CANCEL_INSURANCE,
  TPD_CANCEL_WARNING_DEATH_TPD_AEM_KEY
} from './pano-cancel-insurance.constant';

@Component({
  selector: 'pano-cancel-insurance',
  templateUrl: './pano-cancel-insurance.component.html'
})
export class PanoCancelInsuranceComponent implements OnInit {
  @Input() account: Account;
  @Input() cmsContent: AemContent[];

  @ViewChild('mainHeader', { static: true, read: ElementRef }) mainHeader: ElementRef;

  insurance: InsurancePolicy;
  associatedTpdCovers: InsurancePolicy[];
  inProgress: boolean;
  submitError: boolean = false;
  partialSubmit: boolean = false;
  submittedPolicies: InsurancePolicy[] = [];
  showDecreaseCoverInsteadInfo: boolean = false;
  showChangeCoverInsteadInfo: boolean = false;
  state: string;
  infoAemMessage: string;
  termsAemMessage: string;
  confirmAemMessage: string;
  disclaimer: string;
  date: moment;
  cancelDeathTpdAemMessage: string;
  partialCancelAemMessage: string;
  cancelCoverOver60AemMessage: string;
  canCancelCoverOver60: boolean = false;

  readonly successCancelInsurance: Alert = SUCCESS_CANCEL_INSURANCE;
  readonly reviewFormButton: Button = REVIEW_FORM_BUTTON;
  readonly cancelReviewFormButton: Button = CANCEL_REVIEW_FORM_BUTTON;
  readonly returnInsuranceOverviewButton: Button = RETURN_INSURANCE_OVERVIEW;
  readonly reduceCoverInfoAlert: Alert = REDUCE_COVER_INFO_ALERT;
  readonly reduceCoverInsteadMessage: string = REDUCE_COVER_INSTEAD_MESSAGE;
  readonly decreaseCoverInsteadMessage: string = DECREASE_COVER_INSTEAD_MESSAGE;
  readonly changeCoverInsteadMessage: string = CHANGE_COVER_INSTEAD_MESSAGE;
  readonly submitErrorAlert: Alert = SUBMIT_ERROR_ALERT;
  readonly policyTitleMap: PolicyTitleMap[] = POLICY_TITLE;
  readonly benefitFrequency = BENEFIT_FREQUENCY;
  readonly status: string = CANCELLED_DISPLAY_STATUS;
  readonly policyType = PolicyType;
  readonly employerPaidAlert: Alert = OUTLINE_WARNING_ALERT;
  readonly cancelDeathTpdAlert: Alert = OUTLINE_WARNING_ALERT;
  readonly partialCancelAlert: Alert = OUTLINE_WARNING_ALERT;
  readonly cancelCoverOver60CancelMessageAlert: Alert = OUTLINE_WARNING_ALERT;

  constructor(
    private uiRouter: UIRouter,
    private insuranceService: PanoInsuranceService,
    private accountService: PanoUpgradeAccountService,
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: HTMLDocument,
    private panoInsuranceUtil: PanoInsuranceUtil,
    private readonly disclaimerService: PanoDisclaimersService
  ) {}

  ngOnInit(): void {
    this.date = moment(new Date()).format('D MMM YYYY');
    this.disclaimer = this.disclaimerService.evaluateDisclaimer(this.account);

    this.insuranceService.getInsurance().subscribe(insurance => {
      this.insurance = insurance;
      this.insurance.policyName = find(
        this.policyTitleMap,
        (titleMap: PolicyTitleMap) => titleMap.type === this.insurance.policyType
      ).title;
      this.insurance.benefitFrequencyLabel = find(
        this.benefitFrequency,
        freq => freq.type === this.insurance.personBenefitDetails[0].benefits[0].benefits[0].frequency
      ).name;
      this.canCancelCoverOver60 = this.insurance.ageNextBirthday >= 60;
      this.showChangeDecreaseMsgForCancel(this.insurance, this.account);
      this.setAemMessages();
    });

    this.insuranceService.getAssociatedTpdCovers().subscribe(associatedTpdCovers => {
      associatedTpdCovers.forEach((cover: InsurancePolicy) => {
        cover.policyName = find(
          this.policyTitleMap,
          (titleMap: PolicyTitleMap) => titleMap.type === cover.policyType
        ).title;
      });

      this.associatedTpdCovers = associatedTpdCovers;
    });
  }

  showChangeDecreaseMsgForCancel(policy: InsurancePolicy, account: Account): void {
    const customised = get(policy, 'customised');
    const policyType = get(policy, 'policyType');
    const age = get(policy, 'ageNextBirthday');
    const customerType = get(policy, 'customerType');
    const status = get(policy, 'status');
    if (
      !customised &&
      customerType === RETAIL &&
      age < 60 &&
      (status === PolicyStatus.ACTIVE || status === PolicyStatus.PENDING)
    ) {
      const accountActivationDays = this.panoInsuranceUtil.getAccountActivationDaysFor90DaysCriteria(policy, account);
      if (accountActivationDays <= 90) {
        this.showChangeCoverInsteadInfo = true;
      } else if (
        accountActivationDays > 90 &&
        ((policyType === PolicyType.DEATH && get(policy, 'coverLevel') !== COVER_LEVEL.Single) ||
          policyType === PolicyType.DEATH_AND_TPD)
      ) {
        this.showDecreaseCoverInsteadInfo = true;
      }
    }
  }

  setAemMessages(): void {
    this.cancelDeathTpdAemMessage = findContentByKey(this.cmsContent, TPD_CANCEL_WARNING_DEATH_TPD_AEM_KEY);
    this.partialCancelAemMessage = findContentByKey(this.cmsContent, DEATH_TPD_PARTIAL_SUBMIT_AEM_KEY);
    this.cancelCoverOver60AemMessage = findContentByKey(this.cmsContent, CANCEL_COVER_OVER_60_CANCEL_MESSAGE_AEM_KEY);
    if (this.insurance.status === PolicyStatus.ACTIVE) {
      this.infoAemMessage = findContentByKey(this.cmsContent, CANCEL_ACTIVE_COVER_INFO_AEM_KEY);
      this.termsAemMessage = findContentByKey(this.cmsContent, CANCEL_ACTIVE_COVER_TERMS_AEM_KEY);
      this.confirmAemMessage = findContentByKey(this.cmsContent, CANCEL_ACTIVE_COVER_CONFIRM_AEM_KEY);
    } else {
      this.infoAemMessage = findContentByKey(this.cmsContent, CANCEL_PENDING_COVER_INFO_AEM_KEY);
      this.termsAemMessage = findContentByKey(this.cmsContent, CANCEL_PENDING_COVER_TERMS_AEM_KEY);
      this.confirmAemMessage = findContentByKey(this.cmsContent, CANCEL_PENDING_COVER_CONFIRM_AEM_KEY);
    }
  }

  submitReviewForm(): void {
    this.inProgress = true;
    this.submitError = false;
    this.partialSubmit = false;
    const policiesToSubmit = [this.insurance, ...this.associatedTpdCovers];
    this.submitPolicies(policiesToSubmit);
  }

  submitPolicies(policies: InsurancePolicy[]): void {
    const policy: InsurancePolicy = policies.pop();
    this.insuranceService.submitCancelInsurance(this.accountService.getAccountId(), policy.policyNumber).subscribe(
      () => {
        this.submittedPolicies.unshift(policy);
        if (policies.length > 0) {
          this.submitPolicies(policies);
        } else {
          // if this is the last submit then set in progress to false and show confirmation
          this.state = 'confirmation';
          this.finaliseSubmit();
        }
      },
      () => {
        if (this.submittedPolicies.length > 0) {
          // if at least one policy has been submitted then set in progress to false and show partial success message
          this.partialSubmit = true;
          this.state = 'confirmation';
        } else {
          // if this is the first submit then set in progress to false and show failure message
          this.submitError = true;
        }
        this.finaliseSubmit();
      }
    );
  }

  finaliseSubmit(): void {
    this.inProgress = false;

    this.pageScrollService.scroll({
      document: this.document,
      scrollTarget: '.top-scroll',
      scrollViews: [this.document.querySelector('.layout-scroll')],
      duration: 200
    });

    // Focus stays at the bottom when the confirmation container is switched in. Move it back to the top manually
    this.mainHeader.nativeElement.focus();
  }

  navigateToOverview(): void {
    this.uiRouter.stateService.go('app.investor.account.insurancePolicies', {}, { reload: true });
  }

  navigateToChangeOrDecreaseCover(mode: ChangeCoverMode): void {
    this.uiRouter.stateService.go(CHANGE_INSURANCE_STATE, {
      insurance: this.insurance,
      policyNumber: this.insurance.policyNumber,
      mode
    });
  }
}
