import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';

import { PanoInvestmentPreferenceDialogComponent } from './pano-pref-dialog.component';

describe('PanoInvestmentPreferenceDialogComponent', () => {
  let component: PanoInvestmentPreferenceDialogComponent;
  let fixture: ComponentFixture<PanoInvestmentPreferenceDialogComponent>;
  const title = 'title text';
  const description = 'description text';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PanoInvestmentPreferenceDialogComponent],
      imports: [MatDialogModule],
      providers: [
        { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {
            title,
            description
          }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentPreferenceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('closeDialog()', () => {
      it('should call dialog close method', () => {
        component.closeDialog();
        expect((component as any).dialogRef.close).toHaveBeenCalled();
      });
    });
  });

  describe('View', () => {
    it('should have correct title', () => {
      expect(fixture.debugElement.query(By.css('.js-test-pano-pref-dialog-title')).nativeElement.innerHTML.trim()).toBe(
        title
      );
    });

    it('should have correct content', () => {
      expect(
        fixture.debugElement.query(By.css('.js-test-pano-pref-dialog-description')).nativeElement.innerHTML.trim()
      ).toBe(description);
    });

    describe('close button', () => {
      it('should have correct properties', () => {
        expect(fixture.debugElement.query(By.css('.js-test-close-button')).properties.config).toEqual(
          component.closeButton
        );
      });

      it('should call correct method when cancel button clicked', () => {
        spyOn(component, 'closeDialog');
        fixture.debugElement.query(By.css('bt-button')).nativeElement.dispatchEvent(new Event('btClick', null));

        expect(component.closeDialog).toHaveBeenCalled();
      });
    });

    describe('close icon', () => {
      it('should have correct properties', () => {
        expect(fixture.debugElement.query(By.css('.js-test-close-icon')).properties.config).toEqual(
          component.closeButtonIcon
        );
      });
    });
  });
});
