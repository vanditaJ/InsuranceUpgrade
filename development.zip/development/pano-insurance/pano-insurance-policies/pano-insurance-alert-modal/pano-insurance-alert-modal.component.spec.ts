import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ButtonModule } from '@bt/components/button';

import { PanoInsuranceAlertModalComponent } from './pano-insurance-alert-modal.component';

describe('PanoInsuranceChangeModalComponent', () => {
  let component: PanoInsuranceAlertModalComponent;
  let fixture: ComponentFixture<PanoInsuranceAlertModalComponent>;
  const dialogRef = { close: jasmine.createSpy() };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          ButtonModule,
          RouterTestingModule,
          BrowserDynamicTestingModule,
          HttpClientTestingModule,
          BrowserAnimationsModule
        ],
        declarations: [PanoInsuranceAlertModalComponent],
        providers: [
          { provide: MatDialogRef, useValue: dialogRef },
          { provide: MAT_DIALOG_DATA, useValue: {} }
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsuranceAlertModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('view', () => {
    it('should show the correct heading and description for change cover action', () => {
      component.dialogData = { heading: 'Change cover', description: 'test' };
      fixture.detectChanges();
      const changeCoverHeading = fixture.debugElement.query(By.css('.ts-header'));
      const changeCoverDescription = fixture.debugElement.query(By.css('.js-modal-description'));
      expect(changeCoverHeading.nativeElement.innerHTML).toContain('Change cover');
      expect(changeCoverDescription.nativeElement.innerHTML).toContain('test');
    });

    it('should show continue button if dialog data has show continue button as true', () => {
      component.dialogData = { heading: 'Change cover', description: 'test', showContinueButton: true };
      fixture.detectChanges();
      const continueButton = fixture.debugElement.query(By.css('.ts-continue-button'));
      expect(continueButton.nativeElement.innerHTML).toContain('Continue');
    });

    it('should close the dialog on click of close button', () => {
      const closeButton = fixture.debugElement.query(By.css('.ts-close-button'));

      closeButton.triggerEventHandler('btClick', null);
      fixture.detectChanges();
      expect(dialogRef.close).toHaveBeenCalled();
    });

    it('should close the dialog on click of close icon button', () => {
      const closeIconButton = fixture.debugElement.query(By.css('.ts-close-icon-button'));

      closeIconButton.triggerEventHandler('btClick', null);
      fixture.detectChanges();
      expect(dialogRef.close).toHaveBeenCalled();
    });
  });
});
