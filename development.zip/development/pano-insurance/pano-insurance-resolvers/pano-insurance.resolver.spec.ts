import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { of } from 'rxjs';

import { MOCK_POLICIES } from '../pano-insurance-policies/pano-insurance-policies.component.constants.spec';
import { PanoInsuranceService } from '../pano-insurance.service';

import { panoInsurancePolicyResolver } from './pano-insurance.resolver';

describe('panoInsurancePolicyResolver', () => {
  let accountServiceSpyObj: jasmine.SpyObj<PanoUpgradeAccountService>;
  let panoInsuranceServiceSpyObj: jasmine.SpyObj<PanoInsuranceService>;
  let transition;
  const getObj: any = { get: () => {} };

  beforeEach(() => {
    accountServiceSpyObj = jasmine.createSpyObj('PanoUpgradeAccountService', ['getAccountId']);
    panoInsuranceServiceSpyObj = jasmine.createSpyObj('PanoInsuranceService', ['getPolicies']);
    transition = {
      injector: () => getObj
    };
  });

  it('calls panoInsurancePolicyResolver method', async () => {
    const accountId = '123';
    const getSpy: jasmine.Spy = spyOn(getObj, 'get');
    getSpy.withArgs(PanoUpgradeAccountService).and.returnValue(accountServiceSpyObj);
    getSpy.withArgs(PanoInsuranceService).and.returnValue(panoInsuranceServiceSpyObj);

    accountServiceSpyObj.getAccountId.and.returnValue(accountId);
    panoInsuranceServiceSpyObj.getPolicies.and.returnValues(of([MOCK_POLICIES]));
    const promise = panoInsurancePolicyResolver(transition);
    const policies = await promise;
    expect(policies).toEqual([MOCK_POLICIES]);
  });
});
