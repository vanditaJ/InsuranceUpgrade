import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';

import { InsurancePolicy, NewCoverType, PolicyStatus, PolicyType } from '../../pano-insurance.interface';
import { CoverAmountOptions } from '../pano-change-cover-insurance.interface';

export const NEW_COVER_TYPE: NewCoverType = {
  coverType: {
    policyName: 'Death cover',
    policyType: PolicyType.DEATH,
    description:
      'Retains Death cover only and cancels your TPD if you have bundled Death and TPD cover. Death cover pays a lump sum payment to your beneficiaries when you pass away. You may also be able to claim if you are diagnosed with a terminal illness.'
  },
  coverAmountType: {
    coverSubTypeId: '93',
    coverAmountName: 'Single cover',
    coverAmountType: 'Single',
    coverAmount: 4521,
    premium: '4586',
    increase: false
  }
};

export const INSURANCE_POLICY: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Income Protection',
  policyNumber: '5273590',
  qualifierName: 'Salary continuance cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: null,
  customerType: 'Retail',
  employerFunded: false
};

export const INSURANCE_POLICY_DEATH_AND_TPD: InsurancePolicy = {
  policyType: PolicyType.DEATH,
  policyName: 'Income Protection',
  policyNumber: '5273591',
  qualifierName: 'Salary continuance cover',
  premium: '0.00',
  status: PolicyStatus.ACTIVE,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: true,
  customerType: 'Retail',
  employerFunded: false,
  unitsOfCover: 5
};

export const INSURANCE_POLICY_SCI: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Income Protection',
  policyNumber: '5273590',
  qualifierName: 'Salary continuance cover',
  premium: '0.00',
  status: PolicyStatus.PENDING,
  policyFrequency: 'MONTHLY',
  benefitFrequencyLabel: 'per month',
  commencementDate: '2021-03-01T00:00:00.000+11:00',
  sumInsured: 4521,
  coverSubTypeId: 21,
  coverLevel: 'Double',
  ageNextBirthday: 54,
  newCoverType: NEW_COVER_TYPE,
  customised: true,
  customerType: 'Retail',
  employerFunded: false,
  personBenefitDetails: [
    {
      benefits: [
        {
          waitingPeriod: '2',
          benefitPeriodTerm: '30',
          benefitPeriodFactor: 'years'
        }
      ]
    }
  ]
};

export const INPUT_PARAMS = {
  policyNumber: '5273590',
  coverSubTypeId: '93',
  ageNextBirthday: 54,
  status: PolicyStatus.PENDING,
  coverAmount: 4521,
  currentStartDate: '2021-03-01',
  increase: false
};

export const INPUT_PARAMS_AMOUNT = {
  policyNumber: '5273590',
  coverSubTypeId: '21',
  coverAmount: 3000
};

export const INPUT_PARAMS_UNITS_OF_COVER = {
  policyNumber: '5273591',
  coverSubTypeId: '21',
  units: 3
};

export const INPUT_PARAMS_SCI = {
  policyNumber: '5273590',
  coverSubTypeId: '21',
  waitingPeriod: '30 days',
  benefitPeriod: '2 years',
  coverAmount: 3000
};

export const NEW_COVER_AMOUNT_TYPE: NewCoverType = {
  coverAmountType: {
    coverSubTypeId: '21',
    coverAmount: 3000
  }
};

export const NEW_COVER_UNITS_TYPE: NewCoverType = {
  coverAmountType: {
    coverSubTypeId: '21',
    coverAmount: 3000
  },
  requestUnitsCover: 3
};

export const NEW_COVER_SCI_TYPE: NewCoverType = {
  coverType: { policyName: 'income protection', policyType: PolicyType.INCOME_PROTECTION },
  coverAmountType: {
    coverSubTypeId: '21',
    coverAmount: 3000
  },
  requestWaitingPeriod: '30 days',
  requestBenefitPeriod: '2 years'
};

export const CURRENT_COVER_AMOUNT_DEATH: CoverAmountOptions = {
  policyType: PolicyType.DEATH,
  coverLevel: 'Double',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single']
    }
  ]
};

export const CURRENT_COVER_AMOUNT_DEATH_AND_TPD: CoverAmountOptions = {
  policyType: PolicyType.DEATH_AND_TPD,
  coverLevel: 'Single',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single']
    }
  ]
};

export const CURRENT_COVER_AMOUNT_TPD: CoverAmountOptions = {
  policyType: PolicyType.TPD,
  coverLevel: 'Single',
  coverTypeSelected: [
    {
      coverType: PolicyType.DEATH,
      coverLevels: ['Single']
    }
  ]
};

export const MOCK_AEM_CONTENT_REVIEW: AemContent[] = [
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_review_useful_info_active_increase',
      description: 'mock content for change_cover_review_useful_info_active_increase'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_review_confirm_check_active_increase',
      description: 'mock content for change_cover_review_confirm_check_active_increase'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_review_useful_info_active_decrease',
      description: 'mock content for change_cover_review_useful_info_active_decrease'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_review_confirm_check_active_decrease',
      description: 'mock content for change_cover_review_confirm_check_active_decrease'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_review_useful_info_pending',
      description: 'mock content for change_cover_review_useful_info_pending'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_review_confirm_check_pending',
      description: 'mock content for change_cover_review_confirm_check_pending'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_review_useful_info',
      description: 'mock content for decrease_cover_review_useful_info'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_review_confirm_check',
      description: 'mock content for decrease_cover_review_confirm_check'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'pre_existing_conditions_modal',
      description: 'mock content for pre_existing_conditions_modal'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_review_sum_summary',
      description: 'mock content for decrease_review_sum_summary'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_review_units_summary',
      description: 'mock content for decrease_review_units_summary'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_review_sci_summary',
      description: 'mock content for decrease_review_sci_summary'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'decrease_cover_review_earthrise_confirm_check',
      description: 'mock content for decrease_cover_review_earthrise_confirm_check'
    }
  }
];

export const DECREASE_REQUEST_AMOUNT_COVER_TYPE: NewCoverType = {
  requestCoverAmount: 10
};

export const DECREASE_REQUEST_UNITS_COVER_TYPE: NewCoverType = {
  requestUnitsCover: 2,
  requestCoverAmount: 20
};

export const NEW_DECREASE_REQUEST_AMOUNT_COVER_TYPE: NewCoverType = {
  coverType: {
    policyName: 'Income Protection',
    policyType: PolicyType.DEATH
  },
  coverAmountType: {
    coverSubTypeId: 21,
    coverAmount: 10
  }
};

export const NEW_DECREASE_REQUEST_UNITS_COVER_TYPE: NewCoverType = {
  coverType: {
    policyName: 'Income Protection',
    policyType: PolicyType.DEATH
  },
  coverAmountType: {
    coverSubTypeId: 21,
    coverAmount: 20
  },
  requestUnitsCover: 2
};

export const MOCK_ACCOUNT: Account = {
  key: {
    accountId: 'DE03554AD'
  },
  accountName: 'account name',
  accountNumber: '1234',
  firstMoneyReceivedDate: '2020-10-04T16:00:00.000Z',
  owners: [
    {
      age: 50,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Female',
      lastName: 'LastName'
    }
  ],
  pdsStatus: 'DEFAULT',
  product: {}
};
