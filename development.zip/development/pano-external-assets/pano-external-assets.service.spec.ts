import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { DataModule, DataService } from '@bt/services/data';
import { noop, of, throwError } from 'rxjs';

import {
  ASSET_PRICE_VALUATION_DETAILS,
  EXTERNAL_ASSETS_DETAILS,
  PANORAMA_ASSET_DETAILS,
  SOFTWARE_STATUS_DATA_CONNECTED,
  TEST_ASSET_TYPES,
  TEST_DP_PROPERTY_TYPES
} from './pano-external-assets-constants/pano-external-assets-constants.spec.data';
import {
  API_GET_ASSETS_URL,
  API_GET_EXTERNAL_ASSETS_DETAILED_URL,
  API_GET_INVESTOR_ASSET_TYPES,
  API_GET_INVESTOR_PROPERTY_TYPES,
  API_INVESTOR_ACCOUNTS_BASE_URL,
  API_INVESTOR_ASSET_BASE_URL,
  API_POST_EXTERNAL_ASSETS_URL
} from './pano-external-assets-constants/pano-external-assets.constants';
import {
  GENERIC_CACHE_OPTIONS,
  GENERIC_OPTIONS,
  GENERIC_SAVE_OPTIONS,
  GET_INVESTOR_ASSET_TYPES_OPTIONS
} from './pano-external-assets.constants';
import { PanoExternalAssetsService } from './pano-external-assets.service';

describe('PanoExternalAssetsServices', () => {
  const successHandler: jasmine.Spy = jasmine.createSpy();
  const errorHandler: jasmine.Spy = jasmine.createSpy();

  let dataService: DataService<{}>;
  let extAssetsService: PanoExternalAssetsService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [DataModule, HttpClientModule],
        providers: [Location, { provide: LocationStrategy, useClass: PathLocationStrategy }, PanoExternalAssetsService]
      });
    })
  );

  beforeEach(() => {
    dataService = TestBed.inject(DataService);
    extAssetsService = TestBed.inject(PanoExternalAssetsService);
  });

  afterEach(() => {
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  describe('External assets API', () => {
    let dataServiceSpy;

    beforeEach(() => {
      dataServiceSpy = spyOn(dataService, 'retrieve');
    });

    afterEach(() => {
      dataServiceSpy.calls.reset();
    });

    describe('getExternalAssets', () => {
      const returnValue = { ...EXTERNAL_ASSETS_DETAILS };
      const accountId = '9876';

      it("calls the data service layer's retrieve method with the correct endpoint.", () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getExternalAssets(accountId).subscribe(noop, noop);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          `${API_INVESTOR_ACCOUNTS_BASE_URL}${accountId}${API_GET_EXTERNAL_ASSETS_DETAILED_URL}`,
          GENERIC_OPTIONS
        );
      });

      it('resolves the observable successfully when dataService retrieve returns successfully', () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getExternalAssets(accountId).subscribe(successHandler, errorHandler);

        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('rejects the observable when dataService retrieve errors out', () => {
        dataServiceSpy.and.returnValue(throwError('error'));
        extAssetsService.getExternalAssets(accountId).subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });

    describe('saveExternalAssets', () => {
      const returnValue = { ...EXTERNAL_ASSETS_DETAILS };
      const accountId = '9876';
      const mockExternalAssetsSaveDetails = {
        addedAndEdited: {
          cash: [],
          td: [],
          ls: [],
          ils: [],
          mf: [],
          mp: [],
          dp: [],
          oth: []
        },
        deleted: []
      };

      it("calls the data service layer's update method with the correct endpoint.", () => {
        spyOn(dataService, 'update').and.returnValue(of(returnValue));
        extAssetsService.saveExternalAssets(accountId, mockExternalAssetsSaveDetails).subscribe(noop, noop);

        expect(dataService.update).toHaveBeenCalledWith(
          `${API_INVESTOR_ACCOUNTS_BASE_URL}${accountId}${API_POST_EXTERNAL_ASSETS_URL}`,
          mockExternalAssetsSaveDetails,
          GENERIC_SAVE_OPTIONS
        );
      });

      it('resolves the observable successfully when dataService update returns successfully', () => {
        spyOn(dataService, 'update').and.returnValue(of(returnValue));
        extAssetsService
          .saveExternalAssets(accountId, mockExternalAssetsSaveDetails)
          .subscribe(successHandler, errorHandler);

        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('rejects the observable when dataService update errors out', () => {
        spyOn(dataService, 'update').and.returnValue(throwError('error'));
        extAssetsService
          .saveExternalAssets(accountId, mockExternalAssetsSaveDetails)
          .subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });

    describe('getAssetTypes', () => {
      const returnValue = TEST_ASSET_TYPES;

      it("calls the data service layer's retrieve method with the correct endpoint.", () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getAssetTypes().subscribe(noop, noop);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          API_GET_INVESTOR_ASSET_TYPES,
          GET_INVESTOR_ASSET_TYPES_OPTIONS
        );
      });

      it('resolves the observable successfully when dataService retrieve returns successfully', () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getAssetTypes().subscribe(successHandler, errorHandler);

        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('rejects the observable when dataService retrieve errors out', () => {
        dataServiceSpy.and.returnValue(throwError('error'));
        extAssetsService.getAssetTypes().subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });

    describe('getAssetTypes', () => {
      const returnValue = TEST_DP_PROPERTY_TYPES;

      it("calls the data service layer's retrieve method with the correct endpoint.", () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getPropertyTypes().subscribe(noop, noop);

        expect(dataService.retrieve).toHaveBeenCalledWith(API_GET_INVESTOR_PROPERTY_TYPES, GENERIC_CACHE_OPTIONS);
      });

      it('resolves the observable successfully when dataService retrieve returns successfully', () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getPropertyTypes().subscribe(successHandler, errorHandler);

        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('rejects the observable when dataService retrieve errors out', () => {
        dataServiceSpy.and.returnValue(throwError('error'));
        extAssetsService.getPropertyTypes().subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });

    describe('getAccountingSoftwareStatus', () => {
      const returnValue = SOFTWARE_STATUS_DATA_CONNECTED;

      it('calls the correct API and resolves the observable successfully when dataService retrieve returns successfully', () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getAccountingSoftwareStatus('ABC').subscribe(successHandler, errorHandler);
        expect(dataServiceSpy).toHaveBeenCalledWith(
          `../api/v1/investor/accounts/ABC/accounting-software`,
          GENERIC_OPTIONS
        );
        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('calls the correct API and rejects the observable when dataService retrieve errors out', () => {
        dataServiceSpy.and.returnValue(throwError('error'));
        extAssetsService.getAccountingSoftwareStatus('ABC').subscribe(successHandler, errorHandler);
        expect(dataServiceSpy).toHaveBeenCalledWith(
          `../api/v1/investor/accounts/ABC/accounting-software`,
          GENERIC_OPTIONS
        );

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });

    describe('getValuationForExternalAsset', () => {
      const returnValue = SOFTWARE_STATUS_DATA_CONNECTED;

      it('calls the correct API and resolves the observable successfully when dataService retrieve returns successfully', () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getValuationForExternalAsset('ABC').subscribe(successHandler, errorHandler);
        expect(dataServiceSpy).toHaveBeenCalledWith(
          `../api/v1/investor/accounts/ABC/external-assets/summary-view`,
          GENERIC_OPTIONS
        );
        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('calls the correct API and rejects the observable when dataService retrieve errors out', () => {
        dataServiceSpy.and.returnValue(throwError('error'));
        extAssetsService.getValuationForExternalAsset('ABC').subscribe(successHandler, errorHandler);
        expect(dataServiceSpy).toHaveBeenCalledWith(
          `../api/v1/investor/accounts/ABC/external-assets/summary-view`,
          GENERIC_OPTIONS
        );

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });

    describe('getAssetLatestPrice', () => {
      const returnValue = { ...ASSET_PRICE_VALUATION_DETAILS };
      const assetId = '9876';

      it("calls the data service layer's retrieve method with the correct endpoint with cache options, so that once cached dataservice will return data from cache", () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getAssetLatestPrice(assetId).subscribe(noop, noop);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          `${API_INVESTOR_ASSET_BASE_URL}${assetId}`,
          GENERIC_CACHE_OPTIONS
        );
      });

      it('resolves the observable successfully when dataService retrieve returns successfully', () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getAssetLatestPrice(assetId).subscribe(successHandler, errorHandler);

        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('rejects the observable when dataService retrieve errors out', () => {
        dataServiceSpy.and.returnValue(throwError('error'));
        extAssetsService.getAssetLatestPrice(assetId).subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });

    describe('getPanoramaAssetDetails', () => {
      const returnValue = { ...PANORAMA_ASSET_DETAILS };
      const assetId = '111227';

      it("calls the data service layer's retrieve method with the correct endpoint.", () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getPanoramaAssetDetails(assetId).subscribe(noop, noop);

        expect(dataService.retrieve).toHaveBeenCalledWith(
          `${API_GET_INVESTOR_ASSET_TYPES}/${assetId}${API_GET_ASSETS_URL}`,
          GENERIC_CACHE_OPTIONS
        );
      });

      it('resolves the observable successfully when dataService retrieve returns successfully', () => {
        dataServiceSpy.and.returnValue(of(returnValue));
        extAssetsService.getPanoramaAssetDetails(assetId).subscribe(successHandler, errorHandler);

        expect(successHandler).toHaveBeenCalledWith(returnValue);
        expect(errorHandler).not.toHaveBeenCalled();
      });

      it('rejects the observable when dataService retrieve errors out', () => {
        dataServiceSpy.and.returnValue(throwError('error'));
        extAssetsService.getPanoramaAssetDetails(assetId).subscribe(successHandler, errorHandler);

        expect(successHandler).not.toHaveBeenCalled();
        expect(errorHandler).toHaveBeenCalledWith('error');
      });
    });
  });
});
