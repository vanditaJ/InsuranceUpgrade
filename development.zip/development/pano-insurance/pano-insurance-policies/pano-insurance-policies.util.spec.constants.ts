import * as moment from 'moment-timezone';

import { InsurancePolicy, PolicyStatus, PolicyType } from '../pano-insurance.interface';

export const MOCK_ACTIVE_POLICY: InsurancePolicy[] = [
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    endDate: null,
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: false,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 25,
    customerType: 'PCS',
    pysDetails: {
      optInDate: '2021-04-12T14:00:00.000Z'
    },
    pmifDetails: {
      optInDate: '2021-04-12T14:00:00.000Z',
      lowBalanceThresholdDate: '2021-04-12T14:00:00.000Z'
    },
    riskCommencementDate: '2021-05-02T14:00:00.000Z',
    personBenefitDetails: []
  }
];

export const MOCK_EMPLOYER_FUNDED_POLICY: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: true,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 25,
  customerType: 'PCS',
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_WGP_POLICY: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: true,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 25,
  customerType: 'Staff (WGP)',
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_BTSFL_POLICY_WITHIN_30_DAYS: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Standard cover',
  ageNextBirthday: 25,
  customerType: 'Retail',
  riskCommencementDate: moment()
    .subtract(7, 'days')
    .format(),
  personBenefitDetails: []
};

export const MOCK_BTSFL_POLICY_AFTER_30_DAYS: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 25,
  customerType: 'Retail',
  riskCommencementDate: moment()
    .subtract(50, 'days')
    .format(),
  personBenefitDetails: []
};

export const MOCK_BTSFL_POLICY_ACTIVE_AFTER_30_DAYS: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 25,
  customerType: 'Retail',
  riskCommencementDate: moment()
    .subtract(50, 'days')
    .format(),
  personBenefitDetails: []
};

export const MOCK_SINGLE_POLICY_PYSPMIF_REQUIRED: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_ACTIVE_POLICY_PYS_REQUIRED: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: null,
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pmifDetails: {
    optInDate: '2021-06-12T14:00:00.000Z',
    lowBalanceThresholdDate: null
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_ACTIVE_FUTURE_POLICY_PYS_REQUIRED: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.ACTIVE,
  commencementDate: moment()
    .add(10, 'days')
    .format(),
  endDate: null,
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pmifDetails: {
    optInDate: '2021-06-12T14:00:00.000Z',
    lowBalanceThresholdDate: null
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_POLICY_PYS_REQUIRED: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: null,
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pysDetails: {
    optInDate: '2021-04-01T14:00:00.000Z'
  },
  pmifDetails: {
    optInDate: '2021-04-01T14:00:00.000Z',
    lowBalanceThresholdDate: null
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_POLICY_PYS_REQUIRED_RISK_COMMENCEMENT: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: null,
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pysDetails: {
    optInDate: '2021-04-01T14:00:00.000Z'
  },
  pmifDetails: {
    optInDate: '2021-04-01T14:00:00.000Z',
    lowBalanceThresholdDate: null
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_POLICY_PYS_OPTED_IN: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pysDetails: {
    optInDate: '2021-06-12T14:00:00.000Z'
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_POLICY_PMIF_REQUIRED: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pysDetails: {
    optInDate: '2021-06-12T14:00:00.000Z'
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_POLICY_PMIF_REQUIRED_RISK_COMMENCEMENT: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pmifDetails: {
    optInDate: '2021-04-01T14:00:00.000Z',
    lowBalanceThresholdDate: null
  },
  pysDetails: {
    optInDate: '2021-06-12T14:00:00.000Z'
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_SINGLE_POLICY_PMIF_OPTED_IN: InsurancePolicy = {
  policyType: PolicyType.INCOME_PROTECTION,
  policyName: 'Salary Continuance',
  policyNumber: '13587',
  westpacGroupPlan: false,
  sumInsured: 6000,
  premium: '30',
  status: PolicyStatus.NOT_ACTIVE,
  commencementDate: '2021-02-03T00:00:00.000+10:00',
  endDate: '2080-03-03T00:00:00.000+10:00',
  external: false,
  smokerStatus: 'Not applicable',
  customised: true,
  employerFunded: false,
  applicableNotes: 'TT1',
  coverSubTypeId: 12,
  qualifierName: 'Employee Salary Continuance Insurance',
  ageNextBirthday: 58,
  customerType: 'PCS',
  pmifDetails: {
    optInDate: '2021-06-12T14:00:00.000Z',
    lowBalanceThresholdDate: null
  },
  riskCommencementDate: '2021-05-02T14:00:00.000Z',
  personBenefitDetails: []
};

export const MOCK_MULTIPLE_POLICY_PYSPMIF_REQUIRED: InsurancePolicy[] = [
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.NOT_ACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    endDate: '2080-03-03T00:00:00.000+10:00',
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: false,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 58,
    customerType: 'PCS',
    pmifDetails: {
      optInDate: '2021-04-12T14:00:00.000Z',
      lowBalanceThresholdDate: null
    },
    riskCommencementDate: '2021-05-02T14:00:00.000Z',
    personBenefitDetails: []
  },
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    endDate: null,
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: false,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 58,
    customerType: 'PCS',
    pysDetails: {
      optInDate: '2021-04-12T14:00:00.000Z'
    },
    riskCommencementDate: '2021-05-02T14:00:00.000Z',
    personBenefitDetails: []
  }
];

export const MOCK_NOT_COMBINEDPYSPMIF_POLICY: InsurancePolicy[] = [
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.NOT_ACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    endDate: '2080-03-03T00:00:00.000+10:00',
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: false,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 58,
    customerType: 'PCS',
    pysDetails: {
      optInDate: '2021-05-01T14:00:00.000Z'
    },
    pmifDetails: {
      optInDate: '2021-05-01T14:00:00.000Z',
      lowBalanceThresholdDate: null
    },
    riskCommencementDate: '2021-04-02T14:00:00.000Z',
    personBenefitDetails: []
  }
];

export const MOCK_CANCELLED_POLICY: InsurancePolicy[] = [
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.INACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    endDate: '2021-04-03T00:00:00.000+10:00',
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: false,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 58,
    customerType: 'PCS',
    pysDetails: {
      optInDate: '2021-04-01T14:00:00.000Z'
    },
    pmifDetails: {
      optInDate: '2021-04-01T14:00:00.000Z',
      lowBalanceThresholdDate: null
    },
    riskCommencementDate: '2021-05-02T14:00:00.000Z',
    personBenefitDetails: []
  },
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.INACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    endDate: '2080-04-03T00:00:00.000+10:00',
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: false,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 58,
    customerType: 'PCS',
    pysDetails: {
      optInDate: '2021-04-01T14:00:00.000Z'
    },
    pmifDetails: {
      optInDate: '2021-04-01T14:00:00.000Z',
      lowBalanceThresholdDate: null
    },
    riskCommencementDate: '2021-05-02T14:00:00.000Z',
    personBenefitDetails: []
  },
  {
    policyType: PolicyType.INCOME_PROTECTION,
    policyName: 'Salary Continuance',
    policyNumber: '13587',
    westpacGroupPlan: false,
    sumInsured: 6000,
    premium: '30',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-02-03T00:00:00.000+10:00',
    endDate: null,
    external: false,
    smokerStatus: 'Not applicable',
    customised: true,
    employerFunded: false,
    applicableNotes: 'TT1',
    coverSubTypeId: 12,
    qualifierName: 'Employee Salary Continuance Insurance',
    ageNextBirthday: 58,
    customerType: 'PCS',
    pysDetails: {
      optInDate: '2021-04-01T14:00:00.000Z'
    },
    pmifDetails: {
      optInDate: '2021-04-01T14:00:00.000Z',
      lowBalanceThresholdDate: null
    },
    riskCommencementDate: '2021-05-02T14:00:00.000Z',
    personBenefitDetails: []
  }
];

export const MOCK_NO_OCCUPATION_CODE_POLICY: InsurancePolicy = {
  policyType: 'DEATH',
  policyName: 'Death cover',
  policyNumber: '5694734',
  qualifierName: 'Standard cover',
  customerType: 'PCS',
  policyFrequency: 'MONTHLY',
  premium: '15.14',
  status: 'IN_FORCE',
  commencementDate: '2021-08-01T00:00:00.000+10:00',
  endDate: null,
  personBenefitDetails: [
    {
      benefits: [
        {
          benefitPeriodFactor: null,
          benefitPeriodTerm: null,
          waitingPeriod: null,
          benefits: [
            {
              frequency: 'MONTHLY',
              occupationClass: 'N/A'
            }
          ]
        }
      ]
    }
  ],
  sumInsured: 125000,
  unitsOfCover: null,
  coverSubTypeId: 93,
  applicableNotes: 'II1,II2,FN1',
  smokerStatus: null,
  coverLevel: 'Single',
  ageNextBirthday: 41,
  employerFunded: false,
  westpacGroupPlan: false,
  customised: false,
  groupInsurance: false,
  external: false,
  pysDetails: {
    policyStatus: null,
    optInStatus: null,
    optInDate: '2021-07-14T14:00:00.000Z',
    paidToDate: null,
    inactivityType: null,
    expiryDate: null,
    expired: false
  },
  pmifDetails: {
    optInDate: '2021-06-14T14:00:00.000Z',
    lowBalanceThresholdDate: '2019-10-31T13:00:00.000Z'
  },
  riskCommencementDate: '2021-07-31T14:00:00.000Z',
  associatedTpd: []
};

export const MOCK_OCCUPATION_CODE_POLICY: InsurancePolicy = {
  policyType: 'DEATH',
  policyName: 'Death cover',
  policyNumber: '5694734',
  qualifierName: 'Standard cover',
  customerType: 'Retail',
  policyFrequency: 'MONTHLY',
  premium: '15.14',
  status: 'IN_FORCE',
  commencementDate: '2021-08-01T00:00:00.000+10:00',
  endDate: null,
  personBenefitDetails: [
    {
      benefits: [
        {
          benefitPeriodFactor: null,
          benefitPeriodTerm: null,
          waitingPeriod: null,
          benefits: [
            {
              frequency: 'MONTHLY',
              occupationClass: 'Blue Collar'
            }
          ]
        }
      ]
    }
  ],
  sumInsured: 125000,
  unitsOfCover: null,
  coverSubTypeId: 93,
  applicableNotes: 'II1,II2,FN1',
  smokerStatus: null,
  coverLevel: 'Single',
  ageNextBirthday: 41,
  employerFunded: false,
  westpacGroupPlan: false,
  customised: false,
  groupInsurance: false,
  external: true,
  pysDetails: {
    policyStatus: null,
    optInStatus: null,
    optInDate: '2021-07-14T14:00:00.000Z',
    paidToDate: null,
    inactivityType: null,
    expiryDate: null,
    expired: false
  },
  pmifDetails: {
    optInDate: '2021-06-14T14:00:00.000Z',
    lowBalanceThresholdDate: '2019-10-31T13:00:00.000Z'
  },
  riskCommencementDate: '2021-07-31T14:00:00.000Z',
  associatedTpd: []
};
