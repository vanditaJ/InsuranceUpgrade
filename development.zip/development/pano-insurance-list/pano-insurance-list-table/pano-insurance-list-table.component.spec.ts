// import { Component } from '@angular/core';
// import { ComponentFixture, TestBed } from '@angular/core/testing';
// import { MOCK_POLICIES, MOCK_RELATED_POLICIES, MOCK_STATIC_POLICIES } from '../pano-insurance-list.constants.spec';

// import { PanoInsuranceListTableComponent } from './pano-insurance-list-table.component';

// @Component({
//   template: `
//   <pano-insurance-list-table [getPolicies]="policy"
//                              [getRelatedAccounts]="policyAccounts"
//                              [getStaticData]="policyData">
//   </pano-insurance-list-table>
//   `
// })
// class TestHostComponent {
//   getPolicies = MOCK_POLICIES;
//   getRelatedAccounts = MOCK_RELATED_POLICIES ;
//   getStaticData = MOCK_STATIC_POLICIES;
// }
// describe('PanoInsuranceListTableComponent', () => {
//   let component: PanoInsuranceListTableComponent;
//   let fixture: ComponentFixture<PanoInsuranceListTableComponent>;
//   let testHostComponent: TestHostComponent;
//   let testHostFixture: ComponentFixture<TestHostComponent>;
//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [PanoInsuranceListTableComponent, TestHostComponent]
//     }).compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PanoInsuranceListTableComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
    
//     testHostFixture = TestBed.createComponent(TestHostComponent);
//     testHostComponent = testHostFixture.componentInstance;
//     testHostFixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
