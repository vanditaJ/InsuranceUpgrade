import { Injectable } from '@angular/core';
import { DataService } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';
import { get } from 'lodash-es';
import { forkJoin, Observable, of } from 'rxjs';
import { find, map, switchMap } from 'rxjs/operators';

import { InsuranceRate } from './pano-change-cover-insurance/pano-change-cover-insurance.interface';
import { Insurances } from './pano-insurance-policies/pano-insurance-policies.interface';
import { GENERIC_CACHE_OPTIONS, GENERIC_OPTIONS, SUBMIT_INSURANCE_OPTIONALS } from './pano-insurance.constants';
import { InsuranceOption, InsurancePolicy, Permission } from './pano-insurance.interface';
import { PanoInsuranceUtil } from './pano-insurance.util';

@Injectable()
export class PanoInsuranceService {
  constructor(
    private dataService: DataService<any>,
    private uiRouter: UIRouter,
    private accountService: PanoUpgradeAccountService,
    private panoInsuranceUtil: PanoInsuranceUtil
  ) {}

  getPolicies(accountId: string): Observable<InsurancePolicy[]> {
    return this.dataService
      .retrieve(`../api/policy/v1_0/accounts/${accountId}`, GENERIC_OPTIONS)
      .pipe(map(res => get(res, 'resultList')));
  }

  getPermissions(accountId: string): Observable<Permission> {
    return this.dataService
      .retrieve(`../api/policy/v1_0/accounts/${accountId}/permissions`, GENERIC_CACHE_OPTIONS)
      .pipe(map(res => get(res, 'permissions')));
  }

  getInsurance(): Observable<InsurancePolicy> {
    const insurance = get(this.uiRouter.stateService.params, 'insurance');
    if (insurance) {
      return of(insurance);
    }

    const policyId = get(this.uiRouter.stateService.params, 'policyNumber');
    return this.getPolicies(this.accountService.getAccountId()).pipe(
      switchMap((data: InsurancePolicy[]) => data),
      find((policy: InsurancePolicy) => policy.policyNumber === policyId)
    );
  }

  getAssociatedTpdCovers(): Observable<InsurancePolicy[]> {
    const associatedTpdCovers = get(this.uiRouter.stateService.params, 'associatedTpdCovers');
    if (associatedTpdCovers) {
      return of(associatedTpdCovers);
    } else {
      return forkJoin<InsurancePolicy[], Insurances>([
        this.getPolicies(this.accountService.getAccountId()).pipe(
          map((policies: InsurancePolicy[]) => {
            return policies.filter((policy: InsurancePolicy) =>
              this.panoInsuranceUtil.isPolicyAvailableForInsuranceTable(policy)
            );
          })
        ),
        this.getInsurance()
      ]).pipe(
        map((result: [InsurancePolicy[], Insurances]) =>
          this.panoInsuranceUtil.getDeathAssociatedTPDPolicies(result[0], result[1])
        )
      );
    }
  }

  getInsuranceOptions(coverId: number): Observable<InsuranceOption[]> {
    return this.dataService
      .retrieve(`../panorama-inv-ui/api/v1/insurance/options?coverId=${coverId}`, GENERIC_OPTIONS)
      .pipe(map(res => get(res, 'insuranceOptions')));
  }

  getInsuranceRates(coverId: number, ageNextBirthday: number, gender: string): Observable<InsuranceRate[]> {
    return this.dataService
      .retrieve(
        `../panorama-inv-ui/api/v1/insurance/rates?coverId=${coverId}&ageNextBirthday=${ageNextBirthday}&gender=${gender}`,
        GENERIC_OPTIONS
      )
      .pipe(map((data: any) => data.insuranceRates));
  }

  navigateToOverview(refresh: boolean): void {
    if (refresh) {
      this.uiRouter.stateService.go('app.investor.account.insurancePolicies', {}, { reload: true });
    } else {
      this.uiRouter.stateService.go('app.investor.account.insurancePolicies');
    }
  }

  submitPysOptInRequest(accountId: string, policyNumbers: string[]): Observable<any> {
    return this.dataService.update(
      `../api/v1/investor/accounts/${accountId}/insurance-policy/opt-in`,
      JSON.stringify(policyNumbers),
      SUBMIT_INSURANCE_OPTIONALS
    );
  }

  submitPmifOptInRequest(accountId: string): Observable<any> {
    return this.dataService.update(
      `../panorama-inv-ui/api/v1/insurance/accounts/${accountId}/pmif-opt-in`,
      SUBMIT_INSURANCE_OPTIONALS
    );
  }

  submitCancelInsurance(accountId: string, policyNumber: string): Observable<any> {
    return this.dataService.update(
      `../panorama-inv-ui/api/v1/insurance/accounts/${accountId}/policies/${policyNumber}/cancel`,
      SUBMIT_INSURANCE_OPTIONALS
    );
  }

  submitInsurance(accountId: string, params): Observable<any> {
    return this.dataService.update(
      `../panorama-inv-ui/api/v1/insurance/accounts/${accountId}`,
      params,
      SUBMIT_INSURANCE_OPTIONALS
    );
  }

  submitChangeRequest(accountId: string, params): Observable<any> {
    return this.dataService.update(
      `../panorama-inv-ui/api/v1/insurance/accounts/${accountId}/change-request`,
      params,
      SUBMIT_INSURANCE_OPTIONALS
    );
  }
}
