import { InsurancePolicy, PolicyStatus, PolicyType } from './pano-insurance.interface';

export const IISCOP_PREMIUM_NOT_APPLICABLE_POLICIES: InsurancePolicy[] = [
  {
    policyType: PolicyType.DEATH,
    policyName: 'Income Protection',
    policyNumber: '5273590',
    qualifierName: 'Salary continuance insurance cover',
    premium: '0.00',
    status: PolicyStatus.ACTIVE,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    commencementDate: '2021-03-01T00:00:00.000+11:00',
    sumInsured: 4500,
    coverSubTypeId: 21,
    coverLevel: 'Double',
    ageNextBirthday: 54,
    customised: null,
    customerType: 'Retail',
    employerFunded: false,
    external: true
  },
  {
    policyType: PolicyType.DEATH,
    policyName: 'Income Protection',
    policyNumber: '5273590',
    qualifierName: 'Salary continuance insurance cover',
    premium: '1.00',
    status: PolicyStatus.ACTIVE,
    policyFrequency: 'MONTHLY',
    benefitFrequencyLabel: 'per month',
    commencementDate: '2021-03-01T00:00:00.000+11:00',
    sumInsured: 4500,
    coverSubTypeId: 21,
    coverLevel: 'Double',
    ageNextBirthday: 54,
    customised: null,
    customerType: 'Retail',
    employerFunded: false,
    external: false
  }
];
