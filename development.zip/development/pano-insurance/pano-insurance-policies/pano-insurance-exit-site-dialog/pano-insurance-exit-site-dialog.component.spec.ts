import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { WINDOW } from '@bt/tokens';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradeAccountService } from '@upgrade/upgrade.services';

import { INVESTOR_ACCOUNT_ERROR_STATE } from '../pano-insurance-policies.constants';

import { PanoInsuranceExitSiteDialogComponent } from './pano-insurance-exit-site-dialog.component';
import {
  AIA_PRIVACY_POLICY_LINK,
  AIA_SSO_URL,
  BT_PRIVACY_POLICY_LINK,
  CHECK_YOUR_DETAILS_LINK,
  EXIT_DIALOG_ACCEPT_BUTTON,
  EXIT_DIALOG_CANCEL_BUTTON,
  EXIT_DIALOG_CLOSE_BUTTON
} from './pano-insurance-exit-site-dialog.constants';

describe('PanoInsuranceExitSiteDialogComponent', () => {
  let component: PanoInsuranceExitSiteDialogComponent;
  let fixture: ComponentFixture<PanoInsuranceExitSiteDialogComponent>;
  let accountService: PanoUpgradeAccountService;
  const accountId: string = '';
  const loggedInClientId: string = '';
  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy()
    }
  };

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInsuranceExitSiteDialogComponent],
        providers: [
          {
            provide: PanoUpgradeAccountService,
            useValue: {
              get: () => {}
            }
          },
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          { provide: WINDOW, useValue: { open: jasmine.createSpy() } },
          { provide: UIRouter, useValue: mockUiRouter }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInsuranceExitSiteDialogComponent);
    accountService = TestBed.inject(PanoUpgradeAccountService);
    component = fixture.componentInstance;
    mockUiRouter.stateService.go.calls.reset();
    fixture.detectChanges();
  });

  describe('ngOnInit', () => {
    it('should call account service and intialize account deatils', () => {
      spyOn(accountService, 'get').and.returnValue({
        accountId: '28EE34F55BAFB61A61091E2ED39B7918BC9B993C9AA81E59',
        loggedInClientId: '7AE5CED6FD02CEC4EB8424BC371AED87732D279B33A31D1D1D47F6D28BC62BE4'
      });
      component.ngOnInit();
      expect(accountService.get).toHaveBeenCalled();
      expect(component.checkYourDetailsLink).toBeDefined();
    });
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct values for its properties', () => {
      expect(component.acceptButton).toEqual(EXIT_DIALOG_ACCEPT_BUTTON);
      expect(component.cancelButton).toEqual(EXIT_DIALOG_CANCEL_BUTTON);
      expect(component.closeButton).toEqual(EXIT_DIALOG_CLOSE_BUTTON);
    });

    it('should call dialog close method', () => {
      component.cancel();
      expect((component as any).dialogRef.close).toHaveBeenCalled();
    });

    it('should go to error route if account is not returned from service', () => {
      spyOn(accountService, 'get').and.returnValue(undefined);
      component.ngOnInit();
      component.goToAiaDashboard();
      expect(mockUiRouter.stateService.go).toHaveBeenCalledWith(INVESTOR_ACCOUNT_ERROR_STATE);
      expect((component as any).dialogRef.close).toHaveBeenCalled();
    });

    it('should open a new tab with URL for initiate-sso to AIA', () => {
      spyOn(accountService, 'get').and.returnValue({
        accountId: '28EE34F55BAFB61A61091E2ED39B7918BC9B993C9AA81E59',
        loggedInClientId: '7AE5CED6FD02CEC4EB8424BC371AED87732D279B33A31D1D1D47F6D28BC62BE4'
      });
      component.ngOnInit();
      component.goToAiaDashboard();
      spyOn(window, 'open');
      window.open(`${AIA_SSO_URL}?accountId=${accountId}&customerId=${loggedInClientId}`, '_blank');
      expect(window.open).toHaveBeenCalledWith(
        `${AIA_SSO_URL}?accountId=${accountId}&customerId=${loggedInClientId}`,
        '_blank'
      );
      expect((component as any).dialogRef.close).toHaveBeenCalled();
    });
  });

  describe('View', () => {
    it('should show header', () => {
      expect(
        fixture.debugElement.query(By.css('.js-test-pano-insurance-exit-dialog-header')).nativeElement.innerHTML
      ).toBe(`Manage your insurance with AIA Australia`);
    });

    it('should show close button', () => {
      const closeBtn = fixture.debugElement.query(By.css('.js-test-pano-insurance-exit-button-close'));
      expect(closeBtn).toBeTruthy();
      expect(closeBtn.properties.config).toEqual(EXIT_DIALOG_CLOSE_BUTTON);
    });

    it('should show dialog content', () => {
      expect(
        fixture.debugElement.query(By.css('.js-test-pano-insurance-exit-modal-content')).nativeElement.innerHTML
      ).toContain(
        `You can calculate how much cover you need, apply for new cover, and start or view an existing claim via our insurer, AIA Australia.`
      );
    });

    it('should show check your details link', () => {
      const yourDetailsLink = fixture.debugElement.query(By.css('.js-test-check-your-details-link'));
      expect(yourDetailsLink).toBeTruthy();
      expect(yourDetailsLink.properties.config).toEqual(CHECK_YOUR_DETAILS_LINK);
    });

    it('should show accept button', () => {
      const acceptBtn = fixture.debugElement.query(By.css('.js-test-pano-insurance-exit-button-accept'));
      expect(acceptBtn).toBeTruthy();
      expect(acceptBtn.properties.config).toEqual(EXIT_DIALOG_ACCEPT_BUTTON);
    });

    it('should show cancel button', () => {
      const cancelBtn = fixture.debugElement.query(By.css('.js-test-pano-insurance-exit-button-cancel'));
      expect(cancelBtn).toBeTruthy();
      expect(cancelBtn.properties.config).toEqual(EXIT_DIALOG_CANCEL_BUTTON);
    });

    it('should show bt and aia privacy policy link', () => {
      const privacyPolicyLink = fixture.debugElement.query(By.css('.js-test-pano-insurance-privacy-policy-link'));
      expect(privacyPolicyLink).toBeTruthy();
      expect(privacyPolicyLink.properties.config).toEqual(BT_PRIVACY_POLICY_LINK);
    });

    it('should show aia website link', () => {
      const aiaWebsiteLink = fixture.debugElement.query(By.css('.js-test-pano-insurance-aia-website-link'));
      expect(aiaWebsiteLink).toBeTruthy();
      expect(aiaWebsiteLink.properties.config).toEqual(AIA_PRIVACY_POLICY_LINK);
    });
  });
});
