import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { CopyMatrixPipe, CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { NgxPageScrollCoreModule, PageScrollService } from 'ngx-page-scroll-core';

import { PanoInvProfileAssetMatchAlertsComponent } from './pano-inv-profile-asset-match-alerts.component';
import {
  PAGE_SCROLL_DURATION,
  REQUIRE_PROFILE_REVIEW_UPDATE_ALERT_ID,
  UPDATE_PROFILE_ALERT_ID
} from './pano-inv-profile-asset-match-alerts.constants';

@Component({
  template: `
    <pano-inv-profile-asset-match-alerts
      [showShareEtfsAlert]="showShareEtfsAlert"
      [showAssetNotMatchAlert]="showAssetNotMatchAlert"
      [showNotInTargetMarketAlert]="showNotInTargetMarketAlert"
      [showRequireProfileUpdateAlert]="showRequireProfileUpdateAlert"
      [showRemindProfileReviewAlert]="showRemindProfileReviewAlert"
      [showUpdateProfileAlert]="showUpdateProfileAlert"
      [activeAssetType]="activeAssetType"
    >
    </pano-inv-profile-asset-match-alerts>
  `
})
class TestHostComponent {
  showShareEtfsAlert: boolean;
  showAssetNotMatchAlert: boolean;
  showNotInTargetMarketAlert: boolean;
  showRequireProfileUpdateAlert: boolean;
  showRemindProfileReviewAlert: boolean;
  showUpdateProfileAlert: boolean;
  activeAssetType: string = 'test activeAssetType 1';
}

describe('PanoInvProfileAssetMatchAlertsComponent', () => {
  let component: PanoInvProfileAssetMatchAlertsComponent;
  let fixture: ComponentFixture<PanoInvProfileAssetMatchAlertsComponent>;
  let copyMatrixPipe: CopyMatrixPipe;

  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [CopyMatrixPipeModule, NgxPageScrollCoreModule, NoopAnimationsModule],
      providers: [CopyMatrixPipe, { provide: PageScrollService, useValue: pageScrollService }],
      declarations: [PanoInvProfileAssetMatchAlertsComponent, TestHostComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvProfileAssetMatchAlertsComponent);
    copyMatrixPipe = TestBed.inject(CopyMatrixPipe);

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct input with its host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const hostComponent = hostFixture.componentInstance;
      const currentComp: PanoInvProfileAssetMatchAlertsComponent = hostFixture.debugElement.query(
        By.directive(PanoInvProfileAssetMatchAlertsComponent)
      ).componentInstance;

      hostFixture.detectChanges();

      expect(currentComp.showShareEtfsAlert).toEqual(hostComponent.showShareEtfsAlert);
      expect(currentComp.showAssetNotMatchAlert).toEqual(hostComponent.showAssetNotMatchAlert);
      expect(currentComp.showNotInTargetMarketAlert).toEqual(hostComponent.showNotInTargetMarketAlert);
      expect(currentComp.showRequireProfileUpdateAlert).toEqual(hostComponent.showRequireProfileUpdateAlert);
      expect(currentComp.showRemindProfileReviewAlert).toEqual(hostComponent.showRemindProfileReviewAlert);
      expect(currentComp.showUpdateProfileAlert).toEqual(hostComponent.showUpdateProfileAlert);
      expect(currentComp.activeAssetType).toEqual(hostComponent.activeAssetType);
    });

    describe('ngOnInit()', () => {
      describe('showUpdateProfileAlert', () => {
        it('should call copyMatrixPipe.transform and setup updateProfileMessage if showUpdateProfileAlert is true', () => {
          spyOn(copyMatrixPipe, 'transform').and.returnValue('test replace');
          component.activeAssetType = 'test activeAssetType';
          component.showUpdateProfileAlert = true;

          component.ngOnInit();

          expect(copyMatrixPipe.transform).toHaveBeenCalledWith(UPDATE_PROFILE_ALERT_ID, component.activeAssetType);
          expect(component.updateProfileMessage).toBe(`test replace`);
        });

        it('should NOT call copyMatrixPipe.transform and setup updateProfileMessage if showUpdateProfileAlert is false', () => {
          spyOn(copyMatrixPipe, 'transform').and.returnValue('test replace');
          component.activeAssetType = 'test activeAssetType';
          component.showUpdateProfileAlert = false;

          component.ngOnInit();

          expect(copyMatrixPipe.transform).not.toHaveBeenCalled();
          expect(component.updateProfileMessage).toBeFalsy();
        });
      });

      describe('showRequireProfileUpdateAlert', () => {
        it('should call copyMatrixPipe.transform and setup updateProfileMessage and updateProfileTitle if showRequireProfileUpdateAlert is true', () => {
          spyOn(copyMatrixPipe, 'transform').and.returnValue('test replace showRequireProfileUpdateAlert');
          component.showRequireProfileUpdateAlert = true;

          component.ngOnInit();

          expect(copyMatrixPipe.transform).toHaveBeenCalledWith(REQUIRE_PROFILE_REVIEW_UPDATE_ALERT_ID);
          expect(component.updateProfileMessage).toBe(`test replace showRequireProfileUpdateAlert`);
        });

        it('should NOT call copyMatrixPipe.transform and setup updateProfileMessage and updateProfileTitle if showRequireProfileUpdateAlert is false', () => {
          spyOn(copyMatrixPipe, 'transform').and.returnValue('test replace {1}');
          component.showRequireProfileUpdateAlert = false;

          component.ngOnInit();

          expect(copyMatrixPipe.transform).not.toHaveBeenCalled();
          expect(component.updateProfileMessage).toBeFalsy();
        });
      });
    });

    describe('updateProfile()', () => {
      it('should call scroll service', () => {
        const pageScrollOptions = {
          document: (component as any).document,
          scrollTarget: '.js-investment-profile-title',
          scrollViews: [document.querySelector('.layout-scroll')],
          duration: PAGE_SCROLL_DURATION
        };

        component.updateProfile();

        expect(pageScrollService.scroll).toHaveBeenCalledWith(pageScrollOptions);
      });
    });
  });

  describe('View', () => {
    describe('ShareEtfsAlert', () => {
      it('should NOT show ShareEtfsAlert if showShareEtfsAlert is false ', () => {
        component.showShareEtfsAlert = false;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-share-etfs-alert'))).toBeFalsy();
      });

      it('should show ShareEtfsAlert if showShareEtfsAlert is true ', () => {
        component.showShareEtfsAlert = true;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-share-etfs-alert'))).toBeTruthy();
      });
    });

    describe('assetNotMatchAlert', () => {
      it('should NOT show assetNotMatchAlert if showAssetNotMatchAlert is false ', () => {
        component.showAssetNotMatchAlert = false;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-asset-not-match-alert'))).toBeFalsy();
      });

      it('should show assetNotMatchAlert if showAssetNotMatchAlert is true ', () => {
        component.showAssetNotMatchAlert = true;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-asset-not-match-alert'))).toBeTruthy();
      });
    });

    describe('showNotInTargetMarketAlert', () => {
      it('should NOT show showNotInTargetMarketAlert if showNotInTargetMarketAlert is false ', () => {
        component.showNotInTargetMarketAlert = false;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-asset-not-match-alert'))).toBeFalsy();
      });

      it('should show showNotInTargetMarketAlert if showNotInTargetMarketAlert is true ', () => {
        component.showNotInTargetMarketAlert = true;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-asset-not-match-alert'))).toBeTruthy();
      });
    });

    describe('showRemindProfileReviewAlert', () => {
      it('should NOT show showRemindProfileReviewAlert if showRemindProfileReviewAlert is false ', () => {
        component.showRemindProfileReviewAlert = false;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-asset-not-match-alert'))).toBeFalsy();
      });

      it('should show showRemindProfileReviewAlert if showRemindProfileReviewAlert is true ', () => {
        component.showRemindProfileReviewAlert = true;

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.js-test-asset-not-match-alert'))).toBeTruthy();
      });
    });

    describe('updateProfileAlert', () => {
      describe('when showUpdateProfileAlert is false', () => {
        beforeEach(() => {
          component.showUpdateProfileAlert = false;
          fixture.detectChanges();
        });

        it('should NOT show updateProfileAlert', () => {
          expect(fixture.debugElement.query(By.css('.js-test-update-profile-alert'))).toBeFalsy();
        });

        it('should NOT show updateProfileButton', () => {
          expect(fixture.debugElement.query(By.css('.js-test-update-profile-button'))).toBeFalsy();
        });
      });

      describe('when showUpdateProfileAlert is false', () => {
        beforeEach(() => {
          component.showUpdateProfileAlert = true;
          fixture.detectChanges();
        });

        it('should show updateProfileAlert', () => {
          expect(fixture.debugElement.query(By.css('.js-test-update-profile-alert'))).toBeTruthy();
        });

        it('should show updateProfileButton', () => {
          const button = fixture.debugElement.query(By.css('.js-test-update-profile-button'));
          expect(button).toBeTruthy();
          expect(button.properties.config).toEqual(component.updateProfileButton);
        });
      });
    });
  });
});
