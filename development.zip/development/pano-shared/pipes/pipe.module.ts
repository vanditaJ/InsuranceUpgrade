import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { PerAnnumScreenReaderPipe } from './per-annum-screen-reader/per-annum-screen-reader.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [PerAnnumScreenReaderPipe],
  exports: [PerAnnumScreenReaderPipe]
})
export class PipeModule {}
