import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataModule, DataService } from '@bt/services/data';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { UIRouter } from '@uirouter/core';
import { PanoUpgradePermissionService, StateParams } from '@upgrade/upgrade.services';
import { PageScrollService } from 'ngx-page-scroll-core';
import { of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';

import { PanoInvestmentFeesComponent } from './pano-investment-fees.component';
import {
  AEM_DATA_URL,
  AEM_TEXT_URL,
  GENERIC_OPTIONS,
  INVESTOR_ACCOUNT_ERROR_STATE
} from './pano-investment-fees.constants';
import { AemInvestmentFee } from './pano-investment-fees.interface';
import { PanoInvestmentFeesService } from './pano-investment-fees.service';

describe('PanoInvestmentFees', () => {
  const ENCODED_ACCOUNT_ID: string = 'EncodedAccountId';
  const ACCOUNT: Account = {
    key: {
      accountId: 'EncodedAccountId'
    },
    accountName: 'accountName',
    accountNumber: 'accountNumber',
    firstMoneyReceivedDate: '',
    heritageCohort: 'OPEN',
    pdsStatus: 'DEFAULT',
    product: { productSubType: 'CORPORATE_SUPER' }
  };

  const TEST_INVESTMENTS: AemInvestmentFee[] = [
    {
      cohort: '',
      investmentName: 'lifestage',
      apirCode: 'ls',
      indirectCosts: 1,
      otherFees: 2,
      borrowingCosts: 3,
      lifestage: true
    },
    {
      cohort: '',
      investmentName: 'non-lifestage',
      apirCode: 'nls',
      indirectCosts: 1,
      otherFees: 2,
      borrowingCosts: 3,
      lifestage: false
    }
  ];

  const pageScrollService = jasmine.createSpyObj('pageScrollMockService', { scroll: jasmine.createSpy() });
  const uiRouterStateServiceStub = {
    stateService: {
      go: jasmine.createSpy()
    }
  };
  let component: PanoInvestmentFeesComponent;
  let fixture: ComponentFixture<PanoInvestmentFeesComponent>;
  let disclaimerService: PanoDisclaimersService;
  let superLinkService: PanoSuperLinkService;
  let dataService: DataService<any>;
  let service: PanoInvestmentFeesService;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoInvestmentFeesComponent],
        imports: [
          BrowserAnimationsModule,
          MatButtonToggleModule,
          MatFormFieldModule,
          MatInputModule,
          MatRadioModule,
          CopyMatrixPipeModule,
          DataModule,
          HttpClientTestingModule
        ],
        providers: [
          DataService,
          Location,
          {
            provide: LocationStrategy,
            useClass: PathLocationStrategy
          },
          PanoInvestmentFeesService,
          PanoDisclaimersService,
          PanoSuperLinkService,
          {
            provide: PanoUpgradePermissionService,
            useValue: { hasPermission: jasmine.createSpy() }
          },
          PageScrollService,
          {
            provide: StateParams,
            useValue: {
              accountId: ENCODED_ACCOUNT_ID
            }
          },
          {
            provide: UIRouter,
            useValue: uiRouterStateServiceStub
          },
          {
            provide: PageScrollService,
            useValue: pageScrollService
          }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoInvestmentFeesComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(PanoInvestmentFeesService);
    disclaimerService = TestBed.inject(PanoDisclaimersService);
    spyOn(disclaimerService, 'evaluateDisclaimer').and.returnValue('disclaimer');
    superLinkService = TestBed.inject(PanoSuperLinkService);
    spyOn(superLinkService, 'getLinks').and.returnValue([
      {
        icon: {
          name: 'icon-chevron-left-circle-solid'
        },
        isLinkExternal: true,
        label: 'test link',
        link: 'test url',
        openNewTab: false,
        type: 'flat',
        colourModifier: 'primary',
        iconPosition: 'left'
      }
    ]);
    dataService = TestBed.inject(DataService);
    spyOn(dataService, 'retrieve')
      .withArgs(AEM_DATA_URL, GENERIC_OPTIONS)
      .and.returnValue(
        of({
          details: [
            {
              type: 'rich_text',
              data:
                '\u003cp\u003eDEFAULT,1940s Lifestage,BTA0288AU,0.12,0.15,0,TRUE\u003c/p\u003e\r\n\u003cp\u003eDEFAULT,Active Balanced,BTA8610AU,0.12,0.15,0,FALSE\u003c/p\u003e\r\n\u003cp\u003eOPEN,1940s Lifestage,BTA0288AU,0.11,0.14,0,TRUE\u003c/p\u003e\r\n\u003cp\u003eOPEN,Active Balanced,BTA8610AU,0.11,0.14,0,FALSE\u003c/p\u003e\r\n\u003cp\u003eOPEN,Active GROWTH,BTA8611AU,0.11,0.14,0,FALSE\u003c/p\u003e\r\n'
            }
          ]
        })
      )
      .withArgs(AEM_TEXT_URL, GENERIC_OPTIONS)
      .and.returnValue(
        of({
          details: [
            {
              type: 'title_text_link',
              id: 'general',
              data: {
                headerText: 'headerText',
                description: '\u003cp\u003eheaderText\u003c/p\u003e\r\n'
              }
            }
          ]
        })
      );
  });

  describe('Component', () => {
    describe('ngOnInit', () => {
      describe('successful loading', () => {
        beforeEach(() => {
          component.account = ACCOUNT;
          spyOn(service, 'getTextContent').and.returnValue(of({}));
          spyOn(service, 'getInvestments').and.returnValue(of(TEST_INVESTMENTS));
          component.ngOnInit();
        });

        it('should load the text content', () => {
          expect(service.getTextContent).toHaveBeenCalled();
        });

        it('should load the investment list', () => {
          expect(service.getInvestments).toHaveBeenCalledWith(ACCOUNT);
          expect(component.loading).toBeFalsy();
        });

        it('should update the loading flag', () => {
          expect(component.loading).toBeFalsy();
        });
      });

      describe('composite loading status', () => {
        beforeEach(() => {
          component.account = ACCOUNT;
        });

        it('should stay loading if still getting text content', () => {
          spyOn(service, 'getTextContent').and.returnValue(of({}).pipe(delay(10000)));
          spyOn(service, 'getInvestments').and.returnValue(of([]));
          component.ngOnInit();
          expect(component.loading).toBeTrue();
        });

        it('should stay loading if still getting investments', () => {
          spyOn(service, 'getTextContent').and.returnValue(of({}));
          spyOn(service, 'getInvestments').and.returnValue(of([]).pipe(delay(10000)));
          component.ngOnInit();
          expect(component.loading).toBeTrue();
        });

        it('should stay loading if still getting both', () => {
          spyOn(service, 'getTextContent').and.returnValue(of({}).pipe(delay(10000)));
          spyOn(service, 'getInvestments').and.returnValue(of([]).pipe(delay(10000)));
          component.ngOnInit();
          expect(component.loading).toBeTrue();
        });
      });

      describe('failed text loading', () => {
        beforeEach(() => {
          component.account = ACCOUNT;
          spyOn(service, 'getTextContent').and.returnValue(throwError('oops'));
          spyOn(service, 'getInvestments').and.returnValue(of([]));
          component.ngOnInit();
        });

        it('should redirect to error page when cms text loading fails', () => {
          expect(uiRouterStateServiceStub.stateService.go).toHaveBeenCalledWith(INVESTOR_ACCOUNT_ERROR_STATE, {
            accountId: ACCOUNT.key.accountId
          });
        });
      });

      describe('failed investment loading', () => {
        beforeEach(() => {
          component.account = ACCOUNT;
          spyOn(service, 'getTextContent').and.returnValue(of({}));
          spyOn(service, 'getInvestments').and.returnValue(throwError('oops'));
          component.ngOnInit();
        });

        it('should redirect to error page when cms text loading fails', () => {
          expect(uiRouterStateServiceStub.stateService.go).toHaveBeenCalledWith(INVESTOR_ACCOUNT_ERROR_STATE, {
            accountId: ACCOUNT.key.accountId
          });
        });
      });

      describe('getScreenSize', () => {
        beforeEach(() => {
          component.account = ACCOUNT;
          spyOn(service, 'getTextContent').and.returnValue(of({}));
          spyOn(service, 'getInvestments').and.returnValue(throwError('oops'));

          component.ngOnInit();
        });

        it('should set expanded to true if the screen width is greater than 768', () => {
          spyOnProperty(window, 'innerWidth').and.returnValue(1024);
          expect(component.expanded).toBeTruthy();
        });

        it('should set expanded to false if the screen width is equal to 768', () => {
          spyOnProperty(window, 'innerWidth').and.returnValue(768);
          window.dispatchEvent(new Event('resize'));
          expect(component.expanded).toBeFalsy();
        });

        it('should set expanded to false if the screen width is less than 768', () => {
          spyOnProperty(window, 'innerWidth').and.returnValue(420);
          window.dispatchEvent(new Event('resize'));
          expect(component.expanded).toBeFalsy();
        });
      });
    });
  });

  describe('service', () => {
    describe('getTextContent', () => {
      it('should load the text from aem', () => {
        service.getTextContent();
        expect(dataService.retrieve).toHaveBeenCalledWith(AEM_TEXT_URL, GENERIC_OPTIONS);
      });
    });

    describe('getDataContent', () => {
      it('should load the data from aem', () => {
        service.getInvestments(ACCOUNT);
        expect(dataService.retrieve).toHaveBeenCalledWith(AEM_DATA_URL, GENERIC_OPTIONS);
      });

      it('should load the data from the matching content', async () => {
        const lspAccount: Account = {
          key: {
            accountId: 'EncodedAccountId'
          },
          accountName: 'accountName',
          accountNumber: 'accountNumber',
          firstMoneyReceivedDate: '',
          pdsStatus: 'DEFAULT',
          product: { productSubType: 'CORPORATE_SUPER' },
          heritageCohort: 'OPEN'
        };
        const fees: AemInvestmentFee[] = await service.getInvestments(lspAccount).toPromise();
        expect(fees.length).toBe(3);
        expect(fees[0].apirCode).toBe('BTA0288AU');
      });

      it('should load the default cohort when there is no matching data', async () => {
        const btsAccount: Account = {
          key: {
            accountId: 'EncodedAccountId'
          },
          accountName: 'accountName',
          accountNumber: 'accountNumber',
          firstMoneyReceivedDate: '',
          pdsStatus: 'DEFAULT',
          product: { productSubType: 'CORPORATE_SUPER' }
        };
        const fees: AemInvestmentFee[] = await service.getInvestments(btsAccount).toPromise();
        expect(fees.length).toBe(2);
      });
    });
  });

  describe('view', () => {
    beforeEach(() => {
      spyOn(service, 'getInvestments').and.returnValue(of(TEST_INVESTMENTS));
      component.account = ACCOUNT;
      fixture.detectChanges();
    });

    it(
      'should show loading spinner while fetching data',
      waitForAsync(async () => {
        component.loading = true;
        fixture.detectChanges();
        await fixture.whenStable();
        expect(fixture.debugElement.query(By.css('bt-loading'))).not.toBeNull();
        expect(fixture.debugElement.query(By.css('.js-test-investment-fees-table'))).toBeNull();
      })
    );

    it(
      'should not show loading spinner once data is fetched',
      waitForAsync(async () => {
        component.loading = false;
        fixture.detectChanges();
        await fixture.whenStable();
        expect(fixture.debugElement.query(By.css('bt-loading'))).toBeNull();
        expect(fixture.debugElement.query(By.css('.js-test-investment-fees-table'))).not.toBeNull();
      })
    );

    describe('data tables', () => {
      beforeEach(() => {
        component.loading = false;
        component.lifestageFunds = [TEST_INVESTMENTS[0]];
        component.otherFunds = [TEST_INVESTMENTS[1]];
        component.textContent = {
          headerText: 'headerText',
          indirectCosts: 'indirectCosts',
          indirectCostsPds: 'indirectCostsPds',
          additionalFees: 'additionalFees',
          lifestage: 'lifestage'
        };
        fixture.detectChanges();
      });

      it('should show the title', () => {
        const header = fixture.debugElement.query(By.css('h1'));
        expect(header.nativeElement.innerText).toBe('Ongoing fees');
      });

      it('should show the return link', () => {
        const link = fixture.debugElement.query(By.css('bt-link'));
        expect(link.properties.config.link).toEqual('#/app/investor/account/EncodedAccountId/learn-about-investments');
      });

      it('should have table headers', () => {
        const tableHeaders = fixture.debugElement.queryAll(By.css('thead th'));
        expect(tableHeaders[0].nativeElement.innerText).toBe('Investment option');
        expect(tableHeaders[1].nativeElement.innerText).toBe('Indirect costs');
        expect(tableHeaders[2].nativeElement.innerText).toBe('Other fees');
        expect(tableHeaders[3].nativeElement.innerText).toBe('Borrowing costs');
      });

      it('should render lifestage table lifestage rows', () => {
        const tableRows = fixture.debugElement.queryAll(By.css('.js-test-lifestage-fees-table> tbody tr'));
        const cells = tableRows[0].queryAll(By.css('td'));
        expect(cells[0].nativeElement.innerText).toContain('lifestage');
        expect(cells[0].nativeElement.innerText).toContain('ls');
        expect(cells[1].nativeElement.innerText).toContain('1.00%');
        expect(cells[2].nativeElement.innerText).toContain('2.00%');
        expect(cells[3].nativeElement.innerText).toContain('3.00%');
      });

      it('should render non-lifestage table rows', () => {
        const tableRows = fixture.debugElement.queryAll(By.css('.js-test-investment-fees-table> tbody tr'));
        const cells = tableRows[0].queryAll(By.css('td'));
        expect(cells[0].nativeElement.innerText).toContain('non-lifestage');
        expect(cells[0].nativeElement.innerText).toContain('nls');
        expect(cells[1].nativeElement.innerText).toContain('1.00%');
        expect(cells[2].nativeElement.innerText).toContain('2.00%');
        expect(cells[3].nativeElement.innerText).toContain('3.00%');
      });
    });

    describe('related information', () => {
      beforeEach(() => {
        component.loading = false;
        component.textContent = {
          headerText: 'headerText',
          indirectCosts: 'indirectCosts',
          indirectCostsPds: 'indirectCostsPds',
          additionalFees: 'additionalFees',
          lifestage: 'lifestage'
        };
        fixture.detectChanges();
      });

      it('should render related information', () => {
        const links = fixture.debugElement.queryAll(By.css('.js-test-related-info-link'));
        expect(links[0]).toBeTruthy();
      });
    });
  });
});
