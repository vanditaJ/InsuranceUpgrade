import { TestBed, waitForAsync } from '@angular/core/testing';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment-timezone';

import * as mock from './pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { ASSET_TYPES } from './pano-external-assets-constants/pano-external-assets.constants';
import { PanoExternalAssetsFormCreator } from './pano-external-assets-form-creator';

describe('PanoExternalAssetsFormCreator ', () => {
  let panoExternalAssetsFormCreator: PanoExternalAssetsFormCreator;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        providers: [FormBuilder, PanoExternalAssetsFormCreator]
      });
    })
  );

  beforeEach(() => {
    panoExternalAssetsFormCreator = TestBed.inject(PanoExternalAssetsFormCreator);
  });

  describe('createAssetsFormControl', () => {
    it('should add multiple FormGroups with controls to FormArray when Asset list is passed', () => {
      const externalAssetForm = new FormGroup({
        cashFormArray: new FormArray([])
      });
      const expectedCashFormArray = externalAssetForm.get('cashFormArray') as FormArray;
      panoExternalAssetsFormCreator.createAssetsFormControl(
        externalAssetForm,
        ASSET_TYPES.cash.code,
        mock.ASSET_LIST_CASH
      );
      expect(expectedCashFormArray.controls.length).toEqual(1);
    });

    it('should call createAssetFormControl method', () => {
      spyOn(panoExternalAssetsFormCreator, 'createAssetFormControl');
      const externalAssetForm = new FormGroup({
        cashFormArray: new FormArray([])
      });
      panoExternalAssetsFormCreator.createAssetsFormControl(
        externalAssetForm,
        ASSET_TYPES.cash.code,
        mock.ASSET_LIST_CASH
      );
      expect(panoExternalAssetsFormCreator.createAssetFormControl).toHaveBeenCalled();
    });

    it('should not add anything to FormArray when Asset list is passed with an unknown asset type', () => {
      const externalAssetForm = new FormGroup({
        cashFormArray: new FormArray([])
      });
      const expectedCashFormArray = externalAssetForm.get('cashFormArray') as FormArray;
      panoExternalAssetsFormCreator.createAssetsFormControl(externalAssetForm, 'some other type', mock.ASSET_LIST_CASH);
      expect(expectedCashFormArray.controls.length).toEqual(0);
    });
  });

  describe('createAssetFormControl', () => {
    describe('check timezone', () => {
      it('should get Sydney timezone back when America/Los_Angeles timezone is passed', () => {
        const externalAssetForm = new FormGroup({
          cashFormArray: new FormArray([])
        });
        const expectedCashFormArray = externalAssetForm.get('cashFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(expectedCashFormArray, ASSET_TYPES.cash.code, {
          ...mock.ASSET_LIST_CASH[0],
          valuationDate: moment()
            .tz('America/Los_Angeles')
            .format()
        });
        expect(expectedCashFormArray.controls[0].get('valuationDate').value.format('DD MMM YYYY')).toEqual(
          moment()
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
      });
    });

    describe('Cash Asset type', () => {
      it('should add one FormGroups with controls to FormArray when Cash Asset is passed', () => {
        const externalAssetForm = new FormGroup({
          cashFormArray: new FormArray([])
        });
        const expectedCashFormArray = externalAssetForm.get('cashFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedCashFormArray,
          ASSET_TYPES.cash.code,
          mock.ASSET_LIST_CASH[0]
        );
        expect(expectedCashFormArray.controls.length).toEqual(1);
        expect(expectedCashFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedCashFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedCashFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedCashFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedCashFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedCashFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedCashFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(expectedCashFormArray.controls[0].get('source').value).toEqual(
          mock.TEST_CASH_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
      });
    });

    describe('Term Deposit Asset type', () => {
      it('should add one FormGroups with controls to FormArray when Td Asset is passed', () => {
        const externalAssetForm = new FormGroup({
          tdFormArray: new FormArray([])
        });
        const expectedTdFormArray = externalAssetForm.get('tdFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedTdFormArray,
          ASSET_TYPES.td.code,
          mock.ASSET_LIST_TD[0]
        );

        expect(expectedTdFormArray.controls.length).toEqual(1);
        expect(expectedTdFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedTdFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedTdFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedTdFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedTdFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedTdFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedTdFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(
          moment(expectedTdFormArray.controls[0].get('maturityDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('maturityDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(expectedTdFormArray.controls[0].get('source').value).toEqual(
          mock.TEST_TD_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
        expect(expectedTdFormArray.controls[0].get('isMaturityDateChanged').value).toBe(false);
        expect(expectedTdFormArray.controls[0].get('maturityDate').touched).toBe(true);
      });
    });

    describe('Listed Security Asset type', () => {
      it('should add one FormGroups with controls to FormArray when LS Asset is passed', () => {
        spyOn<any>(panoExternalAssetsFormCreator, 'clearValidatorsForPanoramaAsset');
        const externalAssetForm = new FormGroup({
          lsFormArray: new FormArray([])
        });
        const expectedLsFormArray = externalAssetForm.get('lsFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedLsFormArray,
          ASSET_TYPES.ls.code,
          mock.ASSET_LIST_LS[0]
        );

        expect(expectedLsFormArray.controls.length).toEqual(1);
        expect(expectedLsFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedLsFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedLsFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedLsFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedLsFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedLsFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedLsFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(expectedLsFormArray.controls[0].get('assetId').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('assetId').value
        );
        expect(expectedLsFormArray.controls[0].get('isPanoramaAsset').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
        expect(expectedLsFormArray.controls[0].get('positionCode').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('positionCode').value
        );
        expect(expectedLsFormArray.controls[0].get('quantity').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('quantity').value
        );
        expect(expectedLsFormArray.controls[0].get('source').value).toEqual(
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
        expect(expectedLsFormArray.controls[0].get('isLastPriceLoading').value).toBe(false);
        expect((panoExternalAssetsFormCreator as any).clearValidatorsForPanoramaAsset).toHaveBeenCalledWith(
          expectedLsFormArray.controls[0] as FormGroup,
          mock.TEST_LS_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
      });
    });

    describe('International Listed Security Asset type', () => {
      it('should add one FormGroups with controls to FormArray when International Listed Security Asset is passed', () => {
        const externalAssetForm = new FormGroup({
          ilsFormArray: new FormArray([])
        });
        const expectedILsFormArray = externalAssetForm.get('ilsFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedILsFormArray,
          ASSET_TYPES.ils.code,
          mock.ASSET_LIST_ILS[0]
        );

        expect(expectedILsFormArray.controls.length).toEqual(1);
        expect(expectedILsFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedILsFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedILsFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedILsFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedILsFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedILsFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedILsFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(expectedILsFormArray.controls[0].get('isPanoramaAsset').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
        expect(expectedILsFormArray.controls[0].get('positionCode').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('positionCode').value
        );
        expect(expectedILsFormArray.controls[0].get('quantity').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('quantity').value
        );
        expect(expectedILsFormArray.controls[0].get('source').value).toEqual(
          mock.TEST_ILS_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
      });
    });

    describe('Managed Fund Asset type', () => {
      it('should add one FormGroups with controls to FormArray when MF Asset is passed', () => {
        spyOn<any>(panoExternalAssetsFormCreator, 'clearValidatorsForPanoramaAsset');
        const externalAssetForm = new FormGroup({
          mfFormArray: new FormArray([])
        });
        const expectedMfFormArray = externalAssetForm.get('mfFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedMfFormArray,
          ASSET_TYPES.mf.code,
          mock.ASSET_LIST_MF[0]
        );

        expect(expectedMfFormArray.controls.length).toEqual(1);
        expect(expectedMfFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedMfFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedMfFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedMfFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedMfFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedMfFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedMfFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(expectedMfFormArray.controls[0].get('assetId').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('assetId').value
        );
        expect(expectedMfFormArray.controls[0].get('isPanoramaAsset').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
        expect(expectedMfFormArray.controls[0].get('positionCode').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('positionCode').value
        );
        expect(expectedMfFormArray.controls[0].get('quantity').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('quantity').value
        );
        expect(expectedMfFormArray.controls[0].get('source').value).toEqual(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
        expect(expectedMfFormArray.controls[0].get('isLastPriceLoading').value).toBe(false);
        expect((panoExternalAssetsFormCreator as any).clearValidatorsForPanoramaAsset).toHaveBeenCalledWith(
          expectedMfFormArray.controls[0] as FormGroup,
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
      });
    });

    describe('Managed portfolio Asset type', () => {
      it('should add one FormGroups with controls to FormArray when MP Asset is passed', () => {
        const externalAssetForm = new FormGroup({
          mpFormArray: new FormArray([])
        });
        const expectedMpFormArray = externalAssetForm.get('mpFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedMpFormArray,
          ASSET_TYPES.mp.code,
          mock.ASSET_LIST_MP[0]
        );

        expect(expectedMpFormArray.controls.length).toEqual(1);
        expect(expectedMpFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedMpFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedMpFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedMpFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedMpFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedMpFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedMpFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(expectedMpFormArray.controls[0].get('assetId').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('assetId').value
        );
        expect(expectedMpFormArray.controls[0].get('isPanoramaAsset').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
        expect(expectedMpFormArray.controls[0].get('positionCode').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('positionCode').value
        );
        expect(expectedMpFormArray.controls[0].get('source').value).toEqual(
          mock.TEST_MP_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
      });
    });

    describe('Direct Property type', () => {
      it('should add one FormGroups with controls to FormArray when Direct Property is passed', () => {
        const externalAssetForm = new FormGroup({
          dpFormArray: new FormArray([])
        });
        const expectedDpFormArray = externalAssetForm.get('dpFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedDpFormArray,
          ASSET_TYPES.dp.code,
          mock.ASSET_LIST_DP[0]
        );
        expect(expectedDpFormArray.controls.length).toEqual(1);
        expect(expectedDpFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedDpFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedDpFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedDpFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedDpFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedDpFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedDpFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );
        expect(expectedDpFormArray.controls[0].get('isPanoramaAsset').value).toEqual(
          mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
        expect(expectedDpFormArray.controls[0].get('propertyType').value).toEqual(
          mock.TEST_DP_ASSETS_FORM_ARRAY.controls[0].get('propertyType').value
        );
      });
    });

    describe('Other Asset type', () => {
      it('should add one FormGroups with controls to FormArray when OTH Asset is passed', () => {
        const externalAssetForm = new FormGroup({
          othFormArray: new FormArray([])
        });
        const expectedOthFormArray = externalAssetForm.get('othFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(
          expectedOthFormArray,
          ASSET_TYPES.oth.code,
          mock.ASSET_LIST_OTH[0]
        );

        expect(expectedOthFormArray.controls.length).toEqual(1);
        expect(expectedOthFormArray.controls[0].get('assetClassCode').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedOthFormArray.controls[0].get('assetTypeCode').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedOthFormArray.controls[0].get('marketValue').value).toEqual(
          (+mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedOthFormArray.controls[0].get('isNewAsset').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedOthFormArray.controls[0].get('positionId').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedOthFormArray.controls[0].get('positionName').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(
          moment(expectedOthFormArray.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        ).toEqual(
          moment(mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('valuationDate').value)
            .tz('Australia/Sydney')
            .format('DD MMM YYYY')
        );

        expect(expectedOthFormArray.controls[0].get('isPanoramaAsset').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
        expect(expectedOthFormArray.controls[0].get('positionCode').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('positionCode').value
        );
        expect(expectedOthFormArray.controls[0].get('quantity').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('quantity').value
        );
        expect(expectedOthFormArray.controls[0].get('source').value).toEqual(
          mock.TEST_OTH_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
      });
    });

    describe('Managed Fund Asset type with date as empty', () => {
      it('should add one FormGroups with controls to FormArray when MF Asset is passed', () => {
        spyOn<any>(panoExternalAssetsFormCreator, 'clearValidatorsForPanoramaAsset');
        const mockAsset = { ...mock.ASSET_LIST_MF[0], valuationDate: '' };
        const externalAssetForm = new FormGroup({
          mfFormArray: new FormArray([])
        });
        const expectedMfFormArray = externalAssetForm.get('mfFormArray') as FormArray;
        panoExternalAssetsFormCreator.createAssetFormControl(expectedMfFormArray, ASSET_TYPES.mf.code, mockAsset);

        expect(expectedMfFormArray.controls.length).toBe(1);
        expect(expectedMfFormArray.controls[0].get('assetClassCode').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('assetClassCode').value
        );
        expect(expectedMfFormArray.controls[0].get('assetTypeCode').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('assetTypeCode').value
        );
        expect(expectedMfFormArray.controls[0].get('marketValue').value).toBe(
          (+mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('marketValue').value).toFixed(2)
        );
        expect(expectedMfFormArray.controls[0].get('isNewAsset').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('isNewAsset').value
        );
        expect(expectedMfFormArray.controls[0].get('positionId').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('positionId').value
        );
        expect(expectedMfFormArray.controls[0].get('positionName').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('positionName').value
        );
        expect(expectedMfFormArray.controls[0].get('valuationDate').value).toBe('');
        expect(expectedMfFormArray.controls[0].get('assetId').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('assetId').value
        );
        expect(expectedMfFormArray.controls[0].get('isPanoramaAsset').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
        expect(expectedMfFormArray.controls[0].get('positionCode').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('positionCode').value
        );
        expect(expectedMfFormArray.controls[0].get('quantity').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('quantity').value
        );
        expect(expectedMfFormArray.controls[0].get('source').value).toBe(
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('source').value
        );
        expect(expectedMfFormArray.controls[0].get('isLastPriceLoading').value).toBe(false);
        expect((panoExternalAssetsFormCreator as any).clearValidatorsForPanoramaAsset).toHaveBeenCalledWith(
          expectedMfFormArray.controls[0] as FormGroup,
          mock.TEST_MF_ASSETS_FORM_ARRAY.controls[0].get('isPanoramaAsset').value
        );
      });
    });
  });

  describe('getFieldValue', () => {
    it('should return empty string if the field value is empty', () => {
      const mockAsset = { ...mock.ASSET_LIST_CASH[0], source: '' };
      const result = (panoExternalAssetsFormCreator as any).getFieldValue(mockAsset, 'source', 'text');
      expect(result).toBe('');
    });

    it('should return proper date when the date field is a valid date', () => {
      const mockAsset = { ...mock.ASSET_LIST_CASH[0] };
      const result = (panoExternalAssetsFormCreator as any).getFieldValue(mockAsset, 'valuationDate', 'date');
      expect(result.format('DD MMM YYYY')).toBe(
        moment(mockAsset.valuationDate)
          .tz('Australia/Sydney')
          .format('DD MMM YYYY')
      );
    });

    it('should return empty string when the date field is invalid date', () => {
      const mockAsset = { ...mock.ASSET_LIST_CASH[0], valuationDate: '1888-01-03T00:00:00.000+10:04:52' };
      const result = (panoExternalAssetsFormCreator as any).getFieldValue(mockAsset, 'valuationDate', 'date');
      expect(result).toBe('');
    });

    it('should return proper amount field value with decimal points when the amount is passed', () => {
      const mockAsset = { ...mock.ASSET_LIST_CASH[0] };
      const result = (panoExternalAssetsFormCreator as any).getFieldValue(mockAsset, 'marketValue', 'amount');
      expect(result).toBe((+mockAsset.marketValue).toFixed(2));
    });

    it('should return proper field value when the field passed is proper', () => {
      const mockAsset = { ...mock.ASSET_LIST_CASH[0] };
      const result = (panoExternalAssetsFormCreator as any).getFieldValue(mockAsset, 'source', 'text');
      expect(result).toBe(mockAsset.source);
    });
  });

  describe('clearValidatorsForPanoramaAsset', () => {
    beforeEach(() => {
      spyOn(panoExternalAssetsFormCreator, 'attachDynamicValidators');
    });

    it('should call attachDynamicValidators to empty validators if its a panorama asset', () => {
      const assetDetailsFormGroup = new FormGroup({
        marketValue: new FormControl('10000', [
          Validators.required,
          Validators.min(0.01),
          Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
        ]),
        valuationDate: new FormControl(moment('2019-11-11T00:00:00.000+11:00').tz('Australia/Sydney'), [
          Validators.required
        ])
      });

      (panoExternalAssetsFormCreator as any).clearValidatorsForPanoramaAsset(assetDetailsFormGroup, true);
      expect(panoExternalAssetsFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['valuationDate']
      );
      expect(panoExternalAssetsFormCreator.attachDynamicValidators).toHaveBeenCalledWith(
        assetDetailsFormGroup.controls['marketValue']
      );
    });

    it('should not call attachDynamicValidators to empty validators if its not a panorama asset', () => {
      const assetDetailsFormGroup = new FormGroup({
        marketValue: new FormControl('10000', [
          Validators.required,
          Validators.min(0.01),
          Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
        ]),
        valuationDate: new FormControl(moment('2019-11-11T00:00:00.000+11:00').tz('Australia/Sydney'), [
          Validators.required
        ])
      });

      (panoExternalAssetsFormCreator as any).clearValidatorsForPanoramaAsset(assetDetailsFormGroup, false);
      expect(panoExternalAssetsFormCreator.attachDynamicValidators).not.toHaveBeenCalled();
      expect(panoExternalAssetsFormCreator.attachDynamicValidators).not.toHaveBeenCalled();
    });
  });
});
