import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { SOFTWARE_DATA_CONNECTED_STATE } from '../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import { ACCOUNTING_SOFTWARE_CONNECTED_ALERT } from '../pano-external-assets.constants';
import { SoftwareData } from '../pano-external-assets.interfaces';

import { PanoExternalAssetsConnectedComponent } from './pano-external-assets-connected.component';

@Component({
  template: `
    <pano-external-assets-connected [softwareData]="softwareData"> </pano-external-assets-connected>
  `
})
class TestHostComponent {
  softwareData: SoftwareData = { ...SOFTWARE_DATA_CONNECTED_STATE };
}

describe('PanoExternalAssetsConnectedComponent', () => {
  let component: PanoExternalAssetsConnectedComponent;
  let fixture: ComponentFixture<PanoExternalAssetsConnectedComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoExternalAssetsConnectedComponent, TestHostComponent],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoExternalAssetsConnectedComponent);
    component = fixture.componentInstance;
  });

  describe('view', () => {
    beforeEach(() => {
      component.softwareData = SOFTWARE_DATA_CONNECTED_STATE;
      fixture.detectChanges();
    });

    it('Should set title with valuation data', () => {
      expect(
        fixture.debugElement.query(By.css('.js-test-external-assets-connected-heading')).nativeElement.innerText
      ).toBe('External assets $1,234.00');
    });

    it('Should have alert info', () => {
      const infoAlert = fixture.debugElement.query(By.css('.js-test-external-assets-connected-info-alert'));
      expect(infoAlert.properties.config).toEqual(ACCOUNTING_SOFTWARE_CONNECTED_ALERT);
      expect(infoAlert.nativeElement.innerHTML).toContain('External assets are being retrieved from BGL SF360');
      expect(infoAlert.nativeElement.innerHTML).toContain('You are connected to accounting software');
      expect(infoAlert.nativeElement.innerHTML).toContain(
        'Data for external assets was received from your accounting software.'
      );
    });

    it('Should set link to investment screen with external assets included and check the text of the link', () => {
      const link = fixture.debugElement.query(By.css('.js-test-external-assets-connected-link-to-investments'));
      expect(link.properties.uiParams).toEqual({ 'include-external-assets': true });
      expect(link.attributes.uiSref).toBe('app.investor.account.investments');
      expect(link.nativeElement.innerText).toBe("View external assets in 'Investments'");
    });

    it('should have correct mapping passed from host component', () => {
      const hostFixture: ComponentFixture<TestHostComponent> = TestBed.createComponent(TestHostComponent);
      const currentComp: PanoExternalAssetsConnectedComponent = hostFixture.debugElement.query(
        By.directive(PanoExternalAssetsConnectedComponent)
      ).componentInstance;
      hostFixture.detectChanges();
      expect(currentComp.softwareData).toEqual(hostFixture.componentInstance.softwareData);
    });
  });
});
