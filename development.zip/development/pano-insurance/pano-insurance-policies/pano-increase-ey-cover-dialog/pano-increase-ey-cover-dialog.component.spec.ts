import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

import { PanoIncreaseEyCoverDialogComponent } from './pano-increase-ey-cover-dialog.component';
import { CLOSE_BUTTON, CLOSE_ICON } from './pano-increase-ey-cover-dialog.constants';

describe('PanoIncreaseEyCoverDialogComponent', () => {
  let component: PanoIncreaseEyCoverDialogComponent;
  let fixture: ComponentFixture<PanoIncreaseEyCoverDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [MatDialogModule],
        declarations: [PanoIncreaseEyCoverDialogComponent],
        providers: [
          { provide: MatDialogRef, useValue: { close: jasmine.createSpy() } },
          { provide: MAT_DIALOG_DATA, useValue: {} }
        ],
        schemas: [NO_ERRORS_SCHEMA]
      }).overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents: [PanoIncreaseEyCoverDialogComponent]
        }
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoIncreaseEyCoverDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create component', () => {
      expect(component).toBeTruthy();
      expect(component.closeButton).toBe(CLOSE_BUTTON);
      expect(component.closeIcon).toBe(CLOSE_ICON);
    });

    describe('closeDialog', () => {
      it('should close dialog with parameter', () => {
        component.closeDialog('none');

        expect(component.dialogRef.close).toHaveBeenCalledWith('none');
      });
    });
  });

  describe('view', () => {
    it('should have header', () => {
      expect(fixture.debugElement.query(By.css('h1'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.ts-header')).nativeElement.innerHTML).toBe('Increase cover');
    });

    it('should have body', () => {
      expect(fixture.debugElement.query(By.css('.ts-body')).nativeElement.innerHTML).toBeTruthy();
    });

    it('should have close button', () => {
      const closeButton = fixture.debugElement.query(By.css('.ts-close'));
      expect(closeButton.properties.config).toEqual(CLOSE_BUTTON);

      closeButton.nativeElement.dispatchEvent(new Event('btClick', null));
      expect(component.dialogRef.close).toHaveBeenCalled();
    });

    it('should have close button with X icon', () => {
      const closeIcon = fixture.debugElement.query(By.css('.ts-close-icon'));
      expect(closeIcon.properties.config).toEqual(CLOSE_ICON);

      closeIcon.nativeElement.dispatchEvent(new Event('btClick', null));
      expect(component.dialogRef.close).toHaveBeenCalled();
    });
  });
});
