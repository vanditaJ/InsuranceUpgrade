import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Button } from '@bt/components/button';

import { ModalObj } from '../pano-insurance-policies.interface';

import { CLOSE_BUTTON, CLOSE_ICON_BUTTON, CONTINUE_BUTTON } from './pano-insurance-alert-modal.component.constants';

@Component({
  selector: 'pano-pano-insurance-change-modal',
  templateUrl: './pano-insurance-alert-modal.component.html'
})
export class PanoInsuranceAlertModalComponent {
  closeButton: Button = CLOSE_BUTTON;
  closeIconButton: Button = CLOSE_ICON_BUTTON;
  continueButton: Button = CONTINUE_BUTTON;

  constructor(
    public readonly dialogRef: MatDialogRef<PanoInsuranceAlertModalComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: ModalObj
  ) {}
}
