import { DOCUMENT } from '@angular/common';
import { AfterViewInit, Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { AemContent } from '@panorama/services/cms';
import { get } from 'lodash-es';
import { PageScrollService } from 'ngx-page-scroll-core';

import { RETURN_INSURANCE_OVERVIEW_BUTTON } from '../../pano-insurance.constants';
import { findContentByKey } from '../../pano-insurance.helper';
import { InsurancePolicy, NewCoverType, PolicyStatus, PolicyType } from '../../pano-insurance.interface';
import { PanoInsuranceService } from '../../pano-insurance.service';
import { ChangeCoverMode, CoverMode } from '../pano-change-cover-insurance.interface';

import {
  CHANGE_INCREASE_ACTIVE_COVER_CONFIRM_AEM_KEY,
  CHANGE_PENDING_COVER_CONFIRM_AEM_KEY,
  CHANGE_REDUCE_ACTIVE_COVER_CONFIRM_AEM_KEY,
  DECREASE_COVER_CONFIRM_AEM_KEY,
  DECREASE_REQUEST_COVER_CONFIRM_AEM_KEY,
  DECREASE_REQUEST_SCI_COVER_CONFIRM_AEM_KEY,
  SUCCESS_CHANGE_COVER_ALERT,
  SUCCESS_DECREASE_REQUEST_COVER_ALERT
} from './pano-change-cover-confirmation.constants';

@Component({
  selector: 'pano-change-cover-confirmation',
  templateUrl: './pano-change-cover-confirmation.component.html'
})
export class PanoChangeCoverConfirmationComponent implements OnInit, AfterViewInit {
  @Input() insurance: InsurancePolicy;
  @Input() mode: ChangeCoverMode;
  @Input() newCoverType: NewCoverType;
  @Input() cmsContent: AemContent[];

  @Output() resetFocus: EventEmitter<void> = new EventEmitter<void>();

  confirmAemMessage: string;
  isIncrease: boolean = false;
  successCoverAlert: Alert = SUCCESS_CHANGE_COVER_ALERT;

  readonly returnInsuranceOverviewButton: Button = RETURN_INSURANCE_OVERVIEW_BUTTON;

  constructor(
    public policies: PanoInsuranceService,
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: HTMLDocument
  ) {}

  ngOnInit(): void {
    this.pageScrollService.scroll({
      document: this.document,
      scrollTarget: '.top-scroll',
      duration: 200
    });

    this.isIncrease = get(this.newCoverType, 'coverAmountType.increase', false);

    if (this.mode === CoverMode.DECREASE_REQUEST) {
      this.successCoverAlert = SUCCESS_DECREASE_REQUEST_COVER_ALERT;
    }

    this.setAemMessages();
  }

  ngAfterViewInit(): void {
    this.resetFocus.emit(); // move focus to parent heading
  }

  setAemMessages(): void {
    if (this.mode === CoverMode.DECREASE) {
      this.confirmAemMessage = findContentByKey(this.cmsContent, DECREASE_COVER_CONFIRM_AEM_KEY);
    } else if (this.mode === CoverMode.DECREASE_REQUEST) {
      if (this.insurance.policyType === PolicyType.INCOME_PROTECTION) {
        this.confirmAemMessage = findContentByKey(this.cmsContent, DECREASE_REQUEST_SCI_COVER_CONFIRM_AEM_KEY);
      } else {
        this.confirmAemMessage = findContentByKey(this.cmsContent, DECREASE_REQUEST_COVER_CONFIRM_AEM_KEY);
      }
    } else {
      if (this.insurance.status === PolicyStatus.ACTIVE) {
        if (this.isIncrease) {
          this.confirmAemMessage = findContentByKey(this.cmsContent, CHANGE_INCREASE_ACTIVE_COVER_CONFIRM_AEM_KEY);
        } else {
          this.confirmAemMessage = findContentByKey(this.cmsContent, CHANGE_REDUCE_ACTIVE_COVER_CONFIRM_AEM_KEY);
        }
      } else {
        this.confirmAemMessage = findContentByKey(this.cmsContent, CHANGE_PENDING_COVER_CONFIRM_AEM_KEY);
      }
    }
  }
}
