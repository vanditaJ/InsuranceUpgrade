import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatRadioModule } from '@angular/material/radio';
import { MatTabsModule } from '@angular/material/tabs';
import { AlertModule } from '@bt/components/alert';
import { ButtonModule } from '@bt/components/button';
import { IconModule } from '@bt/components/icon';
import { LinkModule } from '@bt/components/link';
import { LoadingModule } from '@bt/components/loading';
import { CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';
import { DataModule } from '@bt/services/data';
import { panoAccountResolver } from '@investor/account/pano-shared/resolvers';
import { LayoutModule } from '@panorama/components/layout';
import { UIRouterUpgradeModule } from '@uirouter/angular-hybrid';
import { NgxMaskModule } from 'ngx-mask';

import { PanoInvestmentOverviewInfoDialogComponent } from './pano-investment-overview-info-dialoq/pano-investment-overview-info-dialog.component';
import { PanoInvestmentsOverviewQuestionsComponent } from './pano-investment-overview-questions/pano-investments-overview-questions.component';
import { PanoInvestmentsOverviewQuestionsService } from './pano-investment-overview-questions/pano-investments-overview-questions.service';
import { PanoInvestmentsOverviewVideoModalComponent } from './pano-investments-overview-video-modal/pano-investments-overview-video-modal.component';
import { PanoInvestmentsOverviewComponent } from './pano-investments-overview.component';
import { PanoInvestmentsOverviewService } from './pano-investments-overview.service';

@NgModule({
  declarations: [
    PanoInvestmentsOverviewComponent,
    PanoInvestmentsOverviewQuestionsComponent,
    PanoInvestmentsOverviewVideoModalComponent,
    PanoInvestmentOverviewInfoDialogComponent
  ],
  providers: [PanoInvestmentsOverviewService, PanoInvestmentsOverviewQuestionsService],
  entryComponents: [],
  imports: [
    AlertModule,
    ButtonModule,
    CommonModule,
    CopyMatrixPipeModule,
    DataModule,
    IconModule,
    LayoutModule,
    LinkModule,
    LoadingModule,
    HttpClientModule,
    NgxMaskModule.forRoot({}),
    ReactiveFormsModule,
    MatTabsModule,
    MatExpansionModule,
    UIRouterUpgradeModule.forChild({
      states: [
        {
          name: 'app.investor.account.investmentsOverview',
          url: '/investments-overview',
          component: PanoInvestmentsOverviewComponent,
          data: {
            requiredPermissions: {
              rule: 'corporatesuper.view',
              targetId: 'a'
            },
            title: 'Your investments overview'
          },
          resolve: {
            account: ['$transition$', panoAccountResolver]
          }
        }
      ]
    }),
    MatButtonToggleModule,
    MatRadioModule,
    FormsModule
  ]
})
export class PanoInvestmentsOverviewModule {}
