import { TestBed } from '@angular/core/testing';
import { CopyMatrixPipe, CopyMatrixPipeModule } from '@bt/pipes/copy-matrix';

import { PanoDisclaimersService } from './pano-disclaimers.service';
import { EY_URL, WGP_COHORT_URL, WGP_OPEN_URL } from './pano-disclaimers.service.constants';
import {
  BTSFL_NON_WGP_ACCT,
  BTS_BTSFL_DISCLAIMER,
  BT_SUPER_ACCT,
  EY_ACCT,
  EY_DISCLAIMER,
  WGP_DISCLAIMER,
  WGP_NO_COHORT_ACCT,
  WGP_OPEN_ACCT,
  WGP_PLUM_ACCT
} from './pano-disclaimers.service.spec.constants';

describe('PanoDisclaimersService', () => {
  let copyMatrixPipe: CopyMatrixPipe;
  let disclaimersService: PanoDisclaimersService;

  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [CopyMatrixPipeModule],
      providers: [PanoDisclaimersService, CopyMatrixPipe]
    });
  });

  beforeEach(() => {
    disclaimersService = TestBed.inject(PanoDisclaimersService);
    copyMatrixPipe = TestBed.inject(CopyMatrixPipe);
    spyOn(copyMatrixPipe, 'transform')
      .withArgs('DS-IP-0258')
      .and.returnValue(BTS_BTSFL_DISCLAIMER)
      .withArgs('DS-IP-0378')
      .and.returnValue(WGP_DISCLAIMER)
      .withArgs('DS-IP-0379')
      .and.returnValue(EY_DISCLAIMER);
  });

  it('should be created', () => {
    expect(disclaimersService).toBeTruthy();
  });

  describe('evaluateDisclaimer', () => {
    describe('should return correct disclaimer for non WGP account', () => {
      it('should return correct disclaimer for BT Super accounts', () => {
        const disclaimer = disclaimersService.evaluateDisclaimer(BT_SUPER_ACCT);
        expect(disclaimer).toEqual(BTS_BTSFL_DISCLAIMER);
      });

      it('should return correct disclaimer for BT Super for Life accounts', () => {
        const disclaimer = disclaimersService.evaluateDisclaimer(BTSFL_NON_WGP_ACCT);
        expect(disclaimer).toEqual(BTS_BTSFL_DISCLAIMER);
      });

      it('should return correct disclaimer for EY accounts', () => {
        const expectedDisclaimer = EY_DISCLAIMER.replace('{1}', EY_URL);

        const disclaimer = disclaimersService.evaluateDisclaimer(EY_ACCT);

        expect(disclaimer).toEqual(expectedDisclaimer);
      });
    });

    describe('should return correct disclaimer for WGP account', () => {
      it('should return disclaimer with correct link for the WGP OPEN cohort', () => {
        const expectedDisclaimer = WGP_DISCLAIMER.replace('{1}', WGP_OPEN_URL);

        const disclaimer = disclaimersService.evaluateDisclaimer(WGP_OPEN_ACCT);

        expect(disclaimer).toEqual(expectedDisclaimer);
      });

      it('should return disclaimer with correct link for the WGP null cohort', () => {
        const expectedDisclaimer = WGP_DISCLAIMER.replace('{1}', WGP_OPEN_URL);

        const disclaimer = disclaimersService.evaluateDisclaimer(WGP_NO_COHORT_ACCT);

        expect(disclaimer).toEqual(expectedDisclaimer);
      });

      it('should return disclaimer with correct link for the WGP all other cohort', () => {
        const expectedLink = WGP_COHORT_URL.replace('{cohort}', WGP_PLUM_ACCT.heritageCohort.toLowerCase());
        const expectedDisclaimer = WGP_DISCLAIMER.replace('{1}', expectedLink);

        const disclaimer = disclaimersService.evaluateDisclaimer(WGP_PLUM_ACCT);

        expect(disclaimer).toEqual(expectedDisclaimer);
      });
    });
  });
});
