import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Icon } from '@bt/components/icon';
import * as moment from 'moment-timezone';

import { PanoExternalAssetsCommonUtil } from '../../pano-external-assets-common.util';
import * as EXTERNAL_ASSETS from '../../pano-external-assets-constants/pano-external-assets.constants';
import { AssetClasses } from '../../pano-external-assets.interfaces';
import { PanoAddAssetFormCreator } from '../pano-add-asset-form-creator';

@Component({
  selector: 'pano-add-asset-other',
  templateUrl: './pano-add-asset-other.component.html'
})
export class PanoAddAssetOtherComponent implements OnInit {
  @Input() addAssetForm: FormGroup;
  @Input() assetClasses: AssetClasses[];

  assetDetails: FormGroup;
  datePickerIcon: Icon = EXTERNAL_ASSETS.DATE_PICKER_ICON;
  today: Date = moment().tz('Australia/Sydney');

  constructor(
    private externalAssetsAddFormCreator: PanoAddAssetFormCreator,
    private panoExternalAssetsCommonUtil: PanoExternalAssetsCommonUtil
  ) {}

  ngOnInit(): void {
    this.assetDetails = this.externalAssetsAddFormCreator.createAddAssetForm('oth');
    this.addAssetForm.setControl('assetDetails', this.assetDetails);
  }

  getErrorMessagesForQuantity(quantityControl: FormControl): string {
    return this.panoExternalAssetsCommonUtil.getErrorMessagesForQuantity(quantityControl);
  }
}
