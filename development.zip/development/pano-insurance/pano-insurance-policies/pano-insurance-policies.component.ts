import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { DIALOG_CONFIG } from '@bt/components/common';
import { Icon } from '@bt/components/icon';
import { Link } from '@bt/components/link';
import { Loading } from '@bt/components/loading';
import { Account } from '@investor/account/pano-shared/interfaces';
import { PanoDisclaimersService } from '@investor/account/pano-shared/services/pano-disclaimers/pano-disclaimers.service';
import { PanoSuperLinkService } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service';
import { LinkType } from '@investor/account/pano-shared/services/pano-super-link/pano-super-link.service.constants';
import { AemContent } from '@panorama/services/cms';
import { UIRouter } from '@uirouter/core';
import {
  PanoUpgradeAccountService,
  PanoUpgradeFeatureService,
  PanoUpgradePermissionService
} from '@upgrade/upgrade.services';
import * as moment from 'moment-timezone';
import { of } from 'rxjs';
import { Subscription } from 'rxjs/internal/Subscription';
import { finalize } from 'rxjs/operators';

import { ChangeCoverState } from '../pano-change-cover-insurance/pano-change-cover-insurance.interface';
import { PRODUCT } from '../pano-insurance.constants';
import { findContentByKey } from '../pano-insurance.helper';
import { InsurancePolicy, Permission } from '../pano-insurance.interface';
import { PanoInsuranceService } from '../pano-insurance.service';

import { PanoActivateInsuranceDialogComponent } from './pano-activate-insurance-dialog/pano-activate-insurance-dialog.component';
import { PanoInsuranceExitSiteDialogComponent } from './pano-insurance-exit-site-dialog/pano-insurance-exit-site-dialog.component';
import {
  ACTIVATE_COVER_BUTTON,
  ACTIVATE_INFO_ALERT,
  ACTIVATE_INSURANCE_DIALOG_CONFIG,
  ACTIVATE_INSURANCE_REQUESTED_ALERT,
  BASE,
  CALCULATE_COVER_MESSAGE,
  CALCULATOR_ICON,
  DEFAULT_PAGE_LOADING,
  EMULATING,
  INACTIVITY_INFO_ALERT,
  INSURANCE,
  INSURANCE_DISPLAY_PANEL,
  INSURANCE_HELP_TILE_CONTENT,
  INSURANCE_INFO_AEM_KEY,
  INSURANCE_INFO_EXTERNAL_AEM_KEY,
  INSURANCE_INFO_GENERIC_AEM_KEY,
  INSURANCE_INFO_PDS_LINK,
  INSURANCE_PORTAL_BUTTON,
  INSURANCE_SSO_AIA_FEATURE,
  INVESTOR_ACCOUNT_ERROR_STATE,
  INVESTOR_BTSUPER_PMIF,
  INVESTOR_GLOBAL_DISCLAIMER_BTSUPER,
  INVESTOR_INSURANCE_PYSOPTIN,
  KEEP_INSURANCE_BUTTON,
  NO_INSURANCE_ALERT,
  NO_INSURANCE_INFO_AEM_KEY,
  NO_OCCUPATION_CODE_ALERT,
  OCCUPATION_CATEGORY_EMAIL_LINK,
  OCCUPATION_GUIDE_LINK,
  OPT_IN_STATUS,
  POLICIES_INFO_ALERT,
  POLICIES_IN_SCOPE,
  PRODUCT_FAMILY,
  PYS_OPT_IN_ALL_DIALOG_CONFIG,
  PYS_SUBMIT_FAIL_ALERT
} from './pano-insurance-policies.constants';
import { InsuranceHelpTile, PoliciesInScope } from './pano-insurance-policies.interface';
import { PanoInsurancePoliciesUtil } from './pano-insurance-policies.util';
import { PanoPysOptInAllComponent } from './pano-pys-optin-all/pano-pys-opt-in-all.component';

@Component({
  selector: 'pano-insurance-policies',
  templateUrl: './pano-insurance-policies.component.html'
})
export class PanoInsurancePoliciesComponent implements OnInit, OnDestroy {
  @Input() account: Account;
  @Input() policies: InsurancePolicy[];
  @Input() cmsContent: AemContent[];
  @Input() insurancePermissions: Permission;

  state: ChangeCoverState;
  loading: boolean = false;
  emulating: boolean = false;
  isPysOptInInvestor: boolean = false;
  isDisclaimerBtSuperInvestor: boolean = false;
  isIntegrationToAiaEnabled: boolean = false;
  isAvailableForPysOptIn: boolean;
  isAvailableForPmifPysOptIn: boolean;
  pysOptInAllDialogSubscription: Subscription = of(null).subscribe();
  activateInsuranceRequested: boolean;
  activatePysInsuranceRequested: boolean;
  pysSubmitFailed: boolean;
  pmifPermission: boolean = false;
  displayPMIFMessage: boolean = false;
  displayPMIFSuccessMessage: boolean = false;

  visiblePolicies: InsurancePolicy[] = [];
  hasVisiblePolicies: boolean = false;
  hasInternalAndExternalPolicies: boolean;
  hasExternalPoliciesOnly: boolean;
  insuranceInfoMessage: string;
  noInsuranceAlertMessage: string;
  disclaimer: string;
  date: moment;
  displayInsurancePanel: boolean = false;
  displayInsuranceTiles: boolean = false;
  displayNoOccupationCodeMessage: boolean;
  occupationCategoryEmailLink: Link = OCCUPATION_CATEGORY_EMAIL_LINK;
  displayInsuranceInfoPdsLink: boolean = false;
  insuranceInfoPdsLink: Link = INSURANCE_INFO_PDS_LINK;

  readonly loadingSpinner: Loading = DEFAULT_PAGE_LOADING;
  readonly inactivityInfoAlert: Alert = INACTIVITY_INFO_ALERT;
  readonly policiesInfoAlert: Alert = POLICIES_INFO_ALERT;
  readonly noInsuranceAlert: Alert = NO_INSURANCE_ALERT;
  readonly activateInsuranceRequestedAlert: Alert = ACTIVATE_INSURANCE_REQUESTED_ALERT;
  readonly keepInsuranceButton: Button = KEEP_INSURANCE_BUTTON;
  readonly insurancePortalButton: Button = INSURANCE_PORTAL_BUTTON;
  readonly calculatorIcon: Icon = CALCULATOR_ICON;
  readonly insuranceHelpTileContent: InsuranceHelpTile = INSURANCE_HELP_TILE_CONTENT;
  readonly heading: string = INSURANCE;
  readonly calculateCoverMessage: string = CALCULATE_COVER_MESSAGE;
  readonly activateInfoAlert: Alert = ACTIVATE_INFO_ALERT;
  readonly activateCoverButton: Button = ACTIVATE_COVER_BUTTON;
  readonly pysSubmitFailedAlert: Alert = PYS_SUBMIT_FAIL_ALERT;
  readonly noOccupationCodeAlert: Alert = NO_OCCUPATION_CODE_ALERT;
  readonly occupationGuideLink: Link = OCCUPATION_GUIDE_LINK;
  readonly policiesInScope: PoliciesInScope = POLICIES_IN_SCOPE;

  constructor(
    private panoInsuranceService: PanoInsuranceService,
    private accountService: PanoUpgradeAccountService,
    private featureService: PanoUpgradeFeatureService,
    private permissionService: PanoUpgradePermissionService,
    private route: UIRouter,
    private readonly dialog: MatDialog,
    private panoInsurancePoliciesUtil: PanoInsurancePoliciesUtil,
    private disclaimerService: PanoDisclaimersService,
    private linkService: PanoSuperLinkService
  ) {}

  ngOnInit(): void {
    const accountId = this.accountService.getAccountId();
    this.emulating = this.permissionService.hasPermission(EMULATING, BASE);
    this.pmifPermission = this.permissionService.hasPermission(INVESTOR_BTSUPER_PMIF, accountId);
    this.isPysOptInInvestor = this.featureService.hasAccess(INVESTOR_INSURANCE_PYSOPTIN);
    this.isDisclaimerBtSuperInvestor = this.featureService.hasAccess(INVESTOR_GLOBAL_DISCLAIMER_BTSUPER);
    this.isIntegrationToAiaEnabled =
      this.permissionService.hasPermission(INSURANCE_SSO_AIA_FEATURE, 'base') ||
      this.permissionService.hasPermission(INSURANCE_SSO_AIA_FEATURE, accountId);

    this.policies = this.filterPolicies();
    this.visiblePolicies = this.policies.filter((policy: InsurancePolicy) =>
      this.panoInsurancePoliciesUtil.isPolicyAvailableForInsuranceTable(policy)
    );
    const activePolicies: InsurancePolicy[] = this.policies.filter((policy: InsurancePolicy) =>
      this.panoInsurancePoliciesUtil.checkActive(policy)
    );
    const externalPolicies: InsurancePolicy[] = activePolicies.filter((policy: InsurancePolicy) => policy.external);

    this.hasVisiblePolicies = this.visiblePolicies.length > 0;
    const hasActivePolicies = activePolicies.length > 0;
    const hasExternalPolicies = externalPolicies.length > 0;
    this.hasExternalPoliciesOnly = hasExternalPolicies && externalPolicies.length === activePolicies.length;
    this.hasInternalAndExternalPolicies = hasExternalPolicies && externalPolicies.length < activePolicies.length;

    this.isAvailableForPmifPysOptIn = this.panoInsurancePoliciesUtil.pysAndPMIFOptInRequired(this.policies);
    const isPysOptInRequired = this.panoInsurancePoliciesUtil.pysOptInRequiredForPolicies(this.policies);
    this.isAvailableForPysOptIn = hasActivePolicies && isPysOptInRequired && !this.isAvailableForPmifPysOptIn;
    this.displayPMIFMessage = this.panoInsurancePoliciesUtil.pmifOptInRequiredForPolicies(this.policies);
    this.date = moment(new Date()).format('D MMM YYYY');
    this.disclaimer = this.disclaimerService.evaluateDisclaimer(this.account);
    this.displayInsurancePanel = this.showInsurancePanel();
    this.setInsuranceInfoMessages(this.hasVisiblePolicies, hasExternalPolicies, accountId);
    this.setNoOccupationCodeAlert();
    this.showInsuranceTiles(hasActivePolicies);
  }

  showInsurancePanel(): boolean {
    return this.insurancePermissions && this.insurancePermissions[INSURANCE_DISPLAY_PANEL] === 'true';
  }

  filterPolicies(): InsurancePolicy[] {
    if (this.policies) {
      return this.panoInsurancePoliciesUtil.checkPmifPolicy(this.policies, this.pmifPermission);
    }
    return [];
  }

  setInsuranceInfoMessages(hasVisiblePolicies: boolean, hasExternalPolicies: boolean, accountId: string): void {
    if (hasVisiblePolicies) {
      this.insuranceInfoMessage = findContentByKey(this.cmsContent, this.getInsuranceInfoAemKey(hasExternalPolicies));
      this.displayInsuranceInfoPdsLink = false;
    } else {
      this.insuranceInfoMessage = findContentByKey(this.cmsContent, INSURANCE_INFO_AEM_KEY);
      this.noInsuranceAlertMessage = findContentByKey(this.cmsContent, this.getNoInsuranceAlertAemKey());

      this.displayInsuranceInfoPdsLink = true;
      this.insuranceInfoPdsLink.link = this.linkService.getUrl(
        LinkType.PRODUCT_DISCLOSURE_STATEMENT,
        accountId,
        this.account
      );
    }
  }

  private getInsuranceInfoAemKey(hasExternalPolicies: boolean): string {
    if (hasExternalPolicies && !this.isEy()) {
      return INSURANCE_INFO_EXTERNAL_AEM_KEY;
    }
    return INSURANCE_INFO_GENERIC_AEM_KEY;
  }

  private getNoInsuranceAlertAemKey(): string {
    return NO_INSURANCE_INFO_AEM_KEY.replace('{productFamily}', this.getProductFamily());
  }

  private setNoOccupationCodeAlert(): void {
    this.displayNoOccupationCodeMessage = this.showNoOccupationCodeAlertMessage(this.visiblePolicies);
    this.occupationCategoryEmailLink.link = OCCUPATION_CATEGORY_EMAIL_LINK.link.replace(
      '{accountNumber}',
      this.account.accountNumber
    );
  }

  private getProductFamily(): string {
    if (this.isEy()) {
      return PRODUCT_FAMILY.EY;
    } else if (this.isWgp()) {
      return PRODUCT_FAMILY.WGP;
    } else if (this.account.productDescription === PRODUCT.BT_SUPER) {
      return PRODUCT_FAMILY.BT_SUPER;
    }
    return PRODUCT_FAMILY.BT_SUPER_FOR_LIFE;
  }

  private isWgp(): boolean {
    return this.account.pdsStatus === 'WGP_CURRENT' || this.account.pdsStatus === 'WGP_CEASED';
  }

  private isEy(): boolean {
    return this.account.pdsStatus === 'EY';
  }

  refreshPolicies(): void {
    this.loading = true;
    this.panoInsuranceService
      .getPolicies(this.accountService.getAccountId())
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        (policies: InsurancePolicy[]) => (this.policies = policies),
        () => this.route.stateService.go(INVESTOR_ACCOUNT_ERROR_STATE, { accountId: this.account.key.accountId })
      );
  }

  showPysOptInModal(): void {
    this.pysOptInAllDialogSubscription = this.dialog
      .open(PanoPysOptInAllComponent, {
        ...PYS_OPT_IN_ALL_DIALOG_CONFIG,
        data: {
          accountId: this.accountService.getAccountId()
        }
      })
      .afterClosed()
      .subscribe((action: boolean) => {
        if (action) {
          this.activatePysInsuranceRequested = true;
          this.isAvailableForPysOptIn = false;
          this.refreshPolicies();
        }
      });
  }

  showActivateInsuranceDialog(optInToPmif: boolean, optInToPys: boolean): void {
    this.dialog
      .open(PanoActivateInsuranceDialogComponent, {
        ...ACTIVATE_INSURANCE_DIALOG_CONFIG,
        data: {
          accountId: this.accountService.getAccountId(),
          optInToPmif,
          optInToPys,
          showStandardCoverGreaterThan30DaysText: this.panoInsurancePoliciesUtil.getSFLPolicyWithRiskCommencementDateGreaterThan30(
            this.policies
          )
        }
      })
      .afterClosed()
      .subscribe((status: string) => {
        switch (status) {
          case OPT_IN_STATUS.success:
            this.setValuesForOptInStatusSuccessAndPYSFail();
            this.refreshPolicies();
            break;
          case OPT_IN_STATUS.pmifActivated:
            this.displayPMIFSuccessMessage = true;
            this.setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse();
            this.refreshPolicies();
            break;
          case OPT_IN_STATUS.pysFail:
            this.setValuesForOptInStatusSuccessAndPYSFail();
            this.pysSubmitFailed = true;
            this.refreshPolicies();
            break;
        }
      });
  }

  setValuesForOptInStatusSuccessAndPYSFail(): void {
    this.activateInsuranceRequested = true;
    this.setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse();
  }

  setIsAvailableForPmifPysOptInAndDisplayPMIFMessageFalse(): void {
    this.isAvailableForPmifPysOptIn = false;
    this.displayPMIFMessage = false;
  }

  openExitSiteDialog(): void {
    this.dialog.open(PanoInsuranceExitSiteDialogComponent, {
      ...DIALOG_CONFIG.DEFAULT,
      autoFocus: false,
      ariaLabel: 'Open exit website dialog'
    });
  }

  showInsuranceTiles(hasActivePolicies: boolean): void {
    if (this.isEy()) {
      this.displayInsuranceTiles = hasActivePolicies && !this.hasExternalPoliciesOnly;
    } else {
      this.displayInsuranceTiles = !this.hasExternalPoliciesOnly;
    }
  }

  showNoOccupationCodeAlertMessage(visiblePolicies: InsurancePolicy[]): boolean {
    return !!visiblePolicies?.find((policy: InsurancePolicy) =>
      this.panoInsurancePoliciesUtil.isPolicySuitableForNoOccupationCodeAlert(policy)
    );
  }

  ngOnDestroy(): void {
    this.pysOptInAllDialogSubscription.unsubscribe();
  }
}
