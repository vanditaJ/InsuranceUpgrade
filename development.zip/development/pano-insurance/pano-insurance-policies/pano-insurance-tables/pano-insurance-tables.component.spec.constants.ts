import { Account } from '@investor/account/pano-shared/interfaces';
import { AemContent } from '@panorama/services/cms';
import * as moment from 'moment-timezone';

import { InsurancePolicy, PersonBenefitDetails, PolicyStatus, PolicyType } from '../../pano-insurance.interface';
import { MOCK_POLICIES } from '../pano-insurance-policies.component.constants.spec';
import { InsuranceDetail, Insurances } from '../pano-insurance-policies.interface';

import { NOT_OPTED_IN } from './pano-insurance-tables.component.constants';

export const PERSONAL_BENEFIT_DETAILS: PersonBenefitDetails[] = [
  {
    benefits: [
      {
        benefitPeriodTerm: '4',
        waitingPeriod: '1',
        benefitPeriodFactor: 'years',
        benefits: [
          {
            frequency: 'FORTNIGHTLY',
            occupationClass: 'Blue Collar'
          }
        ]
      }
    ]
  }
];

export const MOCK_ALL_POLICIES: InsurancePolicy[] = [
  MOCK_POLICIES,
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    premium: '1.19',
    status: PolicyStatus.PENDING,
    commencementDate: null,
    endDate: null,
    sumInsured: 7000,
    policyNumber: '12300',
    westpacGroupPlan: true,
    smokerStatus: 'Not applicable',
    employerFunded: null,
    customised: false,
    external: false,
    applicableNotes: 'FN1,FN2',
    coverSubTypeId: 4,
    qualifierName: 'Employee Tailored Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 65,
    customerType: 'Retail',
    associatedTpd: [9, 11, 13]
  },
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.TPD,
    policyName: 'Total & Permanent Disablement (TPD) cover',
    external: true,
    premium: '1.19',
    status: PolicyStatus.ACTIVE,
    commencementDate: '2021-01-31T00:00:00.000+10:00',
    endDate: null,
    sumInsured: 7000,
    policyNumber: '56300',
    westpacGroupPlan: false,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 11,
    qualifierName: 'Employer Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 65,
    customerType: 'Retail'
  },
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.DEATH_AND_TPD,
    policyName: 'Death & TPD cover',
    external: true,
    premium: '21.78',
    status: PolicyStatus.INACTIVE,
    commencementDate: null,
    endDate: moment()
      .tz('Australia/Sydney')
      .endOf('month')
      .format(),
    sumInsured: 24500,
    policyNumber: '5659522',
    westpacGroupPlan: true,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 56,
    qualifierName: 'Standard Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 65,
    customerType: 'Retail'
  },
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    premium: '2.19',
    status: PolicyStatus.NOT_ACTIVE,
    commencementDate: null,
    endDate: null,
    sumInsured: 8000,
    policyNumber: '12345',
    westpacGroupPlan: true,
    smokerStatus: 'Not applicable',
    employerFunded: null,
    customised: false,
    external: true,
    applicableNotes: 'FN1,FN2',
    coverSubTypeId: 307,
    qualifierName: 'Employee Tailored Cover - not active',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 55,
    customerType: 'Retail',
    associatedTpd: []
  },
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    premium: '3.19',
    status: PolicyStatus.REQUESTED,
    commencementDate: null,
    endDate: null,
    sumInsured: 9000,
    policyNumber: '123456',
    westpacGroupPlan: true,
    smokerStatus: 'Not applicable',
    employerFunded: null,
    customised: false,
    external: true,
    applicableNotes: 'FN1,FN2',
    coverSubTypeId: 14,
    qualifierName: 'Employee Tailored Cover - request received',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 65,
    customerType: 'Retail'
  },
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.TPD,
    policyName: 'Total & Permanent Disablement (TPD) cover',
    external: true,
    premium: '1.19',
    status: PolicyStatus.ACTIVE,
    commencementDate: moment()
      .add(50, 'days')
      .format(),
    endDate: null,
    sumInsured: 7000,
    policyNumber: '56300',
    westpacGroupPlan: false,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 110,
    qualifierName: 'Employer Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 65,
    customerType: 'Retail'
  },
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    premium: '2.19',
    status: PolicyStatus.NOT_ACTIVE,
    commencementDate: null,
    endDate: null,
    sumInsured: 10000,
    policyNumber: '12345789',
    westpacGroupPlan: false,
    smokerStatus: 'Not applicable',
    employerFunded: null,
    customised: false,
    external: false,
    applicableNotes: 'FN1,FN2',
    coverSubTypeId: 14,
    qualifierName: 'Tailored Cover - not active',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 55,
    customerType: 'Retail',
    riskCommencementDate: '2021-03-02T14:00:00.000Z'
  },
  {
    applicableNotes: 'FN1',
    policyType: PolicyType.TPD,
    policyName: 'Total & Permanent Disablement (TPD) cover',
    external: true,
    premium: '1.19',
    status: PolicyStatus.INACTIVE,
    commencementDate: moment()
      .add(50, 'days')
      .format(),
    endDate: null,
    sumInsured: 7000,
    policyNumber: '56300',
    westpacGroupPlan: false,
    employerFunded: null,
    customised: true,
    smokerStatus: null,
    coverSubTypeId: 13,
    qualifierName: 'Employer Cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 65,
    customerType: 'Retail'
  }
];

export const MOCK_INSURANCE_DETAILS: InsuranceDetail[] = [
  {
    type: PolicyType.DEATH,
    title: 'Death cover',
    insurances: [
      {
        applicableNotes: 'FN1,FN2',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.DEATH,
        policyName: 'Death cover',
        external: false,
        commencementDate: null,
        endDate: null,
        icon: '*',
        premium: '1.19',
        status: PolicyStatus.PENDING,
        sumInsured: 7000,
        policyNumber: '12300',
        westpacGroupPlan: true,
        employerFunded: null,
        customised: false,
        smokerStatus: 'Not applicable',
        policyStatusLabel: 'Pending',
        optInDateLabel: NOT_OPTED_IN,
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        isOccupationCodeAbsent: true,
        ageNextBirthday: 65,
        customerType: 'Retail',
        coverSubTypeId: 4,
        qualifierName: 'Employee Tailored Cover',
        personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        associatedTpd: [9, 11, 13],
        pdsLink: 'https://hello'
      },
      {
        applicableNotes: 'FN1,FN2',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.DEATH,
        policyName: 'Death cover',
        external: true,
        commencementDate: null,
        endDate: null,
        icon: null,
        premium: '2.19',
        status: PolicyStatus.NOT_ACTIVE,
        sumInsured: 8000,
        policyNumber: '12345',
        westpacGroupPlan: true,
        employerFunded: null,
        customised: false,
        smokerStatus: 'Not applicable',
        policyStatusLabel: 'Not active',
        optInDateLabel: NOT_OPTED_IN,
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        isOccupationCodeAbsent: true,
        ageNextBirthday: 55,
        customerType: 'Retail',
        coverSubTypeId: 307,
        qualifierName: 'Employee Tailored Cover - not active',
        personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        associatedTpd: [],
        pdsLink: 'https://hello'
      },
      {
        applicableNotes: 'FN1,FN2',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.DEATH,
        policyName: 'Death cover',
        external: true,
        commencementDate: null,
        endDate: null,
        icon: null,
        premium: '3.19',
        status: PolicyStatus.REQUESTED,
        sumInsured: 9000,
        policyNumber: '123456',
        westpacGroupPlan: true,
        employerFunded: null,
        customised: false,
        smokerStatus: 'Not applicable',
        policyStatusLabel: 'Request received',
        optInDateLabel: NOT_OPTED_IN,
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        isOccupationCodeAbsent: true,
        ageNextBirthday: 65,
        customerType: 'Retail',
        coverSubTypeId: 14,
        qualifierName: 'Employee Tailored Cover - request received',
        personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        pdsLink: 'https://hello'
      },
      {
        applicableNotes: 'FN1,FN2',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.DEATH,
        policyName: 'Death cover',
        external: false,
        commencementDate: null,
        endDate: null,
        icon: null,
        premium: '2.19',
        status: PolicyStatus.NOT_ACTIVE,
        sumInsured: 10000,
        policyNumber: '12345789',
        westpacGroupPlan: false,
        employerFunded: null,
        customised: false,
        smokerStatus: 'Not applicable',
        policyStatusLabel: 'Not active',
        optInDateLabel: NOT_OPTED_IN,
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: true,
        isOccupationCodeAbsent: true,
        ageNextBirthday: 55,
        customerType: 'Retail',
        coverSubTypeId: 14,
        qualifierName: 'Tailored Cover - not active',
        personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        riskCommencementDate: '2021-03-02T14:00:00.000Z',
        pdsLink: 'https://hello'
      }
    ],
    showDeathFootNote: true,
    showInsuranceFootNote: true,
    showPendingFootNote: true,
    showInactiveFootNote: true,
    showWhoPays: true,
    showSmokerStatus: false,
    totalCoverAmount: 1076,
    totalPremiumAmount: 0,
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ],
    availableTableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ]
  },
  {
    type: PolicyType.TPD,
    title: 'Total Permanent Disability/Disablement (TPD)',
    insurances: [
      {
        applicableNotes: 'FN1',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.TPD,
        policyName: 'Total & Permanent Disablement (TPD) cover',
        external: false,
        premium: '1.19',
        status: PolicyStatus.INACTIVE,
        commencementDate: null,
        endDate: null,
        icon: null,
        sumInsured: 7000,
        policyNumber: '56300',
        westpacGroupPlan: false,
        employerFunded: null,
        customised: true,
        smokerStatus: null,
        pdsLink: null,
        policyStatusLabel: 'Active',
        optInDateLabel: NOT_OPTED_IN,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        coverSubTypeId: 71,
        qualifierName: 'Employer Cover',
        ageNextBirthday: 65,
        customerType: 'Retail',
        personBenefitDetails: MOCK_ALL_POLICIES[2].personBenefitDetails,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        }
      },
      {
        applicableNotes: 'FN1',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.TPD,
        policyName: 'Total & Permanent Disablement (TPD) cover',
        external: false,
        premium: '1.19',
        status: PolicyStatus.ACTIVE,
        commencementDate: null,
        endDate: null,
        icon: null,
        sumInsured: 7000,
        policyNumber: '56300',
        westpacGroupPlan: false,
        employerFunded: null,
        customised: true,
        smokerStatus: null,
        policyStatusLabel: 'Active',
        optInDateLabel: NOT_OPTED_IN,
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        coverSubTypeId: 110,
        qualifierName: 'Employer Cover',
        ageNextBirthday: 65,
        customerType: 'Retail',
        personBenefitDetails: MOCK_ALL_POLICIES[2].personBenefitDetails,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        pdsLink: null
      }
    ],
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ],
    availableTableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ],
    showDeathFootNote: true,
    showInsuranceFootNote: false,
    showPendingFootNote: false,
    showInactiveFootNote: false,
    showWhoPays: false,
    totalCoverAmount: 1076,
    totalPremiumAmount: 5432
  },
  {
    type: PolicyType.DEATH_AND_TPD,
    title: 'Death and Total Permanent Disability/Disablement (TPD)',
    insurances: [
      {
        applicableNotes: 'FN1',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.DEATH_AND_TPD,
        policyName: 'Death & TPD cover',
        external: true,
        premium: '21.78',
        status: PolicyStatus.INACTIVE,
        commencementDate: null,
        endDate: null,
        icon: '^',
        sumInsured: 24500,
        policyNumber: '5659522',
        westpacGroupPlan: true,
        employerFunded: null,
        customised: true,
        smokerStatus: null,
        policyStatusLabel: 'Active',
        optInDateLabel: NOT_OPTED_IN,
        coverSubTypeId: 56,
        ageNextBirthday: 65,
        customerType: 'Retail',
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        qualifierName: 'Standard Cover',
        personBenefitDetails: MOCK_ALL_POLICIES[2].personBenefitDetails,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        pdsLink: null
      },
      {
        applicableNotes: 'FN1',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: PolicyType.DEATH_AND_TPD,
        policyName: 'Death & TPD cover',
        external: false,
        premium: '21.78',
        status: PolicyStatus.INACTIVE,
        commencementDate: null,
        endDate: null,
        icon: '^',
        sumInsured: 24500,
        policyNumber: '5659522',
        westpacGroupPlan: true,
        employerFunded: null,
        customised: true,
        smokerStatus: null,
        policyStatusLabel: 'Active',
        optInDateLabel: NOT_OPTED_IN,
        coverSubTypeId: 56,
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        qualifierName: 'Standard Cover',
        personBenefitDetails: MOCK_ALL_POLICIES[2].personBenefitDetails,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        pdsLink: null
      }
    ],
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ],
    availableTableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ],
    showDeathFootNote: true,
    showInsuranceFootNote: false,
    showPendingFootNote: false,
    showInactiveFootNote: true,
    showWhoPays: true,
    totalCoverAmount: 0,
    totalPremiumAmount: 0
  },
  {
    type: PolicyType.INCOME_PROTECTION,
    title: 'Salary Continuance Insurance (SCI)',
    insurances: [
      {
        premium: '30',
        status: PolicyStatus.ACTIVE,
        commencementDate: null,
        endDate: null,
        icon: '^',
        smokerStatus: 'Non-smoker',
        customised: true,
        employerFunded: true,
        applicableNotes: 'TT1',
        policyStatusLabel: 'Active',
        optInDateLabel: NOT_OPTED_IN,
        popoverText: 'Help-IP-0334',
        benefitFrequencyLabel: 'per month',
        occupationClass: 'N/A',
        policyNumber: '13587',
        westpacGroupPlan: false,
        policyType: PolicyType.INCOME_PROTECTION,
        policyName: 'Salary Continuance',
        sumInsured: 6000,
        external: true,
        ageNextBirthday: 65,
        customerType: 'Retail',
        coverSubTypeId: 12,
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: true,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        qualifierName: 'Employee Salary Continuance Insurance',
        personBenefitDetails: MOCK_POLICIES.personBenefitDetails,
        benefits: {
          waitingPeriod: '90',
          benefitPeriodFactor: 'Years',
          benefitPeriodTerm: '2',
          benefits: [
            {
              frequency: 'MONTHLY',
              occupationClass: 'N/A'
            }
          ]
        },
        pdsLink: null
      }
    ],
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Waiting period'
      },
      {
        name: 'Benefit period'
      },
      {
        name: 'Benefit amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ],
    availableTableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Waiting period'
      },
      {
        name: 'Benefit period'
      },
      {
        name: 'Benefit amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Opt in date',
        optInDate: true
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ],
    showDeathFootNote: false,
    showInsuranceFootNote: false,
    showPendingFootNote: false,
    showInactiveFootNote: false,
    showWhoPays: false,
    showSmokerStatus: true
  }
];

export const TPD_INSURANCE: Insurances = {
  applicableNotes: 'FN1',
  popoverText: '',
  occupationClass: 'Blue Collar',
  benefitFrequencyLabel: 'per fortnight',
  policyType: PolicyType.TPD,
  policyName: 'Total & Permanent Disablement (TPD) cover',
  external: true,
  premium: '1.19',
  status: PolicyStatus.ACTIVE,
  commencementDate: null,
  endDate: null,
  icon: null,
  sumInsured: 7000,
  policyNumber: '56300',
  westpacGroupPlan: null,
  ageNextBirthday: 65,
  customerType: 'Retail',
  employerFunded: null,
  customised: true,
  smokerStatus: null,
  policyStatusLabel: 'Active',
  optInDateLabel: NOT_OPTED_IN,
  coverSubTypeId: 10,
  qualifierName: 'Employer Cover',
  personBenefitDetails: MOCK_ALL_POLICIES[2].personBenefitDetails,
  benefits: {
    benefitPeriodTerm: '4',
    waitingPeriod: '1',
    benefitPeriodFactor: 'years',
    benefits: [
      {
        frequency: 'FORTNIGHTLY',
        occupationClass: 'Blue Collar'
      }
    ]
  },
  pdsLink: null
};

export const MOCK_INSURANCE_DETAIL_FOR_TOTAL_ROW: InsuranceDetail[] = [
  {
    type: 'DEATH',
    title: 'Death cover',
    insurances: [
      {
        applicableNotes: 'FN1,FN2',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: 'DEATH',
        policyName: 'Death cover',
        external: true,
        commencementDate: null,
        endDate: null,
        icon: '*',
        premium: '0.00',
        status: 'PROPOSAL',
        sumInsured: 7000,
        policyNumber: '12300',
        westpacGroupPlan: true,
        optInDateLabel: NOT_OPTED_IN,
        employerFunded: null,
        customised: true,
        smokerStatus: 'Non-smoker',
        policyStatusLabel: 'Pending',
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        coverSubTypeId: 14,
        qualifierName: 'Employee Tailored Cover',
        personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        pdsLink: null
      },
      {
        applicableNotes: 'FN1,FN2',
        popoverText: '',
        occupationClass: 'Blue Collar',
        benefitFrequencyLabel: 'per fortnight',
        policyType: 'DEATH',
        policyName: 'Death cover',
        external: true,
        commencementDate: null,
        endDate: null,
        icon: '*',
        premium: '0.00',
        status: 'PROPOSAL',
        sumInsured: 7000,
        policyNumber: '12300',
        westpacGroupPlan: true,
        employerFunded: null,
        customised: true,
        smokerStatus: 'Non-smoker',
        optInDateLabel: NOT_OPTED_IN,
        policyStatusLabel: 'Pending',
        showMenuAction: true,
        showChangeMenuAction: true,
        showDecreaseMenuAction: false,
        showIncreaseMenuAction: false,
        showEyIncreaseMenuAction: false,
        policyGT60DaysMessage: null,
        showPolicyLT90DaysAlert: false,
        showPmifNotActiveGT30DaysAlert: false,
        coverSubTypeId: 14,
        qualifierName: 'Employee Tailored Cover',
        personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
        benefits: {
          benefitPeriodTerm: '4',
          waitingPeriod: '1',
          benefitPeriodFactor: 'years',
          benefits: [
            {
              frequency: 'FORTNIGHTLY',
              occupationClass: 'Blue Collar'
            }
          ]
        },
        pdsLink: null
      }
    ],
    showDeathFootNote: true,
    showInsuranceFootNote: true,
    showPendingFootNote: true,
    showInactiveFootNote: true,
    showWhoPays: true,
    showSmokerStatus: true,
    totalCoverAmount: 1076,
    totalPremiumAmount: 0,
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount',
        align: 'text-right'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Status'
      },
      {
        name: 'Actions',
        align: 'text-right'
      }
    ]
  }
];

export const MOCK_AEM_CONTENT_INSURANCE_TABLES: AemContent[] = [
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'change_cover_age_modal',
      description: 'mock content for change_cover_age_modal'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'cancel_cover_death_modal',
      description: 'mock content for cancel_cover_death_modal'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'view_cover_60_days_message',
      description: 'mock content for view_cover_60_days_message'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'view_cover_90_days_message',
      description: 'mock content for view_cover_90_days_message'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'missing_occupation_message',
      description: 'mock content for missing_occupation_message'
    }
  },
  {
    type: 'title_link',
    id: 'id',
    data: {
      headerText: 'ey_increase_modal',
      description: 'mock content for ey_increase_modal'
    }
  },
  {
    type: 'title_link',
    id: 'important-super-changes',
    data: {
      headerText: 'view_cover_tailored_60_days_message',
      description: 'mock content for view_cover_tailored_60_days_message'
    }
  }
];

export const MOCK_ACCOUNT: Account = {
  key: {
    accountId: '1234'
  },
  accountName: 'test1',
  accountNumber: '4542524',
  firstMoneyReceivedDate: '2021-01-20T13:00:00.000Z',
  owners: [
    {
      age: 50,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Female',
      lastName: 'LastName'
    }
  ],
  pdsStatus: 'DEFAULT',
  product: {}
};

export const MOCK_BT_SUPER_ACCOUNT: Account = {
  key: {
    accountId: '1234'
  },
  accountNumber: null,
  accountName: null,
  firstMoneyReceivedDate: null,
  owners: [
    {
      age: 25,
      dateOfBirth: '',
      emails: [],
      firstName: 'Name',
      gender: 'Male',
      lastName: 'LastName'
    }
  ],
  pdsStatus: 'DEFAULT',
  product: {},
  productDescription: 'BT Super'
};

export const MOCK_60_90_DAYS_INSURANCE_DETAIL: InsuranceDetail = {
  type: PolicyType.DEATH,
  title: 'Death cover',
  insurances: [
    {
      applicableNotes: 'FN1,FN2',
      popoverText: '',
      occupationClass: 'Blue Collar',
      benefitFrequencyLabel: 'per fortnight',
      policyType: PolicyType.DEATH,
      policyName: 'Death cover',
      external: false,
      commencementDate: null,
      endDate: null,
      icon: '*',
      premium: '1.19',
      status: PolicyStatus.PENDING,
      sumInsured: 7000,
      policyNumber: '12300',
      westpacGroupPlan: true,
      employerFunded: null,
      customised: false,
      smokerStatus: 'Not applicable',
      policyStatusLabel: 'Pending',
      optInDateLabel: NOT_OPTED_IN,
      showMenuAction: true,
      showChangeMenuAction: true,
      showDecreaseMenuAction: false,
      showIncreaseMenuAction: false,
      showEyIncreaseMenuAction: false,
      policyGT60DaysMessage: 'policy 60 days message',
      showPolicyLT90DaysAlert: true,
      showPmifNotActiveGT30DaysAlert: false,
      ageNextBirthday: 65,
      customerType: 'Retail',
      coverSubTypeId: 14,
      qualifierName: 'Employee Tailored Cover',
      personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
      benefits: {
        benefitPeriodTerm: '4',
        waitingPeriod: '1',
        benefitPeriodFactor: 'years',
        benefits: [
          {
            frequency: 'FORTNIGHTLY',
            occupationClass: 'Blue Collar'
          }
        ]
      },
      pdsLink: null
    },
    {
      applicableNotes: 'FN1,FN2',
      popoverText: '',
      occupationClass: 'Blue Collar',
      benefitFrequencyLabel: 'per fortnight',
      policyType: PolicyType.DEATH,
      policyName: 'Death cover',
      external: true,
      commencementDate: null,
      endDate: null,
      icon: null,
      premium: '2.19',
      status: PolicyStatus.NOT_ACTIVE,
      sumInsured: 8000,
      policyNumber: '12345',
      westpacGroupPlan: true,
      employerFunded: null,
      customised: false,
      smokerStatus: 'Not applicable',
      policyStatusLabel: 'Not active',
      optInDateLabel: NOT_OPTED_IN,
      showMenuAction: true,
      showChangeMenuAction: true,
      showDecreaseMenuAction: false,
      showIncreaseMenuAction: false,
      showEyIncreaseMenuAction: false,
      policyGT60DaysMessage: 'policy 60 days message',
      showPolicyLT90DaysAlert: true,
      showPmifNotActiveGT30DaysAlert: false,
      ageNextBirthday: 55,
      customerType: 'Retail',
      coverSubTypeId: 14,
      qualifierName: 'Employee Tailored Cover - not active',
      personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
      benefits: {
        benefitPeriodTerm: '4',
        waitingPeriod: '1',
        benefitPeriodFactor: 'years',
        benefits: [
          {
            frequency: 'FORTNIGHTLY',
            occupationClass: 'Blue Collar'
          }
        ]
      },
      pdsLink: null
    }
  ],
  showDeathFootNote: true,
  showInsuranceFootNote: true,
  showPendingFootNote: true,
  showInactiveFootNote: true,
  showWhoPays: true,
  showSmokerStatus: false,
  totalCoverAmount: 1076,
  totalPremiumAmount: 0,
  tableTitles: [
    {
      name: 'Cover type'
    },
    {
      name: 'Cover amount',
      align: 'text-right'
    },
    {
      name: 'Monthly premium',
      align: 'text-right'
    },
    {
      name: 'Who pays?',
      label: 'Who pays',
      whoPays: true
    },
    {
      name: 'Occupation category'
    },
    {
      name: 'Opt in date',
      optInDate: true
    },
    {
      name: 'Smoker status',
      smoking: true
    },
    {
      name: 'Status'
    },
    {
      name: 'Actions',
      align: 'text-right'
    }
  ],
  availableTableTitles: [
    {
      name: 'Cover type'
    },
    {
      name: 'Cover amount',
      align: 'text-right'
    },
    {
      name: 'Monthly premium',
      align: 'text-right'
    },
    {
      name: 'Who pays?',
      label: 'Who pays',
      whoPays: true
    },
    {
      name: 'Occupation category'
    },
    {
      name: 'Opt in date',
      optInDate: true
    },
    {
      name: 'Smoker status',
      smoking: true
    },
    {
      name: 'Status'
    },
    {
      name: 'Actions',
      align: 'text-right'
    }
  ]
};

export const MOCK_NO_OCCUPATION_CODE_INSURANCE_DETAIL: InsuranceDetail = {
  title: 'Death cover',
  type: PolicyType.DEATH,
  insurances: [
    {
      policyType: 'DEATH',
      policyName: 'Death cover',
      policyNumber: '5694734',
      qualifierName: 'Standard cover',
      customerType: 'PCS',
      policyFrequency: 'MONTHLY',
      premium: '15.14',
      status: 'IN_FORCE',
      commencementDate: '2021-08-01T00:00:00.000+10:00',
      endDate: null,
      personBenefitDetails: [
        {
          benefits: [
            {
              benefitPeriodFactor: null,
              benefitPeriodTerm: null,
              waitingPeriod: null,
              benefits: [
                {
                  frequency: 'MONTHLY',
                  occupationClass: 'N/A'
                }
              ]
            }
          ]
        }
      ],
      sumInsured: 125000,
      unitsOfCover: null,
      coverSubTypeId: 93,
      applicableNotes: 'II1,II2,FN1',
      smokerStatus: null,
      coverLevel: 'Single',
      ageNextBirthday: 41,
      employerFunded: false,
      westpacGroupPlan: false,
      customised: false,
      groupInsurance: false,
      external: false,
      riskCommencementDate: '2021-07-31T14:00:00.000Z',
      associatedTpd: [],
      popoverText: '',
      occupationClass: 'N/A',
      benefitFrequencyLabel: 'per fortnight',
      icon: null,
      policyStatusLabel: 'Not active',
      optInDateLabel: NOT_OPTED_IN,
      showMenuAction: true,
      showChangeMenuAction: true,
      showDecreaseMenuAction: false,
      showIncreaseMenuAction: false,
      showEyIncreaseMenuAction: false,
      showPolicyLT90DaysAlert: true,
      showPmifNotActiveGT30DaysAlert: false,
      isOccupationCodeAbsent: true,
      benefits: null,
      pdsLink: null
    }
  ],
  tableTitles: [],
  availableTableTitles: []
};

export const MOCK_60_DAYS_POLICIES: InsurancePolicy[] = [
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    premium: '1.19',
    status: PolicyStatus.ACTIVE,
    commencementDate: null,
    endDate: null,
    sumInsured: 7000,
    policyNumber: '12300',
    westpacGroupPlan: true,
    smokerStatus: 'Not applicable',
    employerFunded: null,
    customised: false,
    external: false,
    applicableNotes: 'FN1,FN2',
    coverSubTypeId: 4,
    qualifierName: 'Essential cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 56,
    customerType: 'PCS',
    associatedTpd: []
  },
  {
    policyType: PolicyType.DEATH,
    policyName: 'Death cover',
    premium: '2.19',
    status: PolicyStatus.ACTIVE,
    commencementDate: null,
    endDate: null,
    sumInsured: 8000,
    policyNumber: '12345',
    westpacGroupPlan: true,
    smokerStatus: 'Not applicable',
    employerFunded: null,
    customised: false,
    external: true,
    applicableNotes: 'FN1,FN2',
    coverSubTypeId: 307,
    qualifierName: 'Tailored cover',
    personBenefitDetails: PERSONAL_BENEFIT_DETAILS,
    ageNextBirthday: 55,
    customerType: 'PCS',
    associatedTpd: []
  }
];
