import { Alert } from '@bt/components/alert';
import { Button } from '@bt/components/button';
import { Icon } from '@bt/components/icon';

import { PolicyStatus, PolicyType } from '../../pano-insurance.interface';
import { InsuranceDetail, PoliciesInScope } from '../pano-insurance-policies.interface';

export const INSURANCE_DETAILS: InsuranceDetail[] = [
  {
    type: PolicyType.DEATH,
    title: 'Death cover',
    insurances: [],
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Opt in date'
      },
      {
        name: 'Status',
        align: ' text-nowrap'
      },
      {
        name: 'Actions',
        align: 'text-right text-nowrap'
      }
    ]
  },
  {
    type: PolicyType.TPD,
    title: 'Total Permanent Disability/Disablement (TPD)',
    insurances: [],
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Opt in date'
      },
      {
        name: 'Status',
        align: ' text-nowrap'
      },
      {
        name: 'Actions',
        align: 'text-right text-nowrap'
      }
    ]
  },
  {
    type: PolicyType.DEATH_AND_TPD,
    title: 'Death and Total Permanent Disability/Disablement (TPD)',
    insurances: [],
    tableTitles: [
      {
        name: 'Cover type'
      },
      {
        name: 'Cover amount'
      },
      {
        name: 'Monthly premium',
        align: 'text-right'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true
      },
      {
        name: 'Occupation category'
      },
      {
        name: 'Smoker status',
        smoking: true
      },
      {
        name: 'Opt in date'
      },
      {
        name: 'Status',
        align: ' text-nowrap'
      },
      {
        name: 'Actions',
        align: 'text-right text-nowrap'
      }
    ]
  },
  {
    type: PolicyType.INCOME_PROTECTION,
    title: 'Salary Continuance Insurance (SCI)',
    insurances: [],
    tableTitles: [
      {
        name: 'Cover type',
        align: 'px-10'
      },
      {
        name: 'Waiting period',
        align: 'px-10'
      },
      {
        name: 'Benefit period',
        align: 'px-10'
      },
      {
        name: 'Benefit amount',
        align: 'text-right px-10'
      },
      {
        name: 'Monthly premium',
        align: 'text-right px-10'
      },
      {
        name: 'Who pays?',
        label: 'Who pays',
        whoPays: true,
        align: 'text-nowrap px-10'
      },
      {
        name: 'Occupation category',
        align: 'px-10'
      },
      {
        name: 'Smoker status',
        smoking: true,
        align: 'px-10'
      },
      {
        name: 'Opt in date',
        align: 'px-10'
      },
      {
        name: 'Status',
        align: 'text-nowrap px-10'
      },
      {
        name: 'Actions',
        align: 'text-right text-nowrap px-10'
      }
    ]
  }
];

export const POLICY_STATUS = [
  {
    type: PolicyStatus.ACTIVE,
    name: 'Active'
  },
  {
    type: PolicyStatus.PENDING,
    name: 'Pending'
  },
  {
    type: PolicyStatus.INACTIVE,
    name: 'Inactive'
  },
  {
    type: PolicyStatus.DECLINED,
    name: 'Not covered'
  },
  {
    type: PolicyStatus.NOT_ACTIVE,
    name: 'Not active'
  },
  {
    type: PolicyStatus.REQUESTED,
    name: 'Request received'
  }
];

export const BENEFIT_FREQUENCY = [
  {
    type: 'MONTHLY',
    name: 'per month'
  },
  {
    type: 'FORTNIGHTLY',
    name: 'per fortnight'
  }
];

export const CHANGE_COVER_BUTTON: Button = {
  colourModifier: 'primary',
  action: 'button',
  label: 'Change cover',
  size: 'medium',
  type: 'outline'
};

export const CANCEL_COVER_BUTTON: Button = {
  colourModifier: 'primary',
  action: 'button',
  label: 'Cancel cover',
  size: 'medium',
  type: 'outline'
};

export const POPOVER_ICON: Icon = {
  name: 'icon-question-solid',
  type: 'info',
  size: 'x-small'
};

export const BASIC_ALERT: Alert = {
  type: 'info',
  outline: false,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const POLICY_GT_60_DAYS_ALERT: Alert = {
  type: 'info',
  inline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const POLICY_LT_90_DAYS_ALERT: Alert = {
  type: 'info',
  inline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const NO_OCCUPATION_CODE_INLINE_ALERT: Alert = {
  type: 'warning',
  inline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const PENDING_POLICY_ALERT: Alert = {
  type: 'info',
  outline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const ACTION_BUTTON: Button = {
  type: 'outline',
  colourModifier: 'basic',
  action: 'button',
  shapeModifier: 'square',
  icon: {
    name: 'icon-menu',
    size: 'small'
  },
  size: 'small',
  a11yProps: {
    ariaLabel: 'Actions menu'
  }
};

export const PMIF_PENDING_STATUS_ALERT: Alert = {
  type: 'warning',
  messages: 'Not active',
  inline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const NOT_OPTED_IN: string = 'Not opted in';

export const CANCEL_INSURANCE_STATE = 'app.investor.account.cancelInsurance';

export const CHANGE_INSURANCE_STATE = 'app.investor.account.changeCoverInsurance';

export const SHOW_ACTION_MENU: Array<string> = [
  PolicyStatus.ACTIVE,
  PolicyStatus.PENDING,
  PolicyStatus.NOT_ACTIVE,
  PolicyStatus.REQUESTED
];

export const SHOW_ACTION_MENU_AMEND: Array<string> = [PolicyStatus.ACTIVE, PolicyStatus.PENDING];

export const DAYS_BASED_ALERT_STATUS: Array<string> = [PolicyStatus.ACTIVE, PolicyStatus.PENDING];

export const CHANGE_COVER_POLICY_TYPE: Array<string> = [PolicyType.DEATH, PolicyType.DEATH_AND_TPD];

export const VIEW_COVER_60_DAYS_AEM_KEY: string = 'view_cover_60_days_message';

export const VIEW_COVER_TAILORED_60_DAYS_AEM_KEY: string = 'view_cover_tailored_60_days_message';

export const VIEW_COVER_90_DAYS_AEM_KEY: string = 'view_cover_90_days_message';

export const VIEW_COVER_NO_OCCUPATION_CODE_AEM_KEY: string = 'missing_occupation_message';

export const CANCEL_COVER_DEATH_MODAL_AEM_KEY: string = 'cancel_cover_death_modal';

export const CHANGE_COVER_AGE_MODAL_AEM_KEY: string = 'change_cover_age_modal';

export const INCREASE_COVER_EY_MODAL_AEM_KEY: string = 'ey_increase_modal';

export const BT_POLICIES_IN_SCOPE: PoliciesInScope = {
  coverSubTypeIds: [314],
  coverSubTypeIdRange: [
    { start: 14, end: 52 },
    { start: 57, end: 92 },
    { start: 141, end: 143 },
    { start: 147, end: 236 },
    { start: 258, end: 308 }
  ]
};

export const BT_60_DAY_POLICIES_IN_SCOPE: PoliciesInScope = {
  coverSubTypeIdRange: [{ start: 144, end: 146 }]
};

export const PMIF_NOT_ACTIVE_GT_30_DAYS_ALERT: Alert = {
  type: 'warning',
  inline: true,
  a11yProps: {
    ariaRole: 'none'
  }
};

export const INACTIVE_FOOTNOTE: string =
  '^ Your cover is still active and will be cancelled effective the last day of this month.';

export const PENDING_FOOTNOTE: string =
  '* Your cover will commence when the first contribution has been received in your BT Super for Life account.';

export const EY_PDS_STATUS: string = 'EY';

export const EY_INSURER_CODE: string = 'Ernst & Young';
