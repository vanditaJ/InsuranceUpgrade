import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DIALOG_CONFIG } from '@bt/components/common';
import { CopyMatrixPipe } from '@bt/pipes/copy-matrix';
import * as moment from 'moment-timezone';

import { PanoAlertDialogComponent } from '../pano-alert-dialog/pano-alert-dialog.component';
import {
  TEST_ADD_EXTERNAL_FORM,
  TEST_ASSET_TYPES,
  TEST_DP_PROPERTY_TYPES
} from '../pano-external-assets-constants/pano-external-assets-constants.spec.data';
import {
  ADD_ASSET_BUTTON,
  ASSET_TYPES,
  CANCEL_ADD_ASSET_BUTTON,
  DEFAULT_ADD_ASSET_PROPS,
  MAX_ASSET_ALERT_BUTTON,
  MAX_ASSET_ALERT_HEADER
} from '../pano-external-assets-constants/pano-external-assets.constants';

import { PanoAddAssetFormCreator } from './pano-add-asset-form-creator';
import { PanoAddAssetComponent } from './pano-add-asset.component';

@Component({
  template: `
    <pano-add-asset
      [assetTypes]="assetTypes"
      [propertyTypes]="propertyTypes"
      [totalAssetsCount]="totalAssetsCount"
    ></pano-add-asset>
  `
})
class TestHostComponent {
  assetTypes = TEST_ASSET_TYPES;
  propertyTypes = TEST_DP_PROPERTY_TYPES;
  totalAssetsCount = 1;
}

describe('PanoAddAssetComponent', () => {
  let component: PanoAddAssetComponent;
  let fixture: ComponentFixture<PanoAddAssetComponent>;
  let externalAssetsAddFormCreator: PanoAddAssetFormCreator;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PanoAddAssetComponent, TestHostComponent],
        providers: [PanoAddAssetFormCreator, { provide: CopyMatrixPipe, useValue: { transform: () => {} } }],
        imports: [MatDialogModule, MatSelectModule, NoopAnimationsModule, ReactiveFormsModule],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PanoAddAssetComponent);
    component = fixture.componentInstance;
    component.assetTypes = TEST_ASSET_TYPES;
    component.addExternalAssetsForm = TEST_ADD_EXTERNAL_FORM as FormGroup;
    fixture.detectChanges();
  });

  describe('component', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('ngOnInit', () => {
      it('should have assetTypeCode control with null and assetClassesSubscription for valuechange defined', () => {
        component.ngOnInit();

        expect(component.addExternalAssetsForm).toBeDefined();
        expect(component.addExternalAssetsForm.get('assetTypeCode').value).toBeNull();
        expect((component as any).assetClassesSubscription).toBeDefined();
      });

      it('should set selected assets classes when assetTypeCode value changes with valid asset type code', () => {
        component.ngOnInit();
        component.addExternalAssetsForm.get('assetTypeCode').setValue(TEST_ASSET_TYPES[0].assetTypeCode);

        expect(component.selectedAssetClasses).toBe(TEST_ASSET_TYPES[0].assetClasses);
      });

      it('should set empty array to selected assets classes when assetTypeCode value changes with null', () => {
        component.ngOnInit();
        component.addExternalAssetsForm.get('assetTypeCode').setValue(null);

        expect(component.selectedAssetClasses).toEqual([]);
      });
    });

    describe('addNewAssetFormDetails', () => {
      beforeEach(() => {
        spyOn(component.assetAdd, 'emit');
        spyOn(component.addExternalAssetsForm, 'reset');
        externalAssetsAddFormCreator = TestBed.inject(PanoAddAssetFormCreator);
        component.totalAssetsCount = 1;
      });

      it('should not emit assetAdd and also should not clear form if form is invalid', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('cash')
        );
        fixture.detectChanges();
        const formData = {
          assetTypeCode: 'cash',
          assetDetails: {
            marketValue: null,
            positionName: '',
            valuationDate: null
          }
        };
        component.addExternalAssetsForm.patchValue({ ...formData });
        component.addNewAssetFormDetails();
        expect(component.assetAdd.emit).not.toHaveBeenCalled();
        expect(component.addExternalAssetsForm.reset).not.toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getCashAssetDetails if form valid for AssetType Cash', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('cash')
        );
        fixture.detectChanges();
        spyOn(component, 'getCashAssetDetails');
        spyOn(component, 'getTermDepositAssetDetails');
        spyOn(component, 'getInternationalShareOrOtherAssetDetails');
        spyOn(component, 'getManagedPortfolioAssetDetails');

        const valuationDate = moment().tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.cash.assetClass,
          assetTypeCode: ASSET_TYPES.cash.code,
          marketValue: '123',
          positionName: 'test',
          source: '',
          valuationDate
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.cash.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });

        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.cash.assetClass,
          assetTypeCode: ASSET_TYPES.cash.code,
          marketValue: '123',
          positionName: 'test',
          valuationDate
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
        expect(component.getCashAssetDetails).toHaveBeenCalled();
        expect(component.getTermDepositAssetDetails).not.toHaveBeenCalled();
        expect(component.getInternationalShareOrOtherAssetDetails).not.toHaveBeenCalled();
        expect(component.getManagedPortfolioAssetDetails).not.toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getTermDepositAssetDetails if form valid for AssetType TD', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('td')
        );
        fixture.detectChanges();
        spyOn(component, 'getCashAssetDetails');
        spyOn(component, 'getTermDepositAssetDetails');
        spyOn(component, 'getInternationalShareOrOtherAssetDetails');
        spyOn(component, 'getManagedPortfolioAssetDetails');

        const valuationDate = moment().tz('Australia/Sydney');
        const maturityDate = moment()
          .add(4, 'day')
          .tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.cash.assetClass,
          assetTypeCode: ASSET_TYPES.td.code,
          marketValue: '123',
          positionName: 'test',
          source: '',
          valuationDate,
          maturityDate
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.td.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });

        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.cash.assetClass,
          assetTypeCode: ASSET_TYPES.td.code,
          marketValue: '123',
          positionName: 'test',
          valuationDate
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
        expect(component.getCashAssetDetails).not.toHaveBeenCalled();
        expect(component.getTermDepositAssetDetails).toHaveBeenCalled();
        expect(component.getInternationalShareOrOtherAssetDetails).not.toHaveBeenCalled();
        expect(component.getManagedPortfolioAssetDetails).not.toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getInternationalShareAssetDetails if form valid for AssetType ils', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('ils')
        );
        fixture.detectChanges();

        const valuationDate = moment().tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.ils.label,
          assetTypeCode: ASSET_TYPES.ils.code,
          marketValue: '123',
          positionName: 'test',
          source: 'ab',
          quantity: '12',
          positionCode: 'AAA9999AA',
          valuationDate
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.ils.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });
        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.ils.label,
          assetTypeCode: ASSET_TYPES.ils.code,
          marketValue: '123',
          positionName: 'test',
          quantity: '12',
          source: 'ab',
          positionCode: 'AAA9999AA',
          valuationDate
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getDirectPropertyAssetDetails if form valid for AssetType DP', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('dp')
        );
        fixture.detectChanges();

        const valuationDate = moment().tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.dp.assetClass,
          assetTypeCode: ASSET_TYPES.dp.code,
          marketValue: '123',
          positionName: 'test',
          valuationDate,
          propertyType: 'RES'
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.dp.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });

        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.dp.assetClass,
          assetTypeCode: ASSET_TYPES.dp.code,
          marketValue: '123',
          positionName: 'test',
          valuationDate,
          propertyType: 'RES'
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getManagedPortfolioAssetDetails if form valid for AssetType mp', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('mp')
        );
        fixture.detectChanges();

        const valuationDate = moment().tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.mp.label,
          assetTypeCode: ASSET_TYPES.mp.code,
          marketValue: '123',
          positionName: 'test',
          source: 'ab',
          positionCode: 'AAA9999AA',
          valuationDate
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.mp.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });
        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.mp.label,
          assetTypeCode: ASSET_TYPES.mp.code,
          marketValue: '123',
          positionName: 'test',
          source: 'ab',
          positionCode: 'AAA9999AA',
          valuationDate
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getManagedFundsAsset if form valid for AssetType mf', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('mf')
        );
        fixture.detectChanges();

        const valuationDate = moment().tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.mf.label,
          assetTypeCode: ASSET_TYPES.mf.code,
          marketValue: '123',
          positionName: 'test',
          source: '',
          quantity: '123',
          assetId: 'test',
          positionCode: 'AAA9999AA',
          panoramaAssetDetails: { assetCode: 'test', assetName: 'test' },
          isPanoramaAsset: true,
          valuationDate
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.mf.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });
        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.mf.label,
          assetTypeCode: ASSET_TYPES.mf.code,
          marketValue: '123',
          positionName: 'test',
          source: '',
          quantity: '123',
          assetId: 'test',
          positionCode: 'AAA9999AA',
          isPanoramaAsset: true,
          valuationDate
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getManagedFundsAsset if form valid for AssetType ls', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('ls')
        );
        fixture.detectChanges();

        const valuationDate = moment().tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.ls.label,
          assetTypeCode: ASSET_TYPES.ls.code,
          marketValue: '123',
          positionName: 'test',
          source: '',
          quantity: '123',
          assetId: 'test',
          positionCode: 'AAA9999AA',
          panoramaAssetDetails: { assetCode: 'test', assetName: 'test' },
          isPanoramaAsset: true,
          valuationDate
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.ls.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });
        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.ls.label,
          assetTypeCode: ASSET_TYPES.ls.code,
          marketValue: '123',
          positionName: 'test',
          source: '',
          quantity: '123',
          assetId: 'test',
          positionCode: 'AAA9999AA',
          isPanoramaAsset: true,
          valuationDate
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
      });

      it('should emit assetAdd,clear the form and call getOtherAssetDetails if form valid for AssetType oth', () => {
        component.addExternalAssetsForm.setControl(
          'assetDetails',
          externalAssetsAddFormCreator.createAddAssetForm('oth')
        );
        fixture.detectChanges();

        const valuationDate = moment().tz('Australia/Sydney');
        const assetDetails = {
          assetClassCode: ASSET_TYPES.oth.label,
          assetTypeCode: ASSET_TYPES.oth.code,
          marketValue: '123',
          positionName: 'test',
          source: 'ab',
          quantity: '',
          positionCode: 'ABCD',
          valuationDate
        };

        const formData = {
          assetTypeCode: ASSET_TYPES.oth.code,
          assetDetails
        };
        component.addExternalAssetsForm.patchValue({ ...formData });
        component.addNewAssetFormDetails();

        expect(component.assetAdd.emit).toHaveBeenCalledWith({
          ...DEFAULT_ADD_ASSET_PROPS,
          assetClassCode: ASSET_TYPES.oth.label,
          assetTypeCode: ASSET_TYPES.oth.code,
          marketValue: '123',
          positionName: 'test',
          quantity: '',
          source: 'ab',
          positionCode: 'ABCD',
          valuationDate
        });
        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
      });

      it('should call showMaxAssetAlertDialog when AssetCount is equal or greater than MAX_ASSET_COUNT', () => {
        spyOn(component, 'showMaxAssetAlertDialog');
        component.totalAssetsCount = 50;

        component.addNewAssetFormDetails();
        expect(component.showMaxAssetAlertDialog).toHaveBeenCalled();
        expect(component.assetAdd.emit).not.toHaveBeenCalled();
        expect(component.addExternalAssetsForm.reset).not.toHaveBeenCalled();
      });
    });

    describe('getCashAssetDetails', () => {
      it('should assign source form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          source: new FormControl('Test source of cash')
        });

        component.getCashAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['source']).toBe(newAssetFormGroup.get('source').value);
      });
    });

    describe('getTermDepositAssetDetails', () => {
      it('should assign source and maturityDate form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          source: new FormControl('Test source of TD'),
          maturityDate: new FormControl('2040-10-16T00:00:00.000+11:00')
        });

        component.getTermDepositAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['source']).toBe(newAssetFormGroup.get('source').value);
        expect(newAssetDetails['maturityDate']).toEqual(
          moment(newAssetFormGroup.get('maturityDate').value).tz('Australia/Sydney')
        );
      });
    });

    describe('getInternationalShareAssetDetails', () => {
      it('should assign source, positionCode and quantity form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          source: new FormControl('Test source of ILS'),
          positionCode: new FormControl('ABCDEF'),
          quantity: new FormControl('1234')
        });

        component.getInternationalShareOrOtherAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['source']).toBe(newAssetFormGroup.get('source').value);
        expect(newAssetDetails['positionCode']).toEqual(newAssetFormGroup.get('positionCode').value);
        expect(newAssetDetails['quantity']).toEqual(newAssetFormGroup.get('quantity').value);
      });
    });

    describe('getDirectPropertyAssetDetails', () => {
      it('should assign propertyType form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          propertyType: new FormControl('Test propertyType of dp')
        });

        component.getDirectPropertyAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['propertyType']).toBe(newAssetFormGroup.get('propertyType').value);
      });
    });

    describe('getManagedPortfolioAssetDetails', () => {
      it('should assign source and positionCode  form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          source: new FormControl('Test source of MP'),
          positionCode: new FormControl('AAA9999AA')
        });

        component.getManagedPortfolioAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['source']).toBe(newAssetFormGroup.get('source').value);
        expect(newAssetDetails['positionCode']).toEqual(newAssetFormGroup.get('positionCode').value);
      });
    });

    describe('getManagedFundOrListedSecurityAssetDetails', () => {
      it('should assign propertyType form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          panoramaAssetDetails: new FormControl('Test panoramaAssetDetails of ls or mf'),
          isPanoramaAsset: new FormControl(false),
          assetId: new FormControl('1234'),
          positionCode: new FormControl('Test code of ls or mf'),
          source: new FormControl('Test source of ls or mf'),
          quantity: new FormControl('123')
        });

        component.getManagedFundOrListedSecurityAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['isPanoramaAsset']).toBe(newAssetFormGroup.get('isPanoramaAsset').value);
        expect(newAssetDetails['assetId']).toBe(newAssetFormGroup.get('assetId').value);
        expect(newAssetDetails['positionCode']).toBe(newAssetFormGroup.get('positionCode').value);
        expect(newAssetDetails['source']).toBe(newAssetFormGroup.get('source').value);
        expect(newAssetDetails['quantity']).toBe(newAssetFormGroup.get('quantity').value);
      });
    });

    describe('getOtherAssetDetails', () => {
      it('should assign source, positionCode and quantity form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          source: new FormControl('Test source of OTH'),
          positionCode: new FormControl('ABCDEF'),
          quantity: new FormControl('')
        });

        component.getInternationalShareOrOtherAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['source']).toBe(newAssetFormGroup.get('source').value);
        expect(newAssetDetails['positionCode']).toEqual(newAssetFormGroup.get('positionCode').value);
        expect(newAssetDetails['quantity']).toEqual(newAssetFormGroup.get('quantity').value);
      });
    });

    describe('getManagedFundsAssetDetails', () => {
      it('should assign propertyType form control value to newAssetDetails', () => {
        const newAssetDetails = {
          ...DEFAULT_ADD_ASSET_PROPS
        };
        const newAssetFormGroup = new FormGroup({
          panoramaAssetDetails: new FormControl('Test panoramaAssetDetails of ls or mf'),
          isPanoramaAsset: new FormControl(false),
          assetId: new FormControl('123'),
          positionCode: new FormControl('Test code of ls or mf'),
          source: new FormControl('Test source of ls or mf'),
          quantity: new FormControl('123')
        });

        component.getManagedFundOrListedSecurityAssetDetails(newAssetFormGroup, newAssetDetails);
        expect(newAssetDetails['isPanoramaAsset']).toBe(newAssetFormGroup.get('isPanoramaAsset').value);
        expect(newAssetDetails['assetId']).toBe(newAssetFormGroup.get('assetId').value);
        expect(newAssetDetails['positionCode']).toBe(newAssetFormGroup.get('positionCode').value);
        expect(newAssetDetails['source']).toBe(newAssetFormGroup.get('source').value);
        expect(newAssetDetails['quantity']).toBe(newAssetFormGroup.get('quantity').value);
      });
    });

    describe('cancelAddAsset', () => {
      it('should rest form when cancelAddAsset get called', () => {
        spyOn(component.addExternalAssetsForm, 'reset');
        component.cancelAddAsset();

        expect(component.addExternalAssetsForm.reset).toHaveBeenCalled();
      });
    });

    describe('showOrHideButtons', () => {
      it('should set property showingButtons to boolean value', () => {
        component.showOrHideButtons(true);
        expect(component.showButtons).toEqual(true);
      });
    });

    describe('showMaxAssetAlertDialog', () => {
      it('should open Alert dialog with proper properties passed', () => {
        spyOn((component as any).copyMatrixPipe, 'transform').and.returnValue('Some text');
        (component as any).dialog = {
          open: jasmine.createSpy()
        };

        const calledWith = {
          ...DIALOG_CONFIG.ALT,
          autoFocus: true,
          disableClose: true,
          data: {
            headerText: MAX_ASSET_ALERT_HEADER,
            descriptionText: 'Some text',
            alertButton: MAX_ASSET_ALERT_BUTTON
          }
        };

        component.showMaxAssetAlertDialog();
        expect((component as any).dialog.open).toHaveBeenCalledWith(PanoAlertDialogComponent, calledWith);
        expect((component as any).copyMatrixPipe.transform).toHaveBeenCalledWith('Err.IP-1226');
      });
    });

    describe('ngOnDestroy()', () => {
      it('should unsubscribe all subscriptions', () => {
        spyOn((component as any).assetClassesSubscription, 'unsubscribe');
        component.ngOnDestroy();

        expect((component as any).assetClassesSubscription.unsubscribe).toHaveBeenCalled();
      });
    });
  });

  describe('view', () => {
    it('should show the form and controls and all the asset type forms should not be visible', () => {
      expect(fixture.debugElement.query(By.css('form'))).toBeTruthy();

      const elementAddAssetLabel = fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-label'));
      expect(elementAddAssetLabel).toBeTruthy();
      expect(elementAddAssetLabel.nativeElement.innerHTML.trim()).toBe('Add a new external asset');
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-select'))).toBeTruthy();

      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeNull();
    });

    it('should show the Cash asset details form only when cash got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.cash.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('should show the TD asset details form only when TD got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.td.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('should show the LS asset details form only when LS got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.ls.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('should show the ILS asset details form only when ILS got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.ils.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('should show the MF asset details form only when MF got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.mf.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('should show the MP asset details form only when MP got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.mp.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('should show the DP asset details form only when DP got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.dp.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeNull();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('should show the OTH asset details form only when OTH got selected and other asset types details should not be visible', () => {
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.oth.code
      });
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('pano-add-asset-cash'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-term-deposit'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-fund'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-direct-property'))).toBeNull();
      expect(fixture.debugElement.query(By.css('pano-add-asset-other'))).toBeTruthy();
      expect(fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button-container'))).toBeTruthy();
    });

    it('when any asset type selected, should contains Add button and Cancel button with its properties', () => {
      spyOn(component, 'cancelAddAsset');
      component.addAssetButton = ADD_ASSET_BUTTON;
      component.cancelAddAssetButton = CANCEL_ADD_ASSET_BUTTON;
      component.addExternalAssetsForm.patchValue({
        assetTypeCode: ASSET_TYPES.oth.code
      });
      fixture.detectChanges();
      const addAssetButton = fixture.debugElement.query(By.css('.js-test-pano-external-add-asset-type-button'));
      const cancelAddAssetButton = fixture.debugElement.query(By.css('.js-test-external-add-cancel-asset-type-button'));

      expect(addAssetButton).toBeTruthy();
      expect(addAssetButton.properties.config).toEqual(ADD_ASSET_BUTTON);

      expect(cancelAddAssetButton).toBeTruthy();
      expect(cancelAddAssetButton.properties.config).toEqual(CANCEL_ADD_ASSET_BUTTON);
      cancelAddAssetButton.nativeElement.dispatchEvent(new Event('btClick'));
      expect(component.cancelAddAsset).toHaveBeenCalled();
    });

    describe('child component pano-add-asset-cash', () => {
      beforeEach(() => {
        component.addExternalAssetsForm = new FormGroup({
          assetTypeCode: new FormControl(ASSET_TYPES.cash.code)
        });
        fixture.detectChanges();
      });

      it('should have the properties passed', () => {
        const panoAddAssetsCashComponent = fixture.debugElement.query(By.css('pano-add-asset-cash'));
        expect(panoAddAssetsCashComponent.nativeElement).toBeTruthy();

        expect(panoAddAssetsCashComponent.properties.addAssetForm).toEqual(component.addExternalAssetsForm);
      });
    });

    describe('child component pano-add-asset-term-deposit', () => {
      beforeEach(() => {
        component.addExternalAssetsForm = new FormGroup({
          assetTypeCode: new FormControl(ASSET_TYPES.td.code)
        });
        fixture.detectChanges();
      });

      it('should have the properties passed', () => {
        const panoAddAssetsTDComponent = fixture.debugElement.query(By.css('pano-add-asset-term-deposit'));
        expect(panoAddAssetsTDComponent.nativeElement).toBeTruthy();

        expect(panoAddAssetsTDComponent.properties.addAssetForm).toEqual(component.addExternalAssetsForm);
      });
    });

    describe('child component pano-add-asset-listed-security', () => {
      beforeEach(() => {
        component.addExternalAssetsForm = new FormGroup({
          assetTypeCode: new FormControl(ASSET_TYPES.ls.code)
        });
        component.selectedAssetClasses = TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'ls').assetClasses;
        fixture.detectChanges();
      });

      it('should have the properties passed and should call showOrHideButtons on event trigger', () => {
        spyOn(component, 'showOrHideButtons');
        const panoAddAssetsLSComponent = fixture.debugElement.query(By.css('pano-add-asset-listed-security'));

        expect(panoAddAssetsLSComponent.nativeElement).toBeTruthy();
        expect(panoAddAssetsLSComponent.properties.addAssetForm).toEqual(component.addExternalAssetsForm);
        expect(panoAddAssetsLSComponent.properties.assetClasses).toEqual(component.selectedAssetClasses);

        panoAddAssetsLSComponent.nativeElement.dispatchEvent(new Event('showButtons'));
        expect(component.showOrHideButtons).toHaveBeenCalled();
      });
    });

    describe('child component pano-add-asset-int-listed-security', () => {
      beforeEach(() => {
        component.addExternalAssetsForm = new FormGroup({
          assetTypeCode: new FormControl(ASSET_TYPES.ils.code)
        });
        component.selectedAssetClasses = TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'ils').assetClasses;
        fixture.detectChanges();
      });

      it('should have the properties passed', () => {
        const panoAddAssetsILSComponent = fixture.debugElement.query(By.css('pano-add-asset-int-listed-security'));
        expect(panoAddAssetsILSComponent.nativeElement).toBeTruthy();

        expect(panoAddAssetsILSComponent.properties.addAssetForm).toEqual(component.addExternalAssetsForm);
        expect(panoAddAssetsILSComponent.properties.assetClasses).toEqual(component.selectedAssetClasses);
      });
    });

    describe('child component pano-add-asset-direct-property-security', () => {
      beforeEach(() => {
        component.addExternalAssetsForm = new FormGroup({
          assetTypeCode: new FormControl(ASSET_TYPES.dp.code)
        });
        component.propertyTypes = TEST_DP_PROPERTY_TYPES;
        fixture.detectChanges();
      });

      it('should have the properties passed', () => {
        const panoAddAssetsDPComponent = fixture.debugElement.query(By.css('pano-add-asset-direct-property'));
        expect(panoAddAssetsDPComponent.nativeElement).toBeTruthy();

        expect(panoAddAssetsDPComponent.properties.addAssetForm).toEqual(component.addExternalAssetsForm);
        expect(panoAddAssetsDPComponent.properties.propertyTypes).toEqual(component.propertyTypes);
      });
    });

    describe('child component pano-add-asset-managed-portfolio', () => {
      beforeEach(() => {
        component.addExternalAssetsForm = new FormGroup({
          assetTypeCode: new FormControl(ASSET_TYPES.mp.code)
        });
        component.selectedAssetClasses = TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'mp').assetClasses;
        fixture.detectChanges();
      });

      it('should have the properties passed', () => {
        const panoAddAssetsILSComponent = fixture.debugElement.query(By.css('pano-add-asset-managed-portfolio'));
        expect(panoAddAssetsILSComponent.nativeElement).toBeTruthy();

        expect(panoAddAssetsILSComponent.properties.addAssetForm).toEqual(component.addExternalAssetsForm);
        expect(panoAddAssetsILSComponent.properties.assetClasses).toEqual(component.selectedAssetClasses);
      });
    });

    describe('child component pano-add-asset-managed-funds', () => {
      beforeEach(() => {
        component.addExternalAssetsForm = new FormGroup({
          assetTypeCode: new FormControl(ASSET_TYPES.mf.code)
        });
        component.selectedAssetClasses = TEST_ASSET_TYPES.find(x => x.assetTypeCode === 'mf').assetClasses;
        fixture.detectChanges();
      });

      it('should have the properties passed and should call showOrHideButtons on event trigger', () => {
        spyOn(component, 'showOrHideButtons');
        const panoAddAssetsMFComponent = fixture.debugElement.query(By.css('pano-add-asset-managed-fund'));

        expect(panoAddAssetsMFComponent.nativeElement).toBeTruthy();
        expect(panoAddAssetsMFComponent.properties.addAssetForm).toEqual(component.addExternalAssetsForm);
        expect(panoAddAssetsMFComponent.properties.assetClasses).toEqual(component.selectedAssetClasses);

        panoAddAssetsMFComponent.nativeElement.dispatchEvent(new Event('showButtons'));
        expect(component.showOrHideButtons).toHaveBeenCalled();
      });
    });
  });
});
