import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { DataModule, DataService } from '@bt/services/data';
import { UIRouter } from '@uirouter/core';
import { of } from 'rxjs';

import {
  GENERIC_OPTIONS,
  LEARN_ABOUT_INVESTMENTS_TILES_CONTENT_URL
} from './pano-learn-about-investments-tiles.constants';
import { Tile } from './pano-learn-about-investments-tiles.interface';
import { PanoLearnAboutInvestmentsTilesService } from './pano-learn-about-investments-tiles.service';

describe('PanoLearnAboutInvestmentsTileService', () => {
  let service: PanoLearnAboutInvestmentsTilesService;

  let dataService: DataService<any>;

  const successHandler: jasmine.Spy = jasmine.createSpy('successHandler');
  const errorHandler: jasmine.Spy = jasmine.createSpy('errorHandler');

  const mockUiRouter = {
    stateService: {
      go: jasmine.createSpy()
    }
  };

  const AEM_TILE: any = {
    bannerTitle: 'VANILLA',
    bannerText: 'VANILLARY',
    links: [{ title: 'ALL vanilla', path: '->>>keep going', openInNewWindow: true }]
  };

  const AEM_TILE_CONTENT: any = {
    tiles: [AEM_TILE]
  };

  const EMPTY_CONTENT: any = {
    tiles: []
  };

  const DECORATED_TILES: Tile[] = [
    {
      heading: 'VANILLA',
      description: 'VANILLARY',
      link: {
        link: '->>>keep going',
        icon: { name: 'icon-chevron-right-circle-solid' },
        isLinkExternal: true,
        openNewTab: true,
        type: 'flat',
        colourModifier: 'primary',
        iconPosition: 'left',
        isUnderlined: false,
        label: 'ALL vanilla'
      }
    }
  ];

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [DataModule, HttpClientTestingModule],
        providers: [PanoLearnAboutInvestmentsTilesService, { provide: UIRouter, useValue: mockUiRouter }]
      });
    })
  );

  beforeEach(() => {
    service = TestBed.inject(PanoLearnAboutInvestmentsTilesService);
    dataService = TestBed.inject(DataService);
  });

  afterEach(() => {
    successHandler.calls.reset();
    errorHandler.calls.reset();
  });

  beforeEach(() => {
    dataService.retrieve = jasmine.createSpy().and.returnValue(of(AEM_TILE_CONTENT));
  });

  describe('Service', () => {
    describe('getTileContent', () => {
      it('should call the data service to retrieve tiles', () => {
        service.getTileContent().subscribe(successHandler, errorHandler);
        expect(dataService.retrieve).toHaveBeenCalledWith(LEARN_ABOUT_INVESTMENTS_TILES_CONTENT_URL, GENERIC_OPTIONS);
        expect(successHandler).toHaveBeenCalledWith(DECORATED_TILES);
      });

      it('should use any provided url', () => {
        service.getTileContent('my-url').subscribe(successHandler, errorHandler);
        expect(dataService.retrieve).toHaveBeenCalledWith('my-url', GENERIC_OPTIONS);
      });

      it('should handle no tiles', () => {
        dataService.retrieve = jasmine.createSpy().and.returnValue(of(EMPTY_CONTENT));
        service.getTileContent().subscribe(successHandler, errorHandler);
        expect(dataService.retrieve).toHaveBeenCalledWith(LEARN_ABOUT_INVESTMENTS_TILES_CONTENT_URL, GENERIC_OPTIONS);
        expect(successHandler).toHaveBeenCalledWith([]);
      });
    });
  });
});
