import { Injectable } from '@angular/core';
import { Link } from '@bt/components/link';
import { DataService } from '@bt/services/data';
import { isDefined } from '@uirouter/angular';
import { get } from 'lodash-es';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  GENERIC_EXTERNAL_LINK,
  GENERIC_OPTIONS,
  LEARN_ABOUT_INVESTMENTS_TILES_CONTENT_URL
} from './pano-learn-about-investments-tiles.constants';
import { Tile } from './pano-learn-about-investments-tiles.interface';

@Injectable()
export class PanoLearnAboutInvestmentsTilesService {
  private cmsTextUrl: string = LEARN_ABOUT_INVESTMENTS_TILES_CONTENT_URL;
  constructor(private dataService: DataService<any>) {}

  getTileContent(contentUrl?: string): Observable<Tile[]> {
    return this.dataService.retrieve(contentUrl ? contentUrl : this.cmsTextUrl, GENERIC_OPTIONS).pipe(
      map(tiles => {
        return this.decorateTile(get(tiles, 'tiles'));
      })
    );
  }

  private decorateTile(tiles: any): Tile[] {
    const decoratedTiles: Tile[] = [];
    if (isDefined(tiles)) {
      for (const tile of tiles) {
        let tileLink: Link;
        tileLink = { ...GENERIC_EXTERNAL_LINK };
        const link = tile.links[0];
        tileLink.label = link.title;
        tileLink.link = link.path;
        decoratedTiles.push({ heading: tile.bannerTitle, description: tile.bannerText, link: tileLink });
      }
    }
    return decoratedTiles;
  }
}
